﻿-- Function: migrate_isd2fsd.f_etl_std_debug(timestamp with time zone, text, text, text, text, text, text)

-- DROP FUNCTION migrate_isd2fsd.f_etl_std_debug(timestamp with time zone, text, text, text, text, text, text);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_etl_std_debug(timestamp with time zone, text, text, text, text, text, text)
  RETURNS integer AS
$BODY$ 
    
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_etl_std_debug                                               */
/*      Author: Gene Belford                                                  */
/* Description: .                                                             */
/*        Date: 2016-02-10                                                    */
/* Source File: 133_f_etl_std_debug.sql                                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/* 2016-06-21             Gene Belford          Added unit test               */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

SELECT migrate_isd2fsd.f_etl_std_debug (
        CLOCK_TIMESTAMP(), 
        'etl_std_debug',  
        'test',
        'error_code',  
        'error_message', 
        'parameters',
        'ejb'
        ); 

SELECT * FROM migrate_isd2fsd.etl_std_debug;

*/

BEGIN 

    INSERT INTO migrate_isd2fsd.etl_std_debug (
        insert_date, process_name,  module_name,
        error_code,  error_message, parameters,
        insert_by
        )  
    VALUES ( 
        $1, 
        SUBSTRING($2, 1, 50), 
        SUBSTRING($3, 1, 50), 
        SUBSTRING($4, 1, 10),
        SUBSTRING($5, 1, 200),
        SUBSTRING($6, 1, 200),
        SUBSTRING($7, 1, 50)
        );
    
    RETURN 1;
    
--EXCEPTION

--    RETURN -1; 

END;
    
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
  
ALTER FUNCTION migrate_isd2fsd.f_etl_std_debug(timestamp with time zone, text, text, text, text, text, text)
  OWNER TO enterprisedb;
