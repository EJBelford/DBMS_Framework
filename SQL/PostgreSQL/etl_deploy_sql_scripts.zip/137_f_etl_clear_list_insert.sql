﻿-- DROP FUNCTION IF EXISTS migrate_isd2fsd.f_etl_clear_list_insert(uuid, text, text);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_etl_clear_list_insert(entityId uuid, processName text, processModule text) 
    RETURNS INT
    
AS 
    
$BODY$ 
    
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_etl_clear_list_insert()                                     */
/*      Author: Gene Belford                                                  */
/* Description: This function returns the version of PostgreSQL installed     */
/*              as an integer value.  This allows the developer program for   */
/*              features not available in the current installed version, but  */
/*              are available newer releases.                                 */
/*              This function was adapted from the following discusion thread */
/* http://postgresql.1045698.n5.nabble.com/Version-Number-Function-td1992392.html */
/*        Date: 2016-06-22                                                    */
/* Source File: 137_f_etl_clear_list_insert.sql                               */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-06-21             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

SELECT migrate_isd2fsd.f_etl_clear_list_insert (
    '000000007158466899372c8ab9fe0227', 
    'f_etl_clear_list_insert', 
    'test'
    );

SELECT * 
FROM migrate_isd2fsd.etl_clear_list 
ORDER BY rec_id DESC; 

*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DECLARE 

f_return                       INTEGER; 

v_null                         INTEGER      = NULL; 

v_rec_id                       INTEGER;
v_rec_uuid                     UUID;
v_process_start                TIMESTAMP WITH TIME ZONE;

vrow_epl                       migrate_isd2fsd.etl_process_log%ROWTYPE; 

vrow_esd                       migrate_isd2fsd.etl_std_debug%ROWTYPE; 
--    insert_date     TIMESTAMP      WITH TIME ZONE,
--    process_name    VARCHAR(50)
--    module_name     VARCHAR(50)
--    error_code      VARCHAR(10)
--    error_message   VARCHAR(200) 
--    parameters      VARCHAR(200)
--    insert_by       VARCHAR(50)

v_num_rows                     INTEGER;

v_debug                        INTEGER      = 0;  -- 0 = Off  1 = On
    
BEGIN 
--    RAISE NOTICE 'v_debug: %', v_debug;

    v_process_start            = CLOCK_TIMESTAMP();

    vrow_esd.process_name      = 'Unit Test';
    vrow_esd.module_name       = 'etl_clear_list_insert'; 
    vrow_esd.parameters        = NULL;

    vrow_epl.batch_id          = NULL;
    vrow_epl.process_id        = 2; 
    vrow_epl.process_status    = NULL; 
    vrow_epl.process_step      = 0;
    vrow_epl.process_start     = v_process_start; 
    vrow_epl.process_message   = NULL;
    
    IF v_debug > 0 THEN 
        RAISE NOTICE 'process_step: %', vrow_epl.process_step; 
    END IF; 
    
    INSERT 
    INTO migrate_isd2fsd.etl_clear_list ( 
        object_uuid,
        object_created_timestamp,
        process_name,
        process_module
        )
    VALUES (
        entityId, 
        CLOCK_TIMESTAMP(),
        processName,
        processModule
        );

    RETURN 1;
                
EXCEPTION
    WHEN others THEN 
        RAISE NOTICE 'EXCEPTION';
        
        GET STACKED DIAGNOSTICS vrow_esd.error_code    = RETURNED_SQLSTATE;
        GET STACKED DIAGNOSTICS vrow_esd.error_message = MESSAGE_TEXT;
        
        SELECT migrate_isd2fsd.f_etl_std_debug (
            CLOCK_TIMESTAMP(),  
            SUBSTRING(vrow_esd.module_name, 1, 50),  
            SUBSTRING(vrow_esd.process_name, 1, 50), 
            SUBSTRING(vrow_esd.error_code, 1, 10),  
            SUBSTRING(vrow_esd.error_message, 1, 200), 
            SUBSTRING(vrow_esd.parameters, 1, 200),
            SUBSTRING(USER, 1, 50)
            ) INTO f_return;  
        
        RETURN -1;

END;
    
$BODY$
LANGUAGE plpgsql VOLATILE 
COST 100;


COMMENT ON FUNCTION migrate_isd2fsd.f_etl_clear_list_insert(uuid, text, text) 
IS 'f_etl_clear_list_insert() - This function .';


ALTER FUNCTION migrate_isd2fsd.f_etl_clear_list_insert(uuid, text, text) 
    OWNER TO enterprisedb; 
    
