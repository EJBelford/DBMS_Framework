﻿-- Function: migrate_isd_2_fsd()

-- DROP FUNCTION migrate_isd2fsd.migrate_isd_2_fsd();

CREATE OR REPLACE FUNCTION migrate_isd2fsd.migrate_isd_2_fsd()
  RETURNS void AS
$BODY$

/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: migrate_isd_2_fsd                                             */
/*      Author: Gene Belford                                                  */
/* Description: Framework to hold ISD to FSD migration objects.               */
/*        Date: 2016-02-10                                                    */
/* Source File: 135_migrate_isd_2_fsd.sql                                         */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

DELETE 
FROM migrate_isd2fsd.etl_process_log 
WHERE process_start < (CLOCK_TIMESTAMP() - INTERVAL '1 DAY');

SELECT migrate_isd2fsd.migrate_isd_2_fsd();

SELECT * 
FROM migrate_isd2fsd.etl_process_log 
ORDER BY process_start DESC;

*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DECLARE

f_return                       INTEGER; 

vrow_epl                       migrate_isd2fsd.etl_process_log%ROWTYPE; 

vrow_esd                       migrate_isd2fsd.etl_std_debug%ROWTYPE; 
--    insert_date     TIMESTAMP      WITH TIME ZONE,
--    process_name    VARCHAR(50)
--    module_name     VARCHAR(50)
--    error_code      VARCHAR(10)
--    error_message   VARCHAR(200) 
--    parameters      VARCHAR(200)
--    insert_by       VARCHAR(50)

p_isdtable text;
p_isdrecordidentifier text;
p_isdfilename text;
p_isdfiletitle text;
p_isdfilepath text;
p_isdfileurl text;
p_isdfileexists boolean = false;
p_migratedflag boolean  = false;
p_migrateddate timestamp with time zone;
p_migrationmethod text;
p_migrationstatus character varying(2);
--p_migrationstatus character varying(5);
p_migrationcomments text;
p_fsdobject text;
p_fsdobjectuuid uuid;
p_fsdfilename text;
p_fsdfilepath text;
p_fsdfileurl text;

v_strt_time                    TEXT;
v_stop_time                    TEXT;
v_recId                        INT;
v_rec_uuid                     UUID;
v_err_msg                      VARCHAR(200);
v_stmt                         TEXT;
v_result                       TEXT;

v_version                      INT := NULL;
v_process_start                TIMESTAMP WITH TIME ZONE = CLOCK_TIMESTAMP();

v_debug                        INT := 0;

BEGIN 
    vrow_esd.process_name = 'migrate_isd_2_fsd';
    vrow_esd.module_name  = '';

    SELECT process_debug,          process_id 
    INTO         v_debug, vrow_epl.process_id 
    FROM   migrate_isd2fsd.etl_process_ref 
    WHERE  UPPER(process_name) = UPPER(vrow_esd.process_name);

    IF v_debug > 0 THEN 
        RAISE NOTICE 'Hello, world % calling! - %', vrow_esd.process_name, v_process_start; 
        RAISE NOTICE 'debug:      %', v_debug; 
        RAISE NOTICE 'process_id: %', vrow_epl.process_id; 
    END IF; 

    SELECT migrate_isd2fsd.f_pg_version_num() 
    INTO v_version;

    v_strt_time := CLOCK_TIMESTAMP()::text;
    v_stmt := 'POSTGRES migrate_isd_2_fsd start: ' || v_process_start;
    
    RAISE LOG    '%', v_stmt;
    IF v_debug > 0 THEN 
        RAISE NOTICE '%', v_stmt; 
    END IF;

    SELECT migrate_isd2fsd.f_etl_process_log_updt(
        'S', v_recId, v_rec_uuid, 0, vrow_epl.process_id, 0, 0, v_process_start, 
        NULL, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 
        '', 'migrate_isd_2_fsd started', ''
        ) INTO v_recId;

    SELECT migrate_isd2fsd.f_etl_track_list_insert() 
    INTO f_return;

    v_stop_time := clock_timestamp()::text;
    v_stmt := 'POSTGRES migrate_isd_2_fsd start: ' || v_strt_time || ' stop: ' || v_stop_time;

    RAISE LOG    '%', v_stmt;
    IF v_debug > 0 THEN 
        RAISE NOTICE '%', v_stmt; 
    END IF;

    SELECT migrate_isd2fsd.f_etl_process_log_updt(
        'E', 
        v_recId, v_rec_uuid, 
        0, 0, 0, 0, 
        CLOCK_TIMESTAMP(), 
        NULL, NULL, NULL, 
        '', 
        0, 0, 0, 0, 0, 0, 0, 0, 
        '', 'migrate_isd_2_fsd stopped', ''
        ) INTO v_recId; 

EXCEPTION
    WHEN OTHERS THEN
--        GET STACKED DIAGNOSTICS vrow_osd.error_code = RETURNED_SQLSTATE;
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT;

        RAISE NOTICE    'Error Message: %', v_err_msg ;
        RAISE EXCEPTION 'Error Message: %', v_err_msg ;
END 
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

ALTER FUNCTION migrate_isd2fsd.migrate_isd_2_fsd()
  OWNER TO enterprisedb;
