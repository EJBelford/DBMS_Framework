﻿/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_process_ref                                             */
/*      Author: Gene Belford                                                  */
/* Description: Contains the reference and operating information for the      */
/*              OMEGA modules.                                                */
/*        Date: 2016-02-10                                                    */
/* Source File: 011_etl_process_ref.sql                                         */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

--DROP TABLE IF EXISTS migrate_isd2fsd.etl_process_ref;

CREATE TABLE migrate_isd2fsd.etl_process_ref 
(
rec_id                      INTEGER      NOT NULL DEFAULT nextval('migrate_isd2fsd.etl_process_ref_seq'::regclass),
--
rec_uuid                    UUID         UNIQUE NOT NULL DEFAULT uuid_generate_v4(), 
--
process_id                  VARCHAR(50)  UNIQUE NOT NULL,
process_name                VARCHAR(50)  NOT NULL, 
--
process_run_ctrl            INTEGER,
process_run_ctrl_override   BOOLEAN      DEFAULT 'FALSE',
process_debug               INTEGER      DEFAULT 0,
--
active_flag                 BOOLEAN      DEFAULT 'TRUE',
active_date                 DATE         DEFAULT '01-JAN-1900',
inactive_date               DATE         DEFAULT '31-DEC-2099',   
--
status                      CHAR(1)      NOT NULL DEFAULT 'C', 
status_by                   VARCHAR(50)  DEFAULT USER,
status_date                 TIMESTAMP    WITH TIME ZONE NOT NULL DEFAULT NOW(), 
--
insert_date                 TIMESTAMP    WITH TIME ZONE NOT NULL DEFAULT NOW(),
insert_by                   VARCHAR(50)  DEFAULT USER,
update_date                 TIMESTAMP    WITH TIME ZONE,
update_by                   VARCHAR(50),
delete_flag                 BOOLEAN      DEFAULT 'FALSE',   
delete_date                 TIMESTAMP    WITH TIME ZONE,
delete_by                   VARCHAR(50),
hidden_flag                 BOOLEAN      DEFAULT 'FALSE',   
hidden_date                 TIMESTAMP    WITH TIME ZONE,
hidden_by                   VARCHAR(50),
--
PRIMARY KEY (rec_id) 
)
WITH (
    OIDS = FALSE 
    );

COMMENT ON TABLE migrate_isd2fsd.etl_process_ref 
IS 'etl_process_ref - Contains the reference and operating information for the OMEGA modules';

COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.rec_id 
IS 'rec_id - The unquie durable single field key assigned to the record.';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.process_id 
IS 'process_id - ';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.process_name 
IS 'process_name - ';

COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.process_run_ctrl 
IS 'process_run_ctrl - ';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.process_run_ctrl_override 
IS 'process_run_ctrl_override - ';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.process_debug 
IS 'process_debug - Allows for more detailed messaging.';
 
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.active_flag 
IS 'active_flag - Flag indicating if the record can be used';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.active_date 
IS 'active_date - Additional control for the active_flag indicating when the record became active.';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.inactive_date 
IS 'inactive_date - Additional control for the active_flag indicating when the record became inactive.';  

COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.status 
IS 'status - A 1 character code for the statsu of the record, (Current, Duplicate, Error, Historical, Logical, New, Processing, Questionable, Ready to process, Waiting)'; 
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.status_by 
IS 'status_by - The user who last changed the status of the record';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.status_date 
IS 'status_date - The date when the record status was last changed';

COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.insert_date 
IS 'insert_date - The date the record was created';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.insert_by 
IS 'insert_by - The user/fuction that created the record';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.update_date 
IS 'update_date - The date the record was last modified';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.update_by 
IS 'update_by - The user/function that last updated the record';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.delete_flag 
IS 'delete_flag - A logical flag used to ignore the record as if it was deleted';   
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.delete_date 
IS 'delete_date - The date the logical delete flag was set';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.delete_by 
IS 'delete_by - The user/function that set the logical delete flag';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.hidden_flag 
IS 'hidden_flag - A flag used to hide/exclude the record from pick lists';  
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.hidden_date 
IS 'hidden_date - The date the hidden flag was set';
COMMENT ON COLUMN migrate_isd2fsd.etl_process_ref.hidden_by 
IS 'hidden_by - The user/function that set the hidden flag';

