﻿-- DROP PROCEDURE migrate_isd2fsd.etl_process_log_updt(character, integer, uuid, integer, integer, integer, integer, timestamp with time zone, timestamp with time zone, character, timestamp with time zone, character, integer, integer, integer, integer, integer, integer, integer, integer, character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_etl_process_log_updt 
    (
    f_op                      CHARACTER, 
    v_recId                   migrate_isd2fsd.etl_process_log.rec_id%TYPE, 
    v_recUuid                 migrate_isd2fsd.etl_process_log.rec_uuid%TYPE, 
    v_batchId                 migrate_isd2fsd.etl_process_log.batch_id%TYPE,
    v_processId               migrate_isd2fsd.etl_process_log.process_id%TYPE,
    v_processModule           migrate_isd2fsd.etl_process_log.process_module%TYPE      = NULL,
    v_processStep             migrate_isd2fsd.etl_process_log.process_step%TYPE        = NULL,
    v_processStart            migrate_isd2fsd.etl_process_log.process_start%TYPE       = NULL,
    v_processStop             migrate_isd2fsd.etl_process_log.process_stop%TYPE        = NULL,
    v_processStatus           migrate_isd2fsd.etl_process_log.process_status%TYPE      = NULL,
    v_processStatusDate       migrate_isd2fsd.etl_process_log.process_status_date%TYPE = NULL,
    v_sqlErrorCode            migrate_isd2fsd.etl_process_log.sql_error_code%TYPE      = NULL,
    v_recReadInt              migrate_isd2fsd.etl_process_log.rec_read%TYPE            = NULL,
    v_recValidInt             migrate_isd2fsd.etl_process_log.rec_valid%TYPE           = NULL,
    v_recLoadInt              migrate_isd2fsd.etl_process_log.rec_load%TYPE            = NULL,
    v_recInsertedInt          migrate_isd2fsd.etl_process_log.rec_insert%TYPE          = NULL,
    v_recMergedInt            migrate_isd2fsd.etl_process_log.rec_merge%TYPE           = NULL,
    v_recSelectedInt          migrate_isd2fsd.etl_process_log.rec_select%TYPE          = NULL,
    v_recUpdatedInt           migrate_isd2fsd.etl_process_log.rec_update%TYPE          = NULL,
    v_recDeletedInt           migrate_isd2fsd.etl_process_log.rec_delete%TYPE          = NULL,
    v_processRunId            migrate_isd2fsd.etl_process_log.process_run_id%TYPE      = '',
    v_processMessage          migrate_isd2fsd.etl_process_log.process_message%TYPE     = '',
    v_processMessageErr       migrate_isd2fsd.etl_process_log.process_message_err%TYPE = ''
    ) 
RETURNS INTEGER

AS 
$BODY$
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_etl_process_log_updt                                        */
/*      Author: Gene Belford                                                  */
/* Description:                                                               */
/*        Date: 2016-02-10                                                    */
/* Source File: 132_f_etl_process_log_updt.sql                                    */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/* 2016-02-17             Gene Belford          Updated                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

DECLARE

v_recId                        INT;

BEGIN
    v_recId    = NULL;

    SELECT migrate_isd2fsd.f_etl_process_log_updt(
        'S', 
        NULL, NULL, 
        0, 0, 0, 0, 
        CLOCK_TIMESTAMP(), 
        NULL, NULL, NULL, 
        '', 
        0, 0, 0, 0, 0, 0, 0, 0, 
        '', 'Unit Test Run', ''
        ) INTO v_recId;

    COMMIT;

    SELECT pg_sleep (1.1); 

    RAISE NOTICE 'v_recId: %', v_recId; 
END;

SELECT migrate_isd2fsd.f_etl_process_log_updt('U');

SELECT pg_sleep (1.1); 

SELECT migrate_isd2fsd.f_etl_process_log_updt('E');

SELECT rec_id, batch_id, process_id, process_start, process_stop, 
    process_status_date 
FROM migrate_isd2fsd.etl_process_log ORDER BY rec_id DESC; 

*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DECLARE 

f_return                       INTEGER; 

v_null                         INTEGER; 

v_rec_uuid                     UUID;

v_op                           CHAR;

vrow_epl                       migrate_isd2fsd.etl_process_log%ROWTYPE; 
--    rec_id               INTEGER - The unquie durable single field key assigned to the record.
--    rec_uuid             UUID    - rec_uuid - Stores the Universally Unique IDentifier (UUID) as defined by RFC 4122, ISO/IEC 9834-8:2005.
--    batch_id             INTEGER - The idebtifier that group processes together as a logical unit.
--    process_id           INTEGER - The FK into process reference table that provides the description of the process being run.
--    process_module       INTEGER - Identities the module within a give mutli-step process
--    process_step         INTEGER - Identities the tep within a give givn multi-step orocess module
--    process_start        TIMESTAMP WITH TIME ZONE - When the task started.
--    process_stop         TIMESTAMP WITH TIME ZONE - When the task ended.
--    process_status       CHARACTER(1) - A 1 character code for the statsu of the record, (Current, Error, Historical, New, Processing, Waiting)
--    process_status_date  TIMESTAMP WITH TIME ZONE - When the process status was last updated.
--    sql_error_code       CHARACTER(5), - Return status of the SQL statment executed.
--    rec_read             INTEGER, - Number of records read by the process.
--    rec_valid            INTEGER, - Number of records found to be valid by the process.
--    rec_load             INTEGER, - Number of records loaded by the process.
--    rec_insert           INTEGER, - Number of records inserted by the process.
--    rec_merge            INTEGER, - Number of records merged by the process.
--    rec_select           INTEGER, - Number of records selected by the process.
--    rec_update           INTEGER, - Number of records updated by the process.
--    rec_delete           INTEGER, - Number of records deleted by the process.
--    process_run_id       CHARACTER VARYING(50) - The user id that this process was run under.
--    process_message      CHARACTER VARYING(254) - Proves information regarding the process state.
--    process_message_err  CHARACTER VARYING(254) - Proves information regarding the error that occured.

vrow_esd                       migrate_isd2fsd.etl_std_debug%ROWTYPE; 
--    insert_date     TIMESTAMP WITH TIME ZONE,
--    process_name    VARCHAR(50)
--    module_name     VARCHAR(50)
--    error_code      VARCHAR(10)
--    error_message   VARCHAR(200)
--    parameters      VARCHAR(200)
--    insert_by       VARCHAR(50)

v_num_rows                     INTEGER;

v_process_id                   INT;
v_version                      INT := NULL;

v_debug                        INTEGER      = 0;  -- 0 = Off  1 = On 
--                             (Being set by lookup in 'etl_process_ref') 
BEGIN 
    SELECT process_debug,   process_id 
    INTO         v_debug, v_process_id 
    FROM   migrate_isd2fsd.etl_process_ref 
    WHERE  UPPER(process_name) = UPPER('f_etl_process_log_updt');

    SELECT migrate_isd2fsd.f_pg_version_num() 
    INTO v_version;

    f_return                   = -999;

    vrow_esd.process_name      = 'Unit Test';
    vrow_esd.module_name       = 'f_etl_process_log_updt'; 
    vrow_esd.parameters        = NULL;

    vrow_epl.batch_id          = NULL;
    vrow_epl.process_status    = NULL; 
    vrow_epl.process_step      = 0;
    vrow_epl.process_start     = CLOCK_TIMESTAMP(); 
    vrow_epl.process_message   = NULL;
    
    v_rec_uuid                 = NULL;
    v_num_rows                 = NULL;
    v_op                       = UPPER(f_op); 

    IF v_debug > 0 THEN 
        RAISE NOTICE 'debug level:  %', v_debug; 
        RAISE NOTICE 'process_step: %', vrow_epl.process_step; 
    END IF; 

    IF (f_op='S') THEN 
        
        vrow_epl.process_step = 10;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
        END IF; 

        INSERT 
        INTO migrate_isd2fsd.etl_process_log (
            rec_uuid,
            batch_id, process_id, process_status, process_start, process_message
            )
        VALUES (
            uuid_generate_v4(), 
            0, v_processid, 'W', vrow_epl.process_start, v_processMessage
            );
            
        vrow_epl.process_step = 11;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
            RAISE NOTICE 'process_start: %', vrow_epl.process_start;
        END IF; 
    
        SELECT rec_id 
        INTO   f_return 
        FROM   migrate_isd2fsd.etl_process_log 
        WHERE  process_start = vrow_epl.process_start; 

        GET DIAGNOSTICS vrow_epl.rec_update = ROW_COUNT;

        UPDATE migrate_isd2fsd.etl_process_log 
        SET rec_update  = vrow_epl.rec_update 
        WHERE rec_id = f_return; 

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
            RAISE NOTICE 'return: %', f_return;
        END IF; 

    ELSIF (f_op='U') THEN 
        
        vrow_epl.process_step = 20;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
        END IF; 
    
        IF FOUND THEN 
            GET DIAGNOSTICS v_num_rows = ROW_COUNT;
            RAISE NOTICE 'Number of rows effected is: %', v_num_rows;
        END IF;
        
        UPDATE migrate_isd2fsd.etl_process_log 
        SET process_status_date = CLOCK_TIMESTAMP(), 
            process_status   = 'P', 
            process_message  = v_processMessage
        WHERE rec_id = v_recId; 
    
        GET DIAGNOSTICS vrow_epl.rec_update = ROW_COUNT;

        UPDATE migrate_isd2fsd.etl_process_log 
        SET rec_update  = vrow_epl.rec_update 
        WHERE rec_id = v_recId; 

        f_return = vrow_epl.process_step;
    
    ELSIF (f_op='E') THEN 
        
        vrow_epl.process_step = 30;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
        END IF; 
    
        UPDATE migrate_isd2fsd.etl_process_log 
        SET process_stop     = CLOCK_TIMESTAMP(), 
            process_status   = 'E', 
            rec_update       = v_recUpdatedInt, 
            process_message  = v_processMessage 
        WHERE rec_id = v_recId; 

        GET DIAGNOSTICS vrow_epl.rec_update = ROW_COUNT;

        UPDATE migrate_isd2fsd.etl_process_log 
        SET rec_update  = rec_update + vrow_epl.rec_update 
        WHERE rec_id = v_recId; 

        f_return = vrow_epl.process_step;
    
    ELSIF (f_op='D') THEN 
        
        vrow_epl.process_step = 40;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'process_step: %', vrow_epl.process_step;
        END IF; 
    
        DELETE 
        FROM migrate_isd2fsd.etl_process_log 
        WHERE rec_id = v_recId; 
    
        GET DIAGNOSTICS vrow_epl.rec_update = ROW_COUNT;

        UPDATE migrate_isd2fsd.etl_process_log 
        SET rec_update  = vrow_epl.rec_update 
        WHERE rec_id = v_recId; 

        f_return = vrow_epl.process_step;
    
    END IF;
    
    vrow_epl.process_step = 999;

    IF v_debug > 0 THEN 
        RAISE NOTICE 'process_step: %', vrow_epl.process_step;
        RAISE NOTICE 'return: % ', f_return;
    END IF; 

    RETURN f_return;
    
EXCEPTION
    WHEN others THEN 
        RAISE NOTICE 'EXCEPTION';
        
        GET STACKED DIAGNOSTICS vrow_esd.error_code = RETURNED_SQLSTATE;
        GET STACKED DIAGNOSTICS vrow_esd.error_message = MESSAGE_TEXT;
        
        SELECT migrate_isd2fsd.f_etl_std_debug (
            CLOCK_TIMESTAMP(), 
            vrow_esd.module_name,  
            vrow_epl.process_id,
            vrow_esd.error_code,  
            vrow_esd.error_message, 
            vrow_esd.parameters,
            USER
            ) AS f_return;

        RETURN -1;
    
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

ALTER FUNCTION migrate_isd2fsd.f_etl_process_log_updt(character, integer, uuid, integer, integer, integer, integer, timestamp with time zone, timestamp with time zone, character, timestamp with time zone, character, integer, integer, integer, integer, integer, integer, integer, integer, character varying, character varying, character varying)
  OWNER TO enterprisedb;


/* 

INSERT 
INTO migrate_isd2fsd.etl_process_ref (
    rec_uuid, 
    process_id, process_name, status
    )
VALUES (
    '00000000-0000-0000-0000-000100000001', 
--    uuid_generate_v4(),   
    1, 'f_etl_process_log_upd', 'C'
    );

*/