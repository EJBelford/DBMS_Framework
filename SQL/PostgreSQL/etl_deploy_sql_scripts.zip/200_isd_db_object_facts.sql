﻿/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: OMEGA_DBMS_Object_Facts_seq                                   */
/*      Author: Gene Belford                                                  */
/* Description: Creates a sequence number for the table that is assigned      */
/*              to the rec_id each new record is created.                     */
/*        Date: 2015-05-06                                                    */
/* Source File: OMEGA_DBMS_Object_Facts_seq.sql                               */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-06             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DROP SEQUENCE IF EXISTS migrate_isd2fsd.isd_db_object_factss_seq;

CREATE SEQUENCE migrate_isd2fsd.isd_db_object_facts_seq 
    INCREMENT   1
    MINVALUE    1
    MAXVALUE    9223372036854775807
    START       1
    CACHE       1;
    
ALTER TABLE migrate_isd2fsd.isd_db_object_facts_seq 
    OWNER TO enterprisedb; 

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: OMEGA_DBMS_Object_Facts                                       */
/*      Author: Gene Belford                                                  */
/* Description: Holds the record count for the objects in the system.         */
/*        Date: 2015-05-06                                                    */
/* Source File: 200_isd_db_object_facts.sql                                   */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-06             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DROP TABLE IF EXISTS migrate_isd2fsd.isd_db_object_facts;

CREATE TABLE migrate_isd2fsd.isd_db_object_facts 
(
rec_id                INTEGER      NOT NULL DEFAULT nextval('isd_db_object_facts_seq'::regclass),
--
row_cnt_date          TIMESTAMP    WITH TIME ZONE NOT NULL DEFAULT CLOCK_TIMESTAMP(), 
schemaname            VARCHAR(50)  NOT NULL,
relname               VARCHAR(50)  NOT NULL,
indexrelname          VARCHAR, 
row_cnt               BIGINT, 
--
PRIMARY KEY (rec_id) 
)
WITH (
    OIDS = FALSE 
    );


ALTER TABLE migrate_isd2fsd.isd_db_object_facts 
    OWNER TO enterprisedb; 


COMMENT ON TABLE migrate_isd2fsd.isd_db_object_facts 
IS 'isd_db_object_facts - Holds the record count for the objects in the system. ';

COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.rec_id 
IS 'rec_id - The unquie durable single field key assigned to the record.';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.row_cnt_date 
IS 'row_cnt_date - '; 
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.schemaname 
IS 'schemaname - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.relname 
IS 'relname - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.relname 
IS 'relname - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.row_cnt 
IS 'row_cnt - ';
    
SELECT pc.relname, pd.description, pd.objoid, pd.classoid, pd.objsubid
  --, pd.* 
FROM pg_description pd 
JOIN pg_class pc ON pd.objoid = pc.oid 
JOIN pg_namespace pn ON pc.relnamespace = pn.oid 
WHERE pc.relname = LOWER('OMEGA_DBMS_Object_Facts') 
    AND pn.nspname = 'public';

SELECT pd.* FROM pg_description pd WHERE pd.objoid = 1259;


/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

ALTER TABLE OMEGA_DBMS_Object_Facts 
    DROP CONSTRAINT OMEGA_DBMS_Object_Facts_status; 

ALTER TABLE OMEGA_DBMS_Object_Facts 
   ADD CONSTRAINT OMEGA_DBMS_Object_Facts_status CHECK (status IN ('C', 'D', 'E', 'H', 'L', 'N', 'P', 'Q', 'R', 'W')); 
     

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

INSERT 
INTO OMEGA_DBMS_Object_Facts (
    rec_uuid, 
    OMEGA_DBMS_Object_Facts_nm, OMEGA_DBMS_Object_Facts_desc, status
    )
VALUES (
    '00000000-0000-0000-0000-000000000001', 
--    uuid_generate_v4(), 
    'test_' || NOW(), 'desc', 'C'
    );
    
SELECT a.* 
FROM   OMEGA_DBMS_Object_Facts a 
ORDER BY rec_id DESC; 


/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Below this section is optional.  If you don't need to have an audit        */
/* trail remove it from the  template.                                        */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/


/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: OMEGA_DBMS_Object_Facts_audit                                             */
/*      Author: Gene Belford                                                      */
/* Description: Creates an audit table for OMEGA_DBMS_Object_Facts that tracks changes    */
/*              to the parent table as they are made.                         */
/*        Date: 2015-05-06                                                  */
/* Source File: OMEGA_DBMS_Object_Facts_audit.sql                                         */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-06           Gene Belford           Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DROP TABLE IF EXISTS OMEGA_DBMS_Object_Facts_audit;

CREATE TABLE OMEGA_DBMS_Object_Facts_audit 
(
rec_id          INTEGER      NOT NULL,
--
cmd             CHAR(1)      NOT NULL,
update_date     TIMESTAMP    WITH TIME ZONE NOT NULL,
update_by       VARCHAR(50),
--
n_OMEGA_DBMS_Object_Facts_nm   VARCHAR(50),
o_OMEGA_DBMS_Object_Facts_nm   VARCHAR(50),
n_OMEGA_DBMS_Object_Facts_desc   VARCHAR(50),
o_OMEGA_DBMS_Object_Facts_desc   VARCHAR(50),
--
PRIMARY KEY (rec_id, cmd, update_date) 
)
WITH (
    OIDS = FALSE 
    );


ALTER TABLE OMEGA_DBMS_Object_Facts_audit 
    OWNER TO enterprisedb; 


/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_OMEGA_DBMS_Object_Facts_audit                                           */
/*      Author: Gene Belford                                                      */
/* Description:                                                               */
/*        Date: 2015-05-06                                                  */
/* Source File: f_OMEGA_DBMS_Object_Facts_audit.sql                                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-06            Gene Belford           Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*


*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DROP FUNCTION IF EXISTS f_OMEGA_DBMS_Object_Facts_audit;

CREATE OR REPLACE FUNCTION f_OMEGA_DBMS_Object_Facts_audit() 
    RETURNS TRIGGER AS 
    
$BODY$ 
    
BEGIN 

    IF (TG_OP='INSERT') THEN 
        
        INSERT INTO OMEGA_DBMS_Object_Facts_audit 
            (rec_id, cmd, update_date, update_by) --, o_OMEGA_DBMS_Object_Facts_nm)  
        SELECT NEW.rec_id, 'I', NOW(), USER; --, OLD.OMEGA_DBMS_Object_Facts_nm;
    
    ELSIF (TG_OP='UPDATE') THEN 
        
        INSERT INTO OMEGA_DBMS_Object_Facts_audit 
            (rec_id, cmd, update_date, update_by, n_OMEGA_DBMS_Object_Facts_nm, o_OMEGA_DBMS_Object_Facts_nm)  
        SELECT NEW.rec_id, 'U', NOW(), USER, NEW.OMEGA_DBMS_Object_Facts_nm, OLD.OMEGA_DBMS_Object_Facts_nm;
    
    ELSIF (TG_OP='DELETE') THEN 
        
        INSERT INTO OMEGA_DBMS_Object_Facts_audit 
            (rec_id, cmd, update_date, update_by, o_OMEGA_DBMS_Object_Facts_nm)  
        SELECT OLD.rec_id, 'D', NOW(), USER, OLD.OMEGA_DBMS_Object_Facts_nm;
    
    END IF;
    
    RETURN NULL;

END;
    
$BODY$
LANGUAGE plpgsql VOLATILE 
COST 100;

ALTER FUNCTION f_OMEGA_DBMS_Object_Facts_audit() 
    OWNER TO enterprisedb; 
    
    
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: OMEGA_DBMS_Object_Facts                                                   */
/*      Author: Gene Belford                                                      */
/* Description:                                                               */
/*        Date: 2015-05-06                                                  */
/* Source File:                                                               */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-06           Gene Belford           Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DROP TRIGGER IF EXISTS t_OMEGA_DBMS_Object_Facts_audit ON OMEGA_DBMS_Object_Facts;

CREATE TRIGGER t_OMEGA_DBMS_Object_Facts_audit 
    AFTER INSERT OR UPDATE OR DELETE 
    ON OMEGA_DBMS_Object_Facts 
    FOR EACH ROW 
    EXECUTE PROCEDURE f_OMEGA_DBMS_Object_Facts_audit(); 
