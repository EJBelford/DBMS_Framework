﻿-- Function: migrate_isd2fsd.f_etl_track_list_insert()

-- DROP FUNCTION migrate_isd2fsd.f_etl_track_list_insert();

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_etl_track_list_insert()
  RETURNS integer AS
$BODY$
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_etl_track_list_insert                                       */
/*      Author: Gene Belford                                                  */
/* Description: .                            */
/*        Date: 2016-01-27                                                    */
/* Source File: 134_etl_track_list_insert.sql                                     */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-01-27             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

DECLARE 

  f_return int;

BEGIN 

--    SELECT set_config ('log_error_verbosity', 'TERSE', false);

--    SELECT current_setting ('log_error_verbosity');

    SELECT migrate_isd2fsd.f_etl_track_list_insert() INTO f_return;

END;

*/

DECLARE 

r                              migrate_isd2fsd.etl_metacard_tracking_list%rowtype;

f_return                       INTEGER; 

v_null                         INTEGER                  = NULL; 

v_rec_id                       INTEGER;
v_rec_uuid                     UUID;
v_pg_version                   INTEGER;
v_process_start                TIMESTAMP WITH TIME ZONE = CLOCK_TIMESTAMP();

vrow_epl                       migrate_isd2fsd.etl_process_log%ROWTYPE; 

vrow_esd                       migrate_isd2fsd.etl_std_debug%ROWTYPE; 
--    insert_date     TIMESTAMP      WITH TIME ZONE,
--    process_name    VARCHAR(50)
--    module_name     VARCHAR(50)
--    error_code      VARCHAR(10)
--    error_message   VARCHAR(200) 
--    parameters      VARCHAR(200)
--    insert_by       VARCHAR(50)

v_num_rows                     INTEGER;

v_filename                     TEXT;
v_filepath                     TEXT;
v_fileext                      TEXT;
v_filetype                     TEXT;

v_debug                        INTEGER      = 0;  -- 0 = Off  1 = On

BEGIN 
    vrow_esd.process_name = 'f_etl_track_list_insert';
    vrow_esd.module_name  = 'migrate_isd2fsd';

    SELECT process_debug,          process_id 
    INTO         v_debug, vrow_epl.process_id 
    FROM   migrate_isd2fsd.etl_process_ref 
    WHERE  UPPER(process_name) = UPPER(vrow_esd.process_name);

    IF v_debug > 0 THEN 
        RAISE NOTICE 'Hello, world % calling! - %', vrow_esd.process_name, v_process_start; 
        RAISE NOTICE 'debug:      %', v_debug; 
        RAISE NOTICE 'process_id: %', vrow_epl.process_id; 
    END IF; 

    SELECT migrate_isd2fsd.f_pg_version_num() 
    INTO v_pg_version; 

    SELECT migrate_isd2fsd.f_etl_process_log_updt( 
        'S', NULL, NULL, 0, vrow_epl.process_id::INT, 0, 0, v_process_start, 
        NULL, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 
        '', 'f_etl_track_list_insert started', '' )
    INTO f_return; 

    v_rec_id = f_return;

-- Insure the table is empty before loading. 
-- Remove once the 'record exists' logic is in place. 

--     DELETE 
--     FROM migrate_isd2fsd.etl_metacard_tracking_list; 
-- 
--     GET DIAGNOSTICS v_num_rows = ROW_COUNT;
-- 
--     vrow_epl.rec_delete = v_num_rows; 

--    DELETE 
--    FROM migrate_isd2fsd.etl_tracking_list; 

--    GET DIAGNOSTICS v_num_rows = ROW_COUNT;

--    vrow_epl.rec_delete = vrow_epl.rec_delete + v_num_rows; 

--     UPDATE migrate_isd2fsd.etl_process_log 
--     SET rec_delete  = vrow_epl.rec_delete 
--     WHERE rec_id = v_rec_id; 


/*---------------------------*/
/*  metacards                */
/*---------------------------*/

--     v_num_rows = 0;

--     INSERT 
--     INTO migrate_isd2fsd.etl_metacard_tracking_list (
--         projectid,
--         isdfiletitle,
--         catalog_created_timestamp,
--         dao_class,
--         isdfileexists
--         )
--     SELECT p.projectid,
--         --p.analyst,
--         --p.comments,
--         --parentprojectid,
--         --p.priority,
--         p.projectname,
--         p.startdatetimeitem,
--         --p.stopdatetimeitem,
--         'project',
--         FALSE
--     FROM omega.project p;

--     GET DIAGNOSTICS v_num_rows = ROW_COUNT;

--     INSERT 
--     INTO migrate_isd2fsd.etl_metacard_tracking_list (
--         catalog_id,
--         catalog_dao_id,
--         dao_class,
--         catalog_dao_uri,
--         catalog_created_timestamp,
--         catalog_modified_timestamp,
--         caseid, 
--         collectioneventid, 
--         collectorid,
--         filedescriptivemetadataid,
--         projectid,
--         reelinfoid,
--         retentionpolicyid,
--         retentionpolicydefaultid,
--         workflowinstanceid,
--         workflowtemplateid --,
--         )
--     SELECT mct.catalog_id::uuid,
--         mct.catalog_dao_id::uuid,
--         REVERSE(LEFT(REVERSE(mct.catalog_dao_classname), STRPOS(REVERSE(mct.catalog_dao_classname), '.')-1))::text,
--         mct.catalog_dao_uri,
--         mct.catalog_created_timestamp,
--         mct.catalog_modified_timestamp,
--         m_c.caseid, 
--         m_ce.collectioneventid, 
--         m_cr.collectorid,
--         m_fd.filedescriptivemetadataid,
--         m_p.projectid,
--         m_ri.reelinfoid,
--         m_rp.retentionpolicyid,
--         m_rpd.retentionpolicydefaultid,
--         m_wfi.workflowinstanceid,
--         m_wft.workflowtemplateid--,
-- --        , '|', mct.*
--     FROM omega.mdf_catalog_tab mct 
--     LEFT OUTER JOIN omega.metacard_case m_c                                     ON m_c.metacardid     = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_collectionevent m_ce                         ON m_ce.metacardid    = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_collector m_cr                               ON m_cr.metacardid    = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_contactcharacterizedsources m_ccs            ON m_ccs.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_contactgeospatialtracks m_cgdt               ON m_cgdt.metacardid  = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_contactofinterest m_coi                      ON m_coi.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_contactofinterestsegmentsummary m_coiss      ON m_coiss.metacardid = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_contactoperationalprofile m_cop              ON m_cop.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_filedescriptivemetadata m_fd                 ON m_fd.metacardid    = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_networksearchfiledescriptivemetadata m_nsfdm ON m_nsfdm.metacardid = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_operation m_o                                ON m_o.metacardid     = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_project m_p                                  ON m_p.metacardid     = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_reelinfo m_ri                                ON m_ri.metacardid    = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_retentionpolicy m_rp                         ON m_rp.metacardid    = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_retentionpolicydefault m_rpd                 ON m_rpd.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_splinstance m_spl                            ON m_spl.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_workflowinstance m_wfi                       ON m_wfi.metacardid   = mct.catalog_id
--     LEFT OUTER JOIN omega.metacard_workflowtemplate m_wft                       ON m_wft.metacardid   = mct.catalog_id 
--     ORDER BY m_c.caseid, 
--         m_ce.collectioneventid, 
--         m_cr.collectorid,
--         m_fd.filedescriptivemetadataid,
--         m_p.projectid,
--         m_ri.reelinfoid,
--         m_rp.retentionpolicyid,
--         m_rpd.retentionpolicydefaultid,
--         m_wfi.workflowinstanceid,
--         m_wft.workflowtemplateid;
-- 
--     GET DIAGNOSTICS v_num_rows = ROW_COUNT;
--     vrow_epl.rec_update = vrow_epl.rec_update + v_num_rows;
-- 
--     UPDATE migrate_isd2fsd.etl_process_log 
--     SET rec_insert  = vrow_epl.rec_update 
--     WHERE rec_id = v_rec_id; 

-- Data parsing 

    FOR r IN
        SELECT 
--            SUBSTR(catalog_dao_uri, 1, STRPOS(catalog_dao_uri, ':')-1)::TEXT as filetype, 
--            REVERSE(LEFT(REVERSE(catalog_dao_uri), STRPOS(REVERSE(catalog_dao_uri), '.')-1))::TEXT as fileext,
--            '|', 
            *
        FROM migrate_isd2fsd.etl_metacard_tracking_list 
        ORDER BY rec_id
    LOOP 
        v_filename  = '';
        v_filepath  = '';
        v_fileext   = '';
        v_filetype  = '';

        v_filetype  = SUBSTR(r.catalog_dao_uri, 1, STRPOS(r.catalog_dao_uri, ':')-1)::TEXT;

        IF LOWER(v_filetype) = 'file' THEN
            v_filename = r.filedescriptivemetadataid::TEXT;
            v_fileext  = REVERSE(LEFT(REVERSE(r.catalog_dao_uri), STRPOS(REVERSE(r.catalog_dao_uri), '.')-1))::TEXT;
            v_filepath = SUBSTR(r.catalog_dao_uri, 8, 17);

            RAISE NOTICE '% ', v_filepath;
        END IF;

--          RAISE NOTICE '% - % - %', v_filetype, r.dao_class, r.catalog_dao_uri;

        UPDATE migrate_isd2fsd.etl_metacard_tracking_list 
        SET isdfilename    = v_filename,
            isdfileext     = v_fileext, 
            isdfilepath    = v_filepath,
            isdfiletype    = v_filetype,
            updatedatetime = clock_timestamp()
        WHERE rec_id = r.rec_id;
    END LOOP;

-- End of process cleanup and logging

    SELECT migrate_isd2fsd.f_etl_process_log_updt( 
        'E', v_rec_id, NULL, 0, vrow_epl.process_id::INT, 0, 0, v_process_start, 
        NULL, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, 
        '', 'f_etl_track_list_insert stopped', '' )
    INTO f_return; 

    RAISE NOTICE 'SUCCESS:'; 

    RETURN 1;
EXCEPTION
    WHEN others THEN 
        IF v_debug > 0 THEN 
            RAISE NOTICE 'EXCEPTION:';
        END IF;

        IF v_pg_version >= 90200 THEN 
            GET STACKED DIAGNOSTICS vrow_esd.error_code    = RETURNED_SQLSTATE; 
            GET STACKED DIAGNOSTICS vrow_esd.error_message = MESSAGE_TEXT; 
        ELSE
            vrow_esd.error_code    = 'No support';
            vrow_esd.error_message = 'No support';
        END IF;

        IF v_debug > 0 THEN 
            RAISE NOTICE 'EXCEPTION: % - %', vrow_esd.error_code, vrow_esd.error_message;
        END IF;

        SELECT migrate_isd2fsd.f_etl_std_debug ( 
            CLOCK_TIMESTAMP(), 
            SUBSTRING(vrow_esd.process_name, 1, 50), 
            SUBSTRING(vrow_esd.module_name, 1, 50),  
            SUBSTRING(vrow_esd.error_code, 1, 10),  
            SUBSTRING(vrow_esd.error_message, 1, 200),  
            SUBSTRING(vrow_esd.parameters, 1, 200),  
            SUBSTRING(USER, 1, 50) 
            ) 
        INTO f_return;

        RETURN 0; 

END;

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
  
ALTER FUNCTION migrate_isd2fsd.f_etl_track_list_insert()
  OWNER TO enterprisedb;
