﻿-- Function: migrate_isd2fsd.dotablecount(character varying)

-- DROP FUNCTION migrate_isd2fsd.dotablecount(character varying);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_do_table_count(p_schema character varying)
  RETURNS void AS
$BODY$

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: doTableCount                                                  */
/*      Author: Gene Belford                                                  */
/* Description: Collects the number of rows in tables for a given schema.     */
/*              The function will delete all records older the 106 days,      */
/*              except the first day of the month.                            */
/*        Date: 2015-05-04                                                    */
/* Source File: 201_f_do_table_count.sql                                      */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2015-05-04             Gene Belford          Created                       */
/* 2015-11-12             Gene Belford          Added "from"                  */ 
/*             and "INTERVAL'106 DAYS'" to delete statements.                 */ 
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

INSERT INTO omega_dbms_object_facts 
    (schemaname, relname, indexrelname, row_cnt_date, row_cnt) 
VALUES('v_schema', 'r.relname', NULL, TIMESTAMP '2001-01-01 00:00:01', -1); 

INSERT INTO omega_dbms_object_facts 
    (schemaname, relname, indexrelname, row_cnt_date, row_cnt) 
VALUES('v_schema', 'r.relname', NULL, TIMESTAMP '2001-01-02 00:00:02', -2); 

INSERT INTO omega_dbms_object_facts 
    (schemaname, relname, indexrelname, row_cnt_date, row_cnt) 
VALUES('v_schema', 'r.relname', NULL, TIMESTAMP '2015-05-08 00:00:03', -3); 

SELECT migrate_isd2fsd.doTableCount('coalesce');

SELECT migrate_isd2fsd.doTableCount('omega');

SELECT migrate_isd2fsd.doTableCount('public');

SELECT schemaname, relname, 
--    indexrelname, 
    row_cnt_date, row_cnt 
FROM   migrate_isd2fsd.omega_dbms_object_facts 
ORDER BY schemaname, relname, row_cnt_date DESC; 

SELECT row_cnt_date 
FROM omega_dbms_object_facts
ORDER BY row_cnt_date; 

--DELETE omega_dbms_object_facts
--WHERE  EXTRACT(DAY FROM row_cnt_date) = 8 
--    AND EXTRACT(MINUTE FROM row_cnt_date) = 25;
*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DECLARE 

r                              pg_stat_all_tables%rowtype;

v_strt_time                    TEXT;
v_stop_time                    TEXT;
v_err_msg                      VARCHAR(200);
v_stmt                         TEXT;
v_schema                       VARCHAR(100);

v_object_cnt                   BIGINT;

v_debug                        INT := 0;

BEGIN 
-- Determines if debugging is on or off
    SELECT COALESCE(process_debug, 1) 
    INTO   v_debug
    FROM   public.omega_process_ref 
    WHERE  UPPER(process_name) = UPPER('doTableCount');

    v_schema := UPPER(p_schema);

-- Get the function start time and make a log entry
    v_strt_time := clock_timestamp()::text;
    v_stmt := 'POSTGRES doTableCount(' || v_schema || ') start: ' || v_strt_time;
    RAISE LOG    '%', v_stmt;
    IF v_debug > 0 THEN 
        RAISE NOTICE '%', v_stmt; 
        RAISE NOTICE 'p_schema %', v_schema; 
    END IF;

--    SELECT * 
--    FROM public.omega_dbms_object_facts
--    WHERE  row_cnt_date < (NOW() - 106)
--        AND EXTRACT(DAY FROM row_cnt_date) <> 1;

-- Remove history data, except for the first of the month
-- 2015-11-12 GB Added "from" and "INTERVAL'106 DAYS'" to delete statements. 
    DELETE 
    FROM migrate_isd2fsd.isd_db_object_facts
    WHERE  row_cnt_date < (NOW() - INTERVAL'106 DAYS')
        AND UPPER(schemaname) = UPPER('OMEGA')  -- v_schema  
        AND EXTRACT(DAY FROM row_cnt_date) <> 1; 

-- START OF ACTUAL WORK

-- Loop through all the tables in the schema and the a record count
    FOR r IN
    SELECT * 
    FROM pg_stat_all_tables 
    WHERE UPPER(schemaname) = UPPER('omega') -- v_schema 
    ORDER BY schemaname, relname 
    LOOP 
        v_object_cnt := 0;
        v_stmt := 'SELECT COUNT(*) FROM ' || v_schema || '.' || r.relname;

        IF v_debug > 0 THEN 
            RAISE NOTICE '%', v_stmt; 
        END IF;

-- Execute the dynamic SQL
        EXECUTE v_stmt INTO v_object_cnt;  

-- Insert the record count in the fact table
        INSERT INTO migrate_isd2fsd.isd_db_object_facts 
            (schemaname, relname, indexrelname, row_cnt_date, row_cnt) 
        VALUES(v_schema, r.relname, NULL, NOW(), v_object_cnt); 

        IF v_debug > 0 THEN 
            RAISE NOTICE '%', v_table_cnt;
        END IF;
        
    END LOOP; 

-- END OF ACTUAL WORK

-- Get the stop time and make a log entry
    v_stop_time := clock_timestamp()::text;
    v_stmt := 'POSTGRES doTableCount(' || v_schema 
        || ') start: ' || v_strt_time 
        || ' stop: '   || v_stop_time;
    
    RAISE LOG    '%', v_stmt;
    IF v_debug > 0 THEN 
        RAISE NOTICE '%', v_stmt; 
    END IF;

EXCEPTION
    WHEN OTHERS THEN
--        GET STACKED DIAGNOSTICS vrow_osd.error_code = RETURNED_SQLSTATE;
        GET STACKED DIAGNOSTICS v_err_msg = MESSAGE_TEXT;

        RAISE NOTICE    'Error Message: %', v_err_msg ;
        RAISE EXCEPTION 'Error Message: %', v_err_msg ;
END 
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION migrate_isd2fsd.dotablecount(character varying)
  OWNER TO omegaservice;
