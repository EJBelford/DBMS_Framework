﻿-- DROP FUNCTION IF EXISTS migrate_isd2fsd.f_pg_version_num();

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_pg_version_num() 
    RETURNS INT
    
AS 
    
$BODY$ 
    
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_pg_version_num()                                            */
/*      Author: Gene Belford                                                  */
/* Description: This function returns the version of PostgreSQL installed     */
/*              as an integer value.  This allows the developer program for   */
/*              features not available in the current installed version, but  */
/*              are available newer releases.                                 */
/*              This function was adapted from the following discusion thread */
/* http://postgresql.1045698.n5.nabble.com/Version-Number-Function-td1992392.html */
/*        Date: 2014-01-20                                                    */
/* Source File: 136_f_pg_version_num.sql                                          */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2014-01-20             Gene Belford          Created                       */
/* 2016-02-09             Gene Belford          The VERSION() returns either  */
/*             'PostgreSQL' or 'EnterpriseDB' which requires the matching     */
/*             pattern to be changed.                                         */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

SELECT migrate_isd2fsd.f_pg_version_num();

SELECT pg_sleep (1.1); 

*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

DECLARE 

f_return                       INTEGER; 

v_null                         INTEGER      = NULL; 

v_rec_id                       INTEGER;
v_rec_uuid                     UUID;
v_process_start                TIMESTAMP    WITH TIME ZONE;

vrow_epl                       migrate_isd2fsd.etl_process_log%ROWTYPE; 

vrow_esd                       migrate_isd2fsd.etl_std_debug%ROWTYPE; 
--    insert_date     TIMESTAMP      WITH TIME ZONE,
--    process_name    VARCHAR(50)
--    module_name     VARCHAR(50)
--    error_code      VARCHAR(10)
--    error_message   VARCHAR(200) 
--    parameters      VARCHAR(200)
--    insert_by       VARCHAR(50)

v_num_rows                     INTEGER;

v_debug                        INTEGER      = 0;  -- 0 = Off  1 = On
    
BEGIN 
--    RAISE NOTICE 'v_debug: %', v_debug;

    v_process_start            = CLOCK_TIMESTAMP();

    vrow_esd.process_name      = 'Unit Test';
    vrow_esd.module_name       = 'pg_version_num'; 
    vrow_esd.parameters        = NULL;

    vrow_epl.batch_id          = NULL;
    vrow_epl.process_id        = 2; 
    vrow_epl.process_status    = NULL; 
    vrow_epl.process_step      = 0;
    vrow_epl.process_start     = v_process_start; 
    vrow_epl.process_message   = NULL;
    
    v_rec_id                   = NULL;
    v_rec_uuid                 = NULL;
    v_num_rows                 = NULL;

    IF v_debug > 0 THEN 
        RAISE NOTICE 'process_step: %', vrow_epl.process_step; 
    END IF; 
    
    SELECT 
        10000 * 
        CAST(SUBSTRING(VERSION() 
            FROM '^EnterpriseDB +([0-9]+)[.][0-9]+[.][0-9]') AS INT) 
        + 
        100 * 
        CAST(SUBSTRING(VERSION() 
            FROM '^EnterpriseDB +[0-9]+[.]([0-9]+)[.][0-9]') AS INT) 
        + 
        CAST(SUBSTRING(VERSION() 
            FROM '^EnterpriseDB +[0-9]+[.][0-9]+[.]([0-9])') AS INT) 
    INTO f_return; 

--     SELECT 
--         10000 * 
--         CAST(SUBSTRING(VERSION() 
--             FROM '^PostgreSQL +([0-9]+)[.][0-9]+[.][0-9]') AS INT) 
--         + 
--         100 * 
--         CAST(SUBSTRING(VERSION() 
--             FROM '^PostgreSQL +[0-9]+[.]([0-9]+)[.][0-9]') AS INT) 
--         + 
--         CAST(SUBSTRING(VERSION() 
--             FROM '^PostgreSQL +[0-9]+[.][0-9]+[.]([0-9])') AS INT) 
--     INTO f_return; 

    RETURN f_return;
                
EXCEPTION
    WHEN others THEN 
        RAISE NOTICE 'EXCEPTION';
        
        GET STACKED DIAGNOSTICS vrow_esd.error_code    = RETURNED_SQLSTATE;
        GET STACKED DIAGNOSTICS vrow_esd.error_message = MESSAGE_TEXT;
        
        SELECT f_omega_std_debug (
            v_process_start, 
            vrow_esd.module_name,  
            vrow_epl.process_id,
            vrow_esd.error_code,  
            vrow_esd.error_message, 
            vrow_esd.parameters,
            USER
            ) INTO f_return;  
        
        RETURN NULL;

END;
    
$BODY$
LANGUAGE plpgsql VOLATILE 
COST 100;


COMMENT ON FUNCTION migrate_isd2fsd.f_pg_version_num() 
IS 'f_pg_version_num() - This function returns the version of PostgreSQL installed as an integer value.  This allows the developer program for featurse not available in the current installed version, but are available newer releases.';


ALTER FUNCTION migrate_isd2fsd.f_pg_version_num() 
    OWNER TO enterprisedb; 
    
