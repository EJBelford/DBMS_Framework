﻿/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_func_warn_log                                             */
/*      Author: Gene Belford                                                  */
/* Description: This table is used to capture warnings for the OMEGA          */
/*              functional user.  Warnings are processing exceptions, and     */
/*              data integrity issues.                                        */
/*        Date: 2016-01-28                                                    */
/* Source File: 041_etl_func_warn_log.sql                                     */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-01-28             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

-- DROP TABLE IF EXISTS migrate_isd2fsd.etl_func_warn_log;

CREATE TABLE migrate_isd2fsd.etl_func_warn_log 
(
rec_id             INTEGER        NOT NULL DEFAULT nextval('migrate_isd2fsd.etl_func_warn_log_seq'::regclass),
--
rec_uuid           UUID, 
--
warning_type       VARCHAR(50),
warning_from       VARCHAR(100), 
warning_msg        VARCHAR(2000), 
warning_status     CHAR(1)        NOT NULL DEFAULT 'C', 
warning_timestamp  TIMESTAMP      WITH TIME ZONE NOT NULL DEFAULT NOW(), 
warning_action     VARCHAR(2000), 
--
update_date        TIMESTAMP      WITH TIME ZONE,
update_by          VARCHAR(50),
--
PRIMARY KEY (rec_id) 
)
WITH (
    OIDS = FALSE 
    );

ALTER TABLE migrate_isd2fsd.etl_func_warn_log 
                OWNER TO enterprisedb


COMMENT ON TABLE migrate_isd2fsd.etl_Func_Warn_Log 
IS 'OMEGA_Func_Warn_Log - This table is used to capture warnings for the OMEGA functional user.  Warnings are processing exceptions, and dat integrity issues.';

COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.rec_id 
IS 'rec_id - The unquie durable single field key assigned to the record.';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.rec_uuid 
IS 'rec_uuid - Stores the Universally Unique IDentifier (UUID) as defined by RFC 4122, ISO/IEC 9834-8:2005.'; 
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_type 
IS 'warning_type - PROCESSING/DATA INTEGRITY/REVIEW REQUIRED/tdb as idicated by raising module.';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_from 
IS 'warning_from - Should contain the name of the raising module with the entire calling string.';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_msg 
IS 'warning_msg - Information with the rasing module that helps resolve, and/or research the issue.';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_status 
IS 'warning_status - A 1 character code for the statsu of the record, (Current, Error, Historical, New, Processing, Waiting)'; 
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_timestamp  
IS 'warning_timestamp - The timestamp of when warning was recorded.';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.warning_action 
IS 'warning_action - The action taken to coreect the warning.';

COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.update_date 
IS 'update_date - The date the record was last modified';
COMMENT ON COLUMN migrate_isd2fsd.etl_func_warn_log.update_by 
IS 'update_by - The user/function that last updated the record';

