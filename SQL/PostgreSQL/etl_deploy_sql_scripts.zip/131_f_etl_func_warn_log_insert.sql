﻿-- DROP FUNCTION migrate_isd2fsd.f_etl_func_warn_log_insert(text, text, text, text);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.f_etl_func_warn_log_insert 
    (
    p_warning_type text, 
    p_warning_from text, 
    p_warning_msg text, 
    p_warning_status text
    )
RETURNS integer 

AS
$BODY$

/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: f_etl_func_warn_log_insert                                    */
/*      Author: Gene Belford                                                  */
/* Description: .                            */
/*        Date: 2016-02-10                                                    */
/* Source File: 131_f_etl_func_warn_log_insert.sql                                */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

DECLARE

SELECT migrate_isd2fsd.f_etl_func_warn_log_insert 
    (
    'test_' || NOW(), 
    'from', 
    'unit test', 
    'C'
    );

SELECT * 
FROM migrate_isd2fsd.etl_func_warn_log 
ORDER BY rec_id DESC;

*/

DECLARE

BEGIN

    INSERT 
    INTO migrate_isd2fsd.etl_func_warn_log (
        warning_type, warning_from, warning_msg, warning_status 
        )
    VALUES (
        p_warning_type, p_warning_from, p_warning_msg, p_warning_status
        );

    RETURN 1;

EXCEPTION
    WHEN others THEN 

        RETURN 0;
END; 

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;

ALTER FUNCTION migrate_isd2fsd.f_etl_func_warn_log_insert(text, text, text, text)
  OWNER TO enterprisedb;
