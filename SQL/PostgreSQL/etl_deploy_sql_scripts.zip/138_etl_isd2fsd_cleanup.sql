﻿-- DROP FUNCTION migrate_isd2fsd.etl_isd2fsd_cleanup(uuid);

CREATE OR REPLACE FUNCTION migrate_isd2fsd.etl_isd2fsd_cleanup(iobjectkey uuid)
  RETURNS integer 

AS 
    
$BODY$ 
    
/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_isd2fsd_cleanup()                                         */
/*      Author: Gene Belford                                                  */
/* Description: This function                                                 */
/* Source File: 138_etl_isd2fsd_cleanup.sql                                   */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-06-21             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Unit Test                                                                  */
/*

SELECT migrate_isd2fsd.f_etl_clear_list_insert (
    '000000007158466899372c8ab9fe0227', 
    'f_etl_clear_list_insert', 
    'test'
    );

SELECT * 
FROM migrate_isd2fsd.etl_clear_list 
ORDER BY rec_id DESC; 

SELECT entity1name, linktype, linkstatus, entity2name, COUNT(entity1name) 
FROM coalesce.coalescelinkage 
GROUP BY entity1name, entity2name, linktype, linkstatus 
ORDER BY entity1name, entity2name; 

*/
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

-- Function: migrate_isd2fsd.etl_isd2fsd_cleanup(uuid)

/*

-- Linkage summary 

SELECT entity1name, linktype, entity2name, count(linktype) 
FROM coalesce.coalescelinkage 
WHERE entity1name NOT IN ('UNIT_TEST') 
    AND entity2name NOT IN ('UNIT_TEST') 
GROUP BY entity1name, linktype, entity2name 
ORDER BY entity1name, linktype, entity2name; 

-- lifecycle_policy_object_recordset --

SELECT * 
FROM coalesce.coalesceentity 
WHERE LOWER(name) LIKE LOWER('Life-Cycle Policy Object') 
ORDER BY datecreated DESC 
LIMIT 25;


SELECT * 
FROM coalesce.lifecycle_policy_object_recordset 
ORDER BY name NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2de09630-7158-4668-9937-2c8ab9fe0227');


-- project_record --

SELECT * 
FROM coalesce.coalesceentity 
WHERE name LIKE 'Project Object%' 
ORDER BY datecreated DESC 
LIMIT 25;

SELECT * 
FROM coalesce.project_record 
ORDER BY projectName NULLS LAST;

SELECT * FROM coalesce.coalesceentity 
WHERE objectkey = 'a84a0516-d559-4aa7-b092-61562025be40';

cae00001-0000-0000-0000-000000000000

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('1d1130ae56e143cd9958b431d37dd4e4');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2dc1742c93a041178ff3c38ef262638c');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('434a9616f169483a9b306e57df54bc13');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('43ca95cd3959486a82f8c8110b8e5f8d');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('7347c55ed0ce4480a1ec197efb46ead4');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('754425ddda6e444aa8b4d5022dac3da0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('a1f0f5c0535f49d8bd74eb05f60592f0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c24e863968814375bb749e9287786f23');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ca84a49bed77455e8ae704df8e08459c');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('e64da67bd57c464885f6f5b340b22ab5');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('eb7837a2dc884c59b60342c900f72b84');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('f5e726c729d84f8cb5586c2aa0a221bf');

objectkey IN ('#', 
    '0c6303b7-f79b-449a-8149-28b09484b209')


-- workflowtemplate_record -- 

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) LIKE 'w%temp%obj%'
ORDER BY dateCreated DESC;

SELECT * 
FROM coalesce.workflowtemplate_record
ORDER BY workflowTemplateName NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0c1e7b1ff0934c0ea17e304ab30efc52');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c58f51e43b74498ca5174119290e0b17'); 
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('cae0000100010001000100000000002a');


-- workflow instance -- 

-- Link p_omegaprojectid: 754425ddda6e444aa8b4d5022dac3da0 to p_workflowinstanceid: afec7cefc6374296b236c0c700cdcba5

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) LIKE 'workflow%obj%'
ORDER BY dateCreated DESC;

SELECT * 
FROM coalesce.workflow_record;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('9f33baa9-e438-46c0-bbbc-24818c1bb326');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('3cf95e8f-375c-4e57-bb84-c852183ffd2d');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('5e994736-df7f-4628-a3eb-e41864819c90');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('afec7cef-c637-4296-b236-c0c700cdcba5');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('aee1fbd5-e9c2-47d3-830e-e4b3f4149264');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('cae00001-0001-0001-0001-00000000001a');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('95dea01a-f402-4fcb-a5c4-e7e9d2c4d6c8');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('87af9af0-fd51-4e47-a578-4af725dae146');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('dfa8b672-9943-4358-a19b-97cdb45851c4');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('86e7a6d1-4e88-48f9-b418-bae780b3aebd');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c3ced56b-c1cd-4ee3-b825-f55d22ffd6b5');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0589205b-9020-4dad-92f0-23a0efcfdef7');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('dc5b6e2d-b9ae-4664-9fcf-8c0011744716');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0de245b5-05bf-46a1-8b25-80135308697f');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0c35ec95-6d54-4ece-bf14-d88decadea79');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('665a254d-e7c2-48d6-b3a5-04234f4a72dc');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('bca521b4-1bdc-4b89-b81b-603667568986');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('41461bd5-e348-480c-a6fe-ccb0a6b99764');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('b1b442a2-9bde-4ead-8a46-3ed0377da341');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('3e5b2a56-c3cf-46d8-b7d5-a48b67447493');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('a4531910-3ebd-4e8f-8661-34fc34dc0f48');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('346b1258-cdc2-4a71-bca3-97062fe499df');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('1cc28b25-5a11-43f7-954e-279b446e1f01');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('5b6ac02f-9f2c-4c89-ada5-c6c63224d716');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('e4bd10d4-6378-4eef-83f7-3c781b223f31');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('87925ec8-874c-4685-a03b-fbbb4a106000');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ac2196f9-3226-44d0-b786-1838ad3c933e');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('f7a4c371-21d1-455c-a62b-18fc6167f047');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ec244291-660d-4d86-be7b-2656bfaf72cf');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('e3e34a01-5c9e-4c6a-846a-77d3e9b533a0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('a73dcb48-120b-468b-b39b-0e1899403c80');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c0ff0d51-c6dc-4c60-851f-f7a9a2771730');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('36d9ca46-2712-49d6-a95f-1fb722619f1c');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('547f701c-3a3f-4c2d-ac19-bea0594f6373');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('96fa4d09-327a-4a60-948f-2c581ec935c5');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('614c98a0-8c02-42ef-9a10-d42c717b3c6a');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('041bcbe0-6411-4634-bbfc-87269b48d683');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('46f5bcb0-d01c-4473-9899-93f6a9f3b837');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('7470ef1a-f630-4d53-866b-1f6576e733b0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('f03ca340-7033-4238-af17-36e21f8d4433');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0003d9fe-5409-492b-86ab-5835b1050590');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('05ef3017-0fd3-44ae-9ba3-391160fda8e4');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('e8cb2b20-26c9-4867-bfe6-589502aae291');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('583bc016-d098-405c-a4a7-18e8cf7ede18');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('3f047707-dd1d-4893-8314-56e7dbc7eb14');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('f5f6dfa6-d7ea-4029-9ff7-02cc5cfc5b8f');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('1838ca8f-9fd8-4e02-a523-2b5a1b3c2b8d');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('1d9cad5d-e99e-4d8f-87a8-ad45997a95b7');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2317cf08-61a6-4305-ab94-5d1ca2680679');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('8e9b8e30-21b6-4331-8f04-2919c7edd1e4');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('070cb530-f4e7-42b5-aecb-f35e36881c6a');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('5207a1db-4fc6-4291-b92d-133159ad85b0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('bcbe9888-a919-4366-b1af-e4269dd5a3cd');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('50823a43-4bb3-4304-8913-6b7733cc5117');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0f605516-826c-4dbf-8510-a1a699662f78');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('9212be57-e8e1-4434-92cc-609a464aa110');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('4cfc392c-d548-4010-b13e-291488470b40');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ed7b6958-b210-415e-8484-cea8cb27c3fe');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('8b0829d4-4a9a-4136-b783-35f18bc9152d');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('31984694-909f-4477-b16d-0b395fff2427');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2656c860-f24c-4263-a0e1-40a962817285');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c1a3a9ff-1777-49df-923b-6c7bd9684ef8');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2a830f9e-8acf-45b6-bcd1-bd43da902469');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('6e16d4c2-760c-4cc5-b0cc-59c87d85fcaa');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('9404644c-bae2-42af-97f2-9de6265ffb9a');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('dc5aa952-9125-415c-aaf0-e85de914da24');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('afec7cef-c637-4296-b236-c0c700cdcba5');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('06b39c02-0c92-4ab3-bc7f-f80efb4dbfa3');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('99e9845b-2e87-4279-bd7e-281ef0ac4305');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('edb50c80-1ed1-41f5-b934-8ffdf37617bd');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('3be48bd5-d79b-49bb-810c-2394a42fe33e');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('52e7dbb2-92d0-46f2-af22-79cc9ae99679');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('61ca756e-754e-46c7-9d46-510f825b2e39');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ce117c0a-f6c1-4850-b6b5-d22314bba587');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('1e49ff01-27c2-4484-b02c-5b657e9b3005');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ee142814-a11b-4c4a-8677-f07ce4f78a86');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('52e80c11-f691-4873-b45c-fe83720d34c1');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('be60a393-f37c-4676-a5b0-967ee4a0ad32');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('52a8e6c9-b2ed-41d1-8b31-cfcd80d10684');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('ec8f118c-d771-481a-af75-65c1f5477223');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0db9a13b-8b3b-46a8-b34d-fa32b47bf011');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('55f924a3-46ce-423a-80bc-85ec5e70719f');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c2c5f8af-3b4e-4ad0-9b96-fe2739223ae0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2c6dec3b-d086-4757-952d-0a134204f922');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('782708b4-2565-49ab-bf78-ec8f65661927');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c28ecd50-2de7-4112-9afa-3fe3e25790dc');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('6bfd5638-1f4e-4607-a637-7b23bd824ad6');


-- workflowactivityinstance_record -- 

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) LIKE 'w%act%obj%'
ORDER BY dateCreated DESC;

SELECT * 
FROM coalesce.workflowactivityinstance_record
ORDER BY workItemId NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('005b37c9eba54844b438107c493de4ce');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('3d617100-2335-41f6-80e2-37ede38f76d0');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('59b628eb-9028-4a4a-bf19-9ca6bf561e27');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('8d77522a-abfd-4e86-93d4-8f70f543e118');

-- user comments record --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('user comments object');

SELECT * 
FROM coalesce.user_comments_record;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('2f46a445-75f2-4869-a440-7ba867c425c6');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('61523d02-efdd-4bf9-bfc5-4ad7598a5a49');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c2fc7a7a-4962-4ed2-ba56-73916fe69848');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('51494c28-4f99-4c57-8447-e1b8e7f693ff');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('a2188dd5-bcef-4cad-a32b-5fa96839f97b');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('c6c07281-c578-40d9-b873-caed06523353');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('4103b41f-8793-4df4-962c-e02c4d2613e1');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('86f4842c-ab83-49d1-8c1f-00fcdb5e2304');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('9f36643b-fcb7-4a9e-8a96-2a78ecb874dc');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('184ae542-44ca-46c4-a307-9e3b2f7e6ad6');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('a2e0fe73-f7c4-4a2f-9b61-d716100ce77a');
SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('00da7f0b-990a-4aff-9908-a260c039333a');


-- workflow_suspend_record --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('workflow suspend object')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.workflow_suspend_record
ORDER BY resumedate DESC NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('cae00001-0000-0000-0000-000000000000');

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('0c1e7b1ff0934c0ea17e304ab30efc52');


-- case --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('case object')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.case_record
ORDER BY oniCaseNumber DESC NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('f0bf0674-7c08-44bc-9157-68ff776c1e63');

'f0bf0674-7c08-44bc-9157-68ff776c1e63'


-- collection event --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('collection event')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.collection_event_record
ORDER BY name DESC NULLS LAST;

SELECT migrate_isd2fsd.etl_isd2fsd_cleanup('d8783cd8-48f3-44ec-9d30-7bd72d316bfe');

'd8783cd8-48f3-44ec-9d30-7bd72d316bfe'


-- reel info --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('reel info')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.reelinfo_recordset
ORDER BY remarks DESC NULLS LAST;

'42b73c15-2c97-4bdf-ad09-31b8bcf75d04'

-- reel cut --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('reel cut')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.reelcut_recordset
ORDER BY comments DESC NULLS LAST;

'e1c943ad-0e45-4eb0-91aa-fa6dfc40b767'

-- collector --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('collector')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.collector_recordset
ORDER BY collectorname NULLS LAST;

'dd2cfd71-c42b-4a4a-921b-eeaa534b9c5d'

-- collector --

SELECT * 
FROM coalesce.coalesceEntity 
WHERE LOWER(name) = LOWER('EventTargetCharacterization')
ORDER BY datecreated DESC;

SELECT * 
FROM coalesce.EventTargetCharacterization_recordset
ORDER BY masterNumber DESC NULLS LAST;

'dd2cfd71-c42b-4a4a-921b-eeaa534b9c5d'

*/

DECLARE 
r                              migrate_isd2fsd.etl_clear_list%rowtype;

dataObject UUID;
objCnt     INTEGER;
    
selectCnt  INTEGER;
rowCnt     INTEGER;

BEGIN 
    objCnt = 0;

    SELECT COUNT(ecl.object_uuid) 
    INTO objCnt 
    FROM migrate_isd2fsd.etl_clear_list ecl; 

    rowCnt = 0;
    
    IF objCnt > 0 THEN 

        DELETE 
        FROM migrate_isd2fsd.etl_process_log 
        WHERE process_stop < (NOW() - INTERVAL '5 days');

        DELETE 
        FROM migrate_isd2fsd.etl_func_warn_log;

        DELETE 
        FROM migrate_isd2fsd.etl_std_debug
        WHERE insert_date < (NOW() - INTERVAL '5 days');

        FOR r IN
        SELECT * 
        FROM migrate_isd2fsd.etl_clear_list 
        ORDER BY rec_id DESC 
	LOOP 

	    iobjectkey = r.object_uuid; -- iobjectkey;

/*-- coalesceentity --*/
    
            selectCnt = 0;

            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.coalesceentity 
            WHERE objectkey = iobjectkey;

            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.coalesceentity 
                WHERE objectkey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

/*-- coalesceLinkage --*/
    
            selectCnt = 0;

            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.coalesceLinkage 
            WHERE entity1key = iobjectkey;

            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.coalesceLinkage 
                WHERE entity1key = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

            selectCnt = 0;

            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.coalesceLinkage 
            WHERE entity2key = iobjectkey;

            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.coalesceLinkage 
                WHERE entity2key = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

/*-- access_control_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.access_control_recordset 
            WHERE entitykey = iobjectkey;

            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.access_control_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

/*-- base_data_object_recordset --*/
    
            selectCnt = 0;
     
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.base_data_object_recordset 
            WHERE entitykey = iobjectkey;

            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.base_data_object_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);
    
/*-- security_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.security_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.security_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

/*-- project_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.project_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.project_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);
    

/*-- lifecycle_policy_object_recordset --*/
    
            selectCnt = 0;
     
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.lifecycle_policy_object_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.lifecycle_policy_object_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

        
/*-- workflowtemplate_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.workflowtemplate_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.workflowtemplate_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);


-- workflow record -- 

/* '9f33baa9-e438-46c0-bbbc-24818c1bb326' */

            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.workflow_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.workflow_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);


/*-- workflowactivityinstance_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.workflowactivityinstance_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.workflowactivityinstance_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

       
/*-- user_comments_record --*/
    
            selectCnt = 0;
     
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.user_comments_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.user_comments_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

       
/*-- workflow_suspend_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.workflow_suspend_record 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.workflow_suspend_record 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0);

/*---------*/
/*-- DAQ --*/
/*---------*/

/*-- case_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.case_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.case_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 

/*-- collection_event_record --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.collectionevent_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.collectionevent_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*-- reelinfo_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.reelinfo_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.reelinfo_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*-- reelcut_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.reelcut_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.reelcut_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*-- collector_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.collector_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.collector_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*-- collector_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.eventtargetcharacterization_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.eventtargetcharacterization_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*-- base_file_object_recordset --*/
    
            selectCnt = 0;
    
            SELECT COUNT(objectkey)
            INTO selectCnt 
            FROM coalesce.base_file_object_recordset 
            WHERE entitykey = iobjectkey;
 
            IF selectCnt > 0 THEN 
                DELETE 
                FROM coalesce.base_file_object_recordset 
                WHERE entitykey = iobjectkey;
            END IF;

            rowCnt = rowCnt + COALESCE(selectCnt, 0); 
            

/*---------------------------------------*/
/* Remove the record from the clear list */            
/*---------------------------------------*/

            DELETE 
            FROM migrate_isd2fsd.etl_clear_list
            WHERE object_uuid = iobjectkey;

        END LOOP; -- Clear list

    END IF; -- IF objCnt > 0
       
/*-- Return --*/ 

    RETURN(rowCnt);

END
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
  
ALTER FUNCTION migrate_isd2fsd.etl_isd2fsd_cleanup(uuid)
  OWNER TO enterprisedb;
