﻿/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_process_ref_seq                                           */
/*      Author: Gene Belford                                                  */
/* Description: Creates a sequence number for the table that is assigned      */
/*              to the rec_id each new record is created.                     */
/*        Date: 2016-02-10                                                    */
/* Source File: 108_etl_isd_db_object_facts__nonzero.sql                      */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

-- View: migrate_isd2fsd.etl_isd_db_object_facts__nonzero

-- DROP VIEW migrate_isd2fsd.etl_isd_db_object_facts__nonzero;

CREATE OR REPLACE VIEW migrate_isd2fsd.etl_isd_db_object_facts__nonzero AS 
 SELECT isd_db_object_facts.rec_id,
    isd_db_object_facts.row_cnt_date,
    isd_db_object_facts.schemaname,
    isd_db_object_facts.relname,
    isd_db_object_facts.indexrelname,
    isd_db_object_facts.row_cnt,
    isd_db_object_facts.etl_entity_cnt AS etl_row_cnt,
    isd_db_object_facts.etl_linkage_cnt,
    isd_db_object_facts.last_updated
   FROM migrate_isd2fsd.isd_db_object_facts
  WHERE isd_db_object_facts.row_cnt > 0 AND (isd_db_object_facts.relname::text <> ALL (ARRAY['acousticmode'::character varying::text, 'acousticradiationtype'::character varying::text, 'aekeyingintervaltype'::character varying::text, 'category'::character varying::text, 'cavitationmode'::character varying::text, 'cavitationtype'::character varying::text, 'classification'::character varying::text, 'confidence'::character varying::text, 'country'::character varying::text, 'cvenumism25x'::character varying::text, 'cvenumismclassificationus'::character varying::text, 'cvenumismdissem'::character varying::text, 'cvenumismfgiopen'::character varying::text, 'cvenumismfgiprotected'::character varying::text, 'cvenumismnonic'::character varying::text, 'cvenumismownerproducer'::character varying::text, 'cvenumismrelto'::character varying::text, 'cvenumismsar'::character varying::text, 'cvenumismscicontrols'::character varying::text, 'cvenumismsourcemarked'::character varying::text, 'depthband'::character varying::text, 'enginelocation'::character varying::text, 'enginetype'::character varying::text, 'homingtype'::character varying::text, 'mediamodetype'::character varying::text, 'operatingprofile'::character varying::text, 'participantrole'::character varying::text, 'platformtype'::character varying::text, 'producttype'::character varying::text, 'projectpriority'::character varying::text, 'propellerlocation'::character varying::text, 'propulsionmode'::character varying::text, 'propulsiontype'::character varying::text, 'pulsetype'::character varying::text, 'soundtype'::character varying::text, 'sourcecategory'::character varying::text, 'sourcecomponent'::character varying::text, 'sourcename'::character varying::text, 'sourceoriginname'::character varying::text, 'speedband'::character varying::text, 'splcavitation'::character varying::text, 'splclass'::character varying::text, 'splcollectionplatform'::character varying::text, 'splcollectionsensor'::character varying::text, 'splcountry'::character varying::text, 'spldepth'::character varying::text, 'splenginelocation'::character varying::text, 'splenginetype'::character varying::text, 'splpropellerlocation'::character varying::text, 'splpropulsionmode'::character varying::text, 'spltransient'::character varying::text, 'ssic'::character varying::text, 'targetflightvariant'::character varying::text, 'tpsfileprecisiontype'::character varying::text, 'transientlevel'::character varying::text, 'type'::character varying::text, 'waveform'::character varying::text, 'weaponactivity'::character varying::text, 'weaponmode'::character varying::text]))
  ORDER BY isd_db_object_facts.schemaname, isd_db_object_facts.relname;

ALTER TABLE migrate_isd2fsd.etl_isd_db_object_facts__nonzero
  OWNER TO enterprisedb;
