﻿/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_metacard_tracking_list                                    */
/*      Author: Gene Belford                                                  */
/* Description: <description>                                */
/*        Date: 2016-02-09                                                    */
/* Source File: 051_etl_metacard_tracking_list.sql                                */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-09  <00.00.00> Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

-- DROP TABLE IF EXISTS migrate_isd2fsd.etl_metacard_tracking_list;

CREATE TABLE migrate_isd2fsd.etl_metacard_tracking_list (
rec_id                         INTEGER      NOT NULL DEFAULT nextval('migrate_isd2fsd.etl_metacard_tracking_list_seq'::regclass),
--
catalog_id                     UUID,
catalog_dao_id                 UUID,
dao_class                      TEXT,
catalog_dao_uri                CHARACTER VARYING(1024),
catalog_created_timestamp      TIMESTAMP WITHOUT TIME ZONE,
catalog_modified_timestamp     TIMESTAMP WITHOUT TIME ZONE,
caseid                         CHARACTER VARYING(255), 
collectioneventid              CHARACTER VARYING(255), 
collectorid                    CHARACTER VARYING(255),
filedescriptivemetadataid      CHARACTER VARYING(255),
projectid                      CHARACTER VARYING(255),
reelinfoid                     CHARACTER VARYING(255),
retentionpolicyid              CHARACTER VARYING(255),
retentionpolicydefaultid       CHARACTER VARYING(255),
workflowinstanceid             CHARACTER VARYING(255),
workflowtemplateid             CHARACTER VARYING(255),
--
insertdatetime                 TIMESTAMP WITH TIME ZONE  DEFAULT CLOCK_TIMESTAMP(),
updatedatetime                 TIMESTAMP WITH TIME ZONE,
isdtable                       TEXT,
isdrecordidentifier            TEXT, 
isdfilename                    TEXT,
isdfileext                     CHARACTER VARYING,
isdfiletitle                   TEXT,
isdfilepath                    TEXT,
isdfileurl                     TEXT, 
isdfiletype                    TEXT, 
isdfileexists                  BOOLEAN,
--
migratedflag                   BOOLEAN,
migrateddate                   TIMESTAMP WITH TIME ZONE, 
migrationmethod                TEXT,
migrationstatus                VARCHAR(2),
migrationcomments              TEXT,
--
fsdobject                      TEXT,
fsdobjectuuid                  UUID,
fsdfilename                    TEXT,
fsdfilepath                    TEXT,
fsdfileurl                     TEXT,
--
PRIMARY KEY (rec_id) 
)
WITH (
    OIDS = FALSE 
    );


ALTER TABLE migrate_isd2fsd.etl_metacard_tracking_list 
    OWNER TO enterprisedb; 


COMMENT ON TABLE migrate_isd2fsd.etl_metacard_tracking_list 
IS 'etl_metacard_tracking_list - <description>';

COMMENT ON COLUMN migrate_isd2fsd.etl_metacard_tracking_list.rec_id 
IS 'rec_id - The unquie durable single field key assigned to the record.';
