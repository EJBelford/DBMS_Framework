﻿/*
* -----------SECURITY CLASSIFICATION: UNCLASSIFIED----------------------------
* 
* Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
* 
* Notwithstanding any contractor copyright notice, the government has
* Unlimited Rights in this work as defined by DFARS 252.227-7013 and
* 252.227-7014. Use of this work other than as specifically authorized by
* these DFARS Clauses may violate government rights in this work.
* 
* DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
* Unlimited Rights. The Government has the right to use, modify,
* reproduce, perform, display, release or disclose this computer software
* in whole or in part, in any manner, and for any purpose whatsoever,
* and to have or authorize others to do so.
* 
* Distribution Statement D. Distribution authorized to the Department of
* Defense and U.S. DoD contractors only in support of US DoD efforts.
* Other requests shall be referred to the ACINT Modernization Program
* Management under the Director of the Office of Naval Intelligence.
* 
* -------------------------------UNCLASSIFIED---------------------------------
*/

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Module Name: etl_process_ref_seq                                           */
/*      Author: Gene Belford                                                  */
/* Description: Creates a sequence number for the table that is assigned      */
/*              to the rec_id each new record is created.                     */
/*        Date: 2016-02-10                                                    */
/* Source File: 071_isd_db_object_facts.sql                                   */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/
/*                                                                            */
/* Change History                                                             */
/* ==============                                                             */
/* Date:       Chng_Ctrl  Name                  Description                   */
/* ==========  =========  ====================  ============================= */
/* 2016-02-10             Gene Belford          Created                       */
/*                                                                            */
/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*/

-- Table: migrate_isd2fsd.isd_db_object_facts

-- DROP TABLE migrate_isd2fsd.isd_db_object_facts;

CREATE TABLE migrate_isd2fsd.isd_db_object_facts
(
  rec_id integer NOT NULL DEFAULT nextval('isd_db_object_facts_seq'::regclass), -- rec_id - The unquie durable single field key assigned to the record.
  row_cnt_date timestamp with time zone NOT NULL DEFAULT clock_timestamp(), -- row_cnt_date -
  schemaname character varying(50) NOT NULL, -- schemaname -
  relname character varying(50) NOT NULL, -- relname -
  indexrelname character varying,
  row_cnt bigint, -- row_cnt -
  etl_entity_cnt bigint,
  etl_linkage_cnt bigint,
  last_updated timestamp with time zone,
  CONSTRAINT isd_db_object_facts_pkey PRIMARY KEY (rec_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE migrate_isd2fsd.isd_db_object_facts
  OWNER TO enterprisedb;
COMMENT ON TABLE migrate_isd2fsd.isd_db_object_facts
  IS 'isd_db_object_facts - Holds the record count for the objects in the system. ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.rec_id IS 'rec_id - The unquie durable single field key assigned to the record.';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.row_cnt_date IS 'row_cnt_date - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.schemaname IS 'schemaname - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.relname IS 'relname - ';
COMMENT ON COLUMN migrate_isd2fsd.isd_db_object_facts.row_cnt IS 'row_cnt - ';

