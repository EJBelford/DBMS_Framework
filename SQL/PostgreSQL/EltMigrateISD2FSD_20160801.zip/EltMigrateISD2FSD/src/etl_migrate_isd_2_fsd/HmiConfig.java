package etl_migrate_isd_2_fsd;

public class HmiConfig {

}
