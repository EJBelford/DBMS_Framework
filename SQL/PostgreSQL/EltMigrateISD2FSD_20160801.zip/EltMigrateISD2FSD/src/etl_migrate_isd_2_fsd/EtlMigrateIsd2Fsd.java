package etl_migrate_isd_2_fsd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;

public class EtlMigrateIsd2Fsd extends JFrame {

	String processName = "EtlMigrateIsd2Fsd";
	
	public static void main(String[] args) {

		String processModule = "main";
		
		EtlMigrateIsd2Fsd etlMigration = new EtlMigrateIsd2Fsd();

		etlMigration.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		etlMigration.pack();
		etlMigration.setVisible(true);

	}

		/***
		 * 
		 */

		public EtlMigrateIsd2Fsd() {
			super("ISD to FSD Migartion Tool");
			
			String processModule = "EtlMigrateIsd2Fsd";
			
			int debugFlag = 0;
			debugFlag = HmiUtilities.getDebugFlag(processName + "_" + processModule);
			
			JTextComponent textArea = createTextComponent();
			
			if (debugFlag > 0) {
				System.out.println("Debug: processName: " + processName + " processModule: " + processModule);
			}
						
			Container content = getContentPane();
			
			content.add(createLabelBar(), BorderLayout.NORTH);
			content.add(textArea, BorderLayout.SOUTH);
						
			setJMenuBar(createMenuBar());
			setSize(600, 400);
		}
		
    // Create the JMenuBar subclass.
		
		protected JMenuBar createMenuBar() {
			
			String processModule = "createMenuBar";
			
			JMenuBar mb = new JMenuBar();
			
			mb.setOpaque(true);
			mb.setBackground(Color.GREEN);
			mb.setPreferredSize(new Dimension(200, 30));
			
			JButton eb0 = new JButton("");
			eb0.setMaximumSize(new Dimension(10, 25));
			eb0.setEnabled(false);
			eb0.setOpaque(false);
			
			mb.add(eb0);
			
			return mb;
		}
		
	// Create the JLable subclass.
		
		protected JLabel createLabelBar() {
			
			String processModule = "createLabelBar";
			
			String etlProcessingServer = "not know";
			
			JLabel label = new JLabel("Processing Server: " + etlProcessingServer);
			
			label.setOpaque(true); 
			label.setBackground(Color.ORANGE);
			label.setPreferredSize(new Dimension(200, 30));
			
			return label;
		}

	// Create the JTextComponent subclass.
		
		protected JTextComponent createTextComponent() {

			String processModule = "createTextBar";
			
			JTextArea ta = new JTextArea();
			
			ta.setBackground(Color.YELLOW);
			ta.setEditable(true);
			ta.setLineWrap(true);
			
			return ta;			
		}

}