package etl_migrate_isd_2_fsd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;

public class EtlMigrateIsd2Fsd extends JFrame {

	String processName = "EtlMigrateIsd2Fsd";

	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		String processModule = "main";

		EtlMigrateIsd2Fsd etlFrame = new EtlMigrateIsd2Fsd();

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		etlFrame.setMinimumSize(new Dimension((int) (dim.width * .75),
				(int) (dim.height * .75)));

		etlFrame.setLocation(dim.width / 2 - etlFrame.getSize().width / 2,
				dim.height / 2 - etlFrame.getSize().height / 2);

		etlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		etlFrame.pack();
		etlFrame.setVisible(true);

		System.out.println("Test output message!");
	}

	/**
		 * 
		 */

	public EtlMigrateIsd2Fsd() {
		super("ISD to FSD Migartion Tool");

		String processModule = "EtlMigrateIsd2Fsd";

		int debugFlag = 0;
		debugFlag = HmiUtilities
				.getDebugFlag(processName + "_" + processModule);

		JTextComponent textArea = createTextComponent();

		JTextArea ta = new JTextArea(40, 50);
		ta.setBackground(Color.white);
		ta.setEditable(false);
		textArea.add(ta);

		PrintStream printStream = new PrintStream(new CustomOutputStream(ta));

		PrintStream standardOut = System.out;
		System.setOut(printStream);

		JTabbedPane tabPane = createTabComponent();

		if (debugFlag > 0) {
			System.out.println("Debug: processName: " + processName
					+ " processModule: " + processModule);
		}

		Container content = getContentPane();

		content.add(createLabelBar(), BorderLayout.NORTH);
		content.add(tabPane, BorderLayout.CENTER);
		content.add(textArea, BorderLayout.SOUTH);

		tabPane.add("System Output", ta);

		tabPane.add("test", x(tabPane));

		tabPane.add("test2", textArea);

		setJMenuBar(createMenuBar());
		setSize(600, 400);
	}

	// Create the JMenuBar subclass.

	protected JMenuBar createMenuBar() {

		String processModule = "createMenuBar";

		JMenuBar mb = new JMenuBar();

		mb.setOpaque(true);
		mb.setBackground(Color.GREEN);
		mb.setPreferredSize(new Dimension(200, 30));

		JButton eb0 = new JButton("");
		eb0.setMaximumSize(new Dimension(10, 25));
		eb0.setEnabled(false);
		eb0.setOpaque(false);

		mb.add(eb0);

		return mb;
	}

	// Create the JLabel subclass.

	protected JLabel createLabelBar() {

		String processModule = "createLabelBar";

		String etlProcessingServer = "not know";

		JLabel label = new JLabel("Processing Server: " + etlProcessingServer);

		label.setOpaque(true);
		label.setBackground(Color.ORANGE);
		label.setPreferredSize(new Dimension(200, 30));

		return label;
	}

	// Create the JTextComponent subclass.

	protected JTextComponent createTextComponent() {

		String processModule = "createTextComponent";

		JTextArea ta = new JTextArea();

		ta.setRows(2);

		ta.setBackground(Color.YELLOW);
		ta.setEditable(true);
		ta.setLineWrap(true);

		return ta;
	}

	// Create the JTabbedPane subclass.

	protected JTabbedPane createTabComponent() {

		String processModule = "createTabComponent";

		JTabbedPane tc = new JTabbedPane();
		add(tc);
		tc.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

		tc.setBackground(Color.CYAN);

		return tc;
	}

	//

	protected JTextArea x(JTabbedPane tab) {
		JTextArea ta = new JTextArea(25, 25);

		ta.setBackground(Color.LIGHT_GRAY);

		return ta;
	}

}