package etl_migrate_isd_2_fsd;

import java.io.InputStream;
import java.util.Properties;

public class HmiUtilities {
	
	static String processName = "HmiUtilities";
	
	static String pathName = "./config/";
	static String fileName = "debug.properties";
	
	public HmiUtilities () {
		// Do nothing
	}
	
	public static int getDebugFlag(String moduleName) {
		
		String processModule = "getDebugFlag";
		
		InputStream debugValues;
		
		Properties prop = new Properties();
		
		int debugFlag = 0;
		
		debugValues = HmiConfig.class.getClassLoader().getResourceAsStream(pathName + fileName);
		
		if (debugValues == null) {
			System.out.println("ERROR_00: " + processName + ": " + processModule);
			return debugFlag;
		}
		
		return debugFlag;
	}
	
}