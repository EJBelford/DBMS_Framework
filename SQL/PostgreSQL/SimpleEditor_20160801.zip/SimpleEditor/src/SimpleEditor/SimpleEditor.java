package SimpleEditor;

// SimpleEditor.java
// An example showing several DefaultEditorKit features. This class is designed
// to be easily extended for additional functionality.
//
import javax.swing.*;
import javax.swing.text.*;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.util.Hashtable;

public class SimpleEditor extends JFrame {

	ImageIcon iconOpen = new ImageIcon("resources/icons/open.png");

	private Action openAction = new OpenAction(iconOpen, KeyEvent.VK_O);
	private Action saveAction = new SaveAction();

	private JTextComponent textComp;
	private Hashtable actionHash = new Hashtable();

	public static void main(String[] args) {
		SimpleEditor editor = new SimpleEditor();
		editor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		editor.setVisible(true);
	}

	// Create an editor.
	public SimpleEditor() {
		super("Swing Editor");
		textComp = createTextComponent();
		makeActionsPretty();

		Container content = getContentPane();
		content.add(textComp, BorderLayout.CENTER);
		content.add(createToolBar(), BorderLayout.NORTH);
		setJMenuBar(createMenuBar());
		setSize(320, 240);
	}

	// Create the JTextComponent subclass.
	protected JTextComponent createTextComponent() {
		JTextArea ta = new JTextArea();
		ta.setLineWrap(true);
		return ta;
	}

	// Add icons and friendly names to actions we care about.
	protected void makeActionsPretty() {
		Action a;
		a = textComp.getActionMap().get(DefaultEditorKit.cutAction);
		a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/cut.png"));
		a.putValue(Action.NAME, "Cut");

		a = textComp.getActionMap().get(DefaultEditorKit.copyAction);
		a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/copy.png"));
		a.putValue(Action.NAME, "Copy");

		a = textComp.getActionMap().get(DefaultEditorKit.pasteAction);
		a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/paste.png"));
		a.putValue(Action.NAME, "Paste");

		a = textComp.getActionMap().get(DefaultEditorKit.selectAllAction);
		a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/selectall.png"));
		a.putValue(Action.NAME, "Select All");
	}

	// Create a simple JToolBar with some buttons.
	protected JToolBar createToolBar() {
		JToolBar bar = new JToolBar();

		// Add simple actions for opening & saving.
		bar.add(getOpenAction()).setText("");
		bar.add(getSaveAction()).setText("");
		bar.addSeparator();

		// Add cut/copy/paste buttons.
		bar.add(textComp.getActionMap().get(DefaultEditorKit.cutAction)).setText("");
		bar.add(textComp.getActionMap().get(
				DefaultEditorKit.copyAction)).setText("");
		bar.add(textComp.getActionMap().get(
				DefaultEditorKit.pasteAction)).setText("");
		return bar;
	}

	// Create a JMenuBar with file & edit menus.
	protected JMenuBar createMenuBar() {
		JMenuBar menubar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);

		JMenu editMenu = new JMenu("Edit");
		editMenu.setMnemonic(KeyEvent.VK_E);

		menubar.add(fileMenu);
		menubar.add(editMenu);

		fileMenu.add(getOpenAction());
		fileMenu.add(getSaveAction());
		fileMenu.addSeparator();
		fileMenu.add(new ExitAction());

		editMenu.add(textComp.getActionMap().get(DefaultEditorKit.cutAction));
		editMenu.add(textComp.getActionMap().get(DefaultEditorKit.copyAction));
		editMenu.add(textComp.getActionMap().get(DefaultEditorKit.pasteAction));
		editMenu.add(textComp.getActionMap().get(DefaultEditorKit.selectAllAction));

		return menubar;
	}

	// Subclass can override to use a different open action.
	protected Action getOpenAction() { return openAction; }

	// Subclass can override to use a different save action.
	protected Action getSaveAction() { return saveAction; }

	protected JTextComponent getTextComponent() { return textComp; }

	// ********** ACTION INNER CLASSES ********** //

	// EXIT 
	// A very simple exit action

	public class ExitAction extends AbstractAction {
		public ExitAction() { super("Exit", new ImageIcon("resources/icons/system-exit.png")); }
		public void actionPerformed(ActionEvent ev) { System.exit(0); }
	}


	// OPEN
	// An action that opens an existing file

	class OpenAction extends AbstractAction {
		public OpenAction(ImageIcon icon, Integer mnemonic) { 
			super("Open", new ImageIcon("resources/icons/open.png")); 

			putValue(SMALL_ICON, icon);
			putValue(MNEMONIC_KEY, mnemonic);
		}

		// Query user for a filename and attempt to open and read the file into the
		// text component.
		public void actionPerformed(ActionEvent ev) {
			JFileChooser chooser = new JFileChooser();
			if (chooser.showOpenDialog(SimpleEditor.this) !=
					JFileChooser.APPROVE_OPTION)
				return;
			File file = chooser.getSelectedFile();
			if (file == null)
				return;

			FileReader reader = null;
			try {
				reader = new FileReader(file);
				textComp.read(reader, null);
			}
			catch (IOException ex) {
				JOptionPane.showMessageDialog(SimpleEditor.this,
						"File Not Found", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException x) {}
				}
			}
		}
	}


	// SAVE 
	// An action that saves the document to a file

	class SaveAction extends AbstractAction {
		public SaveAction() {
			super("Save", new ImageIcon("resources/icons/save.png"));
		}

		// Query user for a filename and attempt to open and write the text
		// component’s content to the file.
		public void actionPerformed(ActionEvent ev) {
			JFileChooser chooser = new JFileChooser();
			if (chooser.showSaveDialog(SimpleEditor.this) !=
					JFileChooser.APPROVE_OPTION)
				return;
			File file = chooser.getSelectedFile();
			if (file == null)
				return;

			FileWriter writer = null;
			try {
				writer = new FileWriter(file);
				textComp.write(writer);
			}
			catch (IOException ex) {
				JOptionPane.showMessageDialog(SimpleEditor.this,
						"File Not Saved", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			finally {
				if (writer != null) {
					try {
						writer.close();
					} catch (IOException x) {}
				}
			}
		}
	}
}
