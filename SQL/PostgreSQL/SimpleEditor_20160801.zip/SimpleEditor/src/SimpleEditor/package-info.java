/**
 * 
 */
/**
 * @author n67154
 *
 */
package SimpleEditor;