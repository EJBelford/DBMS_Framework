create or replace package %YourObjectname% IS
   FUNCTION MyFuncName ( inVal Number ) Return Number;
   PROCEDURE MyProcName ( inVal Number, JobId VARCHAR2 );
--
--
/********************************* TEAM ITSS ***********************************


       NAME:    %YourObjectName%
   
    PURPOSE:    To calculate the desired information.



PARAMETERS::

      INPUT:

     OUTPUT:
 

ASSUMPTIONS:

LIMITATIONS:

      NOTES:

HISTORY of REVISIONS:


  Date     ECP #            Author           Description
---------  ---------------  ---------------  ---------------------------------
%SYSDATE%  CHG00000000000X                   Function Created

******************* TEAM ITSS *************************************************/
--
--
end %YourObjectName%;

/
