create or replace type %YourObjectName% as object
--
--
/********************************* TEAM ITSS ***********************************


       NAME:    %YourObjectName%
   
    PURPOSE:    



PARAMETERS::

      INPUT:

     OUTPUT:
 

ASSUMPTIONS:

LIMITATIONS:

      NOTES:

HISTORY of REVISIONS:


  Date     ECP #            Author           Description
---------  ---------------  ---------------  ---------------------------------
%SYSDATE%  CHG00000000000X                   Function Created





******************* TEAM ITSS *************************************************/
--
--
(
  newattribute varchar2(255),
  member function myfunction(param1 in number) return number,
  member procedure myprocedure(param1 in number)
);
