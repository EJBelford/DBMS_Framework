/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.enums;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCollectorPojo;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author bearyman
 */
public class CollectorEnumHandler extends AbstractEnumHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CollectorEnumHandler.class);
    private static final String GET_ALL_COLLECTOR_SQL = "SELECT * FROM omega.collector";
    private static final String COLLECTOR_NAME = "collectorname";
    private static final String COLLECTOR_TYPE = "collectortype";

    private List<IsdCollectorPojo> mPojos;

    /**
     *
     */
    public CollectorEnumHandler() {
        mPojos = new ArrayList<>();
    }

    @Override
    protected void executeCall() throws DSSPersisterNotInitializedException, SQLException {

        retrieveIsdData();

        for (IsdCollectorPojo pojo: mPojos) {
            createEnums(COLLECTOR_NAME, pojo.getNameCode(), pojo.getName());
            createEnums(COLLECTOR_TYPE, pojo.getTypeCode(), pojo.getType());
        }
    }

    protected void createEnums(String pEnum, String pEnumValue, String pEnumDesc)
            throws DSSPersisterNotInitializedException, SQLException {

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pEnum, DSSConstants.SYSTEM_ACCOUNT);

        if (enumeration != null) {

            // Format enum
            MigrationResult result = new MigrationResult();

            String formattedEnum = formatEnumString(pEnumValue);

            if (validateOnlyFlag) {
                validateEnum(pEnum, pEnumValue, pEnum, formattedEnum);
            } else {

                boolean enumExists = false;
                for (EnumerationValue enumVal: enumeration.getEnumValues()) {
                    if (enumVal.getEnumValue().equals(formattedEnum)) {
                        enumExists = true;
                        break;
                    }
                }
                if (enumExists) {
                    LOGGER.debug(String.format(ENUM_EXISTS_ERR, formattedEnum, pEnum));
                } else {
                    // Add enumeration value to enumeration
                    if (addEnumValue(pEnum, formattedEnum, pEnumDesc)) {
                        EtlUtilitiesDbms.insertClearList(mFsdConn,
                                                         getEnumUUID(pEnum, formattedEnum),
                                                         methodName, mEnumName + "_"
                                                                 + this.getClass().getSimpleName());
                        result.setSaveSuccessful(true);
                        if (!addAssociatedEnumValue(pEnum, formattedEnum, pEnumDesc)) {
                            result.addResult(String.format(ASSOC_ENUM_ADD_FAILED, formattedEnum,
                                                           pEnumDesc));
                        }
                    } else {
                        result.addResult(String.format(ENUM_ADD_FAILED,
                                                       mEnumName.getFsdTableName(), formattedEnum));
                    }
                }
            }
            mResult.addMigrationResult(result);
        } else {
            throw new SQLException(String.format(DSSConstants.ENUMERATION_NOT_FOUND,
                                                 mEnumName.getFsdTableName()));
        }

    }

    protected void retrieveIsdData() throws SQLException {
        methodName = "retrieveIsdData";
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(GET_ALL_COLLECTOR_SQL);

            while (results.next()) {
                IsdCollectorPojo pojo = new IsdCollectorPojo();

                pojo.setName(results.getString("collectorname"));
                pojo.setNameCode(results.getString("collectornamecode"));
                pojo.setType(results.getString("collectortype"));
                pojo.setTypeCode(results.getString("collectortypecode"));

                mPojos.add(pojo);
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

}
