/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdObservedTargetSegmentSummaryPojo {

    private String id;
    private String category;
    private String classification;
    private String country;
    private String flightVariant;
    private Date gainDtg;
    private int hull;
    private Date lostDtg;
    private String name;
    private String pennant;
    private String propulsionPlant;
    private String propulsionType;
    private String type;

    public IsdObservedTargetSegmentSummaryPojo() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category
     *            the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the classification
     */
    public String getClassification() {
        return classification;
    }

    /**
     * @param classification
     *            the classification to set
     */
    public void setClassification(String classification) {
        this.classification = classification;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the flightVariant
     */
    public String getFlightVariant() {
        return flightVariant;
    }

    /**
     * @param flightVariant
     *            the flightVariant to set
     */
    public void setFlightVariant(String flightVariant) {
        this.flightVariant = flightVariant;
    }

    /**
     * @return the gainDtg
     */
    public Date getGainDtg() {
        return gainDtg;
    }

    /**
     * @param gainDtg
     *            the gainDtg to set
     */
    public void setGainDtg(Date gainDtg) {
        this.gainDtg = gainDtg;
    }

    /**
     * @return the hull
     */
    public int getHull() {
        return hull;
    }

    /**
     * @param hull
     *            the hull to set
     */
    public void setHull(int hull) {
        this.hull = hull;
    }

    /**
     * @return the lostDtg
     */
    public Date getLostDtg() {
        return lostDtg;
    }

    /**
     * @param lostDtg
     *            the lostDtg to set
     */
    public void setLostDtg(Date lostDtg) {
        this.lostDtg = lostDtg;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the pennant
     */
    public String getPennant() {
        return pennant;
    }

    /**
     * @param pennant
     *            the pennant to set
     */
    public void setPennant(String pennant) {
        this.pennant = pennant;
    }

    /**
     * @return the propulsionPlant
     */
    public String getPropulsionPlant() {
        return propulsionPlant;
    }

    /**
     * @param propulsionPlant
     *            the propulsionPlant to set
     */
    public void setPropulsionPlant(String propulsionPlant) {
        this.propulsionPlant = propulsionPlant;
    }

    /**
     * @return the propulsionType
     */
    public String getPropulsionType() {
        return propulsionType;
    }

    /**
     * @param propulsionType
     *            the propulsionType to set
     */
    public void setPropulsionType(String propulsionType) {
        this.propulsionType = propulsionType;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

}
