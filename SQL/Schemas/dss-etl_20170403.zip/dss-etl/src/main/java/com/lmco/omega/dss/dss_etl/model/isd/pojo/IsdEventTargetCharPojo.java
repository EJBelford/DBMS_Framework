/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdEventTargetCharPojo {

    private Integer hjid;
    private String masterNumber;
    private String targetClassification;
    private int targetHullNumber;
    private int targetPennant;
    private String targetRole;
    private String targetType;
    private String collectionEventId;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdEventTargetCharPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the hjid
     */
    public Integer getHjid() {
        return hjid;
    }

    /**
     * @param hjid
     *            the hjid to set
     */
    public void setHjid(Integer hjid) {
        this.hjid = hjid;
    }

    /**
     * @return the masterNumber
     */
    public String getMasterNumber() {
        return masterNumber;
    }

    /**
     * @param masterNumber
     *            the masterNumber to set
     */
    public void setMasterNumber(String masterNumber) {
        this.masterNumber = masterNumber;
    }

    /**
     * @return the targetClassification
     */
    public String getTargetClassification() {
        return targetClassification;
    }

    /**
     * @param targetClassification
     *            the targetClassification to set
     */
    public void setTargetClassification(String targetClassification) {
        this.targetClassification = targetClassification;
    }

    /**
     * @return the targetHullNumber
     */
    public int getTargetHullNumber() {
        return targetHullNumber;
    }

    /**
     * @param targetHullNumber
     *            the targetHullNumber to set
     */
    public void setTargetHullNumber(int targetHullNumber) {
        this.targetHullNumber = targetHullNumber;
    }

    /**
     * @return the targetPennant
     */
    public int getTargetPennant() {
        return targetPennant;
    }

    /**
     * @param targetPennant
     *            the targetPennant to set
     */
    public void setTargetPennant(int targetPennant) {
        this.targetPennant = targetPennant;
    }

    /**
     * @return the targetRole
     */
    public String getTargetRole() {
        return targetRole;
    }

    /**
     * @param targetRole
     *            the targetRole to set
     */
    public void setTargetRole(String targetRole) {
        this.targetRole = targetRole;
    }

    /**
     * @return the targetType
     */
    public String getTargetType() {
        return targetType;
    }

    /**
     * @param targetType
     *            the targetType to set
     */
    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    /**
     * @return the collectionEventId
     */
    public String getCollectionEventId() {
        return collectionEventId;
    }

    /**
     * @param collectionEventId
     *            the collectionEventId to set
     */
    public void setCollectionEventId(String collectorId) {
        collectionEventId = collectorId;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

}
