/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl;

/*
 * https://docs.oracle.com/javase/tutorial/uiswing/components/table.html
 */

// JPanels not added to JTabbedPane

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;

public class EtlPaneAssignment extends JPanel {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlPaneAssignment.class);
    /**
 *
 */

    private static final long serialVersionUID = 1L;

    public EtlPaneAssignment() {
        // Does nothing.
    }

    /*
     * etlLoadTable
     */

    public JTable etlLoadTable(JTable sqlTable) {
        DefaultTableModel tableDebugEtl = new DefaultTableModel();

        tableDebugEtl = loadEtlDebugData(tableDebugEtl);

        sqlTable = new JTable(tableDebugEtl);

        sqlTable.setBackground(Color.lightGray);
        sqlTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        sqlTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        setDefaultTableColumnWidth(sqlTable);

        return sqlTable;
    }

    /*
     * Load ETL Tracking Data
     */

    public static DefaultTableModel loadEtlTrackData(DefaultTableModel tableModel) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_tracking_list__file_exists ");
            ResultSetMetaData metaData = rs.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs.getObject(i));
                    LOGGER.debug(rs.getObject(i).toString());
                }
                data.add(vector);
            }

            tableModel.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }

        }
        return tableModel;
    }

    /*
     * Retrieve the ETL processing results
     */

    public static DefaultTableModel loadEtlProcessData(DefaultTableModel tableModel) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs1 =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_process_log__desc ");
            ResultSetMetaData metaData = rs1.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs1.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs1.getObject(i));
                    LOGGER.debug("" + rs1.getObject(i));
                }
                data.add(vector);
            }

            tableModel.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }
        return tableModel;
    }

    /*
     * loadEtlDebugData
     */

    public static DefaultTableModel loadEtlDebugData(DefaultTableModel tableModel) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs1 =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_std_debug__desc ");
            ResultSetMetaData metaData = rs1.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs1.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs1.getObject(i));
                    LOGGER.debug("" + rs1.getObject(i));
                }
                data.add(vector);
            }

            tableModel.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }
        return tableModel;
    }

    /*
     * loadEtlDebugData
     */

    public static DefaultTableModel loadEtlFuncWarnData(DefaultTableModel tableModel) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs1 =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_func_warn_log__desc ");
            ResultSetMetaData metaData = rs1.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs1.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs1.getObject(i));
                    LOGGER.debug("" + rs1.getObject(i));
                }
                data.add(vector);
            }

            tableModel.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }
        return tableModel;
    }

    /**
     * @param loadIsdDbObjectFactsData
     * @return
     */

    public static DefaultTableModel loadIsdDbObjectFactsData(DefaultTableModel tableEtl) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs1 =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_isd_db_object_facts__nonzero ");
            ResultSetMetaData metaData = rs1.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs1.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs1.getObject(i));
                    LOGGER.debug("" + rs1.getObject(i));
                }
                data.add(vector);
            }

            tableEtl.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }

        return tableEtl;
    }

    /**
     * @param linkMatrix
     * @return
     */

    static DefaultTableModel loadLinkMatrix(DefaultTableModel linkMatrix) {
        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

            ResultSet rs1 =
                    connFSDStmt.executeQuery("SELECT * "
                            + "FROM migrate_isd2fsd.etl_coalesce_linkage__matrix ");
            ResultSetMetaData metaData = rs1.getMetaData();

            // Names of columns
            Vector<String> columnNames = new Vector<String>();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
                LOGGER.debug(metaData.getColumnName(i));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<Vector<Object>>();
            while (rs1.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int i = 1; i <= columnCount; i++) {
                    vector.add(rs1.getObject(i));
                    LOGGER.debug("" + rs1.getObject(i));
                }
                data.add(vector);
            }

            linkMatrix.setDataVector(data, columnNames);
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(connFSDStmt);
                EtlUtilitiesDbms.closeConn(connFSD);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }
        return linkMatrix;
    }

    /**
     * makeTextPanel
     */

    protected JComponent makeTextPanel(String text) {
        JPanel panel = new JPanel(false);
        panel.setLayout(new GridLayout(1, 1));

        JLabel filler = new JLabel(text);
        filler.setVerticalAlignment(JLabel.TOP);
        panel.add(filler);
        return panel;
    }

    /**
     * setDefaultTableColumnWidth
     *
     * @param table
     */

    static void setDefaultTableColumnWidth(JTable table) {
        for (int i = 0; i < table.getColumnCount(); i++) {
            DefaultTableColumnModel colModel = (DefaultTableColumnModel) table.getColumnModel();
            TableColumn col = colModel.getColumn(i);
            int width = 0;
            TableCellRenderer renderer = col.getHeaderRenderer();
            if (renderer == null) {
                renderer = table.getTableHeader().getDefaultRenderer();
            }
            Component comp =
                    renderer.getTableCellRendererComponent(table, col.getHeaderValue(), false,
                                                           false, 0, 0);
            width = comp.getPreferredSize().width;
            col.setPreferredWidth(width + 12);
        }
    }
}
