/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdWorkflowInstancePojo {

    private String id;
    private Date creationDate;
    private String creator;
    private String description;
    private Date dueDate;
    private Date endDate;
    private int functionalLeg;
    private String name;
    private String omegaProjectId;
    private String owner;
    private int priority;
    private int processId;
    private Date startDate;
    private int status;
    private boolean validity;
    private String workflowStandardTags;
    private String workflowTemplateId;
    private boolean excludeFromMetrics;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdWorkflowInstancePojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate
     *            the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the creator
     */
    public String getCreator() {
        return creator;
    }

    /**
     * @param creator
     *            the creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the dueDate
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate
     *            the dueDate to set
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the functionalLeg
     */
    public int getFunctionalLeg() {
        return functionalLeg;
    }

    /**
     * @param functionalLeg
     *            the functionalLeg to set
     */
    public void setFunctionalLeg(int functionalLeg) {
        this.functionalLeg = functionalLeg;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the omegaProjectId
     */
    public String getOmegaProjectId() {
        return omegaProjectId;
    }

    /**
     * @param omegaProjectId
     *            the omegaProjectId to set
     */
    public void setOmegaProjectId(String omegaProjectId) {
        this.omegaProjectId = omegaProjectId;
    }

    /**
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * @param owner
     *            the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * @return the priority
     */
    public int getPriority() {
        return priority;
    }

    /**
     * @param priority
     *            the priority to set
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * @return the processId
     */
    public int getProcessId() {
        return processId;
    }

    /**
     * @param processId
     *            the processId to set
     */
    public void setProcessId(int processId) {
        this.processId = processId;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the validity
     */
    public boolean isValidity() {
        return validity;
    }

    /**
     * @param validity
     *            the validity to set
     */
    public void setValidity(boolean validity) {
        this.validity = validity;
    }

    /**
     * @return the workflowStandardTags
     */
    public String getWorkflowStandardTags() {
        return workflowStandardTags;
    }

    /**
     * @param workflowStandardTags
     *            the workflowStandardTags to set
     */
    public void setWorkflowStandardTags(String workflowStandardTags) {
        this.workflowStandardTags = workflowStandardTags;
    }

    /**
     * @return the workflowTemplateId
     */
    public String getWorkflowTemplateId() {
        return workflowTemplateId;
    }

    /**
     * @param workflowTemplateId
     *            the workflowTemplateId to set
     */
    public void setWorkflowTemplateId(String workflowTemplateId) {
        this.workflowTemplateId = workflowTemplateId;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

    /**
     * @return the excludeFromMetrics
     */
    public boolean isExcludeFromMetrics() {
        return excludeFromMetrics;
    }

    /**
     * @param excludeFromMetrics
     *            the excludeFromMetrics to set
     */
    public void setExcludeFromMetrics(boolean excludeFromMetrics) {
        this.excludeFromMetrics = excludeFromMetrics;
    }
}
