/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.DataFormatException;

import org.apache.wss4j.common.principal.SAMLTokenPrincipal;
import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.common.exceptions.CoalesceDataFormatException;
import com.incadencecorp.coalesce.common.helpers.GUIDHelper;
import com.incadencecorp.coalesce.common.helpers.JodaDateTimeHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.incadencecorp.coalesce.framework.validation.CoalesceValidator;
import com.lmco.omega.common.types.classification.EClassification;
import com.lmco.omega.dss.client.api.IMetadataManagerClient;
import com.lmco.omega.dss.client.api.factory.DSSClientFactoryUtil;
import com.lmco.omega.dss.client.api.validators.ValidationUtil;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.DSSServiceSettings;
import com.lmco.omega.dss.common.cache.CoalesceConstraintCache;
import com.lmco.omega.dss.common.configuration.SecuritySettings;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.common.model.BaseFileObject;
import com.lmco.omega.dss.common.model.NonWorkflowEvent;
import com.lmco.omega.dss.common.model.enums.EOperationMode;
import com.lmco.omega.dss.common.model.record.NonWorkflowEventRecord;
import com.lmco.omega.dss.common.model.record.PedigreeEventRecord;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdMandatorySecurityPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkType;

/**
 * @author bearyman
 */
public abstract class AbstractHandler implements Callable<MigrationResult> {

    protected static final String GET_RECORD_SQL =
            "SELECT t1.* FROM omega.%s t1 WHERE t1.%s = '%s'";
    protected static final String PEDIGREE_SAVE_FAILED =
            "Failed to save pedigree information for data object (%s). Reason: %s";
    protected static final String LINK_FAILED =
            "Failed to link %s object (%s) to %s object (%s). Reason: %s";
    protected static final String NO_PARENT_ID = "Parent ID not set for %s in the %s record.";
    protected static final String NULL_EMPTY_KEY = "Key is null or empty.";

    protected static Map<String, String> mWfa2PedigreeMap = new HashMap<>();

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            AbstractHandler.class);
    private static final String CLASSIFIED_BY = "THOMAS_DONNELLY";

    protected String mKey;
    protected String mEntityKey;
    protected String methodName;
    protected String migrationTag;
    protected Boolean validationMode;
    protected MigrationResult mResult;
    protected Connection mIsdConn;
    protected Connection mFsdConn;
    protected NonWorkflowEvent pedigreeEvent;

    protected IMetadataManagerClient mmClient;

    protected SAMLTokenPrincipal principal;

    @Override
    public MigrationResult call() {
        LOGGER.trace("In call");

        mResult = new MigrationResult();
        mResult.setRecordId(mKey);

        migrationTag = "";
        String migrationTagFlag = EtlUtilities.getEtlConfigValue("migrationTagFlag");
        if (!StringHelper.isNullOrEmpty(migrationTagFlag) && migrationTagFlag.equals("1")) {
            migrationTag = " (ETL_ISD_" + getTableType().toString() + ")";
        }
        LOGGER.trace(migrationTag);

        validationMode = false;
        String validateVal = EtlUtilities.getEtlConfigValue("validationMode").toLowerCase();
        if (!StringHelper.isNullOrEmpty(validateVal) && validateVal.equals("true")) {
            validationMode = true;
        }
        LOGGER.trace(validationMode.toString());

        try {

            methodName = "getMetadataManagerClient";
            mmClient = DSSClientFactoryUtil.getMetadataManagerClient(null);
            mmClient.setCredentials(DSSConstants.SYSTEM_PRINCIPAL);
            LOGGER.trace(methodName);
            methodName = "getISDConnection";
            mIsdConn = EtlUtilitiesDbms.getISDConnection();
            LOGGER.trace(methodName);
            methodName = "getFSDConnection";
            try {
                mFsdConn = EtlUtilitiesDbms.getFSDConnection();
                LOGGER.trace(methodName);
            } catch (SQLException e) {
                if (!validationMode) {
                    throw new SQLException(e);
                }
            }

            executeCall();
            LOGGER.trace("Execution complete");

        } catch (Exception e1) {
            LOGGER.trace("Exception occurred: " + e1.getMessage());
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, methodName, e1.getMessage());

            LOGGER.error(errMsg, e1);
            mResult.addResult(errMsg);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(mIsdConn);
                EtlUtilitiesDbms.closeConn(mFsdConn);
            } catch (SQLException e) {
                String errMsg =
                        String.format(DSSConstants.EXCEPTION_OCCURRED, "close connections",
                                      e.getMessage());

                LOGGER.error(errMsg, e);
            }
        }

        return mResult;
    }

    protected void retrieveIsdData() throws Exception {
        methodName = "retrieveIsdData";
        LOGGER.trace(methodName);
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            results =
                    stmt.executeQuery(String.format(GET_RECORD_SQL, getTableType().getTableName(),
                                                    getTableType().getPrimaryKey(), mKey));
            handleIsdResults(results);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    protected void setMandatorySecurity(ResultSet pResults, IsdMandatorySecurityPojo pSecurity)
            throws Exception {
        methodName = "setMandatorySecurity";
        LOGGER.trace(methodName);

        pSecurity.setMandatorySecurity_c0(pResults.getString("mandatorymetadata_security_c_0"));
        pSecurity.setMandatorySecurity_c1(pResults.getString("mandatorymetadata_security_c_1"));
        pSecurity.setMandatorySecurity_c2(pResults.getString("mandatorymetadata_security_c_2"));
        pSecurity.setMandatorySecurity_d0(pResults.getString("mandatorymetadata_security_d_0"));
        pSecurity.setMandatorySecurity_d1(pResults.getString("mandatorymetadata_security_d_1"));
        pSecurity.setMandatorySecurity_d2(pResults.getString("mandatorymetadata_security_d_2"));
        pSecurity.setMandatorySecurity_d3(pResults.getString("mandatorymetadata_security_d_3"));
        pSecurity.setMandatorySecurity_d4(pResults.getString("mandatorymetadata_security_d_4"));
        pSecurity.setMandatorySecurity_d5(pResults.getBoolean("mandatorymetadata_security_d_5"));
        pSecurity.setMandatorySecurity_d6(pResults.getTimestamp("mandatorymetadata_security_d_6"));
        pSecurity.setMandatorySecurity_d7(pResults.getTimestamp("mandatorymetadata_security_d_7"));
        pSecurity.setMandatorySecurity_f0(pResults.getString("mandatorymetadata_security_f_0"));
        pSecurity.setMandatorySecurity_f1(pResults.getString("mandatorymetadata_security_f_1"));
        pSecurity.setMandatorySecurity_n0(pResults.getString("mandatorymetadata_security_n_0"));
        pSecurity.setMandatorySecurity_o0(pResults.getString("mandatorymetadata_security_o_0"));
        pSecurity.setMandatorySecurity_r0(pResults.getString("mandatorymetadata_security_r_0"));
        pSecurity.setMandatorySecurity_s0(pResults.getString("mandatorymetadata_security_s_0"));
        pSecurity.setMandatorySecurity_s1(pResults.getString("mandatorymetadata_security_s_1"));
        pSecurity.setMandatorySecurity_t0(pResults.getString("mandatorymetadata_security_t_0"));
    }

    protected void setCoalesceSecurity(IsdMandatorySecurityPojo pojo, BaseDataObject pCoalesce) {
        methodName = "setCoalesceSecurity";
        LOGGER.trace(methodName);

        if (pojo.getMandatorySecurity_c0() != null) {
            if (pojo.getMandatorySecurity_c0().equals("U")
                    || pojo.getMandatorySecurity_c0().equals("u")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.UNCLASSIFIED);
            } else if (pojo.getMandatorySecurity_c0().equals("R")
                    || pojo.getMandatorySecurity_c0().equals("r")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.RESTRICTED);
            } else if (pojo.getMandatorySecurity_c0().equals("C")
                    || pojo.getMandatorySecurity_c0().equals("c")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.CONFIDENTIAL);
            } else if (pojo.getMandatorySecurity_c0().equals("S")
                    || pojo.getMandatorySecurity_c0().equals("s")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.SECRET);
            } else if (pojo.getMandatorySecurity_c0().equals("TS")
                    || pojo.getMandatorySecurity_c0().equals("ts")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.TOP_SECRET);
            }
        } else {
            pCoalesce.getSecurityRecord().setClassification(EClassification.UNCLASSIFIED);
        }

        pCoalesce.getSecurityRecord().setClassificationReason(pojo.getMandatorySecurity_c2());
        pCoalesce.getSecurityRecord().setClassifiedBy(CLASSIFIED_BY);
        // pCoalesce.getSecurityRecord().setClassifiedBy(pojo.getMandatorySecurity_c1());
        pCoalesce.getSecurityRecord().setDateOfExemptedSource(pojo.getMandatorySecurity_d7());
        pCoalesce.getSecurityRecord().setDeclassificationDate(pojo.getMandatorySecurity_d6());
        pCoalesce.getSecurityRecord().setDeclassificationEvent(pojo.getMandatorySecurity_d3());
        pCoalesce.getSecurityRecord().setDeclassificationExemption(pojo.getMandatorySecurity_d4());
        pCoalesce.getSecurityRecord()
                .setDeclassificationManualReview(pojo.getMandatorySecurity_d5());
        pCoalesce.getSecurityRecord().setDerivativelyClassifiedBy(pojo.getMandatorySecurity_d1());
        pCoalesce.getSecurityRecord().setDerivedFrom(pojo.getMandatorySecurity_d2());
        pCoalesce.getSecurityRecord().setDisseminationControls(pojo.getMandatorySecurity_d0());
        pCoalesce.getSecurityRecord().setFGISourceOpen(pojo.getMandatorySecurity_f0());
        pCoalesce.getSecurityRecord().setFGISourceProtected(pojo.getMandatorySecurity_f1());
        pCoalesce.getSecurityRecord().setNonICMarkings(pojo.getMandatorySecurity_n0());
        pCoalesce.getSecurityRecord().setOwnerProducer(pojo.getMandatorySecurity_o0());
        pCoalesce.getSecurityRecord().setReleasableTo(pojo.getMandatorySecurity_r0());
        pCoalesce.getSecurityRecord().setSARIdentifier(pojo.getMandatorySecurity_s1());

        // TODO REMOVE THIS vvv

        if (pojo.getMandatorySecurity_s0() != null && pojo.getMandatorySecurity_s0().equals("TEST")) {
            pCoalesce.getSecurityRecord().setSCIControls("");
        } else {
            pCoalesce.getSecurityRecord().setSCIControls(pojo.getMandatorySecurity_s0());
        }
        // ^^^
        pCoalesce.getSecurityRecord().setTypeOfExemptedSource(pojo.getMandatorySecurity_t0());
    }

    protected void setCoalesceSecuritySystemHigh(BaseDataObject pCoalesce) {
        methodName = "setCoalesceSecuritySystemHigh";
        LOGGER.trace(methodName);

        if (SecuritySettings.getSHClassification() != null) {
            if (SecuritySettings.getSHClassification().equals("U")
                    || SecuritySettings.getSHClassification().equals("u")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.UNCLASSIFIED);
            } else if (SecuritySettings.getSHClassification().equals("R")
                    || SecuritySettings.getSHClassification().equals("r")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.RESTRICTED);
            } else if (SecuritySettings.getSHClassification().equals("C")
                    || SecuritySettings.getSHClassification().equals("c")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.CONFIDENTIAL);
            } else if (SecuritySettings.getSHClassification().equals("S")
                    || SecuritySettings.getSHClassification().equals("s")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.SECRET);
            } else if (SecuritySettings.getSHClassification().equals("TS")
                    || SecuritySettings.getSHClassification().equals("ts")) {
                pCoalesce.getSecurityRecord().setClassification(EClassification.TOP_SECRET);
            }
        } else {
            pCoalesce.getSecurityRecord().setClassification(EClassification.UNCLASSIFIED);
        }

        pCoalesce.getSecurityRecord().setACCMControls(SecuritySettings.getSHAccmControls());
        pCoalesce.getSecurityRecord().setClassificationReason(SecuritySettings
                                                                      .getSHClassificationReason());
        if (!StringHelper.isNullOrEmpty(SecuritySettings.getSHDerivativelyClassifiedBy())) {
            pCoalesce.getSecurityRecord()
                    .setDerivativelyClassifiedBy(SecuritySettings.getSHDerivativelyClassifiedBy());
        } else {
            pCoalesce.getSecurityRecord().setDerivativelyClassifiedBy(DSSConstants.SYSTEM_ACCOUNT);
        }
        pCoalesce.getSecurityRecord()
                .setDeclassificationEvent(SecuritySettings.getSHDeclassificationEvent());
        pCoalesce.getSecurityRecord()
                .setDeclassificationExemption(SecuritySettings.getSHDeclassificationExemption());
        pCoalesce.getSecurityRecord()
                .setDeclassificationManualReview(SecuritySettings
                                                         .getSHDeclassificationManualReview());
        pCoalesce.getSecurityRecord().setClassifiedBy(SecuritySettings.getSHClassifiedBy());
        pCoalesce.getSecurityRecord().setDerivedFrom(SecuritySettings.getSHDerivedFrom());
        pCoalesce.getSecurityRecord()
                .setDisseminationControls(SecuritySettings.getSHDisseminationControls());
        pCoalesce.getSecurityRecord().setFGISourceOpen(SecuritySettings.getSHFgiSourceOpen());
        pCoalesce.getSecurityRecord().setFGISourceProtected(SecuritySettings
                                                                    .getSHFgiSourceProtected());
        pCoalesce.getSecurityRecord().setNonICMarkings(SecuritySettings.getSHNonIcMarkings());
        pCoalesce.getSecurityRecord().setOwnerProducer(SecuritySettings.getSHOwnerProducer());
        pCoalesce.getSecurityRecord().setReleasableTo(SecuritySettings.getSHReleasableTo());
        pCoalesce.getSecurityRecord().setSAPControls(SecuritySettings.getSHSapControls());
        pCoalesce.getSecurityRecord().setSARIdentifier(SecuritySettings.getSHSarControls());
        pCoalesce.getSecurityRecord().setSCIControls(SecuritySettings.getSHSciControls());
        pCoalesce.getSecurityRecord().setTypeOfExemptedSource(SecuritySettings
                                                                      .getSHTypeOfExemptedSource());

        DateTime date = JodaDateTimeHelper.nowInUtc();

        pCoalesce.getSecurityRecord()
                .setDateOfExemptedSource(new Date(SecuritySettings.getSHDateOfExemptedSource(date)
                                                 .getMillis()));
        pCoalesce.getSecurityRecord()
                .setDeclassificationDate(new Date(SecuritySettings.getSHDeclassificationDate(date)
                                                 .getMillis()));
    }

    protected String setCoalesceKey(CoalesceEntity pCoalesce, String pKey) {

        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(pCoalesce);
        cEntity.setKey(convertIsdKeyToUUID(pKey));
        return cEntity.getKey();
    }

    protected String convertIsdKeyToUUID(String pKey) {

        StringBuffer guid = new StringBuffer(pKey);
        if (!GUIDHelper.isValid(pKey)) {
            guid.insert(8, "-");
            guid.insert(13, "-");
            guid.insert(18, "-");
            guid.insert(23, "-");
        }

        if (!GUIDHelper.isValid(guid.toString())) {
            LOGGER.error("INVALID KEY: " + guid.toString(), null);
        }

        return guid.toString();
    }

    protected void validateEntity(CoalesceEntity pEntity) {
        try {
            // Validate
            CoalesceValidator validator = new CoalesceValidator();

            Map<String, String> results =
                    validator.validate(null, pEntity,
                                       CoalesceConstraintCache.getCoalesceConstraints(pEntity));
            if (!results.isEmpty()) {
                mResult.addResult(ValidationUtil.createErrorMessage(results));
            } else {
                mResult.setSaveSuccessful(true);
            }
        } catch (CoalesceDataFormatException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "validateEntity", e.getMessage());
            mResult.addResult(errMsg);
            LOGGER.error(errMsg, e);
        }
    }

    protected boolean saveEntity(CoalesceEntity pEntity) throws Exception {
        methodName = "saveEntity";
        LOGGER.trace(methodName);

        boolean success = false;
        if (pEntity instanceof BaseFileObject) {
            success =
                    CoalesceFrameworkUtil.saveCoalesceEntity(DSSConstants.SYSTEM_ACCOUNT, pEntity);
        } else if (pEntity instanceof BaseDataObject) {
            BaseDataObject entity = (BaseDataObject) pEntity;
            if (CoalesceFrameworkUtil.coalesceEntityExists(entity.getKey())) {
                success = mmClient.updateDataObject(entity);
            } else {
                success = mmClient.createDataObject(entity);
            }
        } else {
            success =
                    CoalesceFrameworkUtil.saveCoalesceEntity(DSSConstants.SYSTEM_ACCOUNT, pEntity);
        }

        if (success) {
            EtlUtilitiesDbms
                    .insertClearList(mFsdConn, pEntity.getKey(), getTableType().toString(),
                                     getTableType() + "_" + this.getClass().getSimpleName());
            mResult.setSaveSuccessful(true);
        } else {
            if (pEntity instanceof BaseDataObject) {
                String errMsg = DSSConstants.SAVE_FAILED + " Reason: %s";
                mResult.addResult(String.format(errMsg, pEntity.getKey(),
                                                mmClient.getLastResult()[0].getResult()));
            } else {
                mResult.addResult(String.format(DSSConstants.SAVE_FAILED, pEntity.getKey()));
            }
        }
        return success;
    }

    protected boolean saveEntityWithoutValidation(CoalesceEntity pEntity) throws Exception {

        boolean success =
                CoalesceFrameworkUtil.saveCoalesceEntity(DSSConstants.SYSTEM_ACCOUNT, pEntity);

        if (success) {
            EtlUtilitiesDbms
                    .insertClearList(mFsdConn, pEntity.getKey(), getTableType().toString(),
                                     getTableType() + "_" + this.getClass().getSimpleName());
        } else {
            mResult.addResult(String.format(DSSConstants.SAVE_FAILED, pEntity.getKey()));
        }

        return success;
    }

    protected void createPedigree() {
        pedigreeEvent = new NonWorkflowEvent();
        pedigreeEvent.initialize();

        PedigreeEventRecord pedigreeRecord = pedigreeEvent.getPedigreeRecord();
        pedigreeRecord.setOperationMode(EOperationMode.MANUAL);
        // TODO Replace with correct enum
        pedigreeRecord.setOperation("OPERATION_1");

        NonWorkflowEventRecord record = pedigreeEvent.getNonWorkflowRecord();
        record.setComments(getTableType().toString() + "_MIGRATION_ISD_2_FSD");
        record.setEventStart(JodaDateTimeHelper.nowInUtcAsDate());
        record.setOperationSoftwareComponent(getTableType().toString() + "_MIGRATION_ISD_2_FSD");
        record.setUserId(DSSServiceSettings.getRenewer());
    }

    protected void savePedigree(String pEntityKey) {
        methodName = "createPedigree";
        LOGGER.trace(methodName);

        pedigreeEvent.getNonWorkflowRecord().setEventEnd(JodaDateTimeHelper.nowInUtcAsDate());
        pedigreeEvent.addOutput(UUID.fromString(pEntityKey), 1);

        try {
            if (mmClient.createPedigreeEvent(pedigreeEvent)) {
                EtlUtilitiesDbms.insertClearList(mFsdConn, pedigreeEvent.getKey(), methodName,
                                                 getTableType() + "_"
                                                         + this.getClass().getSimpleName());
            } else {
                String errMsg =
                        String.format(PEDIGREE_SAVE_FAILED, pedigreeEvent.getOutputIDs()[0],
                                      mmClient.getLastResult()[0].getResult());
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }
        } catch (RemoteException | SQLException | DataFormatException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "createPedigree", e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        }
    }

    protected void linkEntities(String pKey1, String pKey2, ELinkType pLinkType, String pLabel,
            DataObjectLinkActionType pLinkAction) throws IOException {
        methodName = "linkEntities";
        LOGGER.trace(methodName);
        LOGGER.debug("Linking " + pKey1 + " to " + pKey2 + " with link type " + pLinkType
                + " and label " + pLabel);

        if (!StringHelper.isNullOrEmpty(pKey1) && !StringHelper.isNullOrEmpty(pKey2)) {
            String key1;
            String key2;

            if (GUIDHelper.isValid(pKey1)) {
                key1 = pKey1;
            } else {
                key1 = convertIsdKeyToUUID(pKey1);
            }

            if (GUIDHelper.isValid(pKey2)) {
                key2 = pKey2;
            } else {
                key2 = convertIsdKeyToUUID(pKey2);
            }

            DataObjectLinkType linkType = new DataObjectLinkType();
            linkType.setDataObjectKeySource(key1);
            linkType.setDataObjectKeyTarget(key2);
            linkType.setLinkType(pLinkType);
            linkType.setLabel(pLabel);
            linkType.setAction(pLinkAction);

            if (!mmClient.updateLinkages(linkType)) {
                String errMsg =
                        String.format(LINK_FAILED, getTableType().getTableName(), key1, pLabel,
                                      key2, mmClient.getLastResult()[0].getResult());
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }
        } else {
            String errMsg =
                    String.format(LINK_FAILED, getTableType().getTableName(), pKey1, pLabel, pKey2,
                                  NULL_EMPTY_KEY);
            LOGGER.error(errMsg, null);
            mResult.addResult(errMsg);
        }
    }

    protected ResultSet setSecurityWithParentRecord(EIsdTableNames pTable, String pKey,
            IsdMandatorySecurityPojo pPojo) throws Exception {
        methodName = "setSecurityWithParentRecord";

        ResultSet results = null;

        if (!StringHelper.isNullOrEmpty(pKey)) {
            Statement stmt = null;
            try {
                stmt = mIsdConn.createStatement();

                results =
                        stmt.executeQuery(String.format(GET_RECORD_SQL, pTable.getTableName(),
                                                        pTable.getPrimaryKey(), pKey));

                while (results.next()) {
                    setMandatorySecurity(results, pPojo);
                }
            } finally {
                if (stmt != null) {
                    stmt.close();
                }
            }
        } else {
            throw new SQLException(String.format(NO_PARENT_ID, pTable.getTableName(),
                                                 getTableType().getTableName()));
        }
        return results;
    }

    protected String formatEnumFieldVal(String pEnumStr) {
        String formattedEnum = pEnumStr;
        if (!StringHelper.isNullOrEmpty(formattedEnum)) {
            formattedEnum = formattedEnum.replaceAll("[()]", "");
            formattedEnum = formattedEnum.replaceAll("[^a-zA-Z0-9]", "_");
            formattedEnum = formattedEnum.replaceAll("[\\s]+", "_");
            formattedEnum = formattedEnum.replaceAll("[_]+", "_").toUpperCase();

            if (formattedEnum.endsWith("_")) {
                formattedEnum.substring(0, formattedEnum.length() - 1);
            }
        }
        return formattedEnum;
    }

    protected String formatPlatformTypeEnumFieldVal(String pEnumStr) {
        String formattedEnum = pEnumStr;
        if (!StringHelper.isNullOrEmpty(formattedEnum)) {
            Pattern pat = Pattern.compile("[A-Z]+");
            Matcher mat = pat.matcher(formattedEnum);

            if (mat.find()) {
                formattedEnum = pEnumStr.substring(0, mat.end());
            }
        }
        return formattedEnum;
    }

    protected abstract void executeCall() throws Exception;

    protected abstract void handleIsdResults(ResultSet results) throws Exception;

    protected abstract CoalesceEntity mapToCoalesce() throws Exception;

    protected abstract void createLinkages() throws Exception;

    protected abstract EIsdTableNames getTableType();
}
