/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.enums;

/**
 * @author bearyman
 */
public enum EIsdFileDescriptiveMetadataTypes {
    AUXILIARY_SUPPORT("auxiliarysupport_filedescrip_0"),
    BTR("btr_filedescriptivemetadata__0"),
    CGRAM("cgram_filedescriptivemetadat_0"),
    FAN_OF_BEAMS("fanofbeams_filedescriptiveme_0"),
    FILE_DESCRIPTIVE_METADATA("filedescriptivemetadataid"),
    GRAM("gram_filedescriptivemetadata_0"),
    HORIZONTAL_MEASUREMENTS("horizontalmeasurements_filed_0"),
    HTML_AND_PNG("htmlandpng_filedescriptiveme_0"),
    MS_OFFICE_DOC("msofficedocument_filedescri0"),
    NAD("nad_filedescriptivemetadata__0"),
    PSD("psd_filedescriptivemetadata__0"),
    SENSOR_IDENTIFICATION("sensoridentification_filedes_0"),
    SGRM("sgrm_filedescriptivemetadata_0"),
    SUMMARY_SPL("summaryspl_filedescriptiveme_0"),
    SWIMS_EXPORT_XML("swimsexportxml_filedescripti_0"),
    TAPP_XML("tappxml_filedescriptivemetad_0"),
    TARGET_TRACK_SOLUTION("targettracksolution_filedesc_0"),
    TIME_SERIES("timeseries_filedescriptiveme_0"),
    TPS_BEARING("tpsbearing_filedescriptiveme_0"),
    TPS_SOUND_SPEED("tpssoundspeed_filedescriptiv_0"),
    TPS_TIMESTAMP("tpstimestamp_filedescriptive_0"),
    VERTICAL_MEASUREMENTS("verticalmeasurements_filedes_0"),
    WAVFILE("wavfile_filedescriptivemetad_0");

    private String fieldName;

    private EIsdFileDescriptiveMetadataTypes(String pFieldName) {
        fieldName = pFieldName;
    }

    public String getFieldName() {
        return fieldName;
    }
}
