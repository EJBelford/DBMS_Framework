/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author n67154 (Gene Belford - InCadence)
 */

public class PlatformClassHashMap {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            PlatformClassHashMap.class);
    private static final String GET_PLATFORM_CLASS = "SELECT entitykey, classificationname "
            + "FROM coalesce.platform_class_record;";
    private static final String PLAT_CLASS_NAME = "platformclassname";

    private HashMap<Integer, String> platformClassCache = new HashMap<Integer, String>();

    private ResultSet iResults;

    private String methodName = null;

    public PlatformClassHashMap() throws SQLException {
        retrieveFsdRecs();
    }

    public String getPlatformClassKey(String pPlatformClassName)
            throws DSSPersisterNotInitializedException {
        String mEntityKey = null;

        mEntityKey = platformClassCache.get(convertClassName(pPlatformClassName));

        return mEntityKey;
    }

    private int convertClassName(String pPlatformClassName)
            throws DSSPersisterNotInitializedException {
        int orderingNum = -1;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(PLAT_CLASS_NAME, DSSConstants.SYSTEM_ACCOUNT);

        if (enumeration != null) {

            for (EnumerationValue enumVal: enumeration.getEnumValues()) {
                if (enumVal.getEnumValue().equals(pPlatformClassName)) {
                    orderingNum = enumVal.getOrdering();
                    break;
                }
            }
        }
        return orderingNum;
    }

    private void retrieveFsdRecs() throws SQLException {
        methodName = "retrieveIsdRecs";

        int rowCnt = 0;
        Connection mFsdConn = null;
        Statement stmt = null;

        LOGGER.trace("PlatformClassHashMap" + "_" + methodName + ": #: Start");

        try {
            mFsdConn = EtlUtilitiesDbms.getFSDConnection();
            stmt = mFsdConn.createStatement();
            iResults = stmt.executeQuery(GET_PLATFORM_CLASS);
            handleFsdResults(iResults);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (mFsdConn != null) {
                EtlUtilitiesDbms.closeConn(mFsdConn);
            }
        }
        LOGGER.trace("PlatformClassHashMap" + "_" + methodName + ": #: Stop");
    }

    private void handleFsdResults(ResultSet pResults) throws SQLException {
        methodName = "handleIsdResults";

        String mEntityKey;
        int mClassificationName;

        int recLoop = 0;

        while (pResults.next()) {
            recLoop++;

            mEntityKey = pResults.getString("entitykey");
            mClassificationName = pResults.getInt("classificationname");

            platformClassCache.put(mClassificationName, mEntityKey);
            platformClassCache.get(mClassificationName);

            LOGGER.debug("PlatformClassHashMap" + "_" + methodName + ": #: " + recLoop
                    + " mEntityKey: " + mEntityKey + " mClassificationName: " + mClassificationName);
            LOGGER.debug("PlatformClassHashMap" + "_" + methodName + ": #: " + recLoop
                    + " platformClassCache.get: " + platformClassCache.get(mClassificationName));
        }
    }
}
