/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;

/**
 * @author n67154
 */

/*
 * http://www.mkyong.com/java/java-properties-file-examples/
 */

public class EtlConfiguration {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlConfiguration.class);

    static void etlConfigWrite() {

        Properties prop = new Properties();
        OutputStream output = null;

        String pathname =
                "/home/evans_home/n67154/luna_gwt_workspace/etl_migrate_isd2fsd/src.main.resources/";
        String filename = "etlConfig.properties";

        try {
            LOGGER.debug("DEBUG_0 Java: etl_configuration Write");

            output = new FileOutputStream(pathname + filename);

            // set the property values
            prop.setProperty("isdDBMS", "jdbc:postgresql://10.0.51.82:5444/OMEGA");
            prop.setProperty("isdDBMSuser", "enterprisedb");
            prop.setProperty("isdDBMSpw", "p");

            prop.setProperty("isdGPFSpath", "../../../..");
            prop.setProperty("fsdNearOnline", "../../../..");
            prop.setProperty("omegaFS", "../../../..");

            prop.setProperty("debug", "-3");

            prop.store(output, null);
        } catch (IOException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access output stream",
                                       e.getMessage()), e);
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                               "close output stream", e.getMessage()), e);
                }
            }
        }
    }

    static void etlConfigRead() {
        LOGGER.debug("DEBUG_0 Java: etl_configuration Read");
    }

    public static InputStream getEtlConfigValues() {

        String pathname = "";
        String filename = "etlConfig.properties";
        URL urlname = EtlConfiguration.class.getResource("/");

        InputStream configValues = null;

        // InputStream configValues;
        Properties prop = new Properties();

        Boolean fileExistsBool = false;

        try {
            LOGGER.debug("DEBUG_0 Java: etl_configuration Get");
            LOGGER.debug("DEBUG_0 ========================");
            LOGGER.debug("DEBUG_0 " + pathname);
            LOGGER.debug("DEBUG_0 " + filename);
            fileExistsBool = new File(pathname + filename).isFile();
            LOGGER.debug("DEBUG_0 File exisits: " + fileExistsBool);
            LOGGER.debug("DEBUG_0 " + urlname);
            LOGGER.debug("DEBUG_0 " + pathname);
            LOGGER.debug("DEBUG_0 ========================");

            configValues =
                    EtlConfiguration.class.getClassLoader()
                            .getResourceAsStream(pathname + filename);
            if (configValues == null) {
                LOGGER.error("ERROR Sorry, unable to find " + pathname + filename);
                return configValues;
            }

            prop.load(configValues);

            LOGGER.debug("DEBUG_0 " + configValues);

            Enumeration<?> e = prop.propertyNames();
            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                String value = prop.getProperty(key);
                LOGGER.debug("Key: " + key + ", Value: " + value);
            }
        } catch (IOException ex) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "load properties",
                                       ex.getMessage()), ex);
        } finally {
            if (configValues != null) {
                try {
                    configValues.close();
                } catch (IOException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                               "close input stream", e.getMessage()), e);
                }
            }
        }
        return configValues;
    }

    static void ReadFileExample() {

        File file =
                new File(
                        "/home/evans_home/n67154/luna_gwt_workspace/etl_migrate_isd2fsd/src.main.resources/etlConfig.properties");
        FileInputStream fis = null;

        try {
            fis = new FileInputStream(file);

            LOGGER.debug("Total file size to read (in bytes) : " + fis.available());

            int content;
            while ((content = fis.read()) != -1) {
                // convert to char and display it
                LOGGER.debug("" + (char) content);
            }
        } catch (IOException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access file input stream",
                                       e.getMessage()), e);
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (IOException ex) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                           "close file input stream", ex.getMessage()), ex);
            }
        }
    }
}
