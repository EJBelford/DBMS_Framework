/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdWorkflowActivityInstancePojo {

    private String id;
    private int activityOrder;
    private Date actualEndDate;
    private Date actualStartDate;
    private String applicationToLaunch;
    private String assignee;
    private int functionalLeg;
    private Date dueDate;
    private int status;
    private Integer workItemId;
    private String workflowActivityTemplateId;
    private String workflowActivityTemplateName;
    private Integer casingInfo;
    private String workflowInstanceId;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdWorkflowActivityInstancePojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the activityOrder
     */
    public int getActivityOrder() {
        return activityOrder;
    }

    /**
     * @param activityOrder
     *            the activityOrder to set
     */
    public void setActivityOrder(int activityOrder) {
        this.activityOrder = activityOrder;
    }

    /**
     * @return the actualEndDate
     */
    public Date getActualEndDate() {
        return actualEndDate;
    }

    /**
     * @param actualEndDate
     *            the actualEndDate to set
     */
    public void setActualEndDate(Date actualEndDate) {
        this.actualEndDate = actualEndDate;
    }

    /**
     * @return the actualStartDate
     */
    public Date getActualStartDate() {
        return actualStartDate;
    }

    /**
     * @param actualStartDate
     *            the actualStartDate to set
     */
    public void setActualStartDate(Date actualStartDate) {
        this.actualStartDate = actualStartDate;
    }

    /**
     * @return the applicationToLaunch
     */
    public String getApplicationToLaunch() {
        return applicationToLaunch;
    }

    /**
     * @param applicationToLaunch
     *            the applicationToLaunch to set
     */
    public void setApplicationToLaunch(String applicationToLaunch) {
        this.applicationToLaunch = applicationToLaunch;
    }

    /**
     * @return the assignee
     */
    public String getAssignee() {
        return assignee;
    }

    /**
     * @param assignee
     *            the assignee to set
     */
    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    /**
     * @return the functionalLeg
     */
    public int getFunctionalLeg() {
        return functionalLeg;
    }

    /**
     * @param functionalLeg
     *            the functionalLeg to set
     */
    public void setFunctionalLeg(int functionalLeg) {
        this.functionalLeg = functionalLeg;
    }

    /**
     * @return the dueDate
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate
     *            the dueDate to set
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the workItemId
     */
    public Integer getWorkItemId() {
        return workItemId;
    }

    /**
     * @param workItemId
     *            the workItemId to set
     */
    public void setWorkItemId(Integer workItemId) {
        this.workItemId = workItemId;
    }

    /**
     * @return the workflowActivityTemplateId
     */
    public String getWorkflowActivityTemplateId() {
        return workflowActivityTemplateId;
    }

    /**
     * @param workflowActivityTemplateId
     *            the workflowActivityTemplateId to set
     */
    public void setWorkflowActivityTemplateId(String workflowActivityTemplateId) {
        this.workflowActivityTemplateId = workflowActivityTemplateId;
    }

    /**
     * @return the workflowActivityTemplateName
     */
    public String getWorkflowActivityTemplateName() {
        return workflowActivityTemplateName;
    }

    /**
     * @param workflowActivityTemplateName
     *            the workflowActivityTemplateName to set
     */
    public void setWorkflowActivityTemplateName(String workflowActivityTemplateName) {
        this.workflowActivityTemplateName = workflowActivityTemplateName;
    }

    /**
     * @return the casingInfo
     */
    public Integer getCasingInfo() {
        return casingInfo;
    }

    /**
     * @param casingInfo
     *            the casingInfo to set
     */
    public void setCasingInfo(Integer casingInfo) {
        this.casingInfo = casingInfo;
    }

    /**
     * @return the workflowInstanceId
     */
    public String getWorkflowInstanceId() {
        return workflowInstanceId;
    }

    /**
     * @param workflowInstanceId
     *            the workflowInstanceId to set
     */
    public void setWorkflowInstanceId(String workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }
}
