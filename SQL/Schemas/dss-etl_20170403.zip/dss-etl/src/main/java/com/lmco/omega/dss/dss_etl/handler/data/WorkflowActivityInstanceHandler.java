/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.UUID;
import java.util.zip.DataFormatException;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.common.helpers.GUIDHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.common.model.WorkflowEvent;
import com.lmco.omega.dss.common.model.enums.EOperationMode;
import com.lmco.omega.dss.common.model.record.PedigreeEventRecord;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdWorkflowActivityInstancePojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.workflowactivityinstance.WorkflowActivityInstanceCoalesce;
import com.lmco.omega.ecm.interfaces.model.ActivityState;
import com.lmco.omega.ecm.interfaces.model.WorkflowActivityInstance;

/**
 * @author bearyman
 */
public class WorkflowActivityInstanceHandler extends AbstractDataHandler {

    protected static final String GET_WFACTIVITYINSTANCE_MAX_CNT =
            "SELECT MAX(wai.activityorder) FROM omega.workflowactivityinstance wai "
                    + "WHERE wai.workflowactivityinstances_wo_0 = '%s';";
    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            WorkflowActivityInstanceHandler.class);

    private IsdWorkflowActivityInstancePojo mPojo;

    public WorkflowActivityInstanceHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        LOGGER.trace(methodName);
        mPojo = new IsdWorkflowActivityInstancePojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("workflowactivityinstanceid"));
            mPojo.setActivityOrder(pResults.getInt("activityorder"));
            mPojo.setActualEndDate(pResults.getTimestamp("actualenddateitem"));
            mPojo.setActualStartDate(pResults.getTimestamp("actualstartdateitem"));
            mPojo.setApplicationToLaunch(pResults.getString("applicationtolaunch"));
            mPojo.setAssignee(pResults.getString("assignee"));
            mPojo.setDueDate(pResults.getTimestamp("duedateitem"));
            mPojo.setFunctionalLeg(pResults.getInt("functionalleg"));
            mPojo.setStatus(pResults.getInt("status"));
            mPojo.setWorkItemId(pResults.getInt("workitemid"));
            mPojo.setWorkflowActivityTemplateId(pResults.getString("workflowactivitytemplateid"));
            mPojo.setWorkflowActivityTemplateName(pResults
                    .getString("workflowactivitytemplatename"));
            mPojo.setCasingInfo(pResults.getInt("casinginfo_workflowactivityi_0"));
            mPojo.setWorkflowInstanceId(pResults.getString("workflowactivityinstances_wo_0"));

            // Get security data from parent record
            setSecurityWithParentRecord(EIsdTableNames.WORKFLOW_INSTANCE,
                                        mPojo.getWorkflowInstanceId(), mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        LOGGER.trace(methodName);
        WorkflowActivityInstanceCoalesce entity;

        IDataConverter<WorkflowActivityInstance, WorkflowActivityInstanceCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(WorkflowActivityInstance.class);

        WorkflowActivityInstance pojo = converter.constructPojo();

        // 2016-10-26 - GB - Add this to reflect ISD activities - Start
        String activityTemplateName = null;
        switch (mPojo.getWorkflowActivityTemplateName()) {
            case "Data Acquisition":
                activityTemplateName = "ISD_DATA_ACQUISITION";
                break;
            case "Event Reconstruction":
                activityTemplateName = "ISD_EVENT_RECONSTRUCTION";
                break;
            case "Publish to OMEGA":
                activityTemplateName = "ISD_PUBLISH_TO_OMEGA";
                break;
            case "Signals Analysis":
                activityTemplateName = "ISD_SIGNALS_ANALYSIS";
                break;
            case "Track Validation":
                activityTemplateName = "ISD_TRACK_VALIDATION";
                break;
            default:
                activityTemplateName = "ISD_UNKNOWN";
                break;
        }
        // 2016-10-26 - GB - Add this to reflect ISD activities - Stop

        pojo.setActivityName(activityTemplateName);
        pojo.setActualEndDate(mPojo.getActualEndDate());
        pojo.setActualStartDate(mPojo.getActualStartDate());
        pojo.setAssignee(mPojo.getAssignee());
        pojo.setDueDate(mPojo.getDueDate());

        ActivityState activityState = null;
        switch (mPojo.getStatus()) {
            case 0: // ISD Created
            case 1: // ISD Started
            case 2: // ISD Suspended
            case 3: // ISD Canceled
                activityState = ActivityState.CANCELLED;
                break;
            case 4:
                activityState = ActivityState.COMPLETED;
                break;
            case 5:
                activityState = ActivityState.ERROR;
                break;
            default:
                activityState = ActivityState.ERROR;
                break;
        }
        pojo.setActivityState(activityState);

        if (pojo.getActualStartDate() == null) {
            pojo.setActualEndDate(new Date());
        }
        if (StringHelper.isNullOrEmpty(pojo.getAssignee())) {
            pojo.setAssignee("ETL_Test_WorkflowActivityInstance-237(a)");
        }
        if (pojo.getActualEndDate() == null) {
            pojo.setActualStartDate(new Date());
        }
        if (pojo.getDueDate() == null) {
            pojo.setDueDate(new Date());
        }

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getActualStartDate()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        createWorkflowPedigreeEvent();

        methodName = "createLinkages";
        LOGGER.trace(methodName);

        // Link workflow instance
        if (!StringHelper.isNullOrEmpty(mPojo.getWorkflowInstanceId())) {
            linkEntities(mEntityKey, mPojo.getWorkflowInstanceId(), ELinkType.IS_CHILD_OF,
                         String.valueOf(mPojo.getActivityOrder()), DataObjectLinkActionType.LINK);

            LOGGER.trace("Link to workflow complete");

            // Link current activity
            // 2016-10-28 - GB - Added this to create the CURRENT linkage for HMI - Start
            Statement stmt = null;
            Integer wfActivityInstanceMaxCnt = null;
            ResultSet results = null;

            try {
                stmt = mIsdConn.createStatement();

                if (stmt != null) {
                    results =
                            stmt.executeQuery(String.format(GET_WFACTIVITYINSTANCE_MAX_CNT,
                                                            mPojo.getWorkflowInstanceId()));

                    while (results.next()) {
                        wfActivityInstanceMaxCnt = results.getInt(1);
                        LOGGER.trace("Setting wfActivityInstanceMaxCnt");
                    }
                }
            } finally {
                if (stmt != null) {
                    stmt.close();
                }
            }

            if (wfActivityInstanceMaxCnt != null
                    && wfActivityInstanceMaxCnt == mPojo.getActivityOrder()) {
                linkEntities(mEntityKey, mPojo.getWorkflowInstanceId(), ELinkType.IS_USED_BY,
                             "Current", DataObjectLinkActionType.LINK);
                LOGGER.trace("Link to current workflow instance complete");
            }
            // 2016-10-28 - GB - Added this to create the CURRENT linkage for HMI - Stop
        } else {
            String errMsg =
                    String.format(LINK_FAILED, getTableType().getTableName(), mEntityKey,
                                  "workflow activity", mPojo.getWorkflowInstanceId(),
                                  NULL_EMPTY_KEY);
            LOGGER.error(errMsg, null);
            mResult.addResult(errMsg);
        }

        // Link workflow template
        String templateId = mPojo.getWorkflowActivityTemplateId().split("-")[0];
        linkEntities(mEntityKey, templateId, ELinkType.IS_A_PEER_OF, "workflow template",
                     DataObjectLinkActionType.LINK);
        LOGGER.trace("Link to current workflow template complete");

    }

    @Override
    protected String getCreatedBy() {
        return mPojo.getAssignee();
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.WORKFLOW_ACTIVITY_INSTANCE;
    }

    private void createWorkflowPedigreeEvent() {
        methodName = "createWorkflowPedigreeEvent";

        WorkflowEvent event = new WorkflowEvent();
        event.initialize();

        try {
            String errMsg = null;
            PedigreeEventRecord pedigreeRecord = event.getPedigreeRecord();
            pedigreeRecord.setOperationMode(EOperationMode.MANUAL);
            pedigreeRecord.setOperation("OPERATION_1");

            if (GUIDHelper.isValid(mEntityKey)) {
                event.setWorkflowActivityInstance(UUID.fromString(mEntityKey));

                // Update pedigree event start date
                CoalesceEntity entity = new CoalesceEntity();
                entity.initialize(event);
                entity.setDateCreated(new DateTime(mPojo.getActualStartDate()));

                if (mmClient.createPedigreeEvent(event)) {
                    EtlUtilitiesDbms.insertClearList(mFsdConn, event.getKey(), methodName,
                                                     getTableType() + "_"
                                                             + this.getClass().getSimpleName());
                    mWfa2PedigreeMap.put(mEntityKey, event.getKey());
                } else {
                    errMsg =
                            String.format(PEDIGREE_SAVE_FAILED, event.getKey(),
                                          mmClient.getLastResult()[0].getResult());
                }
            } else {
                errMsg = String.format(PEDIGREE_SAVE_FAILED, mKey, NULL_EMPTY_KEY);
            }

            if (errMsg != null) {
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }

        } catch (RemoteException | SQLException | DataFormatException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "createPedigree", e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        }
    }
}
