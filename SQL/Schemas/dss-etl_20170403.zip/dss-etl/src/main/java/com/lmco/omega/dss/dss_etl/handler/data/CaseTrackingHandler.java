/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.daq.datamodel.CaseTrackingData;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCaseTrackingPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;

/**
 * @author bearyman
 */
public class CaseTrackingHandler extends AbstractDataHandler {

    private IsdCaseTrackingPojo mPojo;

    public CaseTrackingHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdCaseTrackingPojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("casetrackingdataid"));
            mPojo.setCollectionRegion(pResults.getString("collectionregion"));
            mPojo.setColletorId(pResults.getString("collectorid"));
            mPojo.setCollectorName(pResults.getString("collectorname"));
            mPojo.setCurrentState(pResults.getString("currentstate"));
            mPojo.setOrigin(pResults.getString("origin"));
            mPojo.setProjections(pResults.getString("projections"));
            mPojo.setProsecutor(pResults.getString("prosecutor"));
            mPojo.setOniCaseNumber(pResults.getString("trackingdata_case__onicasenu_0"));
            mPojo.setStartCollectionDate(pResults.getTimestamp("startcollectiondateitem"));
            mPojo.setStopCollectionDate(pResults.getTimestamp("stopcollectiondateitem"));
            mPojo.setVaultRegistration(pResults.getString("vaultregistration"));

            // Get security data from parent record
            setSecurityWithParentRecord(EIsdTableNames.CASE, mPojo.getOniCaseNumber(),
                                        mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() {
        methodName = "mapToCoalesce";
        CaseTrackingData entity = new CaseTrackingData();
        entity.initialize();

        // Map pojo to coalesce
        entity.setCollectionRegion(mPojo.getCollectionRegion());
        entity.setCurrentState(mPojo.getCurrentState());
        entity.setOrigin(mPojo.getOrigin() + migrationTag);
        entity.setProjections(mPojo.getProjections());
        entity.setProsecutor(mPojo.getProsecutor());
        entity.setStartCollectionDate(new DateTime(mPojo.getStartCollectionDate()));
        entity.setStopCollectionDate(new DateTime(mPojo.getStopCollectionDate()));
        entity.setValultRegistration(mPojo.getVaultRegistration());

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getStartCollectionDate()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";

        // Link collector
        linkEntities(mEntityKey, mPojo.getColletorId(), ELinkType.HAS_USE_OF, "collector",
                     DataObjectLinkActionType.LINK);

        // Link case
        linkEntities(mEntityKey, EtlUtilitiesDbms.getCaseUuid(mPojo.getOniCaseNumber()),
                     ELinkType.IS_A_PEER_OF, "case", DataObjectLinkActionType.LINK);

    }

    @Override
    protected String getCreatedBy() {
        return DSSConstants.SYSTEM_ACCOUNT;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.CASE_TRACKING_DATA;
    }
}
