/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.JTextComponent;
import javax.xml.transform.TransformerException;

import org.apache.commons.io.FileUtils;
import org.apache.wss4j.common.ext.WSSecurityException;
import org.geotools.factory.CommonFactoryFinder;
import org.opengis.filter.Filter;
import org.opengis.filter.FilterFactory;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.EnumerationProviderUtil;
import com.incadencecorp.coalesce.framework.enumerationprovider.impl.JavaEnumerationProviderImpl;
import com.incadencecorp.coalesce.framework.enumerationprovider.impl.PropertyEnumerationProviderImpl;
import com.incadencecorp.coalesce.framework.persistance.ICoalescePersistor;
import com.incadencecorp.unity.common.IConfigurationsConnector;
import com.incadencecorp.unity.common.connectors.FilePropertyConnector;
import com.incadencecorp.unity.common.factories.PropertyFactory;
import com.lmco.omega.common.user.LdapUsers;
import com.lmco.omega.daq.datamodel.ReelInfo;
import com.lmco.omega.dss.client.api.IEnumerationManagerClient;
import com.lmco.omega.dss.client.api.IMetadataSearchClient;
import com.lmco.omega.dss.client.api.factory.DSSClientFactoryUtil;
import com.lmco.omega.dss.client.api.factory.DSSPropertyFactory;
import com.lmco.omega.dss.client.common.jaxws.util.JAXWSUtil;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.configuration.DSSSettings;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.common.persister.DSSPostGreSQLPersistor;
import com.lmco.omega.dss.common.util.DSSConfiguration;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.database.EtlPersister;
import com.lmco.omega.dss.dss_etl.common.util.CoiPlatformHashMap;
import com.lmco.omega.dss.dss_etl.common.util.EnumerationPropertyFileUtil;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.manager.AbstractCoiMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.CoiCharacterizedSourcesMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.CoiPlatformMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.CoiSegmentMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.DataMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.EnumerationMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.FrequencyIdentifierMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.PlatformClassMigrationManager;
import com.lmco.omega.dss.dss_etl.model.EnumMigrationMetrics;
import com.lmco.omega.dss.dss_etl.model.EnumMigrationResult;
import com.lmco.omega.dss.dss_etl.model.MigrationMetrics;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;
import com.lmco.omega.dss.interfaces.common.EJobStatusType;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.metadatasearch.MetadataSearchFault;

/*
 * @author n67154 (Gene Belford - Incadence)
 */

public class EtlMigrateIsd2Fsd extends JFrame {

    private static final String ENV_CONFIG_LOCATION = "DSS_CONFIG_LOCATION";
    static {
        System.setProperty("DSS_CONFIG_LOCATION", System.getenv("DSS_CONFIG_LOCATION"));
    }

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlMigrateIsd2Fsd.class);
    private static final long serialVersionUID = 3186483853224787587L;
    private static final String MIGRATION_FAILED = "Record: %s  Failure Reason: %s";
    private static final String ENUM_MIGRATION_FAILED = "Enum Type: %s  Failure Reason: %s";
    private static final String PROCESS_COMPILE_DATE = "2017-01-16 08:30";
    private static final String PROCESS_NAME = "EtlMigrateIsd2Fsd";
    private static final String PROCESS_MODULE = "main";
    private static final ImageIcon ICON_OPEN = new ImageIcon("resources/icons/open.png");
    private static final String VALIDATION_MODE_STR =
            "                               ****** VALIDATION MODE ******";

    private static final String TEMP_DIR_NAME = "jars";
    private static URLClassLoader urlClassLoader;
    private static Path tempDir = Paths.get(TEMP_DIR_NAME);

    private static PrintStream outPrintStream;
    private static PrintStream errPrintStream;

    private final JFrame frame;

    private Action openAction;
    private Action saveAction;
    private Action exitAction;

    private String etlProcessingTarget;

    private JTextComponent textComp;
    private static JTextArea sysOutTextArea;
    private static JTextArea sysErrTextArea;

    private Connection connFSD;
    private Statement connFSDStmt;

    private Connection connISD;
    private Statement connISDStmt;
    private CallableStatement pCallStmt;

    private ResultSet connResults;

    private int recIdDBMS;
    private int recIdJava;

    private DateFormat df;
    private Date dateobj;

    private boolean validationMode;
    private boolean fsdAvailable;
    private static boolean logResults;
    private static File logFile;

    public static CoiPlatformHashMap coiPlatMap;

    private DefaultTableModel tableModel = new DefaultTableModel();
    private DefaultTableModel processEtlTbl = new DefaultTableModel();
    private DefaultTableModel linkMatrix = new DefaultTableModel();
    private DefaultTableModel tableFuncWarnEtl = new DefaultTableModel();
    private DefaultTableModel tableDebugEtl = new DefaultTableModel();
    private DefaultTableModel tableIsdDbObjectFactsEtl = new DefaultTableModel();

    private JButton buttonRun = new JButton("Run");
    private JButton buttonClear = new JButton("Clear");

    private JButton closeButton = new JButton("Close");
    private JButton resetButton = new JButton("Reset");
    private JButton refreshSqlButton = new JButton("SQL Refresh");
    private JButton testButton = new JButton("Test");

    public static JButton buttonEnums = new JButton("Enums");
    public static JButton buttonLCPolicy = new JButton("LC Policy");
    public static JButton buttonPrjct = new JButton("Project");
    public static JButton buttonWrkflTemp = new JButton("Wrkflw Templ");
    public static JButton buttonWrkflInst = new JButton("Wrkflw Inst");
    public static JButton buttonWrkflActInst = new JButton("Wrkflw Activity Inst");
    public static JButton buttonWrkflSuspend = new JButton("Wrkflw Suspend");
    public static JButton buttonUserCmnts = new JButton("User Comments");

    public static JButton buttonCase = new JButton("Case");
    public static JButton buttonCaseTrk = new JButton("Case Tracking Data");
    public static JButton buttonReelInfo = new JButton("Reel Info");
    public static JButton buttonReelCut = new JButton("Reel Cut");
    public static JButton buttonCollectionEvent = new JButton("Collection Event");
    public static JButton buttonEventTargetChar = new JButton("Event Target Characterization");
    public static JButton buttonCollector = new JButton("Collector");
    public static JButton buttonSensor = new JButton("Sensor");

    public static JButton buttonContactOfInterestPlatform = new JButton("COI Platform");
    public static JButton buttonContactOfInterest = new JButton("COI");
    public static JButton buttonContactCharacterizedSources = new JButton(
            "Contact Characterized Sources");
    public static JButton buttonContactGeometryEstimate = new JButton("Contact Geometry Estimate");
    public static JButton buttonContactGeospatialTracks = new JButton("Contact Geospatial Tracks");
    public static JButton buttonPlatformClass = new JButton("Platform Class");
    public static JButton buttonCOISegment = new JButton("COI Segment");
    public static JButton buttonFreqIdent = new JButton("Frequency Identifier");

    public static JButton buttonContactOfInterestSegmentSummary = new JButton("COI Seg Summ");
    public static JButton buttonContactOperationalProfile = new JButton(
            "Contact Operational Profile");
    public static JButton buttonGeoSpatialPositions = new JButton("Geospatial Positions");
    public static JButton buttonObservedTargetSegmentSummary = new JButton(
            "Observed Target Seg Summ");

    // public static JButton buttonGram = new JButton("GRAM");
    public static JButton buttonGramSplc = new JButton("GRAM SPLC");
    public static JButton buttonSplcAspectMeasurement = new JButton("SPLC Aspect Meas");
    public static JButton buttonSplcContactMeasurement = new JButton("SPLC Contact Meas");
    public static JButton buttonSplcMeasurementEvent = new JButton("SPLC Meas Event");
    public static JButton buttonSplcPointMeasurement = new JButton("SPLC Point Meas");
    public static JButton buttonSplcSourceMeasurement = new JButton("SPLC Source Meas");
    public static JButton buttonSplcVersion = new JButton("SPLC Ver");

    public static JButton buttonAuxSupport = new JButton("Aux Support");
    public static JButton buttonBtr = new JButton("BTR");
    public static JButton buttonCGram = new JButton("CGRAM");
    public static JButton buttonFanOfBeams = new JButton("Fan Of Beams");
    public static JButton buttonGram = new JButton("GRAM");
    public static JButton buttonHorizontalMeasurement = new JButton("Horiz Meas");
    public static JButton buttonHtmlAndPng = new JButton("HTML & PNG");
    public static JButton buttonMSOfficeDoc = new JButton("MS Doc");
    public static JButton buttonNad = new JButton("NAD");
    public static JButton buttonPsd = new JButton("PSD");
    public static JButton buttonSensorId = new JButton("Sensor ID");
    public static JButton buttonSGrm = new JButton("SGRM");
    public static JButton buttonSummarySpl = new JButton("Summary SPL");
    public static JButton buttonSwimsExportXml = new JButton("Swims XML");
    public static JButton buttonTappXml = new JButton("Tapp XML");
    public static JButton buttonTgtTrackSolution = new JButton("Tgt Track Sol");
    public static JButton buttonTimeSeries = new JButton("Time Series");
    public static JButton buttonTpsBearing = new JButton("TPS Bearing");
    public static JButton buttonTpsSoundSp = new JButton("TPS Speed");
    public static JButton buttonTpsTimestamp = new JButton("TPS Time");
    public static JButton buttonVertMeasurements = new JButton("Vertical Meas");
    public static JButton buttonWavFile = new JButton("WAV");
    public static JButton buttonFileDescMeta = new JButton("File Desc Meta");

    private Color defaultColor;

    /***
     * main
     *
     * @param args
     * @throws SQLException
     */

    public static void main(String[] args) throws Exception {
        Date dateobj = new Date();
        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        LOGGER.info("");
        LOGGER.info("==== " + df.format(dateobj) + " ====");

        try {
            initialize();
            new EtlMigrateIsd2Fsd();
        } catch (Exception e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "execute main",
                                       e.getMessage()), e);
        }
    }

    private static void initialize() throws NoSuchMethodException, IllegalAccessException,
            InvocationTargetException, IOException {
        urlClassLoader = (URLClassLoader) ClassLoader.getSystemClassLoader();

        // extract all jars bundled in this artifact's jar and add them to the
        // class loader
        loadClasses(urlClassLoader.getURLs());

    }

    public static void loadClasses(URL[] urls) throws NoSuchMethodException, SecurityException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException,
            IOException {

        LOGGER.info("Loading jars into ClassLoader...");

        // create temp dir
        tempDir = Paths.get(TEMP_DIR_NAME);

        if (!tempDir.toFile().exists()) {
            tempDir.toFile().mkdir();
        }

        Method method = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
        method.setAccessible(true);

        for (URL url: urls) {

            LOGGER.debug(url.toString());

            if (url.toString().endsWith(".jar")) {

                ZipInputStream jar = new ZipInputStream(url.openStream());

                while (true) {
                    ZipEntry entry = jar.getNextEntry();

                    if (entry == null) {
                        break;
                    }

                    String name = entry.getName();

                    if (name.toString().endsWith(".jar")) {

                        URL resourceURL = urlClassLoader.getResource(name);

                        LOGGER.debug("Adding " + name + " to Classloader");

                        Path destPath = tempDir.resolve(name);

                        // copy to temp dir
                        FileUtils.copyURLToFile(resourceURL, destPath.toFile());

                        // add to class loader
                        method.invoke(urlClassLoader, destPath.toUri().toURL());
                    }

                }

            }

        }

        LOGGER.info("Done");

    }

    public static void writeOutputPrintStream(String text) {
        if (outPrintStream != null) {
            outPrintStream.println(text);
        }
    }

    public static void writeErrorPrintStream(String text) {
        if (errPrintStream != null) {
            errPrintStream.println(text);
        }
    }

    public EtlMigrateIsd2Fsd() throws SQLException, ClassNotFoundException, WSSecurityException,
            TransformerException, MetadataSearchFault, IllegalStateException, IOException,
            DSSPersisterNotInitializedException {

        // set system property to avoid using net.sf.saxon factory
        System.setProperty("javax.xml.transform.TransformerFactory",
                           "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl");

        validationMode = false;
        String validateVal = EtlUtilities.getEtlConfigValue("validationMode").toLowerCase();
        if (!StringHelper.isNullOrEmpty(validateVal) && validateVal.equals("true")) {
            validationMode = true;
        }

        logResults = false;
        String logResultsStr = EtlUtilities.getEtlConfigValue("logResults").toLowerCase();
        if (!StringHelper.isNullOrEmpty(logResultsStr) && logResultsStr.equals("true")) {
            logResults = true;
        }

        LOGGER.debug("DEBUG_0 Java: ISD DBMS Connection");
        connISD = EtlUtilitiesDbms.getISDConnection();
        if (connISD != null) {
            connISDStmt = EtlUtilitiesDbms.getStmt(connISD);

            if (connISDStmt != null) {
                connResults = EtlUtilitiesDbms.getDBVersion(connISD, connISDStmt);
                LOGGER.debug("DEBUG_0 Java: ISD DBMS Ver:  " + connResults.getString(1));
                connResults = EtlUtilitiesDbms.getDBInfo(connISD, connISDStmt);
                LOGGER.debug("DEBUG_0 Java: ISD DBMS Info: " + connResults.getString(1));
            } else {
                LOGGER.error("*ERROR* SQL:  Failed to create to ISD DBMS statement. ");
            }
        } else {
            LOGGER.error("*ERROR* SQL:  Failed to connect to ISD DBMS. ");
        }

        // Connect to the FSD DBMS server

        LOGGER.debug("DEBUG_0 Java: FSD DBMS Connection");
        try {
            fsdAvailable = false;
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            if (connFSD != null) {
                fsdAvailable = true;
                connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);

                if (connFSDStmt != null) {
                    connResults = EtlUtilitiesDbms.getDBVersion(connFSD, connFSDStmt);
                    LOGGER.debug("DEBUG_0 Java: FSD DBMS Ver:  " + connResults.getString(1));
                    connResults = EtlUtilitiesDbms.getDBInfo(connFSD, connFSDStmt);
                    LOGGER.debug("DEBUG_0 Java: FSD DBMS Info: " + connResults.getString(1));
                } else {
                    LOGGER.error("*ERROR* SQL:  Failed to create to FSD DBMS statement. ");
                }
            } else {
                if (!validationMode) {
                    LOGGER.error("*ERROR* SQL:  Failed to connect to FSD DBMS. ");
                } else {
                    LOGGER.debug("WARNING: No FSD Connection!!");
                }
            }
        } catch (SQLException e) {
            if (!validationMode) {
                throw new SQLException(e);
            } else {
                LOGGER.debug("WARNING: No FSD Connection!!");
            }
        }

        DSSConfiguration config = new DSSConfiguration();
        if (validationMode && !fsdAvailable) {
            config.setAuthoritativePersistor(new EtlPersister());
        } else {
            config.setAuthoritativePersistor(new DSSPostGreSQLPersistor());
        }
        config.setSecondaryPersistors(new ICoalescePersistor[] {});
        LdapUsers ldap = getLdapUsers();
        config.setUserInfoSource(ldap);

        if (validationMode) {
            EnumerationPropertyFileUtil.createEnumPropertyFiles(fsdAvailable);
            PropertyEnumerationProviderImpl provider = new PropertyEnumerationProviderImpl();
            Path propertyDir = Paths.get(System.getenv("DSS_CONFIG_LOCATION"), "enum_properties");
            provider.setPaths(propertyDir.toString());
            EnumerationProviderUtil.setEnumerationProviders(provider,
                                                            new JavaEnumerationProviderImpl());

            IConfigurationsConnector connector =
                    new FilePropertyConnector(System.getenv(ENV_CONFIG_LOCATION));
            PropertyFactory factory = new PropertyFactory(connector);

            // Load Enumeration Mappings
            EnumerationProviderUtil.setLookupEntries(factory
                    .getProperties(EnumerationProviderUtil.ENUMERATION_LOOKUPS_FILENAME));
        } else {
            EnumerationProviderUtil.initializeFromConnector();
            // EnumerationProviderUtil.logLookups();
        }

        config.setTemplates(new BaseDataObject(), new ReelInfo());
        config.startup();

        if (!validationMode) {
            EnumerationPropertyFileUtil.createEnumPropertyFiles(fsdAvailable);
        }

        // Verify retrieval of enum
        IEnumerationManagerClient enumClient =
                DSSClientFactoryUtil.getEnumerationManagerClient(null);
        enumClient.setCredentials(JAXWSUtil.createToken("omega", "omega"));
        List<String> enumNames = new ArrayList<>();
        enumNames.add("workflowpriority");
        List<Enumeration> retrieveEnumerations = enumClient.retrieveEnumerations(enumNames);
        if (!retrieveEnumerations.isEmpty()) {
            LOGGER.info("Enumeration client verified");
        } else {
            LOGGER.error("ERROR!! ENUMERATION CLIENT NOT VERIFIED!!!");
        }

        // Verify search
        IMetadataSearchClient searchClient = DSSClientFactoryUtil.getMetadataSearchClient(null);
        searchClient.setCredentials(JAXWSUtil.createToken("omega", "omega"));
        FilterFactory FF = CommonFactoryFinder.getFilterFactory();
        Filter query = FF.equals(DSSPropertyFactory.getEntityKey(), FF.literal(UUID.randomUUID()));
        searchClient.searchMetadata(query, 1);
        LOGGER.info("Metadata Search client verified");

        if (logResults) {
            String filename = "migrationResults.log";
            String logFileDir = ENV_CONFIG_LOCATION;
            String logFileStr = EtlUtilities.getEtlConfigValue("logFileDir").toLowerCase();
            if (!StringHelper.isNullOrEmpty(logFileStr)) {
                logFileDir = logFileStr;
            }

            boolean clearLog = false;
            String clearLogStr =
                    EtlUtilities.getEtlConfigValue("clearLastLogResults").toLowerCase();
            if (!StringHelper.isNullOrEmpty(clearLogStr) && clearLogStr.equals("true")) {
                clearLog = true;
            }

            File logDir = new File(logFileDir);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }

            logFile = Paths.get(logFileDir, filename).toFile();
            try {
                if (logFile.exists() && clearLog) {
                    logFile.delete();
                    logFile.createNewFile();
                } else {
                    logFile.createNewFile();
                }
            } catch (IOException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "create log file",
                                           e.getMessage()));
            }
        }

        df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        frame = new JFrame("ISD to FSD Migration");

        LOGGER.debug("DEBUG_0 Java: " + PROCESS_MODULE + ": Starting run");

        textComp = createTextComponent();

        makeActionsPretty();

        openAction = new OpenAction(ICON_OPEN, KeyEvent.VK_O);
        saveAction = new SaveAction();
        exitAction = new ExitAction();

        dateobj = new Date();
        LOGGER.debug("DEBUG_0 Java: ====3 " + df.format(dateobj) + " 3====");

        // recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", "Start DBMS session");

        // recIdJava = EtlUtilitiesDbms.processLogInit(connFSD, "S", "Start Java application");

        createAndShowHMI();

        dateobj = new Date();
        LOGGER.debug("DEBUG_0 Java: ====4 " + df.format(dateobj) + " 4====");

        LOGGER.debug("DEBUG_0 Java: "
                + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
        LOGGER.debug("DEBUG_0 Java: Pass GUI startup");
    }

    /**
     * createAndShowHMI
     */

    public void createAndShowHMI() {

        // Create and set up the window.
        frame.setLocationByPlatform(true);
        frame.setSize(500, 500);
        frame.setBackground(Color.LIGHT_GRAY);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar mb = createMenuBar();
        frame.setJMenuBar(mb);

        createLabelBar();

        JScrollPane pane = new JScrollPane(new MigratePanel());
        frame.add(pane, BorderLayout.CENTER);

        final JTabbedPane etlTabPanels = createTabComponent();

        etlTabPanels.setBackground(Color.YELLOW);
        etlTabPanels.setAutoscrolls(true);
        etlTabPanels.setSize(300, 200);

        /*
         * System Output
         */

        sysOutTextArea.setBackground(Color.LIGHT_GRAY);

        etlTabPanels.addTab("System Output", new JScrollPane(sysOutTextArea));

        /*
         * System Error Output
         */

        sysErrTextArea.setBackground(Color.LIGHT_GRAY);

        etlTabPanels.addTab("System Error Output", new JScrollPane(sysErrTextArea));

        /*
         * Simple Text Editor for editing configuration files
         */

        textComp.setBackground(Color.LIGHT_GRAY);

        etlTabPanels.addTab("Editor", new JScrollPane(textComp));

        /*
         * ETL Metacard Tracking List
         */

        final DefaultTableModel tableEtl4 = new DefaultTableModel();
        final DefaultTableModel tableEtl5 = new DefaultTableModel();
        final DefaultTableModel tableEtl6 = new DefaultTableModel();
        final DefaultTableModel tableEtl7 = new DefaultTableModel();
        final DefaultTableModel tableEtl8 = new DefaultTableModel();
        final DefaultTableModel tableEtl9 = new DefaultTableModel();

        if (fsdAvailable) {

            tableModel = EtlPaneAssignment.loadEtlTrackData(tableEtl4);

            JTable etlTrackDataTbl = new JTable(tableModel);

            etlTrackDataTbl.setBackground(Color.LIGHT_GRAY);
            etlTrackDataTbl.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            etlTrackDataTbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(etlTrackDataTbl);

            etlTabPanels.addTab("ETL Metacard Tracking List", new JScrollPane(etlTrackDataTbl));

            /*
             * ETL Processing
             */

            processEtlTbl = EtlPaneAssignment.loadEtlProcessData(tableEtl5);

            JTable processTbl = new JTable(processEtlTbl);

            processTbl.setBackground(Color.LIGHT_GRAY);
            processTbl.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            processTbl.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(processTbl);

            etlTabPanels.addTab("ETL Processing", new JScrollPane(processTbl));

            /*
             * Linkage Matrix
             */

            linkMatrix = EtlPaneAssignment.loadLinkMatrix(tableEtl6);

            JTable etlLinkMatrix = new JTable(linkMatrix);

            etlLinkMatrix.setBackground(Color.LIGHT_GRAY);
            etlLinkMatrix.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            etlLinkMatrix.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(etlLinkMatrix);

            etlTabPanels.addTab("Linkage Matrix", new JScrollPane(etlLinkMatrix));

            /*
             * ETL Functional Warning
             */

            tableFuncWarnEtl = EtlPaneAssignment.loadEtlFuncWarnData(tableEtl7);

            JTable funcWarnTable = new JTable(tableFuncWarnEtl);

            funcWarnTable.setBackground(Color.LIGHT_GRAY);
            funcWarnTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            funcWarnTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(funcWarnTable);

            etlTabPanels.addTab("ETL Functional Warning", new JScrollPane(funcWarnTable));

            /*
             * ETL Standard Debug
             */

            tableDebugEtl = EtlPaneAssignment.loadEtlDebugData(tableEtl8);

            JTable debugTable = new JTable(tableDebugEtl);

            debugTable.setBackground(Color.LIGHT_GRAY);
            debugTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            debugTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(debugTable);

            etlTabPanels.addTab("ETL Standard Debug", new JScrollPane(debugTable));

            /*
             * ISD Database Object Facts
             */

            tableIsdDbObjectFactsEtl = EtlPaneAssignment.loadIsdDbObjectFactsData(tableEtl9);

            JTable isdDbObjectFacts = new JTable(tableIsdDbObjectFactsEtl);

            isdDbObjectFacts.setModel(tableIsdDbObjectFactsEtl);
            isdDbObjectFacts.setBackground(Color.LIGHT_GRAY);
            isdDbObjectFacts.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
            isdDbObjectFacts.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            EtlPaneAssignment.setDefaultTableColumnWidth(isdDbObjectFacts);

            JScrollPane jsp = new JScrollPane(isdDbObjectFacts);
            etlTabPanels.addTab("ISD DBMS Table Facts Debug", jsp);
        }

        /*
         * Change Listener
         */

        etlTabPanels.addChangeListener(new ChangeListener() {

            @Override
            public void stateChanged(ChangeEvent e) {
                if (etlTabPanels.getSelectedIndex() == 0) {
                    LOGGER.debug("tab: 1 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                } else if (etlTabPanels.getSelectedIndex() == 1) {
                    LOGGER.debug("tab: 2 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                } else if (etlTabPanels.getSelectedIndex() == 2) {
                    LOGGER.debug("tab: 3 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                } else if (etlTabPanels.getSelectedIndex() == 3) {
                    LOGGER.debug("tab: 4 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    tableModel = EtlPaneAssignment.loadEtlTrackData(tableEtl4);
                } else if (etlTabPanels.getSelectedIndex() == 4) {
                    LOGGER.debug("tab: 5 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    processEtlTbl = EtlPaneAssignment.loadEtlProcessData(tableEtl5);
                } else if (etlTabPanels.getSelectedIndex() == 5) {
                    LOGGER.debug("tab; 6 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    linkMatrix = EtlPaneAssignment.loadLinkMatrix(tableEtl6);
                } else if (etlTabPanels.getSelectedIndex() == 6) {
                    LOGGER.debug("tab: 7 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    tableFuncWarnEtl = EtlPaneAssignment.loadEtlFuncWarnData(tableEtl7);
                } else if (etlTabPanels.getSelectedIndex() == 7) {
                    LOGGER.debug("tab: 8 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    tableDebugEtl = EtlPaneAssignment.loadEtlDebugData(tableEtl8);
                } else if (etlTabPanels.getSelectedIndex() == 8) {
                    LOGGER.debug("tab: 9 - "
                            + etlTabPanels.getTitleAt(etlTabPanels.getSelectedIndex()));
                    tableIsdDbObjectFactsEtl =
                            EtlPaneAssignment.loadIsdDbObjectFactsData(tableEtl9);
                } else {
                    LOGGER.error("Beyond the 'ChangeListener:stateChanged' if-then-else");
                }
            }
        });

        /*
         * Place the ETL tabs
         */

        frame.add(etlTabPanels, BorderLayout.SOUTH);

        /*
         * Display the window.
         */

        frame.pack();
        frame.setVisible(true);
    }

    // Add icons and friendly names to actions we care about.
    protected void makeActionsPretty() {
        Action a;
        a = textComp.getActionMap().get(DefaultEditorKit.cutAction);
        a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/cut.png"));
        a.putValue(Action.NAME, "Cut");

        a = textComp.getActionMap().get(DefaultEditorKit.copyAction);
        a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/copy.png"));
        a.putValue(Action.NAME, "Copy");

        a = textComp.getActionMap().get(DefaultEditorKit.pasteAction);
        a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/paste.png"));
        a.putValue(Action.NAME, "Paste");

        a = textComp.getActionMap().get(DefaultEditorKit.selectAllAction);
        a.putValue(Action.SMALL_ICON, new ImageIcon("Resources/Icons/selectall.png"));
        a.putValue(Action.NAME, "Select All");
    }

    /*
     *
     */

    private JMenuBar createMenuBar() {

        // Create the menu bar. Make it have a green background.
        JMenuBar greenMenuBar = new JMenuBar();

        greenMenuBar.setOpaque(true);
        greenMenuBar.setBackground(new Color(154, 165, 127));
        greenMenuBar.setPreferredSize(new Dimension(200, 30));

        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);

        JMenu editMenu = new JMenu("Edit");
        editMenu.setMnemonic(KeyEvent.VK_E);

        greenMenuBar.add(fileMenu);
        greenMenuBar.add(editMenu);

        fileMenu.add(getOpenAction());
        fileMenu.add(getSaveAction());
        fileMenu.addSeparator();
        fileMenu.add(getExitAction());

        editMenu.add(textComp.getActionMap().get(DefaultEditorKit.cutAction));
        editMenu.add(textComp.getActionMap().get(DefaultEditorKit.copyAction));
        editMenu.add(textComp.getActionMap().get(DefaultEditorKit.pasteAction));
        editMenu.add(textComp.getActionMap().get(DefaultEditorKit.selectAllAction));

        return greenMenuBar;
    }

    /*
     *
     */

    private void createLabelBar() {

        // Display which machine the processing is running on
        etlProcessingTarget = EtlUtilities.getEtlConfigValue("EtlProcessingState");
        if (etlProcessingTarget == null) {
            etlProcessingTarget = "missing";
        }

        // Create a yellow label to put in the content pane.

        String validationModeLabel = "";
        if (validationMode) {
            validationModeLabel = VALIDATION_MODE_STR;
        }

        String label =
                " Compiled: " + PROCESS_COMPILE_DATE + " - Processing Unit: " + etlProcessingTarget
                        + validationModeLabel;

        JLabel yellowLabel = new JLabel(label);
        yellowLabel.setOpaque(true);
        yellowLabel.setBackground(new Color(248, 213, 131));
        yellowLabel.setPreferredSize(new Dimension(225, 30));

        // http://stackoverflow.com/questions/16215307/how-to-add-a-color-indicator-led-lookalike-to-a-jframe
        JLabel isdStatus = new JLabel("☼");
        isdStatus.setMaximumSize(new Dimension(25, 25));
        isdStatus.setForeground(Color.GREEN);
        isdStatus.setOpaque(false);
        yellowLabel.add(isdStatus);

        // Set the menu bar and add the label to the content pane.
        frame.getContentPane().add(yellowLabel, BorderLayout.NORTH);
    }

    /**
     * <h1>createTabComponent</h1>
     * <p>
     * Create the JTabbedPane subclass.
     *
     * @param arg
     *            not used
     * @return dbConnection
     * @since 2016-08-18
     * @author Gene Belford - n67154
     */

    protected JTabbedPane createTabComponent() {

        String processModule = "createTabComponent";

        JTabbedPane tc = new JTabbedPane();
        add(tc);
        tc.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);

        tc.setBackground(Color.CYAN);

        return tc;
    }

    /**
     *
     */

    public class MigratePanel extends JPanel {

        private static final long serialVersionUID = 1L;

        protected JTextField textField;

        public MigratePanel() {
            super(new GridBagLayout());

            defaultColor = buttonFileDescMeta.getBackground();

            sysOutTextArea = new JTextArea(40, 50);
            sysOutTextArea.setBackground(Color.yellow);
            sysOutTextArea.setEditable(false);
            sysOutTextArea.setLineWrap(true);
            outPrintStream = new PrintStream(new CustomOutputStream(sysOutTextArea));

            sysErrTextArea = new JTextArea(40, 50);
            sysErrTextArea.setBackground(Color.yellow);
            sysErrTextArea.setEditable(false);
            sysErrTextArea.setLineWrap(true);
            errPrintStream = new PrintStream(new CustomOutputStream(sysErrTextArea));

            // System.setOut(outPrintStream);
            // System.setErr(errPrintStream);

            // Add Components to this panel.
            setLayout(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();

            // Row 0 - Application

            // adds event handler for Run button

            c.gridx = 0;
            c.gridy = 0;
            c.insets = new Insets(5, 5, 5, 5);
            c.anchor = GridBagConstraints.NORTH;
            add(buttonRun, c);

            buttonRun.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    LOGGER.debug("DEBUG_0 Java: "
                            + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));

                    LOGGER.debug(PROCESS_MODULE + " : Run button pushed.");

                    try {
                        EtlIsdVerification.retrieveIsdMetadata(etlProcessingTarget, connISD,
                                                               connFSD);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "retrieveIsdMetadata", e.getMessage()), e);
                    }

                    EtlIsdMigration t2 = new EtlIsdMigration("Migration Thread Test");
                    t2.start();

                    LOGGER.debug("DEBUG_0 Java: "
                            + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
                    LOGGER.debug(PROCESS_MODULE + " : Run finished.");
                }
            });

            //
            // resetButton
            //

            resetButton.setMaximumSize(new Dimension(75, 25));
            resetButton.setBackground(Color.LIGHT_GRAY);

            resetButton.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        EtlUtilitiesDbms.processLogUpdate(connFSD, recIdJava, "U", 0,
                                                          "HMI reset button pushed.");
                    } catch (SQLException e) {
                        LOGGER.error(e.getClass().getName() + ": " + e.getMessage(), e);
                    }
                    frame.repaint();

                    dateobj = new Date();

                    LOGGER.debug("");
                    LOGGER.debug("===== " + df.format(dateobj) + " =====");
                    LOGGER.debug("Reset button pushed.");
                }
            });

            //
            // closeButton
            //

            closeButton.setMaximumSize(new Dimension(75, 25));
            closeButton.setBackground(Color.LIGHT_GRAY);

            closeButton.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    LOGGER.debug("DEBUG_0 Java: Close button pushed.");

                    if (fsdAvailable) {
                        try {
                            EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", 0,
                                                              "Close DBMS");
                            EtlUtilitiesDbms.processLogUpdate(connFSD, recIdJava, "E", 0,
                                                              "Close Java application");

                            if (pCallStmt != null) {
                                pCallStmt.close();
                            }
                            if (connISDStmt != null) {
                                connISDStmt.close();
                            }
                            if (connISD != null) {
                                EtlUtilitiesDbms.closeConn(connISD);
                            }
                            if (connFSDStmt != null) {
                                connFSDStmt.close();
                            }
                            if (connFSD != null) {
                                EtlUtilitiesDbms.closeConn(connFSD);
                            }
                            if (outPrintStream != null) {
                                outPrintStream.close();
                            }
                            if (errPrintStream != null) {
                                errPrintStream.close();
                            }
                        } catch (SQLException e1) {
                            LOGGER.error(e1.getClass().getName() + ": " + e1.getMessage(), e1);
                            System.exit(0);
                        }

                        LOGGER.debug("DEBUG_0 Java: Closed database connection(s) successfully");
                        LOGGER.debug("DEBUG_0 Java: Closing window.");
                    }

                    frame.setVisible(false);
                    frame.dispose();
                    System.exit(0);
                }
            });

            //
            // Reset the SQL database
            //

            refreshSqlButton.setMaximumSize(new Dimension(75, 25));
            refreshSqlButton.setBackground(Color.LIGHT_GRAY);
            refreshSqlButton.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    LOGGER.debug("DEBUG_0 Java: Clear SQL button pushed.");
                }
            });

            //
            // testButton
            //

            testButton.setMaximumSize(new Dimension(75, 25));
            testButton.setBackground(Color.LIGHT_GRAY);

            testButton.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        EtlUtilitiesDbms.processLogUpdate(connFSD, recIdJava, "U", 0,
                                                          "HMI test button pushed.");
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "processLogUpdate", e.getMessage()), e);
                    }
                    frame.repaint();

                    dateobj = new Date();

                    LOGGER.debug("");
                    LOGGER.debug("===== " + df.format(dateobj) + " =====");
                    LOGGER.debug("Test button pushed.");

                    /*
                     * Function Warning Insert Test
                     */

                    LOGGER.debug("DEBUG_0 Java: =*=*01 " + df.format(dateobj) + " 01*=*=");

                    // EtlUtilitiesDbms.processFuncWarnInsert(processName, processModule, "",
                    // errorMsg, "parameters");

                    /*
                     * ISD File Access Test
                     */

                    LOGGER.debug("DEBUG_0 Java: =*=*02 " + df.format(dateobj) + " 02*=*=");

                    try {
                        EtlIsdVerification.retrieveIsdMetadata(etlProcessingTarget, connISD,
                                                               connFSD);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "retrieveIsdMetadata", e.getMessage()), e);
                    }

                    LOGGER.debug("DEBUG_0 Java: =*=*03 " + df.format(dateobj) + " 03*=*=");

                    /*
                     * ISD enum validation
                     */

                    LOGGER.debug("DEBUG_0 Java: =*=*04 " + df.format(dateobj) + " 04*=*=");

                    try {
                        EtlUtilitiesDbms.validateIsdEnums();
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "validateIsdEnums", e.getMessage()), e);
                    }

                }
            });

            /*
             * adds event handler for button Clear
             */

            c.gridx = 1;
            c.gridy = 0;
            buttonClear.setEnabled(true);
            if (validationMode) {
                buttonClear.setEnabled(false);
            }
            add(buttonClear, c);

            buttonClear.addActionListener(new ActionListener() {

                Integer rowsDeleted;

                @Override
                public void actionPerformed(ActionEvent evt) {
                    // clears the text area
                    try {
                        resetMigrationButtons();

                        dateobj = new Date();

                        sysOutTextArea.getDocument().remove(0,
                                                            sysOutTextArea.getDocument()
                                                                    .getLength());

                        sysErrTextArea.getDocument().remove(0,
                                                            sysErrTextArea.getDocument()
                                                                    .getLength());

                        LOGGER.debug("===== Environment Variables =====");
                        Map<String, String> env = System.getenv();
                        for (String envName: env.keySet()) {
                            LOGGER.debug(String.format("%s=%s%n", envName, env.get(envName)));
                        }

                        LOGGER.info("");
                        LOGGER.info("===== Delete Entities =====");

                        LOGGER.debug("Deleting tracking table");
                        EtlIsdVerification.deleteTrackingTbl(connFSD);

                        LOGGER.debug("Deleting process log");
                        rowsDeleted = EtlUtilitiesDbms.deleteProcessLog();

                        LOGGER.debug("Performing ISD table count");
                        EtlIsdVerification.doIsdTableCount();

                        LOGGER.debug("Deleting FSD objects");
                        rowsDeleted = EtlUtilitiesDbms.deleteClearList();

                        LOGGER.info("Removed " + rowsDeleted + " entities using the 'Clear List'");

                        LOGGER.info("");
                        LOGGER.debug("===== " + df.format(dateobj) + " =====");
                        LOGGER.debug("DEBUG_0 Java: " + PROCESS_MODULE + ": Text area cleared");
                    } catch (BadLocationException | SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "clear",
                                                   e.getMessage()), e);
                    }
                }
            });

            /*
            *
            */

            c.gridx = 3;
            c.gridy = 0;
            add(resetButton, c);

            /*
            *
            */

            c.gridx = 4;
            c.gridy = 0;
            add(closeButton, c);

            /*
            *
            */

            c.gridx = 5;
            c.gridy = 0;
            add(refreshSqlButton, c);

            /*
            *
            */

            c.gridx = 6;
            c.gridy = 0;
            add(testButton, c);

            // Row 1 - ECM

            c.gridx = 0;
            c.gridy = 1;
            buttonEnums.setEnabled(true);
            if (validationMode) {
                buttonEnums.setEnabled(false);
            }
            add(buttonEnums, c);

            c.gridx = 1;
            c.gridy = 1;
            add(buttonLCPolicy, c);

            c.gridx = 2;
            c.gridy = 1;
            add(buttonPrjct, c);

            c.gridx = 3;
            c.gridy = 1;
            add(buttonWrkflTemp, c);

            c.gridx = 4;
            c.gridy = 1;
            add(buttonWrkflInst, c);

            c.gridx = 5;
            c.gridy = 1;
            add(buttonWrkflActInst, c);

            c.gridx = 6;
            c.gridy = 1;
            add(buttonWrkflSuspend, c);

            c.gridx = 7;
            c.gridy = 1;
            add(buttonUserCmnts, c);

            // Row 2 - DAQ

            c.gridx = 0;
            c.gridy = 2;
            buttonCase.setEnabled(true);
            add(buttonCase, c);

            c.gridx = 1;
            c.gridy = 2;
            buttonCollector.setEnabled(true);
            add(buttonCollector, c);

            c.gridx = 2;
            c.gridy = 2;
            buttonCaseTrk.setEnabled(true);
            add(buttonCaseTrk, c);

            c.gridx = 3;
            c.gridy = 2;
            buttonReelInfo.setEnabled(true);
            add(buttonReelInfo, c);

            c.gridx = 4;
            c.gridy = 2;
            buttonReelCut.setEnabled(true);
            add(buttonReelCut, c);

            c.gridx = 5;
            c.gridy = 2;
            buttonCollectionEvent.setEnabled(true);
            add(buttonCollectionEvent, c);

            c.gridx = 6;
            c.gridy = 2;
            buttonEventTargetChar.setEnabled(true);
            add(buttonEventTargetChar, c);

            // adds event handler for GRAM SPLC button

            c.gridx = 7;
            c.gridy = 2;
            buttonGramSplc.setEnabled(true);
            add(buttonGramSplc, c);

            buttonGramSplc.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.GRAMS_SPLC, buttonGramSplc);
                }
            });

            c.gridx = 0;
            c.gridy = 3;
            buttonAuxSupport.setEnabled(true);
            add(buttonAuxSupport, c);

            c.gridx = 1;
            c.gridy = 3;
            buttonBtr.setEnabled(true);
            add(buttonBtr, c);

            c.gridx = 2;
            c.gridy = 3;
            buttonCGram.setEnabled(true);
            add(buttonCGram, c);

            c.gridx = 3;
            c.gridy = 3;
            buttonFanOfBeams.setEnabled(true);
            add(buttonFanOfBeams, c);

            c.gridx = 4;
            c.gridy = 3;
            buttonGram.setEnabled(true);
            add(buttonGram, c);

            c.gridx = 5;
            c.gridy = 3;
            buttonHorizontalMeasurement.setEnabled(true);
            add(buttonHorizontalMeasurement, c);

            c.gridx = 6;
            c.gridy = 3;
            buttonHtmlAndPng.setEnabled(true);
            add(buttonHtmlAndPng, c);

            c.gridx = 7;
            c.gridy = 3;
            buttonMSOfficeDoc.setEnabled(true);
            add(buttonMSOfficeDoc, c);

            c.gridx = 0;
            c.gridy = 4;
            buttonNad.setEnabled(true);
            add(buttonNad, c);

            c.gridx = 1;
            c.gridy = 4;
            buttonPsd.setEnabled(true);
            add(buttonPsd, c);

            c.gridx = 2;
            c.gridy = 4;
            buttonSensorId.setEnabled(false);
            add(buttonSensorId, c);

            c.gridx = 3;
            c.gridy = 4;
            buttonSGrm.setEnabled(true);
            add(buttonSGrm, c);

            c.gridx = 4;
            c.gridy = 4;
            buttonSummarySpl.setEnabled(false);
            add(buttonSummarySpl, c);

            c.gridx = 5;
            c.gridy = 4;
            buttonSwimsExportXml.setEnabled(false);
            add(buttonSwimsExportXml, c);

            c.gridx = 6;
            c.gridy = 4;
            buttonTappXml.setEnabled(false);
            add(buttonTappXml, c);

            c.gridx = 7;
            c.gridy = 4;
            buttonTgtTrackSolution.setEnabled(false);
            add(buttonTgtTrackSolution, c);

            c.gridx = 0;
            c.gridy = 5;
            buttonTimeSeries.setEnabled(true);
            add(buttonTimeSeries, c);

            c.gridx = 1;
            c.gridy = 5;
            buttonTpsBearing.setEnabled(true);
            add(buttonTpsBearing, c);

            c.gridx = 2;
            c.gridy = 5;
            buttonTpsSoundSp.setEnabled(true);
            add(buttonTpsSoundSp, c);

            c.gridx = 3;
            c.gridy = 5;
            buttonTpsTimestamp.setEnabled(true);
            add(buttonTpsTimestamp, c);

            c.gridx = 4;
            c.gridy = 5;
            buttonVertMeasurements.setEnabled(false);
            add(buttonVertMeasurements, c);

            c.gridx = 5;
            c.gridy = 5;
            buttonWavFile.setEnabled(true);
            add(buttonWavFile, c);

            c.gridx = 6;
            c.gridy = 5;
            buttonFileDescMeta.setEnabled(true);
            add(buttonFileDescMeta, c);

            // Row 6 and 7 - ECM

            // adds event handler for Platform Class

            c.gridx = 0;
            c.gridy = 6;
            buttonPlatformClass.setEnabled(true);
            add(buttonPlatformClass, c);

            buttonPlatformClass.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        buttonPlatformClass.setBackground(Color.RED);
                        PlatformClassMigrationManager manager = new PlatformClassMigrationManager();
                        executeCoiDataMigration(manager, buttonPlatformClass);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "create PlatformClassMigrationManager",
                                                   e.getMessage()), e);
                    }
                }
            });

            // adds event handler for COI Platform button

            c.gridx = 1;
            c.gridy = 6;
            buttonContactOfInterestPlatform.setEnabled(true);
            add(buttonContactOfInterestPlatform, c);

            buttonContactOfInterestPlatform.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        buttonContactOfInterestPlatform.setBackground(Color.RED);
                        coiPlatMap = new CoiPlatformHashMap();
                        CoiPlatformMigrationManager manager = new CoiPlatformMigrationManager();
                        executeCoiDataMigration(manager, buttonContactOfInterestPlatform);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "create CoiPlatformMigrationManager",
                                                   e.getMessage()), e);
                    }
                }
            });

            // adds event handler for COI Segment button

            c.gridx = 2;
            c.gridy = 6;
            buttonCOISegment.setEnabled(true);
            add(buttonCOISegment, c);

            buttonCOISegment.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        buttonCOISegment.setBackground(Color.RED);
                        CoiSegmentMigrationManager manager = new CoiSegmentMigrationManager();
                        executeCoiDataMigration(manager, buttonCOISegment);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "create CoiSegmentMigrationManager",
                                                   e.getMessage()), e);
                    }
                }
            });

            // adds event handler for Frequency Identifier button

            c.gridx = 3;
            c.gridy = 6;
            buttonFreqIdent.setEnabled(true);
            add(buttonFreqIdent, c);

            buttonFreqIdent.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        buttonFreqIdent.setBackground(Color.RED);
                        FrequencyIdentifierMigrationManager manager =
                                new FrequencyIdentifierMigrationManager();
                        executeCoiDataMigration(manager, buttonFreqIdent);
                    } catch (SQLException e) {
                        LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                                   "create FrequencyIdentifierMigrationManager",
                                                   e.getMessage()), e);
                    }
                }
            });

            // adds event handler for Contact Characterized Sources button

            c.gridx = 4;
            c.gridy = 6;
            buttonContactCharacterizedSources.setEnabled(true);
            add(buttonContactCharacterizedSources, c);

            buttonContactCharacterizedSources.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    try {
                        buttonContactCharacterizedSources.setBackground(Color.RED);
                        CoiCharacterizedSourcesMigrationManager manager =
                                new CoiCharacterizedSourcesMigrationManager();
                        executeCoiDataMigration(manager, buttonContactCharacterizedSources);
                    } catch (SQLException e) {
                        LOGGER.error(String
                                .format(DSSConstants.EXCEPTION_OCCURRED,
                                        "create CoiCharacterizedSourcesMigrationManager",
                                        e.getMessage()), e);
                    }
                }
            });

            // adds event handler for Observed Target Segment Summary button

            c.gridx = 5;
            c.gridy = 6;
            buttonObservedTargetSegmentSummary.setEnabled(true);
            add(buttonObservedTargetSegmentSummary, c);

            buttonObservedTargetSegmentSummary.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.OBSERVED_TARGET_SEGMENT_SUMMARY,
                                         buttonObservedTargetSegmentSummary);
                }
            });

            c.gridx = 0;
            c.gridy = 9;
            c.gridwidth = 9;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 1.0;
            c.weighty = 1.0;
            add(new JScrollPane(sysOutTextArea), c);

            // adds event handler for Enums button

            buttonEnums.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeEnumMigration();
                }
            });

            // adds event handler for Life Cycle button

            buttonLCPolicy.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.RETENTION_POLICY, buttonLCPolicy);
                }
            });

            // adds event handler for Project button

            buttonPrjct.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.PROJECT, buttonPrjct);
                }
            });

            // adds event handler for Workflow Template button

            buttonWrkflTemp.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WORKFLOW_TEMPLATE, buttonWrkflTemp);
                }
            });

            // adds event handler for Workflow Instance button

            buttonWrkflInst.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WORKFLOW_INSTANCE, buttonWrkflInst);
                }
            });

            // adds event handler for Workflow Activity Instance button

            buttonWrkflActInst.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WORKFLOW_ACTIVITY_INSTANCE,
                                         buttonWrkflActInst);
                }
            });

            // adds event handler for User Comments button

            buttonUserCmnts.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WORKFLOW_USER_COMMENTS, buttonUserCmnts);
                }
            });

            // adds event handler for Workflow Suspend button

            buttonWrkflSuspend.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WORKFLOW_SUSPEND, buttonWrkflSuspend);
                }
            });

            // adds event handler for Case button

            buttonCase.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.CASE, buttonCase);
                }
            });

            // adds event handler for button Case Tracking

            buttonCaseTrk.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.CASE_TRACKING_DATA, buttonCaseTrk);
                }
            });

            // adds event handler for Reel Info button

            buttonReelInfo.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.REEL_INFO, buttonReelInfo);
                }
            });

            // adds event handler for Reel Cut button

            buttonReelCut.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.REEL_CUT, buttonReelCut);
                }
            });

            // adds event handler for Collection Event button

            buttonCollectionEvent.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.COLLECTION_EVENT, buttonCollectionEvent);
                }
            });

            // adds event handler for Event Target Characterization button

            buttonEventTargetChar.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.EVENT_TARGET_CHARACTERIZATION,
                                         buttonEventTargetChar);
                }
            });

            // adds event handler for Collector button

            buttonCollector.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.COLLECTOR, buttonCollector);
                }
            });

            // adds event handler for Sensor button

            buttonSensor.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {}
            });

            // adds event handler for Auxiliary Support button

            buttonAuxSupport.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.AUXILIARY_SUPPORT, buttonAuxSupport);
                }
            });

            // adds event handler for BTR button

            buttonBtr.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.BTR, buttonBtr);
                }
            });

            // adds event handler for CGRAM button

            buttonCGram.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.CGRAM, buttonCGram);
                }
            });

            // adds event handler for FOB button

            buttonFanOfBeams.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.FAN_OF_BEAMS, buttonFanOfBeams);
                }
            });

            // adds event handler for Gram button

            buttonGram.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.GRAM, buttonGram);
                }
            });

            // adds event handler for Horizontal Meas button

            buttonHorizontalMeasurement.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.HORIZONTAL_MEASUREMENTS,
                                         buttonHorizontalMeasurement);
                }
            });

            // adds event handler for HTML/PNG button

            buttonHtmlAndPng.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.HTML_AND_PNG, buttonHtmlAndPng);
                }
            });

            // adds event handler for MS OFffice Doc button

            buttonMSOfficeDoc.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.MS_OFFICE_DOC, buttonMSOfficeDoc);
                }
            });

            // adds event handler for NAD button

            buttonNad.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.NAD, buttonNad);
                }
            });

            // adds event handler for PSD button

            buttonPsd.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.PSD, buttonPsd);
                }
            });

            // adds event handler for Sensor ID button

            buttonSensorId.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.SENSOR_IDENTIFICATION, buttonSensorId);
                }
            });

            // adds event handler for SGRM button

            buttonSGrm.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.SGRM, buttonSGrm);
                }
            });

            // adds event handler for Summary SPL button

            buttonSummarySpl.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.SUMMARY_SPL, buttonSummarySpl);
                }
            });

            // adds event handler for SWIMS XML button

            buttonSwimsExportXml.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.SWIMS_EXPORT_XML, buttonSwimsExportXml);
                }
            });

            // adds event handler for TAPP XML button

            buttonTappXml.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TAPP_XML, buttonTappXml);
                }
            });

            // adds event handler for Target Track button

            buttonTgtTrackSolution.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TARGET_TRACK_SOLUTION,
                                         buttonTgtTrackSolution);
                }
            });

            // adds event handler for Time Series button

            buttonTimeSeries.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TIME_SERIES, buttonTimeSeries);
                }
            });

            // adds event handler for TPS Bearing button

            buttonTpsBearing.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TPS_BEARING, buttonTpsBearing);
                }
            });

            // adds event handler for TPS Sound Speed button

            buttonTpsSoundSp.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TPS_SOUND_SPEED, buttonTpsSoundSp);
                }
            });

            // adds event handler for TPS Timestamp button

            buttonTpsTimestamp.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.TPS_TIMESTAMP, buttonTpsTimestamp);
                }
            });

            // adds event handler for Vertical Meas button

            buttonVertMeasurements.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.VERTICAL_MEASUREMENTS,
                                         buttonVertMeasurements);
                }
            });

            // adds event handler for Wav File button

            buttonWavFile.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.WAVFILE, buttonWavFile);
                }
            });

            // adds event handler for File Descriptive Metadata button

            buttonFileDescMeta.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent evt) {
                    executeDataMigration(EIsdTableNames.FILE_DESCRIPTIVE_METADATA,
                                         buttonFileDescMeta);
                }
            });
        }
    }

    protected LdapUsers getLdapUsers() {
        LdapUsers ldapUsers = new LdapUsers();

        // Get LDAP Properties
        Map<String, String> props = new HashMap<>();
        props.put(LdapUsers.LDAP_CN_PROPERTY, DSSSettings.getLdapCn());
        props.put(LdapUsers.LDAP_DEPARTMENT_ATTR_PROPERTY, "departmentNumber");
        props.put(LdapUsers.LDAP_DOMAIN_PROPERTY, DSSSettings.getLdapOu());
        props.put(LdapUsers.LDAP_GROUPS_OU_PROPERTY, "groups");
        props.put(LdapUsers.LDAP_PASSWORD_PROPERTY, DSSSettings.getLdapPassword());
        props.put(LdapUsers.LDAP_PERMISSIONS_OU_PROPERTY, "permissions");
        props.put(LdapUsers.LDAP_ROLE_ATTR_PROPERTY, "employeeType");
        props.put(LdapUsers.LDAP_ROLES_OU_PROPERTY, "roles");
        props.put(LdapUsers.LDAP_URL_PROPERTY, DSSSettings.getLdapUrl());
        props.put(LdapUsers.LDAP_USER_OU_PROPERTY, "people");
        props.put(LdapUsers.LDAP_USER_PROPERTY, DSSSettings.getLdapUser());

        // Activate LDAP User with properties
        ldapUsers.activate(props);

        return ldapUsers;
    }

    protected void resetMigrationButtons() {
        buttonEnums.setBackground(defaultColor);
        buttonLCPolicy.setBackground(defaultColor);
        buttonPrjct.setBackground(defaultColor);
        buttonWrkflTemp.setBackground(defaultColor);
        buttonWrkflInst.setBackground(defaultColor);
        buttonWrkflActInst.setBackground(defaultColor);
        buttonWrkflSuspend.setBackground(defaultColor);
        buttonUserCmnts.setBackground(defaultColor);

        buttonCase.setBackground(defaultColor);
        buttonCaseTrk.setBackground(defaultColor);
        buttonReelInfo.setBackground(defaultColor);
        buttonReelCut.setBackground(defaultColor);
        buttonCollectionEvent.setBackground(defaultColor);
        buttonEventTargetChar.setBackground(defaultColor);
        buttonCollector.setBackground(defaultColor);
        buttonSensor.setBackground(defaultColor);

        buttonContactOfInterestPlatform.setBackground(defaultColor);
        buttonContactOfInterest.setBackground(defaultColor);
        buttonContactCharacterizedSources.setBackground(defaultColor);
        buttonContactGeometryEstimate.setBackground(defaultColor);
        buttonContactGeospatialTracks.setBackground(defaultColor);
        buttonPlatformClass.setBackground(defaultColor);
        buttonCOISegment.setBackground(defaultColor);
        buttonFreqIdent.setBackground(defaultColor);

        buttonContactOfInterestSegmentSummary.setBackground(defaultColor);
        buttonContactOperationalProfile.setBackground(defaultColor);
        buttonGeoSpatialPositions.setBackground(defaultColor);
        buttonObservedTargetSegmentSummary.setBackground(defaultColor);

        // buttonGram.setBackground(defaultColor);
        buttonGramSplc.setBackground(defaultColor);
        buttonSplcAspectMeasurement.setBackground(defaultColor);
        buttonSplcContactMeasurement.setBackground(defaultColor);
        buttonSplcMeasurementEvent.setBackground(defaultColor);
        buttonSplcPointMeasurement.setBackground(defaultColor);
        buttonSplcSourceMeasurement.setBackground(defaultColor);
        buttonSplcVersion.setBackground(defaultColor);

        buttonAuxSupport.setBackground(defaultColor);
        buttonBtr.setBackground(defaultColor);
        buttonCGram.setBackground(defaultColor);
        buttonFanOfBeams.setBackground(defaultColor);
        buttonGram.setBackground(defaultColor);
        buttonHorizontalMeasurement.setBackground(defaultColor);
        buttonHtmlAndPng.setBackground(defaultColor);
        buttonMSOfficeDoc.setBackground(defaultColor);
        buttonNad.setBackground(defaultColor);
        buttonPsd.setBackground(defaultColor);
        buttonSensorId.setBackground(defaultColor);
        buttonSGrm.setBackground(defaultColor);
        buttonSummarySpl.setBackground(defaultColor);
        buttonSwimsExportXml.setBackground(defaultColor);
        buttonTappXml.setBackground(defaultColor);
        buttonTgtTrackSolution.setBackground(defaultColor);
        buttonTimeSeries.setBackground(defaultColor);
        buttonTpsBearing.setBackground(defaultColor);
        buttonTpsSoundSp.setBackground(defaultColor);
        buttonTpsTimestamp.setBackground(defaultColor);
        buttonVertMeasurements.setBackground(defaultColor);
        buttonWavFile.setBackground(defaultColor);
        buttonFileDescMeta.setBackground(defaultColor);
    }

    protected static void executeCoiDataMigration(AbstractCoiMigrationManager pManager,
            JButton pButton) {

        try {
            sysOutTextArea.getDocument().remove(0, sysOutTextArea.getDocument().getLength());
        } catch (BadLocationException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "clear text area",
                                       e.getMessage()), e);
        }
        LOGGER.debug("DEBUG_0 Java: " + PROCESS_MODULE + " : " + pButton.getName() + " pushed.");

        LOGGER.info("executeCoiDataMigration: Starting");
        MigrationMetrics metrics = pManager.executeMigration();
        displayMetrics(metrics, pButton);
    }

    protected static void executeDataMigration(EIsdTableNames pName, JButton pButton) {

        try {
            sysOutTextArea.getDocument().remove(0, sysOutTextArea.getDocument().getLength());
        } catch (BadLocationException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "clear text area",
                                       e.getMessage()), e);
        }
        LOGGER.debug("DEBUG_0 Java: " + PROCESS_MODULE + " : " + pButton.getName() + " pushed.");

        DataMigrationManager manager;
        try {
            LOGGER.info("executeDataMigration: Starting");

            pButton.setBackground(Color.RED);
            manager = new DataMigrationManager(pName);

            MigrationMetrics metrics = manager.executeMigration();
            displayMetrics(metrics, pButton);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                       "create data migration manager", e.getMessage()), e);
        }
    }

    protected static void executeEnumMigration() {
        try {
            sysOutTextArea.getDocument().remove(0, sysOutTextArea.getDocument().getLength());
        } catch (BadLocationException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "clear text area",
                                       e.getMessage()), e);
        }
        LOGGER.debug("DEBUG_0 Java: " + PROCESS_MODULE + " : Enums button pushed.");

        EnumerationMigrationManager manager;
        try {
            LOGGER.info("executeEnumMigration: Starting");

            buttonEnums.setBackground(Color.RED);
            manager = new EnumerationMigrationManager();

            EnumMigrationMetrics metrics = manager.executeMigration();
            displayEnumMetrics(metrics);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                       "create enum migration manager", e.getMessage()), e);
        }
    }

    private static void displayMetrics(MigrationMetrics pMetrics, JButton pButton) {
        // Display metrics
        if (pMetrics.getStatus() == EJobStatusType.COMPLETE) {
            logResults("=== " + pMetrics.getTable() + " migration results ===");
            logResults("Migration start: " + pMetrics.getStartDate());
            logResults("Migration end: " + pMetrics.getEndDate());
            logResults("Total " + pMetrics.getTable() + " records: " + pMetrics.getTotalRecords());
            logResults("Total successfully migrated: " + pMetrics.getNumSuccessfulMigrations());
            logResults("Total partially migrated: " + pMetrics.getNumPartialMigrations());
            logResults("Total failed migration: " + pMetrics.getNumFailedMigrations());
            if (pMetrics.getNumFailedMigrations() > 0 || pMetrics.getNumPartialMigrations() > 0) {

                if (pMetrics.getNumSuccessfulMigrations() > 0
                        || pMetrics.getNumPartialMigrations() > 0) {
                    pButton.setBackground(Color.YELLOW);
                }
                logResults("=== FAILURE REPORT ===");

                for (MigrationResult result: pMetrics.getResults()) {
                    if (!result.isSuccessful()) {
                        for (String error: result.getResults()) {
                            logResults(String.format(MIGRATION_FAILED, result.getRecordId(), error));
                        }
                    }
                }
            } else {
                pButton.setBackground(Color.GREEN);
            }
        } else {
            logResults(pMetrics.getTable() + " migration failed. Reason: " + pMetrics.getErrorMsg());
        }
        logResults("\n");
    }

    private static void displayEnumMetrics(EnumMigrationMetrics pMetrics) {
        // Display metrics
        if (pMetrics.getStatus() == EJobStatusType.COMPLETE) {
            logResults("Migration start: " + pMetrics.getStartDate());
            logResults("Migration end: " + pMetrics.getEndDate());
            logResults("Total enumeration records: " + pMetrics.getTotalRecords());
            logResults("Total successfully migrated: " + pMetrics.getNumSuccessfulMigrations());
            logResults("Total failed migration: " + pMetrics.getNumFailedMigrations());
            if (pMetrics.getNumFailedMigrations() > 0) {

                if (pMetrics.getNumSuccessfulMigrations() > 0) {
                    buttonEnums.setBackground(Color.YELLOW);
                }
                logResults("=== FAILURE REPORT ===");

                for (EnumMigrationResult results: pMetrics.getResults()) {
                    if (results.isSuccessful()) {
                        for (MigrationResult result: results.getMigrationResults()) {
                            if (!result.isSuccessful()) {
                                for (String error: result.getResults()) {
                                    logResults(String.format(MIGRATION_FAILED,
                                                             result.getRecordId(), error));
                                }
                            }
                        }
                    } else {
                        logResults(String.format(ENUM_MIGRATION_FAILED, results.getEnumName(),
                                                 results.getResult()));
                    }
                }
            } else {
                buttonEnums.setBackground(Color.GREEN);
            }
        } else {
            logResults("Enum migration failed. Reason: " + pMetrics.getErrorMsg());
        }
        logResults("\n");
    }

    private static void logResults(String pLogStr) {
        LOGGER.info(pLogStr);

        if (logResults) {
            try {
                // Write results
                FileUtils.write(logFile, pLogStr + "\n", true);
            } catch (IOException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "write log file",
                                           e.getMessage()));
            }
        }
    }

    // Subclass can override to use a different open action.
    protected Action getOpenAction() {
        return openAction;
    }

    // Subclass can override to use a different save action.
    protected Action getSaveAction() {
        return saveAction;
    }

    // Subclass can override to use a different save action.
    protected Action getExitAction() {
        return exitAction;
    }

    protected JTextComponent getTextComponent() {
        return textComp;
    }

    // Create the JTextComponent subclass.
    protected JTextComponent createTextComponent() {
        String processModule = "createTextComponent";

        JTextArea ta = new JTextArea();

        ta.setRows(5);
        ta.setBackground(Color.yellow);
        ta.setEditable(true);
        ta.setLineWrap(true);

        return ta;
    }

    // ********** ACTION INNER CLASSES ********** //

    // EXIT
    // A very simple exit action

    class ExitAction extends AbstractAction {

        public ExitAction() {
            super("Exit", new ImageIcon("resources/icons/system-exit.png"));
        }

        @Override
        public void actionPerformed(ActionEvent ev) {
            System.exit(0);
        }
    }

    // OPEN
    // An action that opens an existing file

    class OpenAction extends AbstractAction {

        public OpenAction(ImageIcon icon, Integer mnemonic) {
            super("Open", new ImageIcon("resources/icons/open.png"));

            putValue(SMALL_ICON, icon);
            putValue(MNEMONIC_KEY, mnemonic);
        }

        // Query user for a filename and attempt to open and read the file into the
        // text component.
        @Override
        public void actionPerformed(ActionEvent ev) {
            JFileChooser chooser = new JFileChooser();
            try {
                chooser.setCurrentDirectory(new File(new File(".").getCanonicalPath()));
            } catch (IOException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "get path",
                                           e.getMessage()), e);
            }
            if (chooser.showOpenDialog(EtlMigrateIsd2Fsd.this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            File file = chooser.getSelectedFile();
            if (file == null) {
                return;
            }

            FileReader reader = null;
            try {
                reader = new FileReader(file);
                textComp.read(reader, null);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(EtlMigrateIsd2Fsd.this, "File Not Found", "ERROR",
                                              JOptionPane.ERROR_MESSAGE);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException x) {}
                }
            }
        }
    }

    // SAVE
    // An action that saves the document to a file

    class SaveAction extends AbstractAction {

        public SaveAction() {
            super("Save", new ImageIcon("resources/icons/save.png"));
        }

        // Query user for a filename and attempt to open and write the text
        // component's content to the file.
        @Override
        public void actionPerformed(ActionEvent ev) {
            JFileChooser chooser = new JFileChooser();
            try {
                chooser.setCurrentDirectory(new File(new File(".").getCanonicalPath()));
            } catch (IOException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "get path",
                                           e.getMessage()), e);
            }
            if (chooser.showSaveDialog(EtlMigrateIsd2Fsd.this) != JFileChooser.APPROVE_OPTION) {
                return;
            }
            File file = chooser.getSelectedFile();
            if (file == null) {
                return;
            }

            FileWriter writer = null;
            try {
                writer = new FileWriter(file);
                textComp.write(writer);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(EtlMigrateIsd2Fsd.this, "File Not Saved", "ERROR",
                                              JOptionPane.ERROR_MESSAGE);
            } finally {
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException x) {}
                }
            }
        }
    }
}
