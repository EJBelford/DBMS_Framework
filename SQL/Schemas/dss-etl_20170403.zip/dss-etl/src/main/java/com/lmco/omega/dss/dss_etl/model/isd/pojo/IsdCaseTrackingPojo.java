/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdCaseTrackingPojo {

    private String id;
    private String collectionRegion;
    private String colletorId;
    private String collectorName;
    private String currentState;
    private String origin;
    private String projections;
    private String prosecutor;
    private Date startCollectionDate;
    private Date stopCollectionDate;
    private String vaultRegistration;
    private String oniCaseNumber;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdCaseTrackingPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the collectionRegion
     */
    public String getCollectionRegion() {
        return collectionRegion;
    }

    /**
     * @param collectionRegion
     *            the collectionRegion to set
     */
    public void setCollectionRegion(String collectionRegion) {
        this.collectionRegion = collectionRegion;
    }

    /**
     * @return the colletorId
     */
    public String getColletorId() {
        return colletorId;
    }

    /**
     * @param colletorId
     *            the colletorId to set
     */
    public void setColletorId(String colletorId) {
        this.colletorId = colletorId;
    }

    /**
     * @return the collectorName
     */
    public String getCollectorName() {
        return collectorName;
    }

    /**
     * @param collectorName
     *            the collectorName to set
     */
    public void setCollectorName(String collectorName) {
        this.collectorName = collectorName;
    }

    /**
     * @return the currentState
     */
    public String getCurrentState() {
        return currentState;
    }

    /**
     * @param currentState
     *            the currentState to set
     */
    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    /**
     * @return the origin
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * @param origin
     *            the origin to set
     */
    public void setOrigin(String origin) {
        this.origin = origin;
    }

    /**
     * @return the projections
     */
    public String getProjections() {
        return projections;
    }

    /**
     * @param projections
     *            the projections to set
     */
    public void setProjections(String projections) {
        this.projections = projections;
    }

    /**
     * @return the prosecutor
     */
    public String getProsecutor() {
        return prosecutor;
    }

    /**
     * @param prosecutor
     *            the prosecutor to set
     */
    public void setProsecutor(String prosecutor) {
        this.prosecutor = prosecutor;
    }

    /**
     * @return the startCollectionDate
     */
    public Date getStartCollectionDate() {
        return startCollectionDate;
    }

    /**
     * @param startCollectionDate
     *            the startCollectionDate to set
     */
    public void setStartCollectionDate(Date startCollectionDate) {
        this.startCollectionDate = startCollectionDate;
    }

    /**
     * @return the stopCollectionDate
     */
    public Date getStopCollectionDate() {
        return stopCollectionDate;
    }

    /**
     * @param stopCollectionDate
     *            the stopCollectionDate to set
     */
    public void setStopCollectionDate(Date stopCollectionDate) {
        this.stopCollectionDate = stopCollectionDate;
    }

    /**
     * @return the vaultRegistration
     */
    public String getVaultRegistration() {
        return vaultRegistration;
    }

    /**
     * @param vaultRegistration
     *            the vaultRegistration to set
     */
    public void setVaultRegistration(String vaultRegistration) {
        this.vaultRegistration = vaultRegistration;
    }

    /**
     * @return the oniCaseNumber
     */
    public String getOniCaseNumber() {
        return oniCaseNumber;
    }

    /**
     * @param oniCaseNumber
     *            the oniCaseNumber to set
     */
    public void setOniCaseNumber(String oniCaseNumber) {
        this.oniCaseNumber = oniCaseNumber;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }
}
