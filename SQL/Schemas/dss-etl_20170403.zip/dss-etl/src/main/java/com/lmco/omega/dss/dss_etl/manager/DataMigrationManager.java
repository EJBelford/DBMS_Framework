/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.factory.DataHandlerFactory;
import com.lmco.omega.dss.dss_etl.handler.AbstractHandler;
import com.lmco.omega.dss.dss_etl.model.MigrationMetrics;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;

/**
 * @author bearyman
 */
public class DataMigrationManager {

    private static final String GET_IDS_SQL = "SELECT t1.%s FROM omega.%s t1;";
    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            DataMigrationManager.class);

    private Connection mIsdConn;
    private List<String> mRecordIds;
    private ExecutorService mExecutor;
    private MigrationMetrics mMetrics;
    private Queue<AbstractHandler> mHandlerQueue;

    private final String mTableName;
    private final String mTableKey;
    private final EIsdTableNames mTableType;

    /**
     * @throws SQLException
     */
    public DataMigrationManager(final EIsdTableNames pTableType) throws SQLException {
        mTableType = pTableType;
        mTableName = pTableType.getTableName();
        mTableKey = pTableType.getPrimaryKey();
        mIsdConn = EtlUtilitiesDbms.getISDConnection();

        String numThreadsStr = EtlUtilities.getEtlConfigValue("numHandlerThreads");
        Integer numThreads = 1;
        if (!StringHelper.isNullOrEmpty(numThreadsStr)) {
            numThreads = Integer.valueOf(numThreadsStr);
        }
        mExecutor = Executors.newFixedThreadPool(numThreads);
    }

    public MigrationMetrics executeMigration() {
        String errorMsg = null;
        mMetrics = new MigrationMetrics(mTableType.getTableName());

        try {
            retrieveTableIds();
            createHandlers();
            executeTasks();
        } catch (SQLException e) {
            errorMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "retrieveTableIds",
                                  e.getMessage());
            LOGGER.error(errorMsg, e);
        } catch (InterruptedException e) {
            errorMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "executeTasks", e.getMessage());
            LOGGER.error(errorMsg, e);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(mIsdConn);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }

        if (errorMsg != null) {
            mMetrics.setErrorMsg(errorMsg);
        }
        return mMetrics;
    }

    private void retrieveTableIds() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();
            results = stmt.executeQuery(String.format(GET_IDS_SQL, mTableKey, mTableName));

            // Build a list of record ids
            mRecordIds = new ArrayList<>();
            while (results.next()) {
                mRecordIds.add(results.getString(1));
            }
            mMetrics.setTotalRecords(mRecordIds.size());
        } finally {
            if (results != null) {
                results.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private void createHandlers() {
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (String key: mRecordIds) {
            DataHandlerFactory factory = new DataHandlerFactory();
            mHandlerQueue.add(factory.getHandler(mTableType, key));
        }
    }

    private void executeTasks() throws InterruptedException {

        MigrationResult result = new MigrationResult();

        // Execute Tasks
        if (!mHandlerQueue.isEmpty()) {
            for (Future<MigrationResult> future: mExecutor.invokeAll(mHandlerQueue)) {

                try {
                    // Get Result
                    result = future.get();
                } catch (InterruptedException | ExecutionException e) {
                    LOGGER.error(e.getMessage(), e);

                    // Create Failed Result
                    result.addResult(e.getMessage());
                }

                mMetrics.addResult(result);
            }
        }

    }
}
