/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data.coi;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.CoiPlatformHashMap;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCoiSegmentPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.contactsegment.ContactSegmentCoalesce;
import com.lmco.omega.ecm.interfaces.model.ContactSegment;

/**
 * @author n67154 - Gene Belford
 */
public class CoiSegmentHandler extends AbstractCoiDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiSegmentHandler.class);
    private IsdCoiSegmentPojo mPojo;

    public CoiSegmentHandler(IsdCoiSegmentPojo pPojo) {
        mPojo = pPojo;
        mKey = "UNKNOWN";
    }

    @Override
    protected CoalesceEntity mapToCoalesce() throws Exception {
        return mapToCoalesce(mPojo);
    }

    protected CoalesceEntity mapToCoalesce(IsdCoiSegmentPojo pPojo) throws Exception {
        methodName = "mapToCoalesce";
        LOGGER.trace(methodName);

        ContactSegmentCoalesce entity;

        IDataConverter<ContactSegment, ContactSegmentCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(ContactSegment.class);

        ContactSegment pojo = converter.constructPojo();

        pojo.setAcousticMode(formatEnumFieldVal(pPojo.getAcousticMode()));
        pojo.setBoundingBoxXOneYOne(null);
        pojo.setBoundingBoxXTwoYTwo(null);
        pojo.setCavitationMode(formatEnumFieldVal(pPojo.getCavitationMode()));
        pojo.setCavitationType(formatEnumFieldVal(pPojo.getCavitationType()));
        pojo.setComments(pPojo.getComments() + migrationTag);
        pojo.setDepthBand(formatEnumFieldVal(pPojo.getDepthBand()));
        pojo.setGeospatialReferenceBroadArea(pPojo.getGeospatialReferenceBroadArea());
        pojo.setGeospatialReferenceRefinedArea(pPojo.getGeospatialReferenceRefinedArea());
        pojo.setHoldStatus(formatEnumFieldVal(pPojo.getHoldStatus()));
        pojo.setModifiable(pPojo.getModifiable());
        pojo.setName(pPojo.getName());
        pojo.setOperatingProfile(formatEnumFieldVal(pPojo.getOperatingProfile()));
        pojo.setPapaLima(pPojo.getPapaLima());
        pojo.setParticipantRole(formatEnumFieldVal(pPojo.getParticipantRole()));
        pojo.setPlatformConfidence(formatEnumFieldVal(pPojo.getPlatformConfidence()));
        pojo.setPropulsionMode(formatEnumFieldVal(pPojo.getPropulsionMode()));
        pojo.setPropulsionType(formatEnumFieldVal(pPojo.getPropulsionType()));
        pojo.setSpeedBand(formatEnumFieldVal(pPojo.getSpeedBand()));
        pojo.setStartDtg(pPojo.getSegment_startTime());
        pojo.setEndDtg(pPojo.getSegment_endTime());
        pojo.setWeaponActivity(formatEnumFieldVal(pPojo.getWeaponActivity()));

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(pPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = entity.getKey();
        mKey = entity.getKey();

        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);

        // Set date created
        DateTime mSegmentStartTime = new DateTime(pPojo.getSegment_startTime());
        cEntity.setDateCreated(mSegmentStartTime);

        return cEntity;

    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";
        LOGGER.trace(methodName);

        System.out.println("CoiSegmentHandler: ParentPlatformName: "
                + mPojo.getParentPlatformName() + " ParentHullNumber: "
                + mPojo.getParentHullNumber());

        String parentId =
                CoiPlatformHashMap.getPlatformClassKey(mPojo.getParentPlatformName(),
                                                       mPojo.getParentHullNumber());

        System.out.println("CoiSegmentHandler: parentId: " + parentId);

        // Link to COI Platform
        linkEntities(mEntityKey, parentId, ELinkType.IS_CHILD_OF, "coi platform",
                     DataObjectLinkActionType.LINK);

        // Link to file object
        linkEntities(mEntityKey, mPojo.getFiledescriptivemetadataid(), ELinkType.IS_A_PEER_OF,
                     "file object", DataObjectLinkActionType.LINK);
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.CONTACT_OF_INTEREST_SEGMENT_SUMMARY;
    }

}
