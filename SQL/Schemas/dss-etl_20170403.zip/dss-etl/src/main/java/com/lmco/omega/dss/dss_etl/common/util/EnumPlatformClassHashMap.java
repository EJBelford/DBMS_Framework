/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

/**
 * @author n67154 (Gene Belford - InCadence)
 */

public class EnumPlatformClassHashMap {

    private static final String GET_ENUM_PLATFORM_CLASS = "SELECT ev.enumvalue, ev.ordering "
            + "FROM coalesce.enumvalue ev " + "WHERE ev.enumtype = 'platformclassname' ";

    HashMap<String, String> enumPlatformClassCache = new HashMap<String, String>();

    private ResultSet iResults;

    private String methodName = null;

    public EnumPlatformClassHashMap() {
        // Do Nothing
    };

    public void retrieveFsdRecs() throws SQLException {
        methodName = "retrieveIsdRecs";

        int rowCnt = 0;
        Connection mFsdConn = null;
        Statement stmt = null;

        // System.out.println("PlatformClassHashMap" + "_" + methodName + ": #: Start");

        mFsdConn = EtlUtilitiesDbms.getFSDConnection();

        try {
            mFsdConn = EtlUtilitiesDbms.getFSDConnection();
            stmt = mFsdConn.createStatement();
            iResults = stmt.executeQuery(GET_ENUM_PLATFORM_CLASS);
            handleFsdResults(iResults);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (mFsdConn != null) {
                mFsdConn.close();
            }
        }
        // System.out.println("PlatformClassHashMap" + "_" + methodName + ": #: Stop");
    }

    public String getEnumPlatformClassKey(String pPlatformClassName) {
        String mEnumOrdering = null;

        mEnumOrdering = enumPlatformClassCache.get(pPlatformClassName);

        return mEnumOrdering;
    }

    protected void handleFsdResults(ResultSet pResults) throws SQLException {
        methodName = "handleIsdResults";

        String mEnumValue;
        String mOrdering;

        int recLoop = 0;

        while (pResults.next()) {
            recLoop++;

            mEnumValue = pResults.getString("enumValue");
            mOrdering = pResults.getString("ordering");

            enumPlatformClassCache.put(mOrdering, mEnumValue);
            enumPlatformClassCache.get(mOrdering);

            // System.out
            // .println("EnumPlatformClassHashMap" + "_" + methodName + ": #: " + recLoop
            // + " mEnumValue: " + mEnumValue + " mOrdering: "
            // + mOrdering);
            // System.out.println("EnumPlatformClassHashMap" + "_" + methodName + ": #: " + recLoop
            // + " platformClassCache.get: " + enumPlatformClassCache.get(mOrdering));
        }
    }
}
