/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.data.coi.PlatformClassHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdPlatformClassPojo;

/**
 * @author bearyman
 */
public class PlatformClassMigrationManager extends AbstractCoiMigrationManager {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            PlatformClassMigrationManager.class);

    /*
     * Platform Class
     * Uniqueness based upon classification
     */
    private static final String GET_PLATFORM_CATEGORY =
            "SELECT DISTINCT "
                    + "/*   '|' AS uniqueIdentifiers,*/ "
                    + "COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "    NULLIF(coiss.classification, ''), 'UNKNOWN') AS classificationName, "

                    + "/*   '|' AS otherFields,*/ "
                    + "COALESCE (NULLIF(coip.refinedtype, ''), NULLIF(coip.refinedcategory, ''), "
                    + "    NULLIF(coiss.platformtype, ''), NULLIF(coiss.category, ''), 'UNKNOWN') AS platformDesignator, "
                    + "cop.numberofpropellershafts AS propellerCount, "
                    + "COALESCE (coip.mandatorymetadata_security_c_0, "
                    + "    coiss.mandatorymetadata_security_c_0) AS mandatorymetadata_security_c_0, "
                    + "COALESCE (coip.mandatorymetadata_security_c_2, "
                    + "    coiss.mandatorymetadata_security_c_2) AS mandatorymetadata_security_c_2, "
                    + "COALESCE (coip.mandatorymetadata_security_c_1, "
                    + "    coiss.mandatorymetadata_security_c_1) AS mandatorymetadata_security_c_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_7, "
                    + "    coiss.mandatorymetadata_security_d_7) AS mandatorymetadata_security_d_7, "
                    + "COALESCE (coip.mandatorymetadata_security_d_6, "
                    + "    coiss.mandatorymetadata_security_d_6) AS mandatorymetadata_security_d_6, "
                    + "COALESCE (coip.mandatorymetadata_security_d_3, "
                    + "    coiss.mandatorymetadata_security_d_3) AS mandatorymetadata_security_d_3, "
                    + "COALESCE (coip.mandatorymetadata_security_d_4, "
                    + "    coiss.mandatorymetadata_security_d_4) AS mandatorymetadata_security_d_4, "
                    + "COALESCE (coip.mandatorymetadata_security_d_5, "
                    + "    coiss.mandatorymetadata_security_d_5) AS mandatorymetadata_security_d_5, "
                    + "COALESCE (coip.mandatorymetadata_security_d_1, "
                    + "    coiss.mandatorymetadata_security_d_1) AS mandatorymetadata_security_d_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_2, "
                    + "    coiss.mandatorymetadata_security_d_2) AS mandatorymetadata_security_d_2, "
                    + "COALESCE (coip.mandatorymetadata_security_d_0, "
                    + "    coiss.mandatorymetadata_security_d_0) AS mandatorymetadata_security_d_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_0, "
                    + "    coiss.mandatorymetadata_security_f_0) AS mandatorymetadata_security_f_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_1, "
                    + "    coiss.mandatorymetadata_security_f_1) AS mandatorymetadata_security_f_1, "
                    + "COALESCE (coip.mandatorymetadata_security_n_0, "
                    + "    coiss.mandatorymetadata_security_n_0) AS mandatorymetadata_security_n_0, "
                    + "COALESCE (coip.mandatorymetadata_security_o_0, "
                    + "    coiss.mandatorymetadata_security_o_0) AS mandatorymetadata_security_o_0, "
                    + "COALESCE (coip.mandatorymetadata_security_r_0, "
                    + "    coiss.mandatorymetadata_security_r_0) AS mandatorymetadata_security_r_0, "
                    + "COALESCE (coip.mandatorymetadata_security_s_1, "
                    + "    coiss.mandatorymetadata_security_s_1) AS mandatorymetadata_security_s_1, "
                    + "COALESCE (coip.mandatorymetadata_security_s_0, "
                    + "    coiss.mandatorymetadata_security_s_0) AS mandatorymetadata_security_s_0, "
                    + "COALESCE (coip.mandatorymetadata_security_t_0, "
                    + "    coiss.mandatorymetadata_security_t_0) AS mandatorymetadata_security_t_0 "
                    + "FROM omega.contactofinterest AS coi "
                    + "  LEFT JOIN omega.contactofinterestplatform AS coip "
                    + "    ON coip.contactid = coi.contactofinterestid "
                    + "  LEFT JOIN omega.metacard_contactofinterest "
                    + "    ON coi.contactofinterestid = metacard_contactofinterest.contactofinterestid "
                    + "  LEFT JOIN omega.mdf_catalog_tab "
                    + "    ON metacard_contactofinterest.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "    ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.filedescriptivemetadata AS filecoi "
                    + "    ON filecoi.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecoiss.filedescriptivemetadataid AS filecoissid, "
                    + "        filecoiss.filename AS filecoissname, "
                    + "        contactofinterestsegmentsumm_0.* "
                    + "      FROM "
                    + "        omega.contactofinterestsegmentsumm_0 "
                    + "        LEFT JOIN omega.metacard_contactofinterestsegmentsummary "
                    + "          ON contactofinterestsegmentsumm_0.contactsegmentid = metacard_contactofinterestsegmentsummary.contactofinterestsegmentsummaryid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactofinterestsegmentsummary.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecoiss "
                    + "          ON filecoiss.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecoiss.filedescriptivemetadataid != '' "
                    + "      ) AS coiss "
                    + "    ON "
                    + "      ( "
                    + "      coiss.contactofinterestid = coi.contactofinterestid "
                    + "      AND filecoissid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecop.filedescriptivemetadataid AS filecopid, "
                    + "        filecop.filename AS filecopname, "
                    + "        contactoperationalprofile.* "
                    + "      FROM "
                    + "       omega.contactoperationalprofile "
                    + "        LEFT JOIN omega.metacard_contactoperationalprofile "
                    + "          ON contactoperationalprofile.contactoperationalprofileid = metacard_contactoperationalprofile.contactoperationalprofileid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactoperationalprofile.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecop "
                    + "          ON filecop.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecop.filedescriptivemetadataid != '' "
                    + "      ) AS cop "
                    + "    ON "
                    + "      ( "
                    + "      cop.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND filecopid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "WHERE "
                    + "  filecoi.filedescriptivemetadataid != '' "
                    + "  AND COALESCE (coip.refinedclassification, coiss.classification, coip.refinedtype, "
                    + "                coip.refinedcategory, coiss.platformtype, coiss.category) != '' "
                    + "ORDER BY " + "classificationName ASC, " + "platformDesignator ASC; ";

    private IsdPlatformClassPojo mPojo;
    private List<IsdPlatformClassPojo> mPojos;

    /**
     * @throws SQLException
     */
    public PlatformClassMigrationManager() throws SQLException {
        mTableType = EIsdTableNames.PLATFORM_CLASS;
        mIsdConn = EtlUtilitiesDbms.getISDConnection();
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws SQLException {
        LOGGER.trace("handleIsdResults");
        mPojos = new ArrayList<>();

        while (pResults.next()) {
            mPojo = new IsdPlatformClassPojo();

            mPojo.setClassificationName(formatEnumString(pResults.getString("classificationName")));
            mPojo.setPlatformDesignator(formatPlatformTypeEnumString(pResults
                    .getString("platformDesignator")));
            mPojo.setPropellerCount(pResults.getInt("propellerCount"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            mPojos.add(mPojo);
        }
        mMetrics.setTotalRecords(mPojos.size());
    }

    @Override
    protected void createHandlers() {
        LOGGER.trace("createHandlers");
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (IsdPlatformClassPojo pojo: mPojos) {
            mHandlerQueue.add(new PlatformClassHandler(pojo));
        }
    }

    @Override
    protected String getQuery() {
        return GET_PLATFORM_CATEGORY;
    }
}
