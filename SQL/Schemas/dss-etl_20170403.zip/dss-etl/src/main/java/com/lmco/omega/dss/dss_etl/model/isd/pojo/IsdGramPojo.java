/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdGramPojo {

    private String gramId;
    private String gramType;
    private IsdFrequencyInfoPojo freqInfoPojo;
    private IsdTimeIntervalPojo timePojo;
    private IsdFileDescriptiveMetadataPojo fdMetadataPojo;

    /**
     *
     */
    public IsdGramPojo() {
        freqInfoPojo = new IsdFrequencyInfoPojo();
        timePojo = new IsdTimeIntervalPojo();
        fdMetadataPojo = new IsdFileDescriptiveMetadataPojo();
    }

    /**
     * @return the gramId
     */
    public String getGramId() {
        return gramId;
    }

    /**
     * @param gramId
     *            the gramId to set
     */
    public void setGramId(String gramId) {
        this.gramId = gramId;
    }

    /**
     * @return the gramType
     */
    public String getGramType() {
        return gramType;
    }

    /**
     * @param gramType
     *            the gramType to set
     */
    public void setGramType(String gramType) {
        this.gramType = gramType;
    }

    /**
     * @return the freqInfoPojo
     */
    public IsdFrequencyInfoPojo getFreqInfoPojo() {
        return freqInfoPojo;
    }

    /**
     * @param freqInfoPojo
     *            the freqInfoPojo to set
     */
    public void setFreqInfoPojo(IsdFrequencyInfoPojo freqInfoPojo) {
        this.freqInfoPojo = freqInfoPojo;
    }

    /**
     * @return the timePojo
     */
    public IsdTimeIntervalPojo getTimePojo() {
        return timePojo;
    }

    /**
     * @param timePojo
     *            the timePojo to set
     */
    public void setTimePojo(IsdTimeIntervalPojo timePojo) {
        this.timePojo = timePojo;
    }

    /**
     * @return the fdMetadataPojo
     */
    public IsdFileDescriptiveMetadataPojo getFdMetadataPojo() {
        return fdMetadataPojo;
    }

    /**
     * @param fdMetadataPojo
     *            the fdMetadataPojo to set
     */
    public void setFdMetadataPojo(IsdFileDescriptiveMetadataPojo fdMetadataPojo) {
        this.fdMetadataPojo = fdMetadataPojo;
    }

}
