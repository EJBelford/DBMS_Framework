/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;

/**
 * @author n67154 (Gene Belford - InCadence)
 */

public class CoiSegmentHashMap {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiSegmentHashMap.class);
    private static final String GET_COI_SEGMENT = "SELECT csr.entitykey, csr.name "
            + "FROM coalesce.contact_segment_record csr";

    private HashMap<String, String> coiSegmentCache = new HashMap<String, String>();

    private ResultSet iResults;

    private String methodName = null;

    public CoiSegmentHashMap() throws SQLException {
        retrieveFsdRecs();
    }

    public String getCoiSegmentKey(String pCoiSegmentName) {
        String mEntityKey = null;

        mEntityKey = coiSegmentCache.get(pCoiSegmentName);

        return mEntityKey;
    }

    private void retrieveFsdRecs() throws SQLException {
        methodName = "retrieveIsdRecs";

        int rowCnt = 0;
        Connection mFsdConn = null;
        Statement stmt = null;

        LOGGER.debug("CoiSegmentHashMap" + "_" + methodName + ": #: Start");

        try {
            mFsdConn = EtlUtilitiesDbms.getFSDConnection();
            stmt = mFsdConn.createStatement();
            iResults = stmt.executeQuery(GET_COI_SEGMENT);
            handleFsdResults(iResults);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (mFsdConn != null) {
                EtlUtilitiesDbms.closeConn(mFsdConn);
            }
        }
        LOGGER.debug("CoiSegmentHashMap" + "_" + methodName + ": #: Stop");
    }

    private void handleFsdResults(ResultSet pResults) throws SQLException {
        methodName = "handleIsdResults";

        String mEntityKey;
        String mClassificationName;

        int recLoop = 0;

        while (pResults.next()) {
            recLoop++;

            mEntityKey = pResults.getString("entitykey");
            mClassificationName = pResults.getString("name");

            coiSegmentCache.put(mClassificationName, mEntityKey);
            coiSegmentCache.get(mClassificationName);

            LOGGER.debug("CoiSegementHashHashMap" + "_" + methodName + ": #: " + recLoop
                    + " mEntityKey: " + mEntityKey + " mClassificationName: " + mClassificationName);
            LOGGER.debug("CoiSegementHashMap" + "_" + methodName + ": #: " + recLoop
                    + " coiSegmentCache.get: " + coiSegmentCache.get(mClassificationName));
        }
    }
}
