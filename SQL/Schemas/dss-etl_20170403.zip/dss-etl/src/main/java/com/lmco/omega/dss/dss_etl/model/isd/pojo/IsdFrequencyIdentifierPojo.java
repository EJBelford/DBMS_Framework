/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author n67154 - Gene Belford - InCadence
 */

public class IsdFrequencyIdentifierPojo {

    // ----- parent ------
    private String parentPlatformClass;
    private String parentPlatformName;
    private String parentHullNumber;

    private String id;
    private String sourceOriginName;
    private String userLabel;
    private String sourceCatagory;
    private int harmonic;
    private int bladesperpropeller;
    private String enginelocation;
    private String enginetype;
    private String propellerlocation;
    private double reductionratio;
    private int turnsperknot;

    private IsdMandatorySecurityPojo security;

    /*
     *
     */
    public IsdFrequencyIdentifierPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

    /**
     * @return the id
     */

    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the bladesperpropeller
     */

    public int getBladesperpropeller() {
        return bladesperpropeller;
    }

    /**
     * @param bladesperpropeller
     *            the bladesperpropeller to set
     */

    public void setBladesperpropeller(int bladesperpropeller) {
        this.bladesperpropeller = bladesperpropeller;
    }

    /**
     * @return the enginelocation
     */

    public String getEnginelocation() {
        return enginelocation;
    }

    /**
     * @param enginelocation
     *            the enginelocation to set
     */

    public void setEnginelocation(String enginelocation) {
        this.enginelocation = enginelocation;
    }

    /**
     * @return the enginetype
     */

    public String getEnginetype() {
        return enginetype;
    }

    /**
     * @param enginetype
     *            the enginetype to set
     */

    public void setEnginetype(String enginetype) {
        this.enginetype = enginetype;
    }

    /**
     * @return the propellerlocation
     */

    public String getPropellerlocation() {
        return propellerlocation;
    }

    /**
     * @param propellerlocation
     *            the propellerlocation to set
     */

    public void setPropellerlocation(String propellerlocation) {
        this.propellerlocation = propellerlocation;
    }

    /**
     * @return the reductionratio
     */

    public double getReductionratio() {
        return reductionratio;
    }

    /**
     * @param reductionratio
     *            the reductionratio to set
     */

    public void setReductionratio(double reductionratio) {
        this.reductionratio = reductionratio;
    }

    /**
     * @return the turnsperknot
     */

    public int getTurnsperknot() {
        return turnsperknot;
    }

    /**
     * @param turnsperknot
     *            the turnsperknot to set
     */

    public void setTurnsperknot(int turnsperknot) {
        this.turnsperknot = turnsperknot;
    }

    /**
     * @return the sourceOriginName
     */

    public String getSourceOriginName() {
        return sourceOriginName;
    }

    /**
     * @param sourceOriginName
     *            the sourceOriginName to set
     */

    public void setSourceOriginName(String sourceOriginName) {
        this.sourceOriginName = sourceOriginName;
    }

    /**
     * @return the userLabel
     */

    public String getUserLabel() {
        return userLabel;
    }

    /**
     * @param userLabel
     *            the userLabel to set
     */

    public void setUserLabel(String userLabel) {
        this.userLabel = userLabel;
    }

    /**
     * @return the harmonic
     */

    public int getHarmonic() {
        return harmonic;
    }

    /**
     * @param harmonic
     *            the harmonic to set
     */

    public void setHarmonic(int harmonic) {
        this.harmonic = harmonic;
    }

    /**
     * @return the sourceCatagory
     */

    public String getSourceCatagory() {
        return sourceCatagory;
    }

    /**
     * @param sourceCatagory
     *            the sourceCatagory to set
     */

    public void setSourceCatagory(String sourceCatagory) {
        this.sourceCatagory = sourceCatagory;
    }

    /**
     * @return the parentPlatformClass
     */
    public String getParentPlatformClass() {
        return parentPlatformClass;
    }

    /**
     * @param parentPlatformClass
     *            the parentPlatformClass to set
     */
    public void setParentPlatformClass(String parentPlatformClass) {
        this.parentPlatformClass = parentPlatformClass;
    }

    /**
     * @return the parentPlatformName
     */
    public String getParentPlatformName() {
        return parentPlatformName;
    }

    /**
     * @param parentPlatformName
     *            the parentPlatformName to set
     */
    public void setParentPlatformName(String parentPlatformName) {
        this.parentPlatformName = parentPlatformName;
    }

    /**
     * @return the parentHullNumber
     */
    public String getParentHullNumber() {
        return parentHullNumber;
    }

    /**
     * @param parentHullNumber
     *            the parentHullNumber to set
     */
    public void setParentHullNumber(String parentHullNumber) {
        this.parentHullNumber = parentHullNumber;
    }

}
