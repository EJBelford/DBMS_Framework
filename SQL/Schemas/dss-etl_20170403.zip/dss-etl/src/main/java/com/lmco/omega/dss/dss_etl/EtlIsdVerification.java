/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl;

import java.io.File;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.Timer;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;

/**
 * -+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 * Module Name: etl_isd_verification
 * Author:..... Gene Belford /n67154
 * Description:
 * Date:....... 2016-02-25
 * Source File: etl_isd_verification.java
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 * Change History
 * ==============
 * Date...... Chng_Ctrl Name................ Description
 * ========== ========= ==================== =============================
 * 2016-02-25 ......... Gene Belford........ Created
 * 2016-03-02 ......... Gene Belford........ verificationMain - A simple shell for unit testing
 * and debugging.
 * 2016-03-02 ......... Gene Belford........ loopIsdDbmsRecs - Uses a list of entries found in the
 * ISD database to verify that a files exist for that record. Writes performance metrics out to
 * etl_process_log.
 * 2016-03-02 ......... Gene Belford........ doesMetacardFileExist - Test to see if the file
 * exists
 * at the recorded location. If the file is not found a functional warning is generated.
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 */

public class EtlIsdVerification extends JFrame {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlIsdVerification.class);
    static String processName = "EtlIsdVerification";

    Timer timer = null;

    // static ProgressMonitor progressMonitor;
    // static int percentComplete = 0;

    public EtlIsdVerification() {
        super("Migration Progress");
        setSize(400, 100);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); // EXIT_ON_CLOSE);

        setVisible(true);
    }

    /*
     * 2016-03-02 ......... Gene Belford ........ verificationMain - A simple shell for unit testing
     * and debugging.
     */

    public static void main(String target, Connection connISD, Connection connFSD) {

        String processModule = "verificationMain";

        Boolean fileExistsBool;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + '_' + processModule);

        String ISDpathname = "../../../../../gpfs/main/";
        String ISDfilename = "";

        fileExistsBool = doesMetacardFileExist(connISD, ISDpathname, ISDfilename);

        if (!fileExistsBool) {
            LOGGER.debug("DEBUG_0 SQL:  " + processName + "_" + processModule
                    + "Metacard file does not exist " + ISDpathname + " " + ISDfilename);
        }

        ISDfilename = "";
        fileExistsBool =
                EtlIsdVerification.doesMetacardFileExist(connISD, ISDpathname, ISDfilename);

        ISDfilename = "log-05-14-02.txt";
        fileExistsBool =
                EtlIsdVerification.doesMetacardFileExist(connISD, ISDpathname, ISDfilename);

        ISDfilename = "log-05-14-14.txt";
        fileExistsBool =
                EtlIsdVerification.doesMetacardFileExist(connISD, ISDpathname, ISDfilename);

        try {
            retrieveIsdMetadata(ISDfilename, connISD, connFSD);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "retrieveIsdMetadata",
                                       e.getMessage()), e);
        }

    }

    /*
     * 2016-03-02 ......... Gene Belford........ loopIsdDbmsRecs - Uses a list of entries found in
     * the ISD database to verify that a files exist for that record. Writes performance metrics out
     * to etl_process_log.
     */

    static void loopIsdDbmsRecs() {

        String processModule = "loopIsdDbmsRecs";

        Boolean fileExistsBool = null;

        Statement connFsdStmt = null;
        Statement updtStmt = null;
        ResultSet connResults = null;

        int recId;
        int recIdDBMS = -1;

        int recUpdated = -1;

        String pathname = null;
        String sqlStr = null;

        int debugFlag = 1;
        // debugFlag = EtlUtilities.getDebugFlag(processName + "_" + processModule);

        String sqlLimit = EtlUtilities.getEtlConfigValue("sqlLimit");
        LOGGER.debug("DEBUG_0 debugFlag:" + debugFlag + " sqlLimit:" + sqlLimit);

        pathname = EtlUtilities.getEtlConfigValue("isdBulkStorage");
        LOGGER.debug("DEBUG_0 " + processName + "_" + processModule + ": pathname: " + pathname);

        Connection connFSD = null;
        Statement connFSDStmt = null;
        try {
            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);
            sqlStr =
                    "SELECT * FROM migrate_isd2fsd.etl_metacard_tracking_list "
                            + "WHERE catalog_dao_uri IS NOT NULL LIMIT " + sqlLimit + ";";
            connResults = connFSDStmt.executeQuery(sqlStr);
        } catch (SQLException e1) {
            LOGGER.error(e1.getMessage(), e1);
            System.exit(0);
        }

        try {
            updtStmt = EtlUtilitiesDbms.getStmt(connFSD);

            recUpdated = 0;

            recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");
            while (connResults.next()) {
                recId = connResults.getInt("rec_id");
                String catalog_dao_uri = connResults.getString("catalog_dao_uri");

                // isdtable text,
                // isdrecordidentifier text,
                String isdfilename = connResults.getString("isdfilename");
                String isdfileext = connResults.getString("isdfileext");
                // isdfiletitle text,
                String isdfilepath = connResults.getString("isdfilepath");
                // isdfileurl text,
                String isdfiletype = connResults.getString("isdfiletype");
                // isdfileexists boolean,

                LOGGER.debug("DEBUG_0 RecId: " + recId + "  ISD File Type: " + isdfiletype);
                LOGGER.debug("DEBUG_0 catalog_dao_uri: " + catalog_dao_uri);
                LOGGER.debug("DEBUG_0 isdfilepath: " + isdfilepath);
                LOGGER.debug("DEBUG_0 isdfilename: " + isdfilename);
                LOGGER.debug("DEBUG_0 isdfileext: " + isdfileext);
                if (catalog_dao_uri.length() > 12) {
                    LOGGER.debug("DEBUG_0 URI: " + pathname + catalog_dao_uri.substring(12));
                }

                if (catalog_dao_uri.length() > 12) {
                    // fileExistsBool =
                    // doesMetacardFileExist(connFSD, pathname, catalog_dao_uri.substring(12));
                    fileExistsBool =
                            doesMetacardFileExist(connFSD, pathname, "/" + isdfilename + "."
                                    + isdfileext);

                    LOGGER.debug("DEBUG_0 File exisits: " + fileExistsBool);

                    sqlStr =
                            "UPDATE migrate_isd2fsd.etl_metacard_tracking_list "
                                    + "SET isdfileexists = " + fileExistsBool
                                    + ", updatedatetime = clock_timestamp() " + "WHERE rec_id = "
                                    + recId + ";";
                    updtStmt.executeUpdate(sqlStr);

                    recUpdated = recUpdated + 1;
                }
            }
        } catch (SQLException e2) {
            LOGGER.error(e2.getClass().getName() + ": " + e2.getMessage(), e2);
            System.exit(0);
        }

        try {
            recIdDBMS =
                    EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", recUpdated,
                                                      "File verification ended");
            if (updtStmt != null) {
                updtStmt.close();
            }
        } catch (SQLException e3) {
            LOGGER.error(e3.getClass().getName() + ": " + e3.getMessage(), e3);
            System.exit(0);
        }
    }

    /*
     * 2016-03-02 ......... Gene Belford........ doesMetacardFileExist - Test to see if the file
     * exists at the recorded location. If the file is not found a functional warning is generated.
     */

    static Boolean doesMetacardFileExist(Connection connISD, String pathname, String filename) {

        String processModule = "doesMetacardFileExist";

        Boolean fileExistsBool = false;

        LOGGER.debug("========================");
        LOGGER.debug(processName + "_" + processModule + ": pathname: " + pathname + " filename: "
                + filename);

        fileExistsBool = new File(pathname + filename).isFile();

        String errMsg =
                "etl_utilities Module: " + processModule + pathname + filename + " exisits: "
                        + fileExistsBool;

        if (fileExistsBool == false) {
            try {
                EtlUtilitiesDbms.processFuncWarnInsert(processName, processModule, "ExistsFailed",
                                                       errMsg, pathname + filename);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                           "processFuncWarnInsert", e.getMessage()), e);
            }
        }

        LOGGER.debug("DEBUG_0 " + errMsg);

        return fileExistsBool;
    }

    /**
     * <h1>retrieveIsdMetadata</h1>
     * <p>
     * Returns the integer flag for the requested module. Can be used to turn on/off debugging in
     * compiled applications. The default is 0 if a bad key is passed in.
     *
     * @param etlProcessingTarget
     * @param connISD
     * @param connFSD
     * @throws SQLException
     * @since 2016-03-02
     * @author Gene Belford - n67154
     */

    public static void retrieveIsdMetadata(String etlProcessingTarget, Connection connISD,
            Connection connFSD) throws SQLException {

        String processModule = "retrieveIsdMetadata";

        int recIdDBMS;

        @SuppressWarnings("unused")
        Statement connFsdStmt = null;

        recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");

        LOGGER.debug("DEBUG_0 processName: " + processName + " processModule: " + processModule);

        String sqlLimit = EtlUtilities.getEtlConfigValue("sqlLimit");

        connFsdStmt = EtlUtilitiesDbms.getStmt(connFSD);

        LOGGER.debug("DEBUG_0 sqlLimit:" + sqlLimit);

        deleteTrackingTbl(connFSD);

        loadTrackingTbl(connISD, connFSD);

        EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", 0, processModule + " closed");
    }

    /*
     * deleteTrackingTbl
     */

    static void deleteTrackingTbl(Connection conn) {

        String processModule = "deleteTrackingTbl";

        int recIdDBMS = 0;

        Statement pStmt = null;
        PreparedStatement pCallStmt = null;
        ResultSet rs = null;
        int rowCntBefore = 0;
        int rowCntAfter = 0;

        LOGGER.debug("DEBUG_0 SQL : processName: " + processName + " processModule: "
                + processModule);

        try {
            recIdDBMS = EtlUtilitiesDbms.processLogInit(conn, "S", processModule + " started");
            pStmt = conn.createStatement();
            rs =
                    pStmt.executeQuery("SELECT COUNT(*) AS rowcnt "
                            + "FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            while (rs.next()) {
                rowCntBefore = rs.getInt("rowcnt");
            }

            LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: "
                    + processModule + " rowCntBefore: " + rowCntBefore);

            pCallStmt =
                    conn.prepareStatement("DELETE FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            pCallStmt.executeUpdate();

            rs = null;
            rs =
                    pStmt.executeQuery("SELECT COUNT(*) AS rowcnt "
                            + "FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            while (rs.next()) {
                rowCntAfter = rs.getInt("rowcnt");
            }

            LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: "
                    + processModule + " rowCntAfter: " + rowCntAfter);

            int rowCntDel = rowCntBefore - rowCntAfter;

            LOGGER.debug("DEBUG_0 Java: " + processModule + "SQL: rowCntDel: " + rowCntDel);

            pCallStmt = null;
            pCallStmt =
                    conn.prepareStatement("UPDATE migrate_isd2fsd.etl_process_log "
                            + "SET rec_delete  = ? " + "WHERE rec_id = ?; ");

            pCallStmt.setInt(1, rowCntDel);
            pCallStmt.setInt(2, recIdDBMS);

            EtlUtilitiesDbms.processLogUpdate(conn, recIdDBMS, "E", 0, processModule + " closed");
            pCallStmt.executeUpdate();

        } catch (SQLException e) {
            LOGGER.error(e.getClass().getName() + ": " + e.getMessage(), e);
            // System.exit(0);
        }
    }

    /*
     * loadTrackingTbl
     */

    private static void loadTrackingTbl(Connection connISD, Connection connFSD) {

        String processModule = "loadTrackingTbl";

        Statement connIsdStmt = null;
        PreparedStatement pFsdStmt = null;
        ResultSet connResults = null;

        int recIdDBMS = 0;

        int recInsert = 0;

        int debugFlag = 0;

        try {
            recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");

            connIsdStmt = EtlUtilitiesDbms.getStmt(connISD);
            connResults = null;
            connResults =
                    connIsdStmt
                            .executeQuery("SELECT REPLACE(mct.catalog_id, 'N/A', '00000000-0000-0000-0000-000000000000')::uuid, "
                                    + "    REPLACE(mct.catalog_dao_id, 'N/A', '00000000-0000-0000-0000-000000000000')::uuid, "
                                    + "    REVERSE(LEFT(REVERSE(mct.catalog_dao_classname), STRPOS(REVERSE(mct.catalog_dao_classname), '.')-1))::text AS dao_class, "
                                    + "    mct.catalog_dao_uri, "
                                    + "    mct.catalog_created_timestamp, "
                                    + "    mct.catalog_modified_timestamp, "
                                    + "    m_c.caseid,  "
                                    + "    m_ce.collectioneventid,  "
                                    + "    m_cr.collectorid, "
                                    + "    m_fd.filedescriptivemetadataid, "
                                    + "    m_p.projectid, "
                                    + "    m_ri.reelinfoid, "
                                    + "    m_rp.retentionpolicyid, "
                                    + "    m_rpd.retentionpolicydefaultid, "
                                    + "    m_wfi.workflowinstanceid, "
                                    + "    m_wft.workflowtemplateid "
                                    + ", '|', mct.* "
                                    + "FROM omega.mdf_catalog_tab mct "
                                    + "LEFT OUTER JOIN omega.metacard_case m_c                                     ON m_c.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_collectionevent m_ce                         ON m_ce.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_collector m_cr                               ON m_cr.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactcharacterizedsources m_ccs            ON m_ccs.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactgeospatialtracks m_cgdt               ON m_cgdt.metacardid  = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactofinterest m_coi                      ON m_coi.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactofinterestsegmentsummary m_coiss      ON m_coiss.metacardid = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactoperationalprofile m_cop              ON m_cop.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_filedescriptivemetadata m_fd                 ON m_fd.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_networksearchfiledescriptivemetadata m_nsfdm ON m_nsfdm.metacardid = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_operation m_o                                ON m_o.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_project m_p                                  ON m_p.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_reelinfo m_ri                                ON m_ri.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_retentionpolicy m_rp                         ON m_rp.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_retentionpolicydefault m_rpd                 ON m_rpd.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_splinstance m_spl                            ON m_spl.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_workflowinstance m_wfi                       ON m_wfi.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_workflowtemplate m_wft                       ON m_wft.metacardid   = mct.catalog_id  "
                                    + "WHERE mct.catalog_id::VARCHAR(32) NOT LIKE 'cae%' "
                                    + "      AND mct.catalog_id::VARCHAR(32) NOT LIKE '000%' "
                                    + "ORDER BY m_c.caseid, m_ce.collectioneventid,  "
                                    + "    m_cr.collectorid, m_fd.filedescriptivemetadataid, "
                                    + "    m_p.projectid, m_ri.reelinfoid, "
                                    + "    m_rp.retentionpolicyid, "
                                    + "    m_rpd.retentionpolicydefaultid, "
                                    + "    m_wfi.workflowinstanceid, "
                                    + "    m_wft.workflowtemplateid; ");
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "execute query",
                                       e.getMessage()), e);
        }

        try {
            while (connResults.next()) {
                String catalog_id = connResults.getString("catalog_id");
                String catalog_dao_id = connResults.getString("catalog_dao_id");
                String dao_class = connResults.getString("dao_class");
                String catalog_dao_uri = connResults.getString("catalog_dao_uri");
                Date catalog_created_timestamp = connResults.getDate("catalog_created_timestamp");
                Date catalog_modified_timestamp = connResults.getDate("catalog_modified_timestamp");
                String caseid = connResults.getString("caseid");
                String collectioneventid = connResults.getString("collectioneventid");
                String collectorid = connResults.getString("collectorid");
                String filedescriptivemetadataid =
                        connResults.getString("filedescriptivemetadataid");
                String projectid = connResults.getString("projectid");
                String reelinfoid = connResults.getString("reelinfoid");
                String retentionpolicyid = connResults.getString("retentionpolicyid");
                String retentionpolicydefaultid = connResults.getString("retentionpolicydefaultid");
                String workflowinstanceid = connResults.getString("workflowinstanceid");
                String workflowtemplateid = connResults.getString("workflowtemplateid");

                LOGGER.debug("catalog_id: " + catalog_id);
                try {
                    pFsdStmt = null;
                    pFsdStmt =
                            connFSD.prepareCall("INSERT INTO migrate_isd2fsd.etl_metacard_tracking_list ( "
                                    + "catalog_id, catalog_dao_id, dao_class, catalog_dao_uri, "
                                    + "catalog_created_timestamp, catalog_modified_timestamp, "
                                    + "caseid, collectioneventid, collectorid, filedescriptivemetadataid, "
                                    + "projectid, reelinfoid, retentionpolicyid, retentionpolicydefaultid, "
                                    + "workflowinstanceid, workflowtemplateid "
                                    + ") VALUES (?::uuid, ?::uuid, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

                    pFsdStmt.setString(1, catalog_id);
                    pFsdStmt.setString(2, catalog_dao_id);
                    pFsdStmt.setString(3, dao_class);
                    pFsdStmt.setString(4, catalog_dao_uri);

                    pFsdStmt.setDate(5, catalog_created_timestamp);
                    pFsdStmt.setDate(6, catalog_modified_timestamp);

                    pFsdStmt.setString(7, caseid);
                    pFsdStmt.setString(8, collectioneventid);
                    pFsdStmt.setString(9, collectorid);
                    pFsdStmt.setString(10, filedescriptivemetadataid);

                    pFsdStmt.setString(11, projectid);
                    pFsdStmt.setString(12, reelinfoid);
                    pFsdStmt.setString(13, retentionpolicyid);
                    pFsdStmt.setString(14, retentionpolicydefaultid);

                    pFsdStmt.setString(15, workflowinstanceid);
                    pFsdStmt.setString(16, workflowtemplateid);

                    LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + pFsdStmt);

                    pFsdStmt.execute();

                    LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + 0);

                } catch (SQLException e1) {
                    LOGGER.error(e1.getClass().getName() + ": " + e1.getMessage(), e1);
                    // System.exit(0);
                }
                recInsert++;
            }

        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "execute call",
                                       e.getMessage()), e);
        }

        LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: " + processModule
                + " recInsert: " + recInsert);

        pFsdStmt = null;
        try {
            pFsdStmt =
                    connFSD.prepareStatement("UPDATE migrate_isd2fsd.etl_process_log "
                            + "SET rec_insert  = ? " + "WHERE rec_id = ?; ");

            pFsdStmt.setInt(1, recInsert);
            pFsdStmt.setInt(2, recIdDBMS);

            EtlUtilitiesDbms
                    .processLogUpdate(connFSD, recIdDBMS, "E", 0, processModule + " closed");
            pFsdStmt.executeUpdate();
            EtlUtilitiesDbms.closeConn(connISD);

        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        }

    }

    /**
     * doIsdTableCount
     */

    public static void doIsdTableCount() {

        String processModule = "doIsdTableCount";

        Connection connISD = null;
        Statement connIsdStmt1 = null;
        Statement connIsdStmt2 = null;

        Connection connFSD = null;
        Statement connFsdStmt1 = null;

        int recIdDBMS = 0;

        ResultSet connResults1;
        ResultSet connResults2;

        String v_stmt = null;

        LOGGER.debug("DEBUG_0 Java: " + processName + " : " + processModule + " : Line 1308");

        try {
            connISD = EtlUtilitiesDbms.getISDConnection();
            connIsdStmt1 = EtlUtilitiesDbms.getStmt(connISD);
            connIsdStmt2 = EtlUtilitiesDbms.getStmt(connISD);

            connFSD = EtlUtilitiesDbms.getFSDConnection();
            connFsdStmt1 = EtlUtilitiesDbms.getStmt(connFSD);

            recIdDBMS =
                    EtlUtilitiesDbms.processLogInit(connFSD, "S", processName + "_" + processModule
                            + " started");

            v_stmt = "DELETE FROM migrate_isd2fsd.isd_db_object_facts; ";
            connFsdStmt1.executeUpdate(v_stmt);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        }

        try {
            LOGGER.debug("DEBUG_0 Java: " + processName + " : " + processModule + " : Line 1333");
            connResults1 =
                    connIsdStmt1.executeQuery("SELECT schemaname, relname "
                            + "FROM pg_stat_all_tables "
                            + "WHERE UPPER(schemaname) = UPPER('omega') "
                            + "ORDER BY schemaname, relname " + "; ");

            while (connResults1.next()) {
                connResults2 =
                        connIsdStmt2.executeQuery("SELECT COUNT(*) " + "FROM "
                                + connResults1.getString(1) + "." + connResults1.getString(2) + " "
                                + "; ");

                while (connResults2.next()) {
                    LOGGER.debug("DEBUG_0 Java: " + processName + " : " + processModule + "Row: "
                            + connResults1.getString(1) + " " + connResults1.getString(2) + " "
                            + connResults2.getString(1));

                    v_stmt =
                            "INSERT INTO migrate_isd2fsd.isd_db_object_facts "
                                    + " (schemaname, relname, indexrelname, row_cnt_date, row_cnt) "
                                    + " VALUES('" + connResults1.getString(1) + "', '"
                                    + connResults1.getString(2) + "', NULL, NOW(), '"
                                    + connResults2.getString(1) + "') " + "; ";

                    LOGGER.debug("DEBUG_0 Java: " + processName + " : " + processModule
                            + ": v_stmt: " + v_stmt);

                    connFsdStmt1.executeUpdate(v_stmt);
                }
            }
            EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", 0, "Close " + processName
                    + "_" + processModule);
            EtlUtilitiesDbms.closeConn(connFSD);
            EtlUtilitiesDbms.closeConn(connISD);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access database",
                                       e.getMessage()), e);
        }

    }
}
