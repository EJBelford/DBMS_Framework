/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dsc.model.GramsSplcObject;
import com.lmco.omega.dsc.model.record.interfaces.IGramsSplcRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcAspectMeasurementRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcContactMeasurementRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcMeasurementEventRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcPlatformDescriptionRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcPointMeasurementRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcSourceMeasurementRecord;
import com.lmco.omega.dsc.model.record.interfaces.ISplcVersionRecord;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdGramsSplcPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcAspectMeasurementPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcContactMeasurementPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcMeasurementEventPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcPointMeasurementPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcSourceMeasurementPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSplcVersionPojo;

/**
 * @author bearyman
 */
public class GramsSplcHandler extends AbstractDataHandler {

    private static final String GET_ASSOC_VERSION_DATA = "SELECT * "
            + "FROM omega.splcversion WHERE hjid = '%s'";
    private static final String GET_ASSOC_ASPECT_DATA = "SELECT * "
            + "FROM omega.splcaspectmeasurement WHERE splcaspectmeasurement_gramss_0 = '%s'";
    private static final String GET_ASSOC_CONTACT_DATA = "SELECT * "
            + "FROM omega.splccontactmeasurement WHERE splccontactmeasurement_grams_0 = '%s'";
    private static final String GET_ASSOC_MEASUREMENT_DATA = "SELECT * "
            + "FROM omega.splcmeasurementevent WHERE splcmeasurementevent_gramssp_0 = '%s'";
    private static final String GET_ASSOC_POINT_DATA = "SELECT * "
            + "FROM omega.splcpointmeasurement WHERE splcpointmeasurement_gramssp_0 = '%s'";
    private static final String GET_ASSOC_SOURCE_DATA = "SELECT * "
            + "FROM omega.splcsourcemeasurement WHERE splcsourcemeasurement_gramss_0 = '%s'";

    private IsdGramsSplcPojo mGramsSplcPojo;
    private IsdSplcVersionPojo mSplcVersionPojo;
    private List<IsdSplcAspectMeasurementPojo> mSplcAspectPojos;
    private List<IsdSplcContactMeasurementPojo> mSplcContactPojos;
    private List<IsdSplcMeasurementEventPojo> mSplcMeasurementPojos;
    private List<IsdSplcPointMeasurementPojo> mSplcPointPojos;
    private List<IsdSplcSourceMeasurementPojo> mSplcSourcePojos;

    public GramsSplcHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mGramsSplcPojo = new IsdGramsSplcPojo();

        while (pResults.next()) {
            mGramsSplcPojo.setSplInstanceId(pResults.getString("splinstanceid"));
            mGramsSplcPojo.setDateCreated(pResults.getTimestamp("createditem"));
            mGramsSplcPojo.setReviewed(pResults.getBoolean("isreviewed"));
            mGramsSplcPojo.setSplcVersionId(pResults.getInt("splcversion_gramssplc_hjid"));
        }

        mSplcVersionPojo = retrieveAssociatedVersionData();
        mSplcAspectPojos = retrieveAssociatedAspectData();
        mSplcContactPojos = retrieveAssociatedContactData();
        mSplcMeasurementPojos = retrieveAssociatedMeasurementData();
        mSplcPointPojos = retrieveAssociatedPointData();
        mSplcSourcePojos = retrieveAssociatedSourceData();
    }

    @Override
    protected BaseDataObject mapToCoalesce() {
        methodName = "mapToCoalesce";
        GramsSplcObject entity = new GramsSplcObject();
        entity.initialize();

        // Map pojo to coalesce
        IGramsSplcRecord gramsRecord = entity.getGramsSplcRecord();
        gramsRecord.setCreated(mGramsSplcPojo.getDateCreated());
        gramsRecord.setIsReviewed(mGramsSplcPojo.isReviewed());
        gramsRecord.setSplInstanceId(mGramsSplcPojo.getSplInstanceId());

        ISplcVersionRecord versionRecord = entity.getSplcVersionRecord();
        versionRecord.setProcessingSoftwareDate(mSplcVersionPojo.getProcessingSoftwareDate());
        versionRecord.setProcessingSoftwareName(mSplcVersionPojo.getProcessingSoftwareName());
        versionRecord.setProcessingSoftwareVersion(mSplcVersionPojo.getProcessingSoftwareVersion());
        versionRecord.setSplVersion(mSplcVersionPojo.getSplVersion());

        for (IsdSplcAspectMeasurementPojo pojo: mSplcAspectPojos) {
            ISplcAspectMeasurementRecord aspectRecord = entity.addNewSplcAspectMeasurementRecord();
            aspectRecord.setAspectID(pojo.getAspectId());
            aspectRecord.setAspectName(pojo.getAspectName());
            aspectRecord.setBandwidthAvg(pojo.getBandwidthAvg());
            aspectRecord.setBandwidthStd(pojo.getBandwidthStd());
            aspectRecord.setCenterFreqAvg(pojo.getCenterFreqAvg());
            aspectRecord.setM1Avg(pojo.getM1Avg());
            aspectRecord.setM1Std(pojo.getM1Std());
            aspectRecord.setM2Avg(pojo.getM2Avg());
            aspectRecord.setM2Std(pojo.getM2Std());
            aspectRecord.setM3Avg(pojo.getM3Avg());
            aspectRecord.setM3Std(pojo.getM3Std());
            aspectRecord.setMeasuredFrequency(pojo.getMeasuredFrequency());
            aspectRecord.setPeakFreqAvg(pojo.getPeakFreqAvg());
            aspectRecord.setPointCount(pojo.getPointCount());
            aspectRecord.setSnrAvg(pojo.getSnrAvg());
            aspectRecord.setSnrStd(pojo.getSnrStd());
            aspectRecord.setSourceMeasurementID(pojo.getSourceMeasurementId());
        }

        for (IsdSplcContactMeasurementPojo pojo: mSplcContactPojos) {
            ISplcContactMeasurementRecord contactRecord =
                    entity.addNewSplcContactMeasurementRecord();
            contactRecord.setBottomDepth(pojo.getBottomDepth());
            contactRecord.setCavitationCode(formatEnumFieldVal(pojo.getCavitationCode()));
            contactRecord.setContactMeasurementID(pojo.getContactMeasurementId());
            contactRecord.setDeAvg(pojo.getDeAvg());
            contactRecord.setDeMax(pojo.getDeMax());
            contactRecord.setDeMin(pojo.getDeMin());
            contactRecord.setDepthAvg(pojo.getDepthAvg());
            contactRecord.setDepthCode(formatEnumFieldVal(pojo.getDepthCode()));
            contactRecord.setDepthMax(pojo.getDepthMax());
            contactRecord.setDepthMin(pojo.getDepthMin());
            contactRecord.setDepthStd(pojo.getDepthStd());
            contactRecord.setDeStd(pojo.getDeStd());
            contactRecord.setFirstX(pojo.getFirstX());
            contactRecord.setFirstY(pojo.getFirstY());
            contactRecord.setFirstZ(pojo.getFirstZ());
            contactRecord.setLastX(pojo.getLastX());
            contactRecord.setLastY(pojo.getLastY());
            contactRecord.setLastZ(pojo.getLastZ());
            contactRecord.setMaxRangeFtFilter(pojo.getMaxRangeFtFilter());
            contactRecord.setMaxSnrFilter(pojo.getMaxSnrFilter());
            contactRecord.setMaxVelocityKtsFilter(pojo.getMaxVelocityKtsFilter());
            contactRecord.setMaxX(pojo.getMaxX());
            contactRecord.setMaxY(pojo.getMaxY());
            contactRecord.setMaxZ(pojo.getMaxZ());
            contactRecord.setMeasurementEventID(pojo.getMeasurementEventId());
            contactRecord.setMeasurementType(pojo.getMeasurementType());
            contactRecord.setMinRangeFtFilter(pojo.getMinRangeFtFilter());
            contactRecord.setMinSnrFilter(pojo.getMinSnrFilter());
            contactRecord.setMinVelocityKtsFilter(pojo.getMinVelocityKtsFilter());
            contactRecord.setMinX(pojo.getMinX());
            contactRecord.setMinY(pojo.getMinY());
            contactRecord.setMinZ(pojo.getMinZ());
            contactRecord.setP1RPM(pojo.getP1Rpm());
            contactRecord.setP2RPM(pojo.getP2Rpm());
            contactRecord.setP3RPM(pojo.getP3Rpm());
            contactRecord.setPropulsionCode(formatEnumFieldVal(pojo.getPropulsionCode()));
            contactRecord.setRangeMax(pojo.getRangeMax());
            contactRecord.setRangeMin(pojo.getRangeMin());
            contactRecord.setRemarks(pojo.getRemarks());
            contactRecord.setSeaState(pojo.getSeaState());
            contactRecord.setSpeedAvg(pojo.getSpeedAvg());
            contactRecord.setSpeedMax(pojo.getSpeedMax());
            contactRecord.setSpeedMin(pojo.getSpeedMin());
            contactRecord.setSpeedStd(pojo.getSpeedStd());
            contactRecord.setTimestampMax(pojo.getTimestampMaxItem());
            contactRecord.setTimestampMin(pojo.getTimestampMinItem());
            contactRecord.setTPK(pojo.getTpk());
            contactRecord.setTransientCode(formatEnumFieldVal(pojo.getTransientCode()));

            ISplcPlatformDescriptionRecord platformRecord =
                    entity.addNewSplcPlatformDescriptionRecord();
            platformRecord.setBladesPerProp(pojo.getBladesPerProp());
            platformRecord.setClassCode(formatEnumFieldVal(pojo.getContactClassCode()));
            // platformRecord.setContactPlatformID(0);
            platformRecord.setCountryCode(formatEnumFieldVal(pojo.getContactCountryCode()));
            platformRecord.setEngineLocationCode(formatEnumFieldVal(pojo.getEngineLocationCode()));
            platformRecord.setEngineTypeCode(formatEnumFieldVal(pojo.getEngineTypeCode()));
            platformRecord.setHullNumber(pojo.getHullNumber());
            platformRecord.setPlatformCode(formatPlatformTypeEnumFieldVal(pojo
                    .getCollectionPlatformCode()));
            platformRecord.setPropLocation1(formatEnumFieldVal(pojo.getPropellerLocationCode1()));
            platformRecord.setPropLocation2(formatEnumFieldVal(pojo.getPropellerLocationCode2()));
            platformRecord.setPropLocation3(formatEnumFieldVal(pojo.getPropellerLocationCode3()));
        }

        for (IsdSplcMeasurementEventPojo pojo: mSplcMeasurementPojos) {
            ISplcMeasurementEventRecord measurementRecord =
                    entity.addNewSplcMeasurementEventRecord();
            measurementRecord.setCase(pojo.getCaseId());
            measurementRecord.setClassification(formatEnumFieldVal(pojo.getClassification()));
            // measurementRecord.setCollectorCode();
            measurementRecord.setContactNumber(pojo.getContactNumber());
            // measurementRecord.setContactPlatformID();
            measurementRecord.setCut(pojo.getCut());
            measurementRecord.setEventDate(pojo.getEventDate());
            measurementRecord.setEventLocation(pojo.getEventLocation());
            measurementRecord.setEventName(pojo.getEventName());
            measurementRecord.setMeasurementEventID(pojo.getMeasurementEventId());
            measurementRecord.setMissionNumber(pojo.getMissionNumber());
            measurementRecord.setOmegaProjectId(pojo.getOmegaProjectId());
            measurementRecord.setProcessDate(pojo.getProcessDate());
            measurementRecord.setProcessLocation(pojo.getProcessLocation());
            measurementRecord.setProcessOperator(pojo.getProcessOperator());
            measurementRecord.setReel(pojo.getReel());
            measurementRecord.setRefLat(pojo.getRefLat());
            measurementRecord.setRefLon(pojo.getRefLon());
            measurementRecord.setReleasable(pojo.getReleasable());
            measurementRecord.setRemarks(pojo.getRemarks());
            measurementRecord.setSensorCode(formatEnumFieldVal(pojo.getSensorCode()));
            measurementRecord.setUnitsType(pojo.getUnitsType());
        }

        for (IsdSplcPointMeasurementPojo pojo: mSplcPointPojos) {
            ISplcPointMeasurementRecord pointRecord = entity.addNewSplcPointMeasurementRecord();
            pointRecord.setBandwidth(pojo.getBandwidth());
            pointRecord.setContactAspect(pojo.getContactAspect());
            pointRecord.setContactBearing(pojo.getContactBearing());
            pointRecord.setContactDepth(pojo.getContactDepth());
            pointRecord.setContactRangeYds(pojo.getContactRangeYds());
            pointRecord.setContactVelocityKts(pojo.getContactVelocityKts());
            pointRecord.setDepressionAngle(pojo.getDepressionAngle());
            pointRecord.setInclude(pojo.getInclude());
            pointRecord.setLineNumber(pojo.getLineNumber());
            pointRecord.setLowerFreq(pojo.getLowerFreq());
            pointRecord.setM1(pojo.getM1());
            pointRecord.setM2(pojo.getM2());
            pointRecord.setM3(pojo.getM3());
            pointRecord.setNoiseCorrect(pojo.getNoiseCorrect());
            pointRecord.setOctantName(pojo.getOctantName());
            pointRecord.setPeakFreq(pojo.getPeakFreq());
            pointRecord.setPropLoss(pojo.getPropLoss());
            pointRecord.setRangePass(pojo.getRangePass());
            pointRecord.setSensorChannel(pojo.getSensorChannel());
            pointRecord.setSnr(pojo.getSnr());
            pointRecord.setSnrPass(pojo.getSnrPass());
            pointRecord.setSourceMeasurementID(pojo.getSourceMeasurementId());
            pointRecord.setSystemCal(pojo.getSystemCal());
            pointRecord.setTimestamp(pojo.getTimestamp());
        }

        for (IsdSplcSourceMeasurementPojo pojo: mSplcSourcePojos) {
            ISplcSourceMeasurementRecord sourceRecord = entity.addNewSplcSourceMeasurementRecord();
            sourceRecord.setContactMeasurementID(pojo.getContactMeasurementId());
            sourceRecord.setHarmonic(pojo.getHarmonic());
            sourceRecord.setMeasuredFrequency(pojo.getMeasuredFrequency());
            sourceRecord.setProcessAccuracy(pojo.getProcessAccuracy());
            sourceRecord.setProcessBandwidth(pojo.getProcessBandwidth());
            sourceRecord.setProcessIntegrationTime(pojo.getProcessIntegrationTime());
            sourceRecord.setProcessResolution(pojo.getProcessResolution());
            sourceRecord.setPropLossMethod(pojo.getPropLossMethod());
            sourceRecord.setPropLossMethodName(pojo.getPropLossMethodName());
            sourceRecord.setSourceDescription(pojo.getSourceDescription());
            sourceRecord.setSourceDescriptionID(pojo.getSourceDescriptionId());
            sourceRecord.setSourceMeasurementID(pojo.getSourceMeasurementId());
        }

        // Set security
        setCoalesceSecuritySystemHigh(entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mGramsSplcPojo.getDateCreated()));

        return entity;
    }

    @Override
    protected String getCreatedBy() {
        return DSSConstants.SYSTEM_ACCOUNT;
    }

    @Override
    protected void createLinkages() throws SQLException, RemoteException {
        methodName = "createLinkages";

        // DO NOTHING
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.GRAMS_SPLC;
    }

    private IsdSplcVersionPojo retrieveAssociatedVersionData() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        IsdSplcVersionPojo pojo = new IsdSplcVersionPojo();
        try {
            stmt = mIsdConn.createStatement();

            results =
                    stmt.executeQuery(String.format(GET_ASSOC_VERSION_DATA,
                                                    mGramsSplcPojo.getSplcVersionId()));

            while (results.next()) {
                pojo.setId(results.getInt("hjid"));
                pojo.setProcessingSoftwareDate(results.getTimestamp("processingsoftwaredateitem"));
                pojo.setProcessingSoftwareName(results.getString("processingsoftwarename"));
                pojo.setProcessingSoftwareVersion(results.getLong("processingsoftwareversion"));
                pojo.setSplVersion(results.getLong("splversion"));
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojo;
    }

    private List<IsdSplcAspectMeasurementPojo> retrieveAssociatedAspectData() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<IsdSplcAspectMeasurementPojo> pojos = new ArrayList<IsdSplcAspectMeasurementPojo>();
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ASSOC_ASPECT_DATA, mKey));

            while (results.next()) {
                IsdSplcAspectMeasurementPojo pojo = new IsdSplcAspectMeasurementPojo();
                pojo.setId(results.getInt("hjid"));
                pojo.setAspectId(results.getInt("aspectid"));
                pojo.setAspectName(results.getString("aspectname"));
                pojo.setBandwidthAvg(results.getDouble("bandwidthavg"));
                pojo.setBandwidthStd(results.getDouble("bandwidthstd"));
                pojo.setCenterFreqAvg(results.getDouble("centerfreqavg"));
                pojo.setM1Avg(results.getDouble("m1avg"));
                pojo.setM1Std(results.getDouble("m1std"));
                pojo.setM2Avg(results.getDouble("m2avg"));
                pojo.setM2Std(results.getInt("m2std"));
                pojo.setM3Avg(results.getDouble("m3avg"));
                pojo.setM3Std(results.getDouble("m3std"));
                pojo.setMeasuredFrequency(results.getDouble("measuredfrequency"));
                pojo.setPeakFreqAvg(results.getDouble("peakfreqavg"));
                pojo.setPointCount(results.getInt("pointcount"));
                pojo.setSnrAvg(results.getDouble("snravg"));
                pojo.setSnrStd(results.getDouble("snrstd"));
                pojo.setSourceMeasurementId(results.getLong("sourcemeasurementid"));
                pojo.setGramsSplId(results.getString("splcaspectmeasurement_gramss_0"));
                pojos.add(pojo);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojos;
    }

    private List<IsdSplcContactMeasurementPojo> retrieveAssociatedContactData() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<IsdSplcContactMeasurementPojo> pojos = new ArrayList<IsdSplcContactMeasurementPojo>();
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ASSOC_CONTACT_DATA, mKey));

            while (results.next()) {
                IsdSplcContactMeasurementPojo pojo = new IsdSplcContactMeasurementPojo();
                pojo.setId(results.getInt("hjid"));
                pojo.setBladesPerProp(results.getString("bladesperprop"));
                pojo.setBottomDepth(results.getDouble("bottomdepth"));
                pojo.setCavitationCode(results.getString("cavitationcode"));
                pojo.setCollectionPlatformCode(results.getString("collectionplatformcode"));
                pojo.setContactClassCode(results.getString("contactclasscode"));
                pojo.setContactCountryCode(results.getString("contactcountrycode"));
                pojo.setContactMeasurementId(results.getLong("contactmeasurementid"));
                pojo.setDeAvg(results.getDouble("deavg"));
                pojo.setDeMax(results.getDouble("demax"));
                pojo.setDeMin(results.getDouble("demin"));
                pojo.setDeStd(results.getDouble("destd"));
                pojo.setDepthAvg(results.getDouble("depthavg"));
                pojo.setDepthCode(results.getString("depthcode"));
                pojo.setDepthMax(results.getDouble("depthmax"));
                pojo.setDepthMin(results.getDouble("depthmin"));
                pojo.setDepthStd(results.getDouble("depthstd"));
                pojo.setEngineLocationCode(results.getString("enginelocationcode"));
                pojo.setEngineTypeCode(results.getString("enginetypecode"));
                pojo.setFirstX(results.getDouble("firstx"));
                pojo.setFirstY(results.getDouble("firsty"));
                pojo.setFirstZ(results.getDouble("firstz"));
                pojo.setHullNumber(results.getInt("hullnumber"));
                pojo.setLastX(results.getDouble("lastx"));
                pojo.setLastY(results.getDouble("lasty"));
                pojo.setLastZ(results.getDouble("lastz"));
                pojo.setMaxRangeFtFilter(results.getDouble("maxrangeftfilter"));
                pojo.setMaxSnrFilter(results.getDouble("maxsnrfilter"));
                pojo.setMaxVelocityKtsFilter(results.getDouble("maxvelocityktsfilter"));
                pojo.setMaxX(results.getDouble("maxx"));
                pojo.setMaxY(results.getDouble("maxy"));
                pojo.setMaxZ(results.getDouble("maxz"));
                pojo.setMeasurementEventId(results.getLong("measurementeventid"));
                pojo.setMeasurementType(results.getString("measurementtype"));
                pojo.setMinRangeFtFilter(results.getDouble("minrangeftfilter"));
                pojo.setMinSnrFilter(results.getDouble("minsnrfilter"));
                pojo.setMinVelocityKtsFilter(results.getDouble("minvelocityktsfilter"));
                pojo.setMinX(results.getDouble("minx"));
                pojo.setMinY(results.getDouble("miny"));
                pojo.setMinZ(results.getDouble("minz"));
                pojo.setP1Rpm(results.getDouble("p1rpm"));
                pojo.setP2Rpm(results.getDouble("p2rpm"));
                pojo.setP3Rpm(results.getDouble("p3rpm"));
                pojo.setPropellerLocationCode1(results.getString("propellerlocationcode1"));
                pojo.setPropellerLocationCode2(results.getString("propellerlocationcode2"));
                pojo.setPropellerLocationCode3(results.getString("propellerlocationcode3"));
                pojo.setPropulsionCode(results.getString("propulsioncode"));
                pojo.setRangeMax(results.getDouble("rangemax"));
                pojo.setRangeMin(results.getDouble("rangemin"));
                pojo.setRemarks(results.getString("remarks"));
                pojo.setSeaState(results.getInt("seastate"));
                pojo.setSpeedAvg(results.getDouble("speedavg"));
                pojo.setSpeedMax(results.getDouble("speedmax"));
                pojo.setSpeedMin(results.getDouble("speedmin"));
                pojo.setSpeedStd(results.getDouble("speedstd"));
                pojo.setTpk(results.getDouble("tpk"));
                pojo.setTimestampMaxItem(results.getTimestamp("timestampmaxitem"));
                pojo.setTimestampMinItem(results.getTimestamp("timestampminitem"));
                pojo.setTransientCode(results.getString("transientcode"));
                pojo.setGramsSplcId(results.getString("splccontactmeasurement_grams_0"));
                pojos.add(pojo);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojos;
    }

    private List<IsdSplcMeasurementEventPojo> retrieveAssociatedMeasurementData()
            throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<IsdSplcMeasurementEventPojo> pojos = new ArrayList<IsdSplcMeasurementEventPojo>();
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ASSOC_MEASUREMENT_DATA, mKey));

            while (results.next()) {
                IsdSplcMeasurementEventPojo pojo = new IsdSplcMeasurementEventPojo();
                pojo.setHjid(results.getInt("hjid"));
                pojo.setCaseId(results.getString("case_"));
                pojo.setClassification(results.getString("classification"));
                pojo.setContactNumber(results.getString("contactnumber"));
                pojo.setCut(results.getString("cut"));
                pojo.setEventDate(results.getTimestamp("eventdateitem"));
                pojo.setEventLocation(results.getString("eventlocation"));
                pojo.setEventName(results.getString("eventname"));
                pojo.setMeasurementEventId(results.getLong("measurementeventid"));
                pojo.setMissionNumber(results.getString("missionnumber"));
                pojo.setOmegaProjectId(results.getString("omegaprojectid"));
                pojo.setProcessDate(results.getTimestamp("processdateitem"));
                pojo.setProcessLocation(results.getString("processlocation"));
                pojo.setProcessOperator(results.getString("processoperator"));
                pojo.setReel(results.getString("reel"));
                pojo.setRefLat(results.getDouble("reflat"));
                pojo.setRefLon(results.getDouble("reflon"));
                pojo.setReleasable(results.getString("releasable"));
                pojo.setRemarks(results.getString("remarks"));
                pojo.setSensorCode(results.getString("sensorcode"));
                pojo.setUnitsType(results.getString("unitstype"));
                pojo.setGramsSplcId(results.getString("splcmeasurementevent_gramssp_0"));
                pojos.add(pojo);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojos;
    }

    private List<IsdSplcPointMeasurementPojo> retrieveAssociatedPointData() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<IsdSplcPointMeasurementPojo> pojos = new ArrayList<IsdSplcPointMeasurementPojo>();
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ASSOC_POINT_DATA, mKey));

            while (results.next()) {
                IsdSplcPointMeasurementPojo pojo = new IsdSplcPointMeasurementPojo();
                pojo.setId(results.getInt("hjid"));
                pojo.setBandwidth(results.getDouble("bandwidth"));
                pojo.setContactAspect(results.getDouble("contactaspect"));
                pojo.setContactBearing(results.getDouble("contactbearing"));
                pojo.setContactDepth(results.getDouble("contactdepth"));
                pojo.setContactRangeYds(results.getDouble("contactrangeyds"));
                pojo.setContactVelocityKts(results.getDouble("contactvelocitykts"));
                pojo.setDepressionAngle(results.getDouble("depressionangle"));
                pojo.setInclude(results.getBoolean("include"));
                pojo.setLineNumber(results.getLong("linenumber"));
                pojo.setLowerFreq(results.getDouble("lowerfreq"));
                pojo.setM1(results.getDouble("m1"));
                pojo.setM2(results.getDouble("m2"));
                pojo.setM3(results.getDouble("m3"));
                pojo.setNoiseCorrect(results.getDouble("noisecorrect"));
                pojo.setOctantName(results.getString("octantname"));
                pojo.setPeakFreq(results.getDouble("peakfreq"));
                pojo.setPropLoss(results.getDouble("proploss"));
                pojo.setRangePass(results.getBoolean("rangepass"));
                pojo.setSnr(results.getDouble("snr"));
                pojo.setSensorChannel(results.getInt("sensorchannel"));
                pojo.setSnrPass(results.getBoolean("snrpass"));
                pojo.setSourceMeasurementId(results.getLong("sourcemeasurementid"));
                pojo.setSystemCal(results.getDouble("systemcal"));
                pojo.setTimestamp(results.getDate("timestampitem"));
                pojo.setGramsSplcId(results.getString("splcpointmeasurement_gramssp_0"));
                pojos.add(pojo);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojos;
    }

    private List<IsdSplcSourceMeasurementPojo> retrieveAssociatedSourceData() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<IsdSplcSourceMeasurementPojo> pojos = new ArrayList<IsdSplcSourceMeasurementPojo>();
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ASSOC_SOURCE_DATA, mKey));

            while (results.next()) {
                IsdSplcSourceMeasurementPojo pojo = new IsdSplcSourceMeasurementPojo();
                pojo.setId(results.getInt("hjid"));
                pojo.setContactMeasurementId(results.getLong("contactmeasurementid"));
                pojo.setHarmonic(results.getDouble("harmonic"));
                pojo.setMeasuredFrequency(results.getDouble("measuredfrequency"));
                pojo.setProcessAccuracy(results.getDouble("processaccuracy"));
                pojo.setProcessBandwidth(results.getDouble("processbandwidth"));
                pojo.setProcessIntegrationTime(results.getDouble("processintegrationtime"));
                pojo.setProcessResolution(results.getDouble("processresolution"));
                pojo.setPropLossMethod(results.getInt("proplossmethod"));
                pojo.setPropLossMethodName(results.getString("proplossmethodname"));
                pojo.setSourceDescription(results.getString("sourcedescription"));
                pojo.setSourceDescriptionId(results.getLong("sourcedescriptionid"));
                pojo.setSourceMeasurementId(results.getLong("sourcemeasurementid"));
                pojo.setGramsSplcId(results.getString("splcsourcemeasurement_gramss_0"));
                pojos.add(pojo);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }

        return pojos;
    }
}
