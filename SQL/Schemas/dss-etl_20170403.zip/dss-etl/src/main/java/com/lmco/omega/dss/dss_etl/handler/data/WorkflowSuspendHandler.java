/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdWorkflowSuspendPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.workflowsuspend.WorkflowSuspendCoalesce;
import com.lmco.omega.ecm.interfaces.model.WorkflowSuspend;

/**
 * @author bearyman
 */
public class WorkflowSuspendHandler extends AbstractDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            WorkflowSuspendHandler.class);

    private IsdWorkflowSuspendPojo mPojo;

    public WorkflowSuspendHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdWorkflowSuspendPojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("workflowsuspendid"));
            mPojo.setDependentWorkflowId(pResults.getString("dependentworkflowid"));
            mPojo.setResumeTime(pResults.getTimestamp("resumetimeitem"));
            mPojo.setSuspendTime(pResults.getTimestamp("suspendtimeitem"));
            mPojo.setWorkflowInstanceId(pResults.getString("workflowsuspend_workflowinst_0"));

            // Get security data from parent record
            setSecurityWithParentRecord(EIsdTableNames.WORKFLOW_INSTANCE,
                                        mPojo.getWorkflowInstanceId(), mPojo.getSecurity());

        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        WorkflowSuspendCoalesce entity;

        IDataConverter<WorkflowSuspend, WorkflowSuspendCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(WorkflowSuspend.class);

        WorkflowSuspend pojo = converter.constructPojo();

        pojo.setResumeDate(mPojo.getResumeTime());

        if (pojo.getResumeDate() == null) {
            pojo.setResumeDate(new Date());
        }

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getSuspendTime()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";

        // Link workflow instance
        linkEntities(mEntityKey, mPojo.getWorkflowInstanceId(), ELinkType.IS_CHILD_OF,
                     "workflow instance", DataObjectLinkActionType.LINK);

        // Link dependent workflows
        linkEntities(mEntityKey, mPojo.getDependentWorkflowId(), ELinkType.IS_USED_BY,
                     "dependent workflow", DataObjectLinkActionType.LINK);
    }

    @Override
    protected String getCreatedBy() {
        ResultSet results = null;
        Statement stmt = null;
        String createdBy = null;
        try {
            stmt = mIsdConn.createStatement();

            String query = String.format(GET_CREATOR_FOR_WF, mPojo.getWorkflowInstanceId());
            results = stmt.executeQuery(query);

            if (results.next()) {
                createdBy = results.getString(1);
            }
        } catch (SQLException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "retrieve creator",
                                  e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    String errMsg =
                            String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                          e.getMessage());
                    LOGGER.error(errMsg, e);
                }
            }
        }
        return createdBy;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.WORKFLOW_SUSPEND;
    }
}
