/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author n67154 - Belford - InCadence
 */

public class IsdContactCharacterizedSourcesPojo {

    // ----- parent -----
    private String parentPlatformClass;
    private String parentPlatformName;
    private String parentHullNumber;
    private String parentSegmentName;
    // ----- requiredFields -----
    private Date characterizationTime;
    private double peakFrequency;
    // ----- otherFields -----
    // This might be a link or a uuid reference to Frequency Identifier */"
    private String sourceOriginName;
    // This might be a link or a uuid reference to Frequency Identifier */"
    private String userLabel;

    private double aekeyinginterval;
    private String aekeyingintervaltype;
    private double altitude;
    private double angleonthebow;
    private double aspect;
    private double bandwidth;
    private double centerfrequency;
    private String comment;
    private double course;
    private double depressionelevationangle;
    private double enginecrankshaftrate;
    private double enginecylinderrate;
    private double enginerpm;
    private double freqbandstart;
    private double freqbandstop;
    private String geospatialconfidence;
    private double harmonic;
    private double heading;
    private String homingtype;
    private double maxenginerpm;
    private double maxpropellerrpm;
    private double minenginerpm;
    private double minpropellerrpm;
    private double peakfreq;
    private double propellerbladerate;
    private double propellerrpm;
    private double propellershaftrate;
    private String pulsetype;
    private double rangefromsensor;
    private double relativebearing;
    private double reportedspeed;
    private double signallevel;
    private double snr;
    private double snrazimuthal;
    private double snrdepressionelevationangle;
    private String soundtype;
    private double soundvelocity;
    private double sourcerpm;
    private double speed;
    private Date starttime;
    private Date stoptime;
    private String transientlevel;
    private double truebearing;
    private String type;
    private double waterdepth;
    private String waveform;
    private String weaponmode;

    private IsdMandatorySecurityPojo security;

    /*
     *
     */
    public IsdContactCharacterizedSourcesPojo() {
        setSecurity(new IsdMandatorySecurityPojo());
    }

    /**
     * @return the aekeyinginterval
     */

    public Double getAekeyinginterval() {
        return aekeyinginterval;
    }

    /**
     * @param aekeyinginterval
     *            the aekeyinginterval to set
     */

    public void setAekeyinginterval(int aekeyinginterval) {
        this.aekeyinginterval = aekeyinginterval;
    }

    /**
     * @return the aekeyingintervaltype
     */

    public String getAekeyingintervaltype() {
        return aekeyingintervaltype;
    }

    /**
     * @param aekeyingintervaltype
     *            the aekeyingintervaltype to set
     */

    public void setAekeyingintervaltype(String aekeyingintervaltype) {
        this.aekeyingintervaltype = aekeyingintervaltype;
    }

    /**
     * @return the altitude
     */

    public double getAltitude() {
        return altitude;
    }

    /**
     * @param altitude
     *            the altitude to set
     */

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    /**
     * @return the angleonthebow
     */

    public double getAngleonthebow() {
        return angleonthebow;
    }

    /**
     * @param angleonthebow
     *            the angleonthebow to set
     */

    public void setAngleonthebow(double angleonthebow) {
        this.angleonthebow = angleonthebow;
    }

    /**
     * @return the aspect
     */

    public double getAspect() {
        return aspect;
    }

    /**
     * @param aspect
     *            the aspect to set
     */

    public void setAspect(double aspect) {
        this.aspect = aspect;
    }

    /**
     * @return the bandwidth
     */

    public double getBandwidth() {
        return bandwidth;
    }

    /**
     * @param bandwidth
     *            the bandwidth to set
     */

    public void setBandwidth(double bandwidth) {
        this.bandwidth = bandwidth;
    }

    /**
     * @return the centerfrequency
     */

    public double getCenterfrequency() {
        return centerfrequency;
    }

    /**
     * @param centerfrequency
     *            the centerfrequency to set
     */

    public void setCenterfrequency(double centerfrequency) {
        this.centerfrequency = centerfrequency;
    }

    /**
     * @return the comment
     */

    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */

    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the course
     */

    public double getCourse() {
        return course;
    }

    /**
     * @param course
     *            the course to set
     */

    public void setCourse(double course) {
        this.course = course;
    }

    /**
     * @return the depressionelevationangle
     */

    public double getDepressionelevationangle() {
        return depressionelevationangle;
    }

    /**
     * @param depressionelevationangle
     *            the depressionelevationangle to set
     */

    public void setDepressionelevationangle(double depressionelevationangle) {
        this.depressionelevationangle = depressionelevationangle;
    }

    /**
     * @return the enginecrankshaftrate
     */

    public double getEnginecrankshaftrate() {
        return enginecrankshaftrate;
    }

    /**
     * @param enginecrankshaftrate
     *            the enginecrankshaftrate to set
     */

    public void setEnginecrankshaftrate(double enginecrankshaftrate) {
        this.enginecrankshaftrate = enginecrankshaftrate;
    }

    /**
     * @return the enginecylinderrate
     */

    public double getEnginecylinderrate() {
        return enginecylinderrate;
    }

    /**
     * @param enginecylinderrate
     *            the enginecylinderrate to set
     */

    public void setEnginecylinderrate(double enginecylinderrate) {
        this.enginecylinderrate = enginecylinderrate;
    }

    /**
     * @return the enginerpm
     */

    public double getEnginerpm() {
        return enginerpm;
    }

    /**
     * @param enginerpm
     *            the enginerpm to set
     */

    public void setEnginerpm(double enginerpm) {
        this.enginerpm = enginerpm;
    }

    /**
     * @return the freqbandstart
     */

    public double getFreqbandstart() {
        return freqbandstart;
    }

    /**
     * @param freqbandstart
     *            the freqbandstart to set
     */

    public void setFreqbandstart(double freqbandstart) {
        this.freqbandstart = freqbandstart;
    }

    /**
     * @return the freqbandstop
     */

    public double getFreqbandstop() {
        return freqbandstop;
    }

    /**
     * @param freqbandstop
     *            the freqbandstop to set
     */

    public void setFreqbandstop(double freqbandstop) {
        this.freqbandstop = freqbandstop;
    }

    /**
     * @return the geospatialconfidence
     */

    public String getGeospatialconfidence() {
        return geospatialconfidence;
    }

    /**
     * @param geospatialconfidence
     *            the geospatialconfidence to set
     */

    public void setGeospatialconfidence(String geospatialconfidence) {
        this.geospatialconfidence = geospatialconfidence;
    }

    /**
     * @return the harmonic
     */

    public double getHarmonic() {
        return harmonic;
    }

    /**
     * @param harmonic
     *            the harmonic to set
     */

    public void setHarmonic(double harmonic) {
        this.harmonic = harmonic;
    }

    /**
     * @return the heading
     */

    public double getHeading() {
        return heading;
    }

    /**
     * @param heading
     *            the heading to set
     */

    public void setHeading(double heading) {
        this.heading = heading;
    }

    /**
     * @return the homingtype
     */

    public String getHomingtype() {
        return homingtype;
    }

    /**
     * @param homingtype
     *            the homingtype to set
     */

    public void setHomingtype(String homingtype) {
        this.homingtype = homingtype;
    }

    /**
     * @return the maxenginerpm
     */

    public double getMaxenginerpm() {
        return maxenginerpm;
    }

    /**
     * @param maxenginerpm
     *            the maxenginerpm to set
     */

    public void setMaxenginerpm(double maxenginerpm) {
        this.maxenginerpm = maxenginerpm;
    }

    /**
     * @return the maxpropellerrpm
     */

    public double getMaxpropellerrpm() {
        return maxpropellerrpm;
    }

    /**
     * @param maxpropellerrpm
     *            the maxpropellerrpm to set
     */

    public void setMaxpropellerrpm(double maxpropellerrpm) {
        this.maxpropellerrpm = maxpropellerrpm;
    }

    /**
     * @return the minenginerpm
     */

    public double getMinenginerpm() {
        return minenginerpm;
    }

    /**
     * @param minenginerpm
     *            the minenginerpm to set
     */

    public void setMinenginerpm(double minenginerpm) {
        this.minenginerpm = minenginerpm;
    }

    /**
     * @return the minpropellerrpm
     */

    public double getMinpropellerrpm() {
        return minpropellerrpm;
    }

    /**
     * @param minpropellerrpm
     *            the minpropellerrpm to set
     */

    public void setMinpropellerrpm(double minpropellerrpm) {
        this.minpropellerrpm = minpropellerrpm;
    }

    /**
     * @return the peakfreq
     */

    public double getPeakfreq() {
        return peakfreq;
    }

    /**
     * @param peakfreq
     *            the peakfreq to set
     */

    public void setPeakfreq(double peakfreq) {
        this.peakfreq = peakfreq;
    }

    /**
     * @return the propellerbladerate
     */

    public double getPropellerbladerate() {
        return propellerbladerate;
    }

    /**
     * @param propellerbladerate
     *            the propellerbladerate to set
     */

    public void setPropellerbladerate(double propellerbladerate) {
        this.propellerbladerate = propellerbladerate;
    }

    /**
     * @return the propellerrpm
     */

    public double getPropellerrpm() {
        return propellerrpm;
    }

    /**
     * @param propellerrpm
     *            the propellerrpm to set
     */

    public void setPropellerrpm(double propellerrpm) {
        this.propellerrpm = propellerrpm;
    }

    /**
     * @return the propellershaftrate
     */

    public double getPropellershaftrate() {
        return propellershaftrate;
    }

    /**
     * @param propellershaftrate
     *            the propellershaftrate to set
     */

    public void setPropellershaftrate(double propellershaftrate) {
        this.propellershaftrate = propellershaftrate;
    }

    /**
     * @return the pulsetype
     */

    public String getPulsetype() {
        return pulsetype;
    }

    /**
     * @param pulsetype
     *            the pulsetype to set
     */

    public void setPulsetype(String pulsetype) {
        this.pulsetype = pulsetype;
    }

    /**
     * @return the rangefromsensor
     */

    public double getRangefromsensor() {
        return rangefromsensor;
    }

    /**
     * @param rangefromsensor
     *            the rangefromsensor to set
     */

    public void setRangefromsensor(double rangefromsensor) {
        this.rangefromsensor = rangefromsensor;
    }

    /**
     * @return the relativebearing
     */

    public double getRelativebearing() {
        return relativebearing;
    }

    /**
     * @param relativebearing
     *            the relativebearing to set
     */

    public void setRelativebearing(double relativebearing) {
        this.relativebearing = relativebearing;
    }

    /**
     * @return the reportedspeed
     */

    public double getReportedspeed() {
        return reportedspeed;
    }

    /**
     * @param reportedspeed
     *            the reportedspeed to set
     */

    public void setReportedspeed(double reportedspeed) {
        this.reportedspeed = reportedspeed;
    }

    /**
     * @return the signallevel
     */

    public double getSignallevel() {
        return signallevel;
    }

    /**
     * @param signallevel
     *            the signallevel to set
     */

    public void setSignallevel(double signallevel) {
        this.signallevel = signallevel;
    }

    /**
     * @return the snr
     */

    public double getSnr() {
        return snr;
    }

    /**
     * @param snr
     *            the snr to set
     */

    public void setSnr(double snr) {
        this.snr = snr;
    }

    /**
     * @return the snrazimuthal
     */

    public double getSnrazimuthal() {
        return snrazimuthal;
    }

    /**
     * @param snrazimuthal
     *            the snrazimuthal to set
     */

    public void setSnrazimuthal(double snrazimuthal) {
        this.snrazimuthal = snrazimuthal;
    }

    /**
     * @return the snrdepressionelevationangle
     */

    public double getSnrdepressionelevationangle() {
        return snrdepressionelevationangle;
    }

    /**
     * @param snrdepressionelevationangle
     *            the snrdepressionelevationangle to set
     */

    public void setSnrdepressionelevationangle(double snrdepressionelevationangle) {
        this.snrdepressionelevationangle = snrdepressionelevationangle;
    }

    /**
     * @return the soundtype
     */

    public String getSoundtype() {
        return soundtype;
    }

    /**
     * @param soundtype
     *            the soundtype to set
     */

    public void setSoundtype(String soundtype) {
        this.soundtype = soundtype;
    }

    /**
     * @return the soundvelocity
     */

    public double getSoundvelocity() {
        return soundvelocity;
    }

    /**
     * @param soundvelocity
     *            the soundvelocity to set
     */

    public void setSoundvelocity(double soundvelocity) {
        this.soundvelocity = soundvelocity;
    }

    /**
     * @return the sourcerpm
     */

    public double getSourcerpm() {
        return sourcerpm;
    }

    /**
     * @param sourcerpm
     *            the sourcerpm to set
     */

    public void setSourcerpm(double sourcerpm) {
        this.sourcerpm = sourcerpm;
    }

    /**
     * @return the speed
     */

    public double getSpeed() {
        return speed;
    }

    /**
     * @param speed
     *            the speed to set
     */

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    /**
     * @return the starttime
     */

    public Date getStarttime() {
        return starttime;
    }

    /**
     * @param starttime
     *            the starttime to set
     */

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    /**
     * @return the stoptime
     */

    public Date getStoptime() {
        return stoptime;
    }

    /**
     * @param stoptime
     *            the stoptime to set
     */

    public void setStoptime(Date stoptime) {
        this.stoptime = stoptime;
    }

    /**
     * @return the transientlevel
     */

    public String getTransientlevel() {
        return transientlevel;
    }

    /**
     * @param transientlevel
     *            the transientlevel to set
     */

    public void setTransientlevel(String transientlevel) {
        this.transientlevel = transientlevel;
    }

    /**
     * @return the truebearing
     */

    public double getTruebearing() {
        return truebearing;
    }

    /**
     * @param truebearing
     *            the truebearing to set
     */

    public void setTruebearing(double truebearing) {
        this.truebearing = truebearing;
    }

    /**
     * @return the type
     */

    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */

    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the waterdepth
     */

    public double getWaterdepth() {
        return waterdepth;
    }

    /**
     * @param waterdepth
     *            the waterdepth to set
     */

    public void setWaterdepth(double waterdepth) {
        this.waterdepth = waterdepth;
    }

    /**
     * @return the waveform
     */

    public String getWaveform() {
        return waveform;
    }

    /**
     * @param waveform
     *            the waveform to set
     */

    public void setWaveform(String waveform) {
        this.waveform = waveform;
    }

    /**
     * @return the weaponmode
     */

    public String getWeaponmode() {
        return weaponmode;
    }

    /**
     * @param weaponmode
     *            the weaponmode to set
     */

    public void setWeaponmode(String weaponmode) {
        this.weaponmode = weaponmode;
    }

    /**
     * @return the security
     */

    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */

    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

    /**
     * @return the parentPlatformClass
     */
    public String getParentPlatformClass() {
        return parentPlatformClass;
    }

    /**
     * @param parentPlatformClass
     *            the parentPlatformClass to set
     */
    public void setParentPlatformClass(String parentPlatformClass) {
        this.parentPlatformClass = parentPlatformClass;
    }

    /**
     * @return the parentPlatformName
     */
    public String getParentPlatformName() {
        return parentPlatformName;
    }

    /**
     * @param parentPlatformName
     *            the parentPlatformName to set
     */
    public void setParentPlatformName(String parentPlatformName) {
        this.parentPlatformName = parentPlatformName;
    }

    /**
     * @return the parentHullNumber
     */
    public String getParentHullNumber() {
        return parentHullNumber;
    }

    /**
     * @param parentHullNumber
     *            the parentHullNumber to set
     */
    public void setParentHullNumber(String parentHullNumber) {
        this.parentHullNumber = parentHullNumber;
    }

    /**
     * @return the parentSegmentName
     */
    public String getParentSegmentName() {
        return parentSegmentName;
    }

    /**
     * @param parentSegmentName
     *            the parentSegmentName to set
     */
    public void setParentSegmentName(String parentSegmentName) {
        this.parentSegmentName = parentSegmentName;
    }

    /**
     * @return the characterizationTime
     */
    public Date getCharacterizationTime() {
        return characterizationTime;
    }

    /**
     * @param characterizationTime
     *            the characterizationTime to set
     */
    public void setCharacterizationTime(Date characterizationTime) {
        this.characterizationTime = characterizationTime;
    }

    /**
     * @return the peakFrequency
     */
    public double getPeakFrequency() {
        return peakFrequency;
    }

    /**
     * @param peakFrequency
     *            the peakFrequency to set
     */
    public void setPeakFrequency(double peakFrequency) {
        this.peakFrequency = peakFrequency;
    }

    /**
     * @return the sourceOriginName
     */
    public String getSourceOriginName() {
        return sourceOriginName;
    }

    /**
     * @param sourceOriginName
     *            the sourceOriginName to set
     */
    public void setSourceOriginName(String sourceOriginName) {
        this.sourceOriginName = sourceOriginName;
    }

    /**
     * @return the userLabel
     */
    public String getUserLabel() {
        return userLabel;
    }

    /**
     * @param userLabel
     *            the userLabel to set
     */
    public void setUserLabel(String userLabel) {
        this.userLabel = userLabel;
    }
}
