/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.enums;

/**
 * @author bearyman
 *         2016-10-25 - Gene Belford - Added PLATFORMCLASS
 */
public enum EIsdTableNames {

    AUXILIARY_SUPPORT("auxiliarysupport", "hjid"),
    BTR("btr", "hjid"),
    CASE("case_", "onicasenumber"),
    CASE_TRACKING_DATA("casetrackingdata", "casetrackingdataid"),
    CGRAM("cgram", "hjid"),
    COLLECTION_EVENT("collectionevent", "collectioneventid"),
    COLLECTOR("collector", "collectorid"),
    CONTACT_CHARACTERIZED_SOURCES("contactcharacterizedsources", "contactcharacterizedsourcesid"),
    CONTACT_GEOMETRY_ESTIMATE("contactgeometryestimate", "contactgeometryestimateid"),
    CONTACT_GEOMETRY_SPATIAL_TRACKS("contactgeometryspatialtracks", "contactgeospatialtracksid"),
    CONTACT_OF_INTEREST("contactofinterest", "contactofinterestid"),
    CONTACT_OF_INTEREST_PLATFORM("contactofinterestplatform", "contactofinterestplatformid"),
    CONTACT_OF_INTEREST_SEGMENT_SUMMARY("contactofinterestsegmentsumm_0", "contactsegmentid"),
    CONTACT_OPERATIONAL_PROFILE("contactoperationalprofile", "contactoperationalprofileid"),
    EVENT_TARGET_CHARACTERIZATION("eventtargetcharacterization", "hjid"),
    FAN_OF_BEAMS("fanofbeams", "hjid"),
    FILE_DESCRIPTIVE_METADATA("filedescriptivemetadata", "filedescriptivemetadataid"),
    // FREQUENCY_IDENTIFIER not an ISD table
    FREQUENCY_IDENTIFIER("frequencyidentifier", "frequencyidentifierid"),
    GEOSPATIAL_POSITIONS("geospatialpostitions", "geospatialpositionsid"),
    GRAM("gram", "hjid"),
    GRAMS_SPLC("gramssplc", "splinstanceid"),
    HORIZONTAL_MEASUREMENTS("horizontalmeasurements", "hjid"),
    HTML_AND_PNG("htmlandpng", "hjid"),
    MS_OFFICE_DOC("msofficedocument", "hjid"),
    NAD("nad", "hjid"),
    OBSERVED_TARGET_SEGMENT_SUMMARY("observedtargetsegmentsummary", "obstargetid"),
    PLATFORM_CLASS("contactofinterestplatform", "contactofinterestplatformid"),
    PROJECT("project", "projectid"),
    PSD("psd", "hjid"),
    REEL_CUT("reelcut", "reelcutid"),
    REEL_INFO("reelinfo", "reelinfoid"),
    RETENTION_POLICY("retentionpolicy", "retentionpolicyid"),
    SENSOR("sensor", "sensorid"),
    SENSOR_IDENTIFICATION("sensoridentificationtypehold_0", "hjid"),
    SGRM("sgrm", "hjid"),
    SPLC_ASPECT_MEASUREMENT("splcaspectmeasurement", "hjid"),
    SPLC_CONTACT_MEASUREMENT("splccontactmeasurement", "hjid"),
    SPLC_MEASUREMENT_EVENT("splcmeasurementevent", "hjid"),
    SPLC_POINT_MEASUREMENT("splcpointmeasurement", "hjid"),
    SPLC_SOURCE_MEASUREMENT("splcsourcemeasurement", "hjid"),
    SPLC_VERSION("splcversion", "hjid"),
    SUMMARY_SPL("summaryspl", "hjid"),
    SWIMS_EXPORT_XML("swimsexportxml", "hjid"),
    TAPP_XML("tappxml", "hjid"),
    TARGET_TRACK_SOLUTION("targettracksolution", "hjid"),
    TIME_SERIES("timeseriesholder", "hjid"),
    TPS_BEARING("tpsbearing", "hjid"),
    TPS_SOUND_SPEED("tpssoundspeed", "hjid"),
    TPS_TIMESTAMP("tpstimestamp", "hjid"),
    VERTICAL_MEASUREMENTS("verticalmeasurements", "hjid"),
    WAVFILE("wavfile", "hjid"),
    WORKFLOW_ACTIVITY_INSTANCE("workflowactivityinstance", "workflowactivityinstanceid"),
    WORKFLOW_INSTANCE("workflowinstance", "workflowinstanceid"),
    WORKFLOW_SUSPEND("workflowsuspend", "workflowsuspendid"),
    WORKFLOW_TEMPLATE("workflowtemplate", "workflowtemplateid"),
    WORKFLOW_USER_COMMENTS("workflowusercomments", "workflowcommentid");

    private String tableName;
    private String primaryKey;

    private EIsdTableNames(String pTableName, String pPrimaryKey) {
        tableName = pTableName;
        primaryKey = pPrimaryKey;
    }

    public String getTableName() {
        return tableName;
    }

    public String getPrimaryKey() {
        return primaryKey;
    }
}
