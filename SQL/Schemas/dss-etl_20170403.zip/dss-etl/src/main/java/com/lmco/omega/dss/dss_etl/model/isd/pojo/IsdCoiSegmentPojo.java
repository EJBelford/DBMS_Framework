/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author n67154
 */

public class IsdCoiSegmentPojo {

    // ----- associatedfile -----
    private String filedescriptivemetadataid;
    private String filename;
    // ----- parent ------
    private String parentPlatformClass;
    private String parentPlatformName;
    private String parentHullNumber;
    // ----- uniqueIdentifiers -----
    private String name;
    // ----- requiredFields -----
    private Date segment_startTime;
    private Date segment_endTime;
    // ----- otherFields ------
    private String comments;
    private String holdStatus;
    private String operatingProfile;
    private String participantRole;
    private String acousticMode;
    private String speedBand;
    private String depthBand;
    private String cavitationType;
    private String cavitationMode;
    private String propulsionType;
    private String propulsionMode;
    private String weaponActivity;
    private String platformConfidence;
    private String papaLima;
    private String geospatialReferenceBroadArea;
    private String geospatialReferenceRefinedArea;
    private String boundingBoxXOneYOne_longitude;
    private String boundingBoxXOneYOne_latitude;
    private String boundingBoxXOneYOne_altitude;
    private String boundingBoxXTwoYTwo_longitude;
    private String boundingBoxXTwoYTwo_latitude;
    private String boundingBoxXTwoYTwo_altitude;
    private Boolean modifiable;

    private IsdMandatorySecurityPojo security;

    /*
     *
     */
    public IsdCoiSegmentPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */

    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

    /**
     * @return the filedescriptivemetadataid
     */

    public String getFiledescriptivemetadataid() {
        return filedescriptivemetadataid;
    }

    /**
     * @param filedescriptivemetadataid
     *            the filedescriptivemetadataid to set
     */

    public void setFiledescriptivemetadataid(String filedescriptivemetadataid) {
        this.filedescriptivemetadataid = filedescriptivemetadataid;
    }

    /**
     * @return the filename
     */

    public String getFilename() {
        return filename;
    }

    /**
     * @param filename
     *            the filename to set
     */

    public void setFilename(String filename) {
        this.filename = filename;
    }

    /**
     * @return the parentPlatformClass
     */

    public String getParentPlatformClass() {
        return parentPlatformClass;
    }

    /**
     * @param parentPlatformClass
     *            the parentPlatformClass to set
     */

    public void setParentPlatformClass(String parentPlatformClass) {
        this.parentPlatformClass = parentPlatformClass;
    }

    /**
     * @return the parentPlatformName
     */

    public String getParentPlatformName() {
        return parentPlatformName;
    }

    /**
     * @param parentPlatformName
     *            the parentPlatformName to set
     */

    public void setParentPlatformName(String parentPlatformName) {
        this.parentPlatformName = parentPlatformName;
    }

    /**
     * @return the parentHullNumber
     */

    public String getParentHullNumber() {
        return parentHullNumber;
    }

    /**
     * @param parentHullNumber
     *            the parentHullNumber to set
     */

    public void setParentHullNumber(String parentHullNumber) {
        this.parentHullNumber = parentHullNumber;
    }

    /**
     * @return the segment_startTime
     */

    public Date getSegment_startTime() {
        return segment_startTime;
    }

    /**
     * @param segment_startTime
     *            the segment_startTime to set
     */

    public void setSegment_startTime(Date segment_startTime) {
        this.segment_startTime = segment_startTime;
    }

    /**
     * @return the segment_endTime
     */

    public Date getSegment_endTime() {
        return segment_endTime;
    }

    /**
     * @param segment_endTime
     *            the segment_endTime to set
     */

    public void setSegment_endTime(Date segment_endTime) {
        this.segment_endTime = segment_endTime;
    }

    /**
     * @return the comments
     */

    public String getComments() {
        return comments;
    }

    /**
     * @param comments
     *            the comments to set
     */

    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the operatingProfile
     */

    public String getOperatingProfile() {
        return operatingProfile;
    }

    /**
     * @param operatingProfile
     *            the operatingProfile to set
     */

    public void setOperatingProfile(String operatingProfile) {
        this.operatingProfile = operatingProfile;
    }

    /**
     * @return the holdStatus
     */

    public String getHoldStatus() {
        return holdStatus;
    }

    /**
     * @param holdStatus
     *            the holdStatus to set
     */

    public void setHoldStatus(String holdStatus) {
        this.holdStatus = holdStatus;
    }

    /**
     * @return the participantRole
     */

    public String getParticipantRole() {
        return participantRole;
    }

    /**
     * @param participantRole
     *            the participantRole to set
     */

    public void setParticipantRole(String participantRole) {
        this.participantRole = participantRole;
    }

    /**
     * @return the acousticMode
     */

    public String getAcousticMode() {
        return acousticMode;
    }

    /**
     * @param acousticMode
     *            the acousticMode to set
     */

    public void setAcousticMode(String acousticMode) {
        this.acousticMode = acousticMode;
    }

    /**
     * @return the speedBand
     */

    public String getSpeedBand() {
        return speedBand;
    }

    /**
     * @param speedBand
     *            the speedBand to set
     */

    public void setSpeedBand(String speedBand) {
        this.speedBand = speedBand;
    }

    /**
     * @return the depthBand
     */

    public String getDepthBand() {
        return depthBand;
    }

    /**
     * @param depthBand
     *            the depthBand to set
     */

    public void setDepthBand(String depthBand) {
        this.depthBand = depthBand;
    }

    /**
     * @return the cavitationType
     */

    public String getCavitationType() {
        return cavitationType;
    }

    /**
     * @param cavitationType
     *            the cavitationType to set
     */

    public void setCavitationType(String cavitationType) {
        this.cavitationType = cavitationType;
    }

    /**
     * @return the cavitationMode
     */

    public String getCavitationMode() {
        return cavitationMode;
    }

    /**
     * @param cavitationMode
     *            the cavitationMode to set
     */

    public void setCavitationMode(String cavitationMode) {
        this.cavitationMode = cavitationMode;
    }

    /**
     * @return the propulsionType
     */

    public String getPropulsionType() {
        return propulsionType;
    }

    /**
     * @param propulsionType
     *            the propulsionType to set
     */

    public void setPropulsionType(String propulsionType) {
        this.propulsionType = propulsionType;
    }

    /**
     * @return the propulsionMode
     */

    public String getPropulsionMode() {
        return propulsionMode;
    }

    /**
     * @param propulsionMode
     *            the propulsionMode to set
     */

    public void setPropulsionMode(String propulsionMode) {
        this.propulsionMode = propulsionMode;
    }

    /**
     * @return the weaponActivity
     */

    public String getWeaponActivity() {
        return weaponActivity;
    }

    /**
     * @param weaponActivity
     *            the weaponActivity to set
     */

    public void setWeaponActivity(String weaponActivity) {
        this.weaponActivity = weaponActivity;
    }

    /**
     * @return the platformConfidence
     */

    public String getPlatformConfidence() {
        return platformConfidence;
    }

    /**
     * @param platformConfidence
     *            the platformConfidence to set
     */

    public void setPlatformConfidence(String platformConfidence) {
        this.platformConfidence = platformConfidence;
    }

    /**
     * @return the papaLima
     */

    public String getPapaLima() {
        return papaLima;
    }

    /**
     * @param papaLima
     *            the papaLima to set
     */

    public void setPapaLima(String papaLima) {
        this.papaLima = papaLima;
    }

    /**
     * @return the geospatialReferenceBroadArea
     */

    public String getGeospatialReferenceBroadArea() {
        return geospatialReferenceBroadArea;
    }

    /**
     * @param geospatialReferenceBroadArea
     *            the geospatialReferenceBroadArea to set
     */

    public void setGeospatialReferenceBroadArea(String geospatialReferenceBroadArea) {
        this.geospatialReferenceBroadArea = geospatialReferenceBroadArea;
    }

    /**
     * @return the geospatialReferenceRefinedArea
     */

    public String getGeospatialReferenceRefinedArea() {
        return geospatialReferenceRefinedArea;
    }

    /**
     * @param geospatialReferenceRefinedArea
     *            the geospatialReferenceRefinedArea to set
     */

    public void setGeospatialReferenceRefinedArea(String geospatialReferenceRefinedArea) {
        this.geospatialReferenceRefinedArea = geospatialReferenceRefinedArea;
    }

    /**
     * @return the boundingBoxXOneYOne_longitude
     */

    public String getBoundingBoxXOneYOne_longitude() {
        return boundingBoxXOneYOne_longitude;
    }

    /**
     * @param boundingBoxXOneYOne_longitude
     *            the boundingBoxXOneYOne_longitude to set
     */

    public void setBoundingBoxXOneYOne_longitude(String boundingBoxXOneYOne_longitude) {
        this.boundingBoxXOneYOne_longitude = boundingBoxXOneYOne_longitude;
    }

    /**
     * @return the boundingBoxXOneYOne_latitude
     */

    public String getBoundingBoxXOneYOne_latitude() {
        return boundingBoxXOneYOne_latitude;
    }

    /**
     * @param boundingBoxXOneYOne_latitude
     *            the boundingBoxXOneYOne_latitude to set
     */

    public void setBoundingBoxXOneYOne_latitude(String boundingBoxXOneYOne_latitude) {
        this.boundingBoxXOneYOne_latitude = boundingBoxXOneYOne_latitude;
    }

    /**
     * @return the boundingBoxXOneYOne_altitude
     */

    public String getBoundingBoxXOneYOne_altitude() {
        return boundingBoxXOneYOne_altitude;
    }

    /**
     * @param boundingBoxXOneYOne_altitude
     *            the boundingBoxXOneYOne_altitude to set
     */

    public void setBoundingBoxXOneYOne_altitude(String boundingBoxXOneYOne_altitude) {
        this.boundingBoxXOneYOne_altitude = boundingBoxXOneYOne_altitude;
    }

    /**
     * @return the boundingBoxXTwoYTwo_longitude
     */

    public String getBoundingBoxXTwoYTwo_longitude() {
        return boundingBoxXTwoYTwo_longitude;
    }

    /**
     * @param boundingBoxXTwoYTwo_longitude
     *            the boundingBoxXTwoYTwo_longitude to set
     */

    public void setBoundingBoxXTwoYTwo_longitude(String boundingBoxXTwoYTwo_longitude) {
        this.boundingBoxXTwoYTwo_longitude = boundingBoxXTwoYTwo_longitude;
    }

    /**
     * @return the boundingBoxXTwoYTwo_latitude
     */

    public String getBoundingBoxXTwoYTwo_latitude() {
        return boundingBoxXTwoYTwo_latitude;
    }

    /**
     * @param boundingBoxXTwoYTwo_latitude
     *            the boundingBoxXTwoYTwo_latitude to set
     */

    public void setBoundingBoxXTwoYTwo_latitude(String boundingBoxXTwoYTwo_latitude) {
        this.boundingBoxXTwoYTwo_latitude = boundingBoxXTwoYTwo_latitude;
    }

    /**
     * @return the boundingBoxXTwoYTwo_altitude
     */

    public String getBoundingBoxXTwoYTwo_altitude() {
        return boundingBoxXTwoYTwo_altitude;
    }

    /**
     * @param boundingBoxXTwoYTwo_altitude
     *            the boundingBoxXTwoYTwo_altitude to set
     */

    public void setBoundingBoxXTwoYTwo_altitude(String boundingBoxXTwoYTwo_altitude) {
        this.boundingBoxXTwoYTwo_altitude = boundingBoxXTwoYTwo_altitude;
    }

    /**
     * @return the modifiable
     */

    public Boolean getModifiable() {
        return modifiable;
    }

    /**
     * @param modifiable
     *            the modifiable to set
     */

    public void setModifiable(Boolean modifiable) {
        this.modifiable = modifiable;
    }

    /**
     * @return the name
     */

    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */

    public void setName(String name) {
        this.name = name;
    }

}
