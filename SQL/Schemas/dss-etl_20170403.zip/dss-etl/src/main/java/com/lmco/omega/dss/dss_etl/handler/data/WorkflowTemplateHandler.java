/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdWorkflowTemplatePojo;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.workflowtemplate.WorkflowTemplateCoalesce;
import com.lmco.omega.ecm.interfaces.model.WorkflowTemplate;

/**
 * @author bearyman
 */
public class WorkflowTemplateHandler extends AbstractDataHandler {

    private IsdWorkflowTemplatePojo mPojo;

    public WorkflowTemplateHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdWorkflowTemplatePojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("workflowtemplateid"));
            mPojo.setCreationDate(pResults.getTimestamp("creationdateitem"));
            mPojo.setCreator(pResults.getString("creator"));
            mPojo.setDescription(pResults.getString("description"));
            mPojo.setLastModificationDate(pResults.getTimestamp("lastmodificationdateitem"));
            mPojo.setName(pResults.getString("name_"));
            mPojo.setVersion(pResults.getInt("version_"));

            setMandatorySecurity(pResults, mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        WorkflowTemplateCoalesce entity;

        IDataConverter<WorkflowTemplate, WorkflowTemplateCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(WorkflowTemplate.class);

        WorkflowTemplate pojo = converter.constructPojo();

        // pojo.setKey(mWFTemplatePojo.getId());
        pojo.setWorkflowTemplateDescription(mPojo.getDescription());
        pojo.setWorkflowTemplateName(mPojo.getName() + migrationTag);
        pojo.setWorkflowTemplateVersion(Integer.toString(mPojo.getVersion()));
        pojo.setAutomated(false);
        pojo.setDateCreated(mPojo.getCreationDate());
        pojo.setLastModified(mPojo.getLastModificationDate());
        pojo.getDataObjectRecord().setCreatedBy(mPojo.getCreator());

        if (StringHelper.isNullOrEmpty(pojo.getWorkflowTemplateName())) {
            pojo.setWorkflowTemplateName("ETL_Test_WorkflowTemplate-210(a)");
        }
        if (StringHelper.isNullOrEmpty(pojo.getWorkflowTemplateVersion())) {
            pojo.setWorkflowTemplateVersion("4");
        }
        if (StringHelper.isNullOrEmpty(pojo.getWorkflowTemplateDescription())) {
            pojo.setWorkflowTemplateDescription("Workflow Template Description");
        }
        pojo.setAutomated(false);
        if (pojo.getActivityNameList().isEmpty()) {
            pojo.getActivityNameList().add("NameList");
        }
        if (pojo.getActivityDisplayNameList().isEmpty()) {
            pojo.getActivityDisplayNameList().add("DisplayNameList");
        }

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getCreationDate()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        // DO NOTHING
    }

    @Override
    protected String getCreatedBy() {
        return mPojo.getCreator();
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.WORKFLOW_TEMPLATE;
    }
}
