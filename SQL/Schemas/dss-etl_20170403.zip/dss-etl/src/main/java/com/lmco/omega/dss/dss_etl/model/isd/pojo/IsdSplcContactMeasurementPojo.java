/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdSplcContactMeasurementPojo {

    private int id;
    private String bladesPerProp;
    private Double bottomDepth;
    private String cavitationCode;
    private String collectionPlatformCode;
    private String contactClassCode;
    private String contactCountryCode;
    private long contactMeasurementId;
    private Double deAvg;
    private Double deMax;
    private Double deMin;
    private Double deStd;
    private Double depthAvg;
    private String depthCode;
    private Double depthMax;
    private Double depthMin;
    private Double depthStd;
    private String engineLocationCode;
    private String engineTypeCode;
    private Double firstX;
    private Double firstY;
    private Double firstZ;
    private Integer hullNumber;
    private Double lastX;
    private Double lastY;
    private Double lastZ;
    private Double maxRangeFtFilter;
    private Double maxSnrFilter;
    private Double maxVelocityKtsFilter;
    private Double maxX;
    private Double maxY;
    private Double maxZ;
    private long measurementEventId;
    private String measurementType;
    private Double minRangeFtFilter;
    private Double minSnrFilter;
    private Double minVelocityKtsFilter;
    private Double minX;
    private Double minY;
    private Double minZ;
    private Double p1Rpm;
    private Double p2Rpm;
    private Double p3Rpm;
    private String propellerLocationCode1;
    private String propellerLocationCode2;
    private String propellerLocationCode3;
    private String propulsionCode;
    private Double rangeMax;
    private Double rangeMin;
    private String remarks;
    private Integer seaState;
    private Double speedAvg;
    private Double speedMax;
    private Double speedMin;
    private Double speedStd;
    private Double tpk;
    private Date timestampMaxItem;
    private Date timestampMinItem;
    private String transientCode;
    private String gramsSplcId;

    /**
     *
     */
    public IsdSplcContactMeasurementPojo() {}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the bladesPerProp
     */
    public String getBladesPerProp() {
        return bladesPerProp;
    }

    /**
     * @param bladesPerProp
     *            the bladesPerProp to set
     */
    public void setBladesPerProp(String bladesPerProp) {
        this.bladesPerProp = bladesPerProp;
    }

    /**
     * @return the bottomDepth
     */
    public Double getBottomDepth() {
        return bottomDepth;
    }

    /**
     * @param bottomDepth
     *            the bottomDepth to set
     */
    public void setBottomDepth(Double bottomDepth) {
        this.bottomDepth = bottomDepth;
    }

    /**
     * @return the cavitationCode
     */
    public String getCavitationCode() {
        return cavitationCode;
    }

    /**
     * @param cavitationCode
     *            the cavitationCode to set
     */
    public void setCavitationCode(String cavitationCode) {
        this.cavitationCode = cavitationCode;
    }

    /**
     * @return the collectionPlatformCode
     */
    public String getCollectionPlatformCode() {
        return collectionPlatformCode;
    }

    /**
     * @param collectionPlatformCode
     *            the collectionPlatformCode to set
     */
    public void setCollectionPlatformCode(String collectionPlatformCode) {
        this.collectionPlatformCode = collectionPlatformCode;
    }

    /**
     * @return the contactClassCode
     */
    public String getContactClassCode() {
        return contactClassCode;
    }

    /**
     * @param contactClassCode
     *            the contactClassCode to set
     */
    public void setContactClassCode(String contactClassCode) {
        this.contactClassCode = contactClassCode;
    }

    /**
     * @return the contactCountryCode
     */
    public String getContactCountryCode() {
        return contactCountryCode;
    }

    /**
     * @param contactCountryCode
     *            the contactCountryCode to set
     */
    public void setContactCountryCode(String contactCountryCode) {
        this.contactCountryCode = contactCountryCode;
    }

    /**
     * @return the contactMeasurementId
     */
    public long getContactMeasurementId() {
        return contactMeasurementId;
    }

    /**
     * @param contactMeasurementId
     *            the contactMeasurementId to set
     */
    public void setContactMeasurementId(long contactMeasurementId) {
        this.contactMeasurementId = contactMeasurementId;
    }

    /**
     * @return the deAvg
     */
    public Double getDeAvg() {
        return deAvg;
    }

    /**
     * @param deAvg
     *            the deAvg to set
     */
    public void setDeAvg(Double deAvg) {
        this.deAvg = deAvg;
    }

    /**
     * @return the deMax
     */
    public Double getDeMax() {
        return deMax;
    }

    /**
     * @param deMax
     *            the deMax to set
     */
    public void setDeMax(Double deMax) {
        this.deMax = deMax;
    }

    /**
     * @return the deMin
     */
    public Double getDeMin() {
        return deMin;
    }

    /**
     * @param deMin
     *            the deMin to set
     */
    public void setDeMin(Double deMin) {
        this.deMin = deMin;
    }

    /**
     * @return the eStd
     */
    public Double getDeStd() {
        return deStd;
    }

    /**
     * @param eStd
     *            the eStd to set
     */
    public void setDeStd(Double deStd) {
        this.deStd = deStd;
    }

    /**
     * @return the depthAvg
     */
    public Double getDepthAvg() {
        return depthAvg;
    }

    /**
     * @param depthAvg
     *            the depthAvg to set
     */
    public void setDepthAvg(Double depthAvg) {
        this.depthAvg = depthAvg;
    }

    /**
     * @return the depthCode
     */
    public String getDepthCode() {
        return depthCode;
    }

    /**
     * @param depthCode
     *            the depthCode to set
     */
    public void setDepthCode(String depthCode) {
        this.depthCode = depthCode;
    }

    /**
     * @return the depthMax
     */
    public Double getDepthMax() {
        return depthMax;
    }

    /**
     * @param depthMax
     *            the depthMax to set
     */
    public void setDepthMax(Double depthMax) {
        this.depthMax = depthMax;
    }

    /**
     * @return the depthMin
     */
    public Double getDepthMin() {
        return depthMin;
    }

    /**
     * @param depthMin
     *            the depthMin to set
     */
    public void setDepthMin(Double depthMin) {
        this.depthMin = depthMin;
    }

    /**
     * @return the depthStd
     */
    public Double getDepthStd() {
        return depthStd;
    }

    /**
     * @param depthStd
     *            the depthStd to set
     */
    public void setDepthStd(Double depthStd) {
        this.depthStd = depthStd;
    }

    /**
     * @return the engineLocationCode
     */
    public String getEngineLocationCode() {
        return engineLocationCode;
    }

    /**
     * @param engineLocationCode
     *            the engineLocationCode to set
     */
    public void setEngineLocationCode(String engineLocationCode) {
        this.engineLocationCode = engineLocationCode;
    }

    /**
     * @return the engineTypeCode
     */
    public String getEngineTypeCode() {
        return engineTypeCode;
    }

    /**
     * @param engineTypeCode
     *            the engineTypeCode to set
     */
    public void setEngineTypeCode(String engineTypeCode) {
        this.engineTypeCode = engineTypeCode;
    }

    /**
     * @return the firstX
     */
    public Double getFirstX() {
        return firstX;
    }

    /**
     * @param firstX
     *            the firstX to set
     */
    public void setFirstX(Double firstX) {
        this.firstX = firstX;
    }

    /**
     * @return the firstY
     */
    public Double getFirstY() {
        return firstY;
    }

    /**
     * @param firstY
     *            the firstY to set
     */
    public void setFirstY(Double firstY) {
        this.firstY = firstY;
    }

    /**
     * @return the firstZ
     */
    public Double getFirstZ() {
        return firstZ;
    }

    /**
     * @param firstZ
     *            the firstZ to set
     */
    public void setFirstZ(Double firstZ) {
        this.firstZ = firstZ;
    }

    /**
     * @return the hullNumber
     */
    public Integer getHullNumber() {
        return hullNumber;
    }

    /**
     * @param hullNumber
     *            the hullNumber to set
     */
    public void setHullNumber(Integer hullNumber) {
        this.hullNumber = hullNumber;
    }

    /**
     * @return the lastX
     */
    public Double getLastX() {
        return lastX;
    }

    /**
     * @param lastX
     *            the lastX to set
     */
    public void setLastX(Double lastX) {
        this.lastX = lastX;
    }

    /**
     * @return the lastY
     */
    public Double getLastY() {
        return lastY;
    }

    /**
     * @param lastY
     *            the lastY to set
     */
    public void setLastY(Double lastY) {
        this.lastY = lastY;
    }

    /**
     * @return the lastZ
     */
    public Double getLastZ() {
        return lastZ;
    }

    /**
     * @param lastZ
     *            the lastZ to set
     */
    public void setLastZ(Double lastZ) {
        this.lastZ = lastZ;
    }

    /**
     * @return the maxRangeFtFilter
     */
    public Double getMaxRangeFtFilter() {
        return maxRangeFtFilter;
    }

    /**
     * @param maxRangeFtFilter
     *            the maxRangeFtFilter to set
     */
    public void setMaxRangeFtFilter(Double maxRangeFtFilter) {
        this.maxRangeFtFilter = maxRangeFtFilter;
    }

    /**
     * @return the maxSnrFilter
     */
    public Double getMaxSnrFilter() {
        return maxSnrFilter;
    }

    /**
     * @param maxSnrFilter
     *            the maxSnrFilter to set
     */
    public void setMaxSnrFilter(Double maxSnrFilter) {
        this.maxSnrFilter = maxSnrFilter;
    }

    /**
     * @return the maxVelocityKtsFilter
     */
    public Double getMaxVelocityKtsFilter() {
        return maxVelocityKtsFilter;
    }

    /**
     * @param maxVelocityKtsFilter
     *            the maxVelocityKtsFilter to set
     */
    public void setMaxVelocityKtsFilter(Double maxVelocityKtsFilter) {
        this.maxVelocityKtsFilter = maxVelocityKtsFilter;
    }

    /**
     * @return the maxX
     */
    public Double getMaxX() {
        return maxX;
    }

    /**
     * @param maxX
     *            the maxX to set
     */
    public void setMaxX(Double maxX) {
        this.maxX = maxX;
    }

    /**
     * @return the maxY
     */
    public Double getMaxY() {
        return maxY;
    }

    /**
     * @param maxY
     *            the maxY to set
     */
    public void setMaxY(Double maxY) {
        this.maxY = maxY;
    }

    /**
     * @return the maxZ
     */
    public Double getMaxZ() {
        return maxZ;
    }

    /**
     * @param maxZ
     *            the maxZ to set
     */
    public void setMaxZ(Double maxZ) {
        this.maxZ = maxZ;
    }

    /**
     * @return the measurementEventId
     */
    public long getMeasurementEventId() {
        return measurementEventId;
    }

    /**
     * @param measurementEventId
     *            the measurementEventId to set
     */
    public void setMeasurementEventId(long measurementEventId) {
        this.measurementEventId = measurementEventId;
    }

    /**
     * @return the measurementType
     */
    public String getMeasurementType() {
        return measurementType;
    }

    /**
     * @param measurementType
     *            the measurementType to set
     */
    public void setMeasurementType(String measurementType) {
        this.measurementType = measurementType;
    }

    /**
     * @return the minRangeFtFilter
     */
    public Double getMinRangeFtFilter() {
        return minRangeFtFilter;
    }

    /**
     * @param minRangeFtFilter
     *            the minRangeFtFilter to set
     */
    public void setMinRangeFtFilter(Double minRangeFtFilter) {
        this.minRangeFtFilter = minRangeFtFilter;
    }

    /**
     * @return the minSnrFilter
     */
    public Double getMinSnrFilter() {
        return minSnrFilter;
    }

    /**
     * @param minSnrFilter
     *            the minSnrFilter to set
     */
    public void setMinSnrFilter(Double minSnrFilter) {
        this.minSnrFilter = minSnrFilter;
    }

    /**
     * @return the minVelocityKtsFilter
     */
    public Double getMinVelocityKtsFilter() {
        return minVelocityKtsFilter;
    }

    /**
     * @param minVelocityKtsFilter
     *            the minVelocityKtsFilter to set
     */
    public void setMinVelocityKtsFilter(Double minVelocityKtsFilter) {
        this.minVelocityKtsFilter = minVelocityKtsFilter;
    }

    /**
     * @return the minX
     */
    public Double getMinX() {
        return minX;
    }

    /**
     * @param minX
     *            the minX to set
     */
    public void setMinX(Double minX) {
        this.minX = minX;
    }

    /**
     * @return the minY
     */
    public Double getMinY() {
        return minY;
    }

    /**
     * @param minY
     *            the minY to set
     */
    public void setMinY(Double minY) {
        this.minY = minY;
    }

    /**
     * @return the minZ
     */
    public Double getMinZ() {
        return minZ;
    }

    /**
     * @param minZ
     *            the minZ to set
     */
    public void setMinZ(Double minZ) {
        this.minZ = minZ;
    }

    /**
     * @return the p1Rpm
     */
    public Double getP1Rpm() {
        return p1Rpm;
    }

    /**
     * @param p1Rpm
     *            the p1Rpm to set
     */
    public void setP1Rpm(Double p1Rpm) {
        this.p1Rpm = p1Rpm;
    }

    /**
     * @return the p2Rpm
     */
    public Double getP2Rpm() {
        return p2Rpm;
    }

    /**
     * @param p2Rpm
     *            the p2Rpm to set
     */
    public void setP2Rpm(Double p2Rpm) {
        this.p2Rpm = p2Rpm;
    }

    /**
     * @return the p3Rpm
     */
    public Double getP3Rpm() {
        return p3Rpm;
    }

    /**
     * @param p3Rpm
     *            the p3Rpm to set
     */
    public void setP3Rpm(Double p3Rpm) {
        this.p3Rpm = p3Rpm;
    }

    /**
     * @return the propellerLocationCode1
     */
    public String getPropellerLocationCode1() {
        return propellerLocationCode1;
    }

    /**
     * @param propellerLocationCode1
     *            the propellerLocationCode1 to set
     */
    public void setPropellerLocationCode1(String propellerLocationCode1) {
        this.propellerLocationCode1 = propellerLocationCode1;
    }

    /**
     * @return the propellerLocationCode2
     */
    public String getPropellerLocationCode2() {
        return propellerLocationCode2;
    }

    /**
     * @param propellerLocationCode2
     *            the propellerLocationCode2 to set
     */
    public void setPropellerLocationCode2(String propellerLocationCode2) {
        this.propellerLocationCode2 = propellerLocationCode2;
    }

    /**
     * @return the propellerLocationCode3
     */
    public String getPropellerLocationCode3() {
        return propellerLocationCode3;
    }

    /**
     * @param propellerLocationCode3
     *            the propellerLocationCode3 to set
     */
    public void setPropellerLocationCode3(String propellerLocationCode3) {
        this.propellerLocationCode3 = propellerLocationCode3;
    }

    /**
     * @return the propulsionCode
     */
    public String getPropulsionCode() {
        return propulsionCode;
    }

    /**
     * @param propulsionCode
     *            the propulsionCode to set
     */
    public void setPropulsionCode(String propulsionCode) {
        this.propulsionCode = propulsionCode;
    }

    /**
     * @return the rangeMax
     */
    public Double getRangeMax() {
        return rangeMax;
    }

    /**
     * @param rangeMax
     *            the rangeMax to set
     */
    public void setRangeMax(Double rangeMax) {
        this.rangeMax = rangeMax;
    }

    /**
     * @return the rangeMin
     */
    public Double getRangeMin() {
        return rangeMin;
    }

    /**
     * @param rangeMin
     *            the rangeMin to set
     */
    public void setRangeMin(Double rangeMin) {
        this.rangeMin = rangeMin;
    }

    /**
     * @return the remarks
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * @param remarks
     *            the remarks to set
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /**
     * @return the seaState
     */
    public Integer getSeaState() {
        return seaState;
    }

    /**
     * @param seaState
     *            the seaState to set
     */
    public void setSeaState(Integer seaState) {
        this.seaState = seaState;
    }

    /**
     * @return the speedAvg
     */
    public Double getSpeedAvg() {
        return speedAvg;
    }

    /**
     * @param speedAvg
     *            the speedAvg to set
     */
    public void setSpeedAvg(Double speedAvg) {
        this.speedAvg = speedAvg;
    }

    /**
     * @return the speedMax
     */
    public Double getSpeedMax() {
        return speedMax;
    }

    /**
     * @param speedMax
     *            the speedMax to set
     */
    public void setSpeedMax(Double speedMax) {
        this.speedMax = speedMax;
    }

    /**
     * @return the speedMin
     */
    public Double getSpeedMin() {
        return speedMin;
    }

    /**
     * @param speedMin
     *            the speedMin to set
     */
    public void setSpeedMin(Double speedMin) {
        this.speedMin = speedMin;
    }

    /**
     * @return the speedStd
     */
    public Double getSpeedStd() {
        return speedStd;
    }

    /**
     * @param speedStd
     *            the speedStd to set
     */
    public void setSpeedStd(Double speedStd) {
        this.speedStd = speedStd;
    }

    /**
     * @return the tpk
     */
    public Double getTpk() {
        return tpk;
    }

    /**
     * @param tpk
     *            the tpk to set
     */
    public void setTpk(Double tpk) {
        this.tpk = tpk;
    }

    /**
     * @return the timestampMaxItem
     */
    public Date getTimestampMaxItem() {
        return timestampMaxItem;
    }

    /**
     * @param timestampMaxItem
     *            the timestampMaxItem to set
     */
    public void setTimestampMaxItem(Date timestampMaxItem) {
        this.timestampMaxItem = timestampMaxItem;
    }

    /**
     * @return the timestampMinItem
     */
    public Date getTimestampMinItem() {
        return timestampMinItem;
    }

    /**
     * @param timestampMinItem
     *            the timestampMinItem to set
     */
    public void setTimestampMinItem(Date timestampMinItem) {
        this.timestampMinItem = timestampMinItem;
    }

    /**
     * @return the transientCode
     */
    public String getTransientCode() {
        return transientCode;
    }

    /**
     * @param transientCode
     *            the transientCode to set
     */
    public void setTransientCode(String transientCode) {
        this.transientCode = transientCode;
    }

    /**
     * @return the gramsSplcId
     */
    public String getGramsSplcId() {
        return gramsSplcId;
    }

    /**
     * @param gramsSplcId
     *            the gramsSplcId to set
     */
    public void setGramsSplcId(String gramsSplcId) {
        this.gramsSplcId = gramsSplcId;
    }

}
