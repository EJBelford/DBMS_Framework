/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bearyman
 */
public class EnumMigrationResult {

    private boolean succeeded;
    private String enumName;
    private String result;
    private List<MigrationResult> migrationResults;

    /**
     * Default constructor
     */
    public EnumMigrationResult() {
        succeeded = false;
        result = "";
        enumName = "";
        migrationResults = new ArrayList<MigrationResult>();
    }

    /**
     * Constructs a CallResult using the provided parameters.
     *
     * @param pSucceeded
     *            True or false whether the command succeeded
     * @param pErrMsg
     *            Error message if the command failed
     */
    public EnumMigrationResult(boolean pSucceeded, String pEnumName, String pResult,
            List<MigrationResult> pResults) {
        succeeded = pSucceeded;
        result = pResult;
        enumName = pEnumName;
        migrationResults = pResults;
    }

    /**
     * @return True or false whether the command succeeded
     */
    public boolean isSuccessful() {
        return succeeded;
    }

    /**
     * Sets whether the command succeeded
     *
     * @param success
     *            True or false
     */
    public void setSuccessful(boolean success) {
        succeeded = success;
    }

    /**
     * @return Result of the command
     */
    public String getResult() {
        return result;
    }

    /**
     * Set the result of the command
     *
     * @param pResult
     *            Command result
     */
    public void setResult(String pResult) {
        result = pResult;
    }

    /**
     * @return the enumName
     */
    public String getEnumName() {
        return enumName;
    }

    /**
     * @param pEnumName
     *            the enumName to set
     */
    public void setEnumName(String pEnumName) {
        enumName = pEnumName;
    }

    /**
     * @return the migrationResults
     */
    public List<MigrationResult> getMigrationResults() {
        return migrationResults;
    }

    public void addMigrationResult(MigrationResult pResult) {
        migrationResults.add(pResult);
    }

}
