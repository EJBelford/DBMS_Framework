/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.data.coi.CoiPlatformHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCoiPlatformPojo;

/**
 * @author bearyman
 */
public class CoiPlatformMigrationManager extends AbstractCoiMigrationManager {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiPlatformMigrationManager.class);
    /*
     * Contact Platform
     * Uniqueness based upon on name for a specific parent platform class and if hull
     * number > 0, then hull number unique for a specific parent platform class
     */
    private static final String GET_CONTACT_PLATFORM =
            "SELECT DISTINCT "
                    + " /* '|' AS parent, */"
                    + "COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "    NULLIF(coiss.classification, ''), 'UNKNOWN') AS parentPlatformClass, "

                    + " /* '|' AS uniqueIdentifiers, */"
                    + "COALESCE (coip.refinedname, coiss.name_, NULLIF(coip.refinedclassification, ''), "
                    + "    NULLIF(coiss.classification, '')) "
                    + "    || '_' || COALESCE (TO_CHAR(coip.refinedhull), TO_CHAR(coiss.hull), '0') AS uniqueContactPlatformName, "
                    + "COALESCE (coip.refinedhull, coiss.hull, 0) AS hullNumber, "
                    + "COALESCE (TO_CHAR(coip.refinedname), TO_CHAR(coiss.name_), "
                    + "    COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "        NULLIF(coiss.classification, '')) "
                    + "    || '_' || COALESCE (TO_CHAR(coip.refinedhull), TO_CHAR(coiss.hull), '0')) AS name "

                    + " /* '|' AS otherFields, */"
                    + "COALESCE (NULLIF(coip.refinedtype, ''), NULLIF(coip.refinedcategory, ''), "
                    + "    NULLIF(coiss.platformtype, ''), NULLIF(coiss.category, ''), 'UNKNOWN') AS type, "
                    + "COALESCE (coip.sconum, coiss.sconum) AS sconum, "
                    + "COALESCE (coip.refinedpennant, coiss.pennant) AS pennant, "
                    + "COALESCE (coip.refinedcountry, coiss.country) AS ownerCountry, "
                    + "coip.producecountry AS producerCountry, "
                    + "COALESCE (coip.refinedtargetflightvariant, coiss.targetflightvariant) AS targetFlightVariant, "
                    + "COALESCE (coip.mandatorymetadata_security_c_0, "
                    + "    coiss.mandatorymetadata_security_c_0) AS mandatorymetadata_security_c_0, "
                    + "COALESCE (coip.mandatorymetadata_security_c_2, "
                    + "    coiss.mandatorymetadata_security_c_2) AS mandatorymetadata_security_c_2, "
                    + "COALESCE (coip.mandatorymetadata_security_c_1, "
                    + "    coiss.mandatorymetadata_security_c_1) AS mandatorymetadata_security_c_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_7, "
                    + "    coiss.mandatorymetadata_security_d_7) AS mandatorymetadata_security_d_7, "
                    + "COALESCE (coip.mandatorymetadata_security_d_6, "
                    + "    coiss.mandatorymetadata_security_d_6) AS mandatorymetadata_security_d_6, "
                    + "COALESCE (coip.mandatorymetadata_security_d_3, "
                    + "    coiss.mandatorymetadata_security_d_3) AS mandatorymetadata_security_d_3, "
                    + "COALESCE (coip.mandatorymetadata_security_d_4, "
                    + "    coiss.mandatorymetadata_security_d_4) AS mandatorymetadata_security_d_4, "
                    + "COALESCE (coip.mandatorymetadata_security_d_5, "
                    + "    coiss.mandatorymetadata_security_d_5) AS mandatorymetadata_security_d_5, "
                    + "COALESCE (coip.mandatorymetadata_security_d_1, "
                    + "    coiss.mandatorymetadata_security_d_1) AS mandatorymetadata_security_d_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_2, "
                    + "    coiss.mandatorymetadata_security_d_2) AS mandatorymetadata_security_d_2, "
                    + "COALESCE (coip.mandatorymetadata_security_d_0, "
                    + "    coiss.mandatorymetadata_security_d_0) AS mandatorymetadata_security_d_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_0, "
                    + "    coiss.mandatorymetadata_security_f_0) AS mandatorymetadata_security_f_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_1, "
                    + "    coiss.mandatorymetadata_security_f_1) AS mandatorymetadata_security_f_1, "
                    + "COALESCE (coip.mandatorymetadata_security_n_0, "
                    + "    coiss.mandatorymetadata_security_n_0) AS mandatorymetadata_security_n_0, "
                    + "COALESCE (coip.mandatorymetadata_security_o_0, "
                    + "    coiss.mandatorymetadata_security_o_0) AS mandatorymetadata_security_o_0, "
                    + "COALESCE (coip.mandatorymetadata_security_r_0, "
                    + "    coiss.mandatorymetadata_security_r_0) AS mandatorymetadata_security_r_0, "
                    + "COALESCE (coip.mandatorymetadata_security_s_1, "
                    + "    coiss.mandatorymetadata_security_s_1) AS mandatorymetadata_security_s_1, "
                    + "COALESCE (coip.mandatorymetadata_security_s_0, "
                    + "    coiss.mandatorymetadata_security_s_0) AS mandatorymetadata_security_s_0, "
                    + "COALESCE (coip.mandatorymetadata_security_t_0, "
                    + "    coiss.mandatorymetadata_security_t_0) AS mandatorymetadata_security_t_0 "
                    + "FROM omega.contactofinterest AS coi "
                    + "LEFT JOIN omega.contactofinterestplatform AS coip "
                    + "    ON coip.contactid = coi.contactofinterestid "
                    + "LEFT JOIN omega.metacard_contactofinterest "
                    + "    ON coi.contactofinterestid = metacard_contactofinterest.contactofinterestid "
                    + "LEFT JOIN omega.mdf_catalog_tab "
                    + "    ON metacard_contactofinterest.metacardid = mdf_catalog_tab.catalog_id "
                    + "LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "    ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "LEFT JOIN omega.filedescriptivemetadata AS filecoi "
                    + "    ON filecoi.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "LEFT JOIN "
                    + "    ( "
                    + "    SELECT "
                    + "      filecoiss.filedescriptivemetadataid AS filecoissid, "
                    + "      filecoiss.filename AS filecoissname, "
                    + "      contactofinterestsegmentsumm_0.* "
                    + "    FROM "
                    + "      omega.contactofinterestsegmentsumm_0 "
                    + "      LEFT JOIN omega.metacard_contactofinterestsegmentsummary "
                    + "        ON contactofinterestsegmentsumm_0.contactsegmentid = metacard_contactofinterestsegmentsummary.contactofinterestsegmentsummaryid "
                    + "      LEFT JOIN omega.mdf_catalog_tab "
                    + "        ON metacard_contactofinterestsegmentsummary.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "        ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.filedescriptivemetadata AS filecoiss "
                    + "        ON filecoiss.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "    WHERE "
                    + "      filecoiss.filedescriptivemetadataid != ''     "
                    + "    ) AS coiss "
                    + "    ON "
                    + "    ( "
                    + "    coiss.contactofinterestid = coi.contactofinterestid "
                    + "    AND filecoissid = filecoi.filedescriptivemetadataid "
                    + "    ) "
                    + "WHERE "
                    + "  filecoi.filedescriptivemetadataid != '' "
                    + "  AND COALESCE (coip.refinedclassification, coiss.classification, coip.refinedtype, "
                    + "                coip.refinedcategory, coiss.platformtype, coiss.category) != '' "
                    + "ORDER BY " + "  parentPlatformClass ASC, " + "  name ASC, "
                    + "  hullNumber ASC, " + "  type ASC; ";

    private IsdCoiPlatformPojo mPojo;
    private List<IsdCoiPlatformPojo> mPojos;

    /**
     * @throws SQLException
     */
    public CoiPlatformMigrationManager() throws SQLException {
        mTableType = EIsdTableNames.CONTACT_OF_INTEREST_PLATFORM;
        mIsdConn = EtlUtilitiesDbms.getISDConnection();
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws SQLException {
        mPojos = new ArrayList<>();

        while (pResults.next()) {
            mPojo = new IsdCoiPlatformPojo();

            mPojo.setParentPlatformClass(formatEnumString(pResults.getString("parentPlatformClass")));
            mPojo.setUniqueContactPlatformName(formatEnumString(pResults
                    .getString("uniqueContactPlatformName")));
            mPojo.setHullNumber(pResults.getInt("hullNumber"));
            mPojo.setType(formatPlatformTypeEnumString(pResults.getString("type")));

            mPojo.setName(formatEnumString(pResults.getString("name")));
            mPojo.setScoNum(pResults.getString("sconum"));
            mPojo.setPennant(pResults.getString("pennant"));
            mPojo.setOwnerCountry(pResults.getString("ownerCountry"));
            mPojo.setProducerCountry(pResults.getString("producerCountry"));
            mPojo.setTargetFlightVariant(pResults.getString("targetflightvariant"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            mPojos.add(mPojo);
        }
        mMetrics.setTotalRecords(mPojos.size());
    }

    @Override
    protected void createHandlers() {
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (IsdCoiPlatformPojo pojo: mPojos) {
            mHandlerQueue.add(new CoiPlatformHandler(pojo));
        }
    }

    @Override
    protected String getQuery() {
        return GET_CONTACT_PLATFORM;
    }

}
