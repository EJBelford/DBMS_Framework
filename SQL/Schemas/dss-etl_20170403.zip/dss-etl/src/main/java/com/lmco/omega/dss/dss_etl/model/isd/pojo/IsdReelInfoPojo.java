/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdReelInfoPojo {

    private String id;
    private String dataFormat;
    private String dataFormatCode;
    private String oniMediaType;
    private String oniMediaTypeCode;
    private String reelCaveat;
    private String reelCaveatAbbr;
    private String reelDissemination;
    private int reelNumber;
    private String reelSecurityClass;
    private Date reelStartTime;
    private Date reelStopTime;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdReelInfoPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the dataFormat
     */
    public String getDataFormat() {
        return dataFormat;
    }

    /**
     * @param dataFormat
     *            the dataFormat to set
     */
    public void setDataFormat(String dataFormat) {
        this.dataFormat = dataFormat;
    }

    /**
     * @return the dataFormatCode
     */
    public String getDataFormatCode() {
        return dataFormatCode;
    }

    /**
     * @param dataFormatCode
     *            the dataFormatCode to set
     */
    public void setDataFormatCode(String dataFormatCode) {
        this.dataFormatCode = dataFormatCode;
    }

    /**
     * @return the oniMediaType
     */
    public String getOniMediaType() {
        return oniMediaType;
    }

    /**
     * @param oniMediaType
     *            the oniMediaType to set
     */
    public void setOniMediaType(String oniMediaType) {
        this.oniMediaType = oniMediaType;
    }

    /**
     * @return the oniMediaTypeCode
     */
    public String getOniMediaTypeCode() {
        return oniMediaTypeCode;
    }

    /**
     * @param oniMediaTypeCode
     *            the oniMediaTypeCode to set
     */
    public void setOniMediaTypeCode(String oniMediaTypeCode) {
        this.oniMediaTypeCode = oniMediaTypeCode;
    }

    /**
     * @return the reelCaveat
     */
    public String getReelCaveat() {
        return reelCaveat;
    }

    /**
     * @param reelCaveat
     *            the reelCaveat to set
     */
    public void setReelCaveat(String reelCaveat) {
        this.reelCaveat = reelCaveat;
    }

    /**
     * @return the reelCaveatAbbr
     */
    public String getReelCaveatAbbr() {
        return reelCaveatAbbr;
    }

    /**
     * @param reelCaveatAbbr
     *            the reelCaveatAbbr to set
     */
    public void setReelCaveatAbbr(String reelCaveatAbbr) {
        this.reelCaveatAbbr = reelCaveatAbbr;
    }

    /**
     * @return the reelDissemination
     */
    public String getReelDissemination() {
        return reelDissemination;
    }

    /**
     * @param reelDissemination
     *            the reelDissemination to set
     */
    public void setReelDissemination(String reelDissemination) {
        this.reelDissemination = reelDissemination;
    }

    /**
     * @return the reelNumber
     */
    public int getReelNumber() {
        return reelNumber;
    }

    /**
     * @param reelNumber
     *            the reelNumber to set
     */
    public void setReelNumber(int reelNumber) {
        this.reelNumber = reelNumber;
    }

    /**
     * @return the reelSecurityClass
     */
    public String getReelSecurityClass() {
        return reelSecurityClass;
    }

    /**
     * @param reelSecurityClass
     *            the reelSecurityClass to set
     */
    public void setReelSecurityClass(String reelSecurityClass) {
        this.reelSecurityClass = reelSecurityClass;
    }

    /**
     * @return the reelStartTime
     */
    public Date getReelStartTime() {
        return reelStartTime;
    }

    /**
     * @param reelStartTime
     *            the reelStartTime to set
     */
    public void setReelStartTime(Date reelStartTime) {
        this.reelStartTime = reelStartTime;
    }

    /**
     * @return the reelStopTime
     */
    public Date getReelStopTime() {
        return reelStopTime;
    }

    /**
     * @param reelStopTime
     *            the reelStopTime to set
     */
    public void setReelStopTime(Date reelStopTime) {
        this.reelStopTime = reelStopTime;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

}
