/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdSplcVersionPojo {

    private int id;
    private Date processingSoftwareDate;
    private String processingSoftwareName;
    private long processingSoftwareVersion;
    private long splVersion;

    /**
     *
     */
    public IsdSplcVersionPojo() {}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the processingSoftwareDate
     */
    public Date getProcessingSoftwareDate() {
        return processingSoftwareDate;
    }

    /**
     * @param processingSoftwareDate
     *            the processingSoftwareDate to set
     */
    public void setProcessingSoftwareDate(Date processingSoftwareDate) {
        this.processingSoftwareDate = processingSoftwareDate;
    }

    /**
     * @return the processingSoftwareName
     */
    public String getProcessingSoftwareName() {
        return processingSoftwareName;
    }

    /**
     * @param processingSoftwareName
     *            the processingSoftwareName to set
     */
    public void setProcessingSoftwareName(String processingSoftwareName) {
        this.processingSoftwareName = processingSoftwareName;
    }

    /**
     * @return the processingSoftwareVersion
     */
    public long getProcessingSoftwareVersion() {
        return processingSoftwareVersion;
    }

    /**
     * @param processingSoftwareVersion
     *            the processingSoftwareVersion to set
     */
    public void setProcessingSoftwareVersion(long processingSoftwareVersion) {
        this.processingSoftwareVersion = processingSoftwareVersion;
    }

    /**
     * @return the splVersion
     */
    public long getSplVersion() {
        return splVersion;
    }

    /**
     * @param splVersion
     *            the splVersion to set
     */
    public void setSplVersion(long splVersion) {
        this.splVersion = splVersion;
    }

}
