/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdWorkflowInstancePojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.workflowinstance.WorkflowInstanceCoalesce;
import com.lmco.omega.ecm.interfaces.model.EProductionStatus;
import com.lmco.omega.ecm.interfaces.model.WorkflowInstance;

/**
 * @author bearyman
 */
public class WorkflowInstanceHandler extends AbstractDataHandler {

    private IsdWorkflowInstancePojo mPojo;

    public WorkflowInstanceHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdWorkflowInstancePojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("workflowinstanceid"));
            mPojo.setCreationDate(pResults.getTimestamp("creationdateitem"));
            mPojo.setCreator(pResults.getString("creator"));
            mPojo.setDescription(pResults.getString("description"));
            mPojo.setDueDate(pResults.getTimestamp("duedateitem"));
            mPojo.setEndDate(pResults.getTimestamp("enddateitem"));
            mPojo.setExcludeFromMetrics(pResults.getBoolean("excludefrommetrics"));
            mPojo.setFunctionalLeg(pResults.getInt("functionalleg"));
            mPojo.setOmegaProjectId(pResults.getString("omegaprojectid"));
            mPojo.setName(pResults.getString("name_"));
            mPojo.setOwner(pResults.getString("owner_"));
            mPojo.setPriority(pResults.getInt("priority"));
            mPojo.setProcessId(pResults.getInt("processid"));
            mPojo.setStartDate(pResults.getTimestamp("startdateitem"));
            mPojo.setStatus(pResults.getInt("status"));
            mPojo.setValidity(pResults.getBoolean("validity"));
            mPojo.setWorkflowStandardTags(pResults.getString("workflowstandardtags"));
            mPojo.setWorkflowTemplateId(pResults.getString("workflowtemplateid"));

            setMandatorySecurity(pResults, mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        WorkflowInstanceCoalesce entity;

        IDataConverter<WorkflowInstance, WorkflowInstanceCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(WorkflowInstance.class);

        WorkflowInstance pojo = converter.constructPojo();

        pojo.setDateCreated(mPojo.getCreationDate());
        pojo.setDescription(mPojo.getDescription());
        pojo.setDueDate(mPojo.getDueDate());
        pojo.setName(mPojo.getName() + migrationTag);
        pojo.setPriority(Integer.toString(mPojo.getPriority()));
        pojo.setAssignedGroup(mPojo.getCreator());

        EProductionStatus productionStatus = null;
        switch (mPojo.getStatus()) {
            case 0: // ISD Created
            case 1: // ISD Started
            case 2: // ISD Suspended
            case 3: // ISD Canceled
                productionStatus = EProductionStatus.CANCELLED;
                break;
            case 4:
                productionStatus = EProductionStatus.COMPLETED;
                break;
            case 5:
                productionStatus = EProductionStatus.ERROR;
                break;
            default:
                productionStatus = EProductionStatus.ERROR;
                break;
        }
        pojo.setStatus(productionStatus);

        String functionLeg = null;
        switch (mPojo.getFunctionalLeg()) {
            case 0:
                functionLeg = "DataAcquisition";
                break;
            case 1:
                functionLeg = "SignalsAnalysis";
                break;
            case 2:
                functionLeg = "SignalsAnalysis_Screening";
                break;
            case 3:
                functionLeg = "EventReconstruction";
                break;
            case 4:
                functionLeg = "SignalsMeasurement";
                break;
            case 5:
                functionLeg = "ModelingAndSimulation";
                break;
            case 6:
                functionLeg = "ProductDissemination";
                break;
            case 7:
                functionLeg = "SystemAdministration";
                break;
            default:
                functionLeg = "Unknown";
                break;
        }
        pojo.setPedFunction(functionLeg);

        if (StringHelper.isNullOrEmpty(pojo.getName())) {
            pojo.setName("ETL_Test_WorkflowInstance-222(a)");
        }

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set other fields
        entity.getDataObjectRecord().setCreatedBy(mPojo.getCreator());

        // 2016-10-27 - GB - Added this to the correct start date issue on HMI - Start
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getCreationDate()));
        // 2016-10-27 - GB - Added this to the correct start date issue on HMI - Stop

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";

        // Link project
        linkEntities(mEntityKey, mPojo.getOmegaProjectId(), ELinkType.IS_CHILD_OF, "project",
                     DataObjectLinkActionType.LINK);

        // Link workflow template
        linkEntities(mEntityKey, mPojo.getWorkflowTemplateId(), ELinkType.IS_CHILD_OF,
                     "workflow template", DataObjectLinkActionType.LINK);
    }

    @Override
    protected String getCreatedBy() {
        return mPojo.getCreator();
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.WORKFLOW_INSTANCE;
    }
}
