/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.database;

import java.util.ArrayList;
import java.util.List;

import com.incadencecorp.coalesce.framework.EnumerationProviderUtil;
import com.lmco.omega.dss.common.persister.DSSPostGreSQLPersistor;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author bearyman
 */
public class EtlPersister extends DSSPostGreSQLPersistor {

    /**
     *
     */
    public EtlPersister() {}

    @Override
    public Enumeration retrieveEnumeration(final String name) {
        Enumeration enumeration = null;

        // Get Metadata for each requested enumeration and add to list
        enumeration = createEnumeration(name, EnumerationProviderUtil.getValues(null, name));

        return enumeration;
    }

    private Enumeration createEnumeration(String name, List<String> values) {
        Enumeration enumeration = null;

        enumeration = new Enumeration();
        // Set initial enumeration attributes
        enumeration.setEnumType(name);
        enumeration.getEnumValues().addAll(createEnumValues(name, values));

        return enumeration;
    }

    private List<EnumerationValue> createEnumValues(String name, List<String> enumValues) {
        List<EnumerationValue> values = new ArrayList<EnumerationValue>();

        for (int i = 0; i < enumValues.size(); i++) {
            EnumerationValue value = new EnumerationValue();
            value.setOrdering(i);
            value.setEnumValue(enumValues.get(i));
            value.setEnumType(name);

            values.add(value);
        }
        return values;
    }

}
