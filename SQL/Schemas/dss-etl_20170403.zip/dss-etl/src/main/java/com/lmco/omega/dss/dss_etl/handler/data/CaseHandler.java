/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;
import java.sql.Statement;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.daq.datamodel.Case;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCasePojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;

/**
 * @author bearyman
 */
public class CaseHandler extends AbstractDataHandler {

    private static final String GET_ASSOC_PROJECT_IDS = "SELECT p.projectid FROM omega.project p "
            + "LEFT OUTER JOIN omega.project_associatedcaseids pa ON p.projectid = pa.projectid "
            + "LEFT OUTER JOIN omega.case_ c ON pa.associatedcaseid = c.onicasenumber "
            + "WHERE c.onicasenumber = '%s'";
    private static final String GET_ASSOC_WAI_IDS = "SELECT wai.workflowactivityinstanceid "
            + "FROM omega.case_ c LEFT OUTER JOIN omega.casinginfo ci ON "
            + "c.onicasenumber = ci.onicasenumber "
            + "LEFT OUTER JOIN omega.workflowactivityinstance wai ON "
            + "ci.hjid = casinginfo_workflowactivityi_0 "
            + "WHERE wai.workflowactivityinstanceid IS NOT NULL " + "AND c.onicasenumber = '%s'";
    // private static final String GET_ASSOC_COLLECTOR_IDS = "SELECT c.collectorid "
    // + "FROM omega.collector c "
    // + "LEFT OUTER JOIN omega.collector_associatedcaseids aci ON "
    // + "aci.collectorid = c.collectorid " + "WHERE aci.hjvalue = '%s'";

    private IsdCasePojo mPojo;

    public CaseHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdCasePojo();

        while (pResults.next()) {
            mPojo.setOniCaseNumber(pResults.getString("onicasenumber"));
            mPojo.setStartTime(pResults.getTimestamp("casestarttimeitem"));
            mPojo.setStopTime(pResults.getTimestamp("casestoptimeitem"));
            mPojo.setMissionNumber(pResults.getString("missionnumber"));

            setMandatorySecurity(pResults, mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() {
        methodName = "mapToCoalesce";
        Case entity = new Case();
        entity.initialize();

        // Map pojo to coalesce
        entity.getCaseRecord().setONICaseNumber(mPojo.getOniCaseNumber());
        entity.getTimeIntervalRecord().setStartTime(mPojo.getStartTime());
        entity.getTimeIntervalRecord().setEndTime(mPojo.getStopTime());
        entity.getCaseRecord().setMissionNumber(mPojo.getMissionNumber());

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = entity.getKey();

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getStartTime()));

        // Set other fields
        cEntity.setTitle(mPojo.getOniCaseNumber());

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            // Link projects
            results = stmt.executeQuery(String.format(GET_ASSOC_PROJECT_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF, "project",
                             DataObjectLinkActionType.LINK);
            }

            // Link workflow activity instances
            results = stmt.executeQuery(String.format(GET_ASSOC_WAI_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF,
                             "workflow activity instance", DataObjectLinkActionType.LINK);
            }

            // Link collectors
            // results = stmt.executeQuery(String.format(GET_ASSOC_COLLECTOR_IDS, mKey));
            //
            // while (results.next()) {
            // if (!StringHelper.isNullOrEmpty(results.getString(1))) {
            // linkEntities(mCaseEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF,
            // null, DataObjectLinkActionType.LINK);
            // }
            // }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    protected String getCreatedBy() {
        return DSSConstants.SYSTEM_ACCOUNT;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.CASE;
    }
}
