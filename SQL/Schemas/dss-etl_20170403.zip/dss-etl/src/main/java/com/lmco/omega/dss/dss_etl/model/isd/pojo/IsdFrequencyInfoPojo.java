/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdFrequencyInfoPojo {

    private Double resolution;
    private Double scanRate;
    private Double startFrequency;
    private Double stopFrequency;

    /**
     *
     */
    public IsdFrequencyInfoPojo() {}

    /**
     * @return the resolution
     */
    public Double getResolution() {
        return resolution;
    }

    /**
     * @param resolution
     *            the resolution to set
     */
    public void setResolution(Double resolution) {
        this.resolution = resolution;
    }

    /**
     * @return the scanRate
     */
    public Double getScanRate() {
        return scanRate;
    }

    /**
     * @param scanRate
     *            the scanRate to set
     */
    public void setScanRate(Double scanRate) {
        this.scanRate = scanRate;
    }

    /**
     * @return the startFrequency
     */
    public Double getStartFrequency() {
        return startFrequency;
    }

    /**
     * @param startFrequency
     *            the startFrequency to set
     */
    public void setStartFrequency(Double startFrequency) {
        this.startFrequency = startFrequency;
    }

    /**
     * @return the stopFrequency
     */
    public Double getStopFrequency() {
        return stopFrequency;
    }

    /**
     * @param stopFrequency
     *            the stopFrequency to set
     */
    public void setStopFrequency(Double stopFrequency) {
        this.stopFrequency = stopFrequency;
    }

}
