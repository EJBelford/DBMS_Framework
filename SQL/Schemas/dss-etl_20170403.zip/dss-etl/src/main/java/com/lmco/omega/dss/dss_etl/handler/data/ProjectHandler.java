/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;
import java.util.Date;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdProjectPojo;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.project.ProjectCoalesce;
import com.lmco.omega.ecm.interfaces.model.Project;

/**
 * @author bearyman
 */
public class ProjectHandler extends AbstractDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            ProjectHandler.class);
    private IsdProjectPojo mPojo;

    public ProjectHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        int iRow = 0;
        mPojo = new IsdProjectPojo();

        LOGGER.debug("ProjectHandler" + "_" + methodName + ": #: Start");

        while (pResults.next()) {
            iRow++;

            mPojo.setId(pResults.getString("projectid"));
            mPojo.setAnalyst(pResults.getString("analyst"));
            mPojo.setComments(pResults.getString("comments"));
            mPojo.setParentId(pResults.getString("parentprojectid"));
            mPojo.setPriority(pResults.getInt("priority"));
            mPojo.setName(pResults.getString("projectname"));
            mPojo.setStartTime(pResults.getTimestamp("startdatetimeitem"));
            mPojo.setStopTime(pResults.getTimestamp("stopdatetimeitem"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            LOGGER.debug("ProjectHandler" + "_" + methodName + ": #: " + iRow);
        }

        LOGGER.debug("ProjectHandler" + "_" + methodName + ": #: Stop");
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        ProjectCoalesce entity;

        IDataConverter<Project, ProjectCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(Project.class);

        Project pojo = converter.constructPojo();

        // pojo.setKey(mProjectPojo.getId());
        pojo.setProjectName(mPojo.getName() + migrationTag);
        pojo.setComments(mPojo.getComments());
        pojo.setPriority(mPojo.getPriority());
        pojo.setAnalyst(mPojo.getAnalyst());
        pojo.setProjectStartTime(mPojo.getStartTime());
        pojo.setProjectStopTime(mPojo.getStopTime());
        pojo.getDataObjectRecord().setCreatedBy(mPojo.getAnalyst());

        if (StringHelper.isNullOrEmpty(pojo.getProjectName())) {
            pojo.setProjectName("ETL_Test_Project-198(a)");
        }
        if (pojo.getProjectStartTime() == null) {
            pojo.setProjectStartTime(new Date());
        }
        if (pojo.getProjectStopTime() == null) {
            pojo.setProjectStopTime(new Date());
        }
        if (StringHelper.isNullOrEmpty(pojo.getAnalyst())) {
            pojo.setAnalyst("ETL_Test_Analyst(a)");
        }
        if (StringHelper.isNullOrEmpty(pojo.getComments())) {
            pojo.setComments("ETL_Test_Comments(a)");
        }
        if (pojo.getPriority() < 0) {
            pojo.setPriority(4);
        }
        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set other needed fields
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getStartTime()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        // DO NOTHING
    }

    @Override
    protected String getCreatedBy() {
        return mPojo.getAnalyst();
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.PROJECT;
    }
}
