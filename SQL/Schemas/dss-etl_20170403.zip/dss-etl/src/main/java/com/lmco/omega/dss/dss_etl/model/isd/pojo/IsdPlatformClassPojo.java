/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author n67154 - Gene Belford
 */
import java.util.Date;

public class IsdPlatformClassPojo {

    private String foreignUuId;
    private String classificationName;
    private String platformDesignator;
    private double displacement;
    private double length;
    private double maximumOperatingSpeed;
    private double maximumOperatingDepth;
    private int propellerCount;
    private String comment;
    private String reference;
    private String source;
    private Date updateTime;
    private IsdMandatorySecurityPojo security;

    /**
    *
    */
    public IsdPlatformClassPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the foreign uuid
     */
    public String getForeignUuId() {
        return foreignUuId;
    }

    /**
     * @param foreignUuId
     *            the id to set
     */
    public void setForeignUuId(String foreignUuId) {
        this.foreignUuId = foreignUuId;
    }

    /**
     * @return the classificationName
     */
    public String getClassificationName() {
        return classificationName;
    }

    /**
     * @param classificationName
     *            the classificationName to set
     */
    public void setClassificationName(String classificationName) {
        this.classificationName = classificationName;
    }

    /**
     * @return the platform designator
     */
    public String getPlatformDesignator() {
        return platformDesignator;
    }

    /**
     * @param platformDesignator
     *            the platform designator to set
     */
    public void setPlatformDesignator(String platformDesignator) {
        this.platformDesignator = platformDesignator;
    }

    /**
     * @return the displacement
     */
    public double getDisplacement() {
        return displacement;
    }

    /**
     * @param displacement
     *            the displacement to set
     */
    public void setDisplacement(double displacement) {
        this.displacement = displacement;
    }

    /**
     * @return the length
     */
    public double getLength() {
        return length;
    }

    /**
     * @param length
     *            the length to set
     */
    public void setLength(double length) {
        this.length = length;
    }

    /**
     * @return the maximumOperatingSpeed
     */
    public double getMaximumOperatingSpeed() {
        return maximumOperatingSpeed;
    }

    /**
     * @param maximumOperatingSpeed
     *            the maximumOperatingSpeed to set
     */
    public void setMaximumOperatingSpeed(double maximumOperatingSpeed) {
        this.maximumOperatingSpeed = maximumOperatingSpeed;
    }

    /**
     * @return the maximumOperatingDepth
     */
    public double getMaximumOperatingDepth() {
        return maximumOperatingDepth;
    }

    /**
     * @param maximumOperatingDepth
     *            the maximumOperatingDepth to set
     */
    public void setMaximumOperatingDepth(double maximumOperatingDepth) {
        this.maximumOperatingDepth = maximumOperatingDepth;
    }

    /**
     * @return the propellerCount
     */
    public int getPropellerCount() {
        return propellerCount;
    }

    /**
     * @param propellerCount
     *            the propellerCount to set
     */
    public void setPropellerCount(int propellerCount) {
        this.propellerCount = propellerCount;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the reference
     */
    public String getReference() {
        return reference;
    }

    /**
     * @param reference
     *            the reference to set
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * @param source
     *            the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * @return the updateTime
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     *            the updateTime to set
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

}
