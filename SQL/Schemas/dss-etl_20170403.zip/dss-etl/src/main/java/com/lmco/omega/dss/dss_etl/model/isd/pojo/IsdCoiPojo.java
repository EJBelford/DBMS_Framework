/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdCoiPojo {

    private String id;
    private Date startDtg;
    private Date endDtg;
    private String geoReferenceBroadArea;
    private String geoReferenceOobDispositionCo0;
    private String geoReferenceRefinedArea;
    private Double geoReferenceBoundingBoxX1;
    private Double geoReferenceBoundingBoxX2;
    private Double geoReferenceBoundingBoxY1;
    private Double geoReferenceBoundingBoxY2;
    private IsdMandatorySecurityPojo security;

    public IsdCoiPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the startDtg
     */
    public Date getStartDtg() {
        return startDtg;
    }

    /**
     * @param startDtg
     *            the startDtg to set
     */
    public void setStartDtg(Date startDtg) {
        this.startDtg = startDtg;
    }

    /**
     * @return the endDtg
     */
    public Date getEndDtg() {
        return endDtg;
    }

    /**
     * @param endDtg
     *            the endDtg to set
     */
    public void setEndDtg(Date endDtg) {
        this.endDtg = endDtg;
    }

    /**
     * @return the geoReferenceBroadArea
     */
    public String getGeoReferenceBroadArea() {
        return geoReferenceBroadArea;
    }

    /**
     * @param geoReferenceBroadArea
     *            the geoReferenceBroadArea to set
     */
    public void setGeoReferenceBroadArea(String geoReferenceBroadArea) {
        this.geoReferenceBroadArea = geoReferenceBroadArea;
    }

    /**
     * @return the geoReferenceOobDispositionCo0
     */
    public String getGeoReferenceOobDispositionCo0() {
        return geoReferenceOobDispositionCo0;
    }

    /**
     * @param geoReferenceOobDispositionCo0
     *            the geoReferenceOobDispositionCo0 to set
     */
    public void setGeoReferenceOobDispositionCo0(String geoReferenceOobDispositionCo0) {
        this.geoReferenceOobDispositionCo0 = geoReferenceOobDispositionCo0;
    }

    /**
     * @return the geoReferenceRefinedArea
     */
    public String getGeoReferenceRefinedArea() {
        return geoReferenceRefinedArea;
    }

    /**
     * @param geoReferenceRefinedArea
     *            the geoReferenceRefinedArea to set
     */
    public void setGeoReferenceRefinedArea(String geoReferenceRefinedArea) {
        this.geoReferenceRefinedArea = geoReferenceRefinedArea;
    }

    /**
     * @return the geoReferenceBoundingBoxX1
     */
    public Double getGeoReferenceBoundingBoxX1() {
        return geoReferenceBoundingBoxX1;
    }

    /**
     * @param geoReferenceBoundingBoxX1
     *            the geoReferenceBoundingBoxX1 to set
     */
    public void setGeoReferenceBoundingBoxX1(Double geoReferenceBoundingBoxX1) {
        this.geoReferenceBoundingBoxX1 = geoReferenceBoundingBoxX1;
    }

    /**
     * @return the geoReferenceBoundingBoxX2
     */
    public Double getGeoReferenceBoundingBoxX2() {
        return geoReferenceBoundingBoxX2;
    }

    /**
     * @param geoReferenceBoundingBoxX2
     *            the geoReferenceBoundingBoxX2 to set
     */
    public void setGeoReferenceBoundingBoxX2(Double geoReferenceBoundingBoxX2) {
        this.geoReferenceBoundingBoxX2 = geoReferenceBoundingBoxX2;
    }

    /**
     * @return the geoReferenceBoundingBoxY1
     */
    public Double getGeoReferenceBoundingBoxY1() {
        return geoReferenceBoundingBoxY1;
    }

    /**
     * @param geoReferenceBoundingBoxY1
     *            the geoReferenceBoundingBoxY1 to set
     */
    public void setGeoReferenceBoundingBoxY1(Double geoReferenceBoundingBoxY1) {
        this.geoReferenceBoundingBoxY1 = geoReferenceBoundingBoxY1;
    }

    /**
     * @return the geoReferenceBoundingBoxY2
     */
    public Double getGeoReferenceBoundingBoxY2() {
        return geoReferenceBoundingBoxY2;
    }

    /**
     * @param geoReferenceBoundingBoxY2
     *            the geoReferenceBoundingBoxY2 to set
     */
    public void setGeoReferenceBoundingBoxY2(Double geoReferenceBoundingBoxY2) {
        this.geoReferenceBoundingBoxY2 = geoReferenceBoundingBoxY2;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

}
