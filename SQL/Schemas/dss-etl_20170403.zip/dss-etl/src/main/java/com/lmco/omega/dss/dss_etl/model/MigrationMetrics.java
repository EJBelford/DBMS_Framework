/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.lmco.omega.dss.interfaces.common.EJobStatusType;

/**
 * @author bearyman
 */
public class MigrationMetrics {

    private String table;
    private int totalRecords;
    private int numSuccessfulMigrations;
    private int numPartialMigrations;
    private int numFailedMigrations;
    private List<MigrationResult> results;
    private EJobStatusType status;
    private String errorMsg;
    private Date startDate;
    private Date endDate;

    public MigrationMetrics(String pTable) {
        table = pTable;
        totalRecords = 0;
        numSuccessfulMigrations = 0;
        numFailedMigrations = 0;
        results = new ArrayList<>();
        status = EJobStatusType.COMPLETE;
        startDate = new Date();
        endDate = new Date();
    }

    public void addResult(MigrationResult pResult) {
        status = EJobStatusType.IN_PROGRESS;
        results.add(pResult);
        if (pResult.isSuccessful()) {
            numSuccessfulMigrations++;
        } else if (pResult.isSaveSuccessful()) {
            numPartialMigrations++;
        } else {
            numFailedMigrations++;
        }

        if (getTotalMigrationsExecuted() == totalRecords) {
            status = EJobStatusType.COMPLETE;
            endDate = new Date();
        }
    }

    public void setTable(String pTableName) {
        table = pTableName;
    }

    /**
     * @return the table
     */
    public String getTable() {
        return table;
    }

    /**
     * @return the totalRecords
     */
    public int getTotalRecords() {
        return totalRecords;
    }

    /**
     * @param totalRecords
     *            the totalRecords to set
     */
    public void setTotalRecords(int pTotalRecords) {
        totalRecords = pTotalRecords;
    }

    /**
     * @return the numSuccessfulMigrations
     */
    public int getNumSuccessfulMigrations() {
        return numSuccessfulMigrations;
    }

    /**
     * @return the numFailedMigrations
     */
    public int getNumFailedMigrations() {
        return numFailedMigrations;
    }

    /**
     * @return the results
     */
    public List<MigrationResult> getResults() {
        return results;
    }

    public int getTotalMigrationsExecuted() {
        return numSuccessfulMigrations + numFailedMigrations + numPartialMigrations;
    }

    public int getTotalMigrationsNotExectued() {
        return totalRecords - getTotalMigrationsExecuted();
    }

    public EJobStatusType getStatus() {
        return status;
    }

    /**
     * @return the errorMsg
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * @param errorMsg
     *            the errorMsg to set
     */
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public int getNumPartialMigrations() {
        return numPartialMigrations;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }
}
