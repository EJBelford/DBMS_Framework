/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.enums;

/**
 * @author bearyman
 */
public enum EIsdEnumerationNames {
    ACOUSTIC_MODE("acousticmode", null),
    AE_KEYING_INTERVAL_TYPE("aekeyingintervaltype", "aekeyingtype"),
    CATEGORY("category", "platformtype"),
    CAVITATION_MODE("cavitationmode", null),
    CAVITATION_TYPE("cavitationtype", null),
    CLASSIFICATION("classification", "platformclassname"),
    CONFIDENCE("confidence", null),
    CONTACT_SEGMENT_HOLD_STATUS("contactsegmentholdstatus", null),
    CONTACT_SOLUTION_CONFIDENCE("contactsolutionconfidence", "confidence"),
    COUNTRY("country", null),
    CV_ENUM_ISM_25X("cvenumism25x", null),
    CV_ENUM_ISM_CLASSIFICATION_US("cvenumismclassificationus", null),
    CV_ENUM_ISM_DISSEM("cvenumismdissem", null),
    CV_ENUM_ISM_FGI_OPEN("cvenumismfgiopen", null),
    CV_ENUM_ISM_FGI_PROTECTED("cvenumismfgiprotected", null),
    CV_ENUM_ISM_NON_IC("cvenumismnonic", null),
    CV_ENUM_ISM_OWNER_PRODUCER("cvenumismownerproducer", null),
    CV_ENUM_ISM_REL_TO("cvenumismrelto", null),
    CV_ENUM_ISM_SAR("cvenumismsar", null),
    CV_ENUM_ISM_SCI_CONTROLS("cvenumismscicontrols", null),
    CV_ENUM_ISM_SOURCE_MARKED("cvenumismsourcemarked", null),
    DEPTH_BAND("depthband", null),
    ENGINE_LOCATION("enginelocation", "componentlocation"),
    ENGINE_TYPE("enginetype", null),
    HOMING_TYPE("homingtype", null),
    MEDIA_MODE_TYPE("mediamodetype", null),
    OPERATING_PROFILE("operatingprofile", null),
    PARTICIPANT_ROLE("participantrole", null),
    PLATFORM_TYPE("platformtype", null),
    PROJECT_PRIORITY("projectpriority", null),
    PROPELLER_LOCATION("propellerlocation", "componentlocation"),
    PROPULSION_MODE("propulsionmode", null),
    PROPULSION_TYPE("propulsiontype", null),
    PULSE_TYPE("pulsetype", "transmissionmode"),
    SOUND_TYPE("soundtype", null),
    SOURCE_CATEGORY("sourcecategory", null),
    SOURCE_ORIGIN_NAME("sourceoriginname", null),
    SPEED_BAND("speedband", null),
    SPL_CAVITATION("splcavitation", "cavitationmode"),
    SPL_CLASS("splclass", "platformclassname"),
    SPL_COLLECTION_PLATFORM("splcollectionplatform", "platformtype"),
    SPL_COLLECTION_SENSOR("splcollectionsensor", null),
    SPL_COUNTRY("splcountry", "country"),
    SPL_DEPTH("spldepth", "depthband"),
    SPL_ENGINE_LOCATION("splenginelocation", "enginelocation"),
    SPL_ENGINE_TYPE("splenginetype", "enginetype"),
    SPL_PROPELLER_LOCATION("splpropellerlocation", "propellerlocation"),
    SPL_PROPULSION_MODE("splpropulsionmode", "propulsionmode"),
    SPL_TRANSIENT("spltransient", "propulsiontype"),
    SSIC("ssic", null),
    TARGET_FLIGHT_VARIANT("targetflightvariant", null),
    TRANSIENT_LEVEL("transientlevel", null),
    TYPE("type", null),
    WAVEFORM("waveform", null),
    WEAPON_ACTIVITY("weaponactivity", null),
    WEAPON_MODE("weaponmode", null),

    // SPECIAL CASE
    COLLECTOR("collector", null);

    private String isdTableName;
    private String fsdTableName;

    private EIsdEnumerationNames(String pIsdTableName, String pFsdTableName) {
        isdTableName = pIsdTableName;
        fsdTableName = pFsdTableName;
    }

    public String getIsdTableName() {
        return isdTableName;
    }

    public String getFsdTableName() {
        if (fsdTableName == null) {
            fsdTableName = isdTableName;
        }
        return fsdTableName;
    }
}
