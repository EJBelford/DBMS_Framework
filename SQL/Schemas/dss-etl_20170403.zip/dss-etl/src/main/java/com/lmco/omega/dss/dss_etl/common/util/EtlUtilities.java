/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;

/**
 * <p>
 * -+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8 Module Name:
 * etl_utilities Author:..... Gene Belford /n67154 Description: A collection of useful processes.
 * Date:....... 2016-03-01 Source File: etl_utilities.java
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8 Change History
 * ============== Date...... Chng_Ctrl Name................ Description ========== =========
 * ==================== ============================= 2016-03-02 ......... Gene Belford........
 * Created 2016-03-02 ......... Gene Belford........ getDebugFlag - returns the integer flag for the
 * requested module. Can be used to turn on/off debugging in compiled applications. The default is 0
 * if a bad key is passed in. 2016-03-02 ......... Gene Belford........ getDebugValue - returns a
 * value for the requested module. Can be used be used to set parameters to reduce the amount of
 * data processed. An example would be setting the return on a SELECT to 5 records instead of ALL
 * records. 2016-03-03 ......... Gene Belford........ getEtlConfigValue - returns a configuration
 * value for the requested parameter.
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 */

public class EtlUtilities {

    // static String pathname = ""; // Use this for the workstation
    private static final String PATH = System.getenv("DSS_CONFIG_LOCATION") + File.separator;
    private static final String CONFIG_FILENAME = "etlConfig.properties";
    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlUtilities.class);

    /**
     * <h1>getEtlConfigValue</h1>
     * <p>
     * Returns a configuration value for the requested parameter.
     *
     * @param configVar
     * @return value
     * @since 2016-03-03
     * @author Gene Belford - n67154
     */

    public static String getEtlConfigValue(String configVar) {

        String processModule = "getEtlConfigValue";

        // InputStream configValues;
        Properties prop = new Properties();

        try {
            InputStream input = new FileInputStream(PATH + CONFIG_FILENAME);
            prop.load(input);
            input.close();
        } catch (IOException e0) {
            LOGGER.error(e0.getMessage(), e0);
        }

        String value = prop.getProperty(configVar);

        LOGGER.debug("DEBUG_0 Java: " + processModule + ": configVar: " + configVar + " Value: "
                + value);

        return value;
    }
}
