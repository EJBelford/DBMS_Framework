/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.wss4j.common.ext.WSSecurityException;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.configuration.DSSSettings;
import com.lmco.omega.dss.common.model.enums.EStorageTierTrack;
import com.lmco.omega.dss.common.util.FileUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.enums.EIsdFileDescriptiveMetadataTypes;
import com.lmco.omega.dss.dss_etl.factory.DBConnectionPoolFactory;
import com.lmco.omega.dss.dss_etl.interfaces.IDBConnectionPool;

/**
 * @author n67154
 */
public final class EtlUtilitiesDbms {

    private static final String processName = "EtlUtilitiesDbms";
    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlUtilitiesDbms.class);

    /**
     * <h1>getISDConnection</h1>
     * <p>
     * Add description
     *
     * @param arg
     *            not used
     * @return dbConnection
     * @since 2016-03-02
     * @author Gene Belford - n67154
     * @throws SQLException
     */

    public static Connection getISDConnection() throws SQLException, IllegalStateException {

        String processModule = "getISDConnection";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + ": " + processModule + ": Starting run");

        IDBConnectionPool pool = new DBConnectionPoolFactory().getIsdConnectionPool();

        return pool.getConnection();
    }

    /**
     * <h1>getFSDConnection</h1>
     * <p>
     * Add description
     *
     * @param arg
     *            not used
     * @return Connection
     * @since 2016-03-02
     * @author Gene Belford - n67154
     * @throws SQLException
     */

    public static Connection getFSDConnection() throws SQLException, IllegalStateException {

        String processModule = "getFSDConnection";

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.trace("DEBUG_0 SQL:  " + processName + ": " + processModule + ": Starting run");

        IDBConnectionPool pool = new DBConnectionPoolFactory().getFsdConnectionPool();

        return pool.getConnection();
    }

    /**
     * <h1>getStmt</h1>
     * <p>
     * Add description
     *
     * @param connISD
     *            The connection will be used with.
     * @return Statement
     * @since 2016-03-02
     * @author Gene Belford - n67154
     * @throws SQLException
     */

    public static Statement getStmt(Connection connISD) throws SQLException {

        String processModule = "getStmt";

        Statement stmt = null;

        LOGGER.debug("DEBUG_0 SQL:  " + processName + "_" + processModule);

        stmt = connISD.createStatement();

        return stmt;

    }

    /**
     * <h1>getDBInfo</h1>
     * <p>
     * Returns information about the database being accessed, (Server, DB, Schema, User).
     *
     * @param connISD
     *            The connection will be used with.
     * @param connStmt
     *            The SQL statement to be executed.
     * @return ResultSet
     * @since 2016-03-02
     * @author Gene Belford - n67154
     * @throws SQLException
     */

    public static ResultSet getDBInfo(Connection connISD, Statement connStmt) throws SQLException {

        String processModule = "getDBInfo";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        ResultSet connResults = null;

        connResults =
                connStmt.executeQuery("SELECT 'Server: ' || INET_SERVER_ADDR()::VARCHAR "
                        + "|| ' DB: ' || CURRENT_DATABASE() "
                        + "|| ' Schema: ' || CURRENT_SCHEMA() " + "|| ' User: ' || CURRENT_USER; ");

        if (connResults.next()) {
            LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": " + connResults.getString(1));
        }

        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": 'version()' was successful");

        return connResults;
    }

    /**
     * <h1>getDBVersion</h1>
     * <p>
     * Returns version of the database being accessed.
     *
     * @param connISD
     *            The connection will be used with.
     * @param connStmt
     *            The SQL statement to be executed.
     * @return ResultSet
     * @since 2016-03-02
     * @author Gene Belford - n67154
     * @throws SQLException
     */

    public static ResultSet getDBVersion(Connection connISD, Statement connStmt)
            throws SQLException {

        String processModule = "getDBVersion";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        ResultSet connResults = null;

        connResults = connStmt.executeQuery("SELECT VERSION();");

        if (connResults.next()) {
            LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": " + connResults.getString(1));
        }

        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": 'version()' was successful");

        return connResults;
    }

    /**
     * <h1>processLogInit</h1>
     * <p>
     *
     * @param connISD
     * @param logAction
     * @param logMessage
     * @return
     * @throws SQLException
     */

    public static int processLogInit(Connection connISD, String logAction, String logMessage)
            throws SQLException {

        String processModule = "processLogInit";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        int recId = 0;
        CallableStatement pCallStmt = null;

        pCallStmt =
                connISD.prepareCall("{ ? = call migrate_isd2fsd.f_etl_process_log_updt( "
                        + "?, NULL, NULL, 0, 0, 0, 0, CLOCK_TIMESTAMP(), "
                        + "NULL, NULL, NULL, '', 0, 0, 0, 0, 0, 0, 0, 0, '', ?, '' ) }");

        pCallStmt.registerOutParameter(1, Types.INTEGER);
        pCallStmt.setString(2, logAction);
        pCallStmt.setString(3, logMessage);
        LOGGER.debug("DEBUG_1 Java: " + processModule + ": " + pCallStmt);

        pCallStmt.execute();

        recId = pCallStmt.getInt(1);
        LOGGER.debug("DEBUG_1 SQL:  " + processModule + ": Results: " + recId);

        return recId;
    }

    /**
     * <h1>processLogUpdate</h1>
     * <p>
     *
     * @param connISD
     * @param recId
     * @param logAction
     * @param recUpdated
     * @param logMessage
     * @return
     * @throws SQLException
     */

    public static int processLogUpdate(Connection connISD, int recId, String logAction,
            int recUpdated, String logMessage) throws SQLException {

        String processModule = "processLogUpdate";

        CallableStatement pCallStmt = null;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        pCallStmt =
                connISD.prepareCall("{ ? = call migrate_isd2fsd.f_etl_process_log_updt( "
                        + "?, ?, NULL, 0, 0, 0, 0, CLOCK_TIMESTAMP(), "
                        + "NULL, NULL, NULL, '', 0, 0, 0, 0, 0, 0, ?, 0, '', ?, '' ) }");

        pCallStmt.registerOutParameter(1, Types.INTEGER);
        pCallStmt.setString(2, logAction);
        pCallStmt.setInt(3, recId);
        pCallStmt.setInt(4, recUpdated);
        pCallStmt.setString(5, logMessage);
        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + pCallStmt);

        pCallStmt.execute();

        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + recId);

        return recId;
    }

    /**
     * <h1>processDebugUpdat</h1>
     * <p>
     *
     * @param connISD
     * @param process_name
     * @param module_name
     * @param error_code
     * @param error_message
     * @param parameters
     * @param insert_by
     * @return
     * @throws SQLException
     */

    public static int processDebugUpdate(Connection connISD, String process_name,
            String module_name, String error_code, String error_message, String parameters,
            String insert_by) throws SQLException {

        String processModule = "processDebugUpdate";

        CallableStatement pCallStmt = null;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        pCallStmt =
                connISD.prepareCall("{ ? = call migrate_isd2fsd.f_etl_std_debug( "
                        + "CLOCK_TIMESTAMP(), ?,  ?, ?,  ?, ?, ?) }");

        pCallStmt.registerOutParameter(1, Types.INTEGER);
        pCallStmt.setString(2, process_name);
        pCallStmt.setString(3, module_name);
        pCallStmt.setString(4, error_code);
        pCallStmt.setString(5, error_message);
        pCallStmt.setString(6, parameters);
        pCallStmt.setString(7, insert_by);
        LOGGER.debug("DEBUG_1 SQL:  " + processModule + ": " + pCallStmt);

        pCallStmt.execute();
        return 0;
    }

    /**
     * <h1>processFuncWarnInsert</h1>
     * <p>
     *
     * @throws SQLException
     */

    public static int processFuncWarnInsert(String process_name, String module_name,
            String error_code, String error_message, String parameters) throws SQLException,
            IllegalStateException {

        String processModule = "processFuncWarnInsert";

        Connection conn = null;

        CallableStatement pCallStmt = null;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        conn = getFSDConnection();

        LOGGER.debug("DEBUG_0 SQL:  " + " conn: " + conn);

        LOGGER.debug("DEBUG_0 SQL:  " + processName + "_" + processModule + ": Prepare Call");

        pCallStmt =
                conn.prepareCall("{ ? = call migrate_isd2fsd.f_etl_func_warn_log_insert( "
                        + "?, ?, ?, ?) }");

        String p_warning_from = process_name + "_" + module_name;

        pCallStmt.registerOutParameter(1, Types.INTEGER);
        pCallStmt.setString(2, error_code);
        pCallStmt.setString(3, p_warning_from);
        pCallStmt.setString(4, error_message);
        pCallStmt.setString(5, "C");

        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": " + pCallStmt);

        pCallStmt.execute();
        pCallStmt.close();
        conn.close();

        return 0;
    }

    /**
     * <h1>closeConn</h1>
     * <p>
     * closeConn
     *
     * @param connISD
     * @param connStmt
     * @param connResults
     * @throws SQLException
     */

    public static void closeConn(Connection connISD, Statement connStmt, ResultSet connResults)
            throws SQLException {

        String processModule = "closeConn";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        /*
         * if (pStatement != null) {
         * pStatement.close();
         * }
         */
        if (connResults != null) {
            connResults.close();
        }
        /*
         * if (cStmt != null) {
         * cStmt.close();
         * }
         */
        if (connStmt != null) {
            connStmt.close();
        }
        if (connISD != null) {
            connISD.close();
        }
        LOGGER.debug("Connection closed");

        LOGGER.debug("DEBUG_0 Java: " + processModule + ": Closed DBMS connections successfully");

    }

    /**
     * <h1>closeConn</h1>
     * <p>
     * Closes a SQL ResultSet and catches + logs any resulting exceptions.
     *
     * @param rs
     * @throws SQLException
     */

    public static void closeConn(final ResultSet rs) throws SQLException {

        String processModule = "closeConn";

        if (rs != null && !rs.isClosed()) {
            rs.close();
        }
        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Closed");
    }

    /**
     * <h1>closeConn</h1>
     * <p>
     * Closes a SQL PreparedStatement and catches + logs any resulting exceptions.
     *
     * @param ps
     * @throws SQLException
     */

    public static void closeConn(final PreparedStatement ps) throws SQLException {

        String processModule = "closeConn";

        if (ps != null && !ps.isClosed()) {
            ps.close();
            LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Closed");
        }

    }

    /**
     * <h1>closeConn</h1>
     * <p>
     * Closes a SQL Connection and catches + logs any resulting exceptions.
     *
     * @param c
     * @throws SQLException
     */

    public static void closeConn(final Connection c) throws SQLException {

        String processModule = "closeConn";

        if (c != null) {
            c.close();
            LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Closed");
        }
    }

    /**
     * <h1>closeConn</h1>
     * <p>
     * Closes a SQL Statement and catches + logs any resulting exceptions.
     *
     * @param s
     * @throws SQLException
     */

    public static void closeConn(final Statement s) throws SQLException {

        String processModule = "closeConn";

        if (s != null) {
            s.close();
            LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Closed");
        }
    }

    /**
     * <h1>insertClearList</h1>
     * <p>
     *
     * @param connFSD
     * @param p_projectId
     * @param processName2
     * @param processModule
     * @throws SQLException
     */

    public static void insertClearList(Connection connFSD, String entityId, String processName2,
            String processModule2) throws SQLException {

        String processModule = "insertClearList";

        CallableStatement pCallStmt = null;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        pCallStmt =
                connFSD.prepareCall("{ ? = call migrate_isd2fsd.f_etl_clear_list_insert( "
                        + "?::uuid, ?, ?) }");

        pCallStmt.registerOutParameter(1, Types.INTEGER);
        pCallStmt.setString(2, entityId);
        pCallStmt.setString(3, processName2);
        pCallStmt.setString(4, processModule2);

        LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": " + pCallStmt);

        pCallStmt.execute();
    }

    /**
     * <h1>deleteClearList</h1>
     * <p>
     *
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws WSSecurityException
     * @throws RemoteException
     */

    public static Integer deleteClearList() throws SQLException {

        String processModule = "deleteClearList";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        boolean deleteAllFiles = false;
        String deleteFlag = EtlUtilities.getEtlConfigValue("deleteAllFiles").toLowerCase();
        if (!StringHelper.isNullOrEmpty(deleteFlag) && deleteFlag.equals("true")) {
            deleteAllFiles = true;
        }

        LOGGER.debug("Delete all files: " + deleteAllFiles);

        Connection conn = null;
        Statement stmt = null;

        ResultSet recResults = null;
        Integer rowsDeleted = 0;

        // String filePath = null;
        // String track = null;
        // EStorageTierTrack eTrack = null;

        if (deleteAllFiles) {
            conn = EtlUtilitiesDbms.getISDConnection();
            stmt = EtlUtilitiesDbms.getStmt(conn);

            recResults =
                    stmt.executeQuery("SELECT filedescriptivemetadataid from omega.filedescriptivemetadata");

            while (recResults.next()) {
                String fileId = recResults.getString(1);
                deleteFile(fileId);
            }
            closeConn(conn);
        } else {
            conn = EtlUtilitiesDbms.getFSDConnection();
            stmt = EtlUtilitiesDbms.getStmt(conn);

            recResults =
                    stmt.executeQuery("SELECT object_uuid, process_name"
                            + " FROM migrate_isd2fsd.etl_clear_list");

            while (recResults.next()) {
                String fileId = recResults.getString("object_uuid");
                String tableName = recResults.getString("process_name");

                for (EIsdFileDescriptiveMetadataTypes type: EIsdFileDescriptiveMetadataTypes
                        .values()) {
                    if (tableName.equals(type.toString())) {
                        deleteFile(fileId);
                    }
                }
            }
            closeConn(conn);
        }

        conn = EtlUtilitiesDbms.getFSDConnection();
        stmt = EtlUtilitiesDbms.getStmt(conn);

        LOGGER.debug("Executing cleanup script...");
        recResults =
                stmt.executeQuery("SELECT migrate_isd2fsd.etl_isd2fsd_cleanup "
                        + "('00000000-0000-0000-0000-000000000000')");
        LOGGER.debug("Clean up scipt complete");

        /*
         * Get the number of rows deleted by the call above.
         */

        while (recResults.next()) {
            rowsDeleted = recResults.getInt(1);
        }

        closeConn(conn);

        return rowsDeleted;
    }

    private static void deleteFile(String pFileId) {
        LOGGER.debug("Deleting files...");
        // Delete file
        StringBuilder path = null;
        try {

            for (EGpfsStorageTiers tier: EGpfsStorageTiers.values()) {

                path =
                        new StringBuilder(tier.getDirectory())
                                .append(FileUtil.getSubDirectory(UUID.fromString(pFileId)))
                                .append(File.separator).append(pFileId).append(File.separator);

                File file = new File(path.toString());

                if (file.exists()) {
                    FileUtils.deleteDirectory(file);
                    LOGGER.debug("File " + pFileId + " deleted successfully");
                    break;
                }
            }
        } catch (IOException e) {
            LOGGER.error(String.format(DSSConstants.DELETE_FILE_FAILED, path.toString()));
        }
    }

    /**
     * <h1>deleteProcessLog</h1>
     * <p>
     *
     * @throws SQLException
     */

    public static Integer deleteProcessLog() throws SQLException {

        String processModule = "deleteProcessLog";

        String pSchema = "migrate_isd2fsd";
        String pTable = "etl_process_log";

        Connection connFSD = null;
        Statement connFsdStmt = null;
        String v_stmt = null;

        Integer rowsDeleted = 0;

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        // Get the amount of data to be retained

        String etlProcessLogPeriod =
                EtlUtilities.getEtlConfigValue(processName + "_" + processModule
                        + "_etlProcessLogPeriod");

        String etlProcessLogPeriodType =
                EtlUtilities.getEtlConfigValue(processName + "_" + processModule
                        + "_etlProcessLogPeriodType");

        LOGGER.debug("etlProcessLogPeriod: " + etlProcessLogPeriod);
        LOGGER.debug("etlProcessLogPeriodType: " + etlProcessLogPeriodType);

        // Delete the ETL process log records

        connFSD = EtlUtilitiesDbms.getFSDConnection();
        connFsdStmt = EtlUtilitiesDbms.getStmt(connFSD);

        v_stmt =
                "DELETE FROM " + pSchema + "." + pTable + " "
                        + "WHERE process_start < (NOW() - INTERVAL '" + etlProcessLogPeriod + " "
                        + etlProcessLogPeriodType + "')" + "; ";

        connFsdStmt.executeUpdate(v_stmt);

        closeConn(connFsdStmt);
        closeConn(connFSD);

        return rowsDeleted;
    }

    /**
     * <h1>getCaseUuid</h1>
     * <p>
     *
     * @throws SQLException
     */

    public static String getCaseUuid(String oniCaseId) throws SQLException {

        String processModule = "getCaseUuid";

        LOGGER.trace(processName + "_" + processModule);

        LOGGER.debug("DEBUG_0 SQL:  " + processName + ": " + processModule + ": oniCaseId: "
                + oniCaseId);

        Connection connFSD = null;
        Statement connFSDStmt = null;

        ResultSet recResults = null;

        String caseId = null;

        connFSD = EtlUtilitiesDbms.getFSDConnection();

        if (connFSD != null) {
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);
        }

        recResults =
                connFSDStmt.executeQuery("SELECT entitykey " + "FROM coalesce.case_recordset "
                        + "WHERE LOWER('" + oniCaseId + "') = LOWER(onicasenumber) " + "; ");

        while (recResults.next()) {
            caseId = recResults.getString(1);
        }

        LOGGER.debug("DEBUG_0 Java: " + processName + ": " + processModule + ": CaseId: " + caseId);

        connFSDStmt.close();

        connFSD.close();

        return caseId;
    }

    /**
     * <h1>updateClearList</h1>
     * <p>
     *
     * @param connFSD
     * @param entityId
     * @param processName2
     * @param processModule
     * @throws SQLException
     */

    public static void updateClearList(Connection connFSD, String pEntityId,
            String pTargetFilePath, EStorageTierTrack pTrack) throws SQLException {

        String processModule = "updateClearList";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + "_" + processModule);

        Statement connFsdStmt = null;

        String v_stmt = null;

        connFsdStmt = EtlUtilitiesDbms.getStmt(connFSD);

        v_stmt =
                "UPDATE migrate_isd2fsd.etl_clear_list " + " SET filepath = '" + pTargetFilePath
                        + "', track = '" + pTrack + "' WHERE object_uuid = '" + pEntityId
                        + "'::uuid; ";

        connFsdStmt.executeUpdate(v_stmt);

        connFsdStmt.close();
    }

    /**
     * <h1>processFactUpdate</h1>
     * <p>
     *
     * @param connFSD
     * @param pTable
     * @param pTable
     * @param pEntityCnt
     * @param pLikageCnt
     * @throws SQLException
     */

    public static void processFactUpdate(Connection connFSD, String pSchema, String pTable,
            Integer pEntityCnt, Integer pLikageCnt) throws SQLException {

        Statement connFsdStmt1 = null;

        String v_stmt = null;

        connFsdStmt1 = EtlUtilitiesDbms.getStmt(connFSD);

        v_stmt =
                "UPDATE migrate_isd2fsd.isd_db_object_facts " + " SET etl_entity_cnt = "
                        + pEntityCnt + ", etl_linkage_cnt = " + pLikageCnt + ", "
                        + "last_updated = NOW() " + "WHERE LOWER(schemaname) = LOWER('" + pSchema
                        + "') AND LOWER(relname) = LOWER('" + pTable + "'); ";

        connFsdStmt1.executeUpdate(v_stmt);

        connFsdStmt1.close();
    }

    /**
     * <h1>processEntLnkCnt</h1>
     * <p>
     *
     * @param connFSD
     * @param pSchema
     * @param pTable
     * @throws SQLException
     */

    public static int processFactEntCnt(Connection connFSD, String pSchema, String pTable)
            throws SQLException {

        String processModule = "processFactEntCnt";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + ": " + processModule + ": pSchema: "
                + pSchema + ": pTable: " + pTable);

        Statement connFSDStmt = null;

        ResultSet recResults = null;

        int etlCnt = 0;

        connFSD = EtlUtilitiesDbms.getFSDConnection();

        if (connFSD != null) {
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);
        }

        recResults =
                connFSDStmt.executeQuery("SELECT etl_entity_cnt "
                        + "FROM migrate_isd2fsd.isd_db_object_facts "
                        + "WHERE LOWER(schemaname) = LOWER('" + pSchema
                        + "') AND LOWER(relname) = LOWER('" + pTable + "'); ");

        while (recResults.next()) {
            etlCnt = recResults.getInt(1);
        }

        LOGGER.debug("DEBUG_0 SQL:  " + processName + ": " + processModule + ": CaseId: " + etlCnt);

        connFSDStmt.close();

        connFSD.close();

        return etlCnt;
    }

    /**
     * <h1>processFactLnkCnt</h1>
     * <p>
     *
     * @param connFSD
     * @param pSchema
     * @param pTable
     * @throws SQLException
     */

    public static int processFactLnkCnt(Connection connFSD, String pSchema, String pTable)
            throws SQLException {

        String processModule = "processFactLnkCnt";

        LOGGER.trace("DEBUG_0 SQL:  " + processName + ": " + processModule + ": pSchema: "
                + pSchema + ": pTable: " + pTable);

        Statement connFSDStmt = null;

        ResultSet recResults = null;

        int etlCnt = 0;

        connFSD = EtlUtilitiesDbms.getFSDConnection();

        if (connFSD != null) {
            connFSDStmt = EtlUtilitiesDbms.getStmt(connFSD);
        }

        recResults =
                connFSDStmt.executeQuery("SELECT etl_linkage_cnt "
                        + "FROM migrate_isd2fsd.isd_db_object_facts "
                        + "WHERE LOWER(schemaname) = LOWER('" + pSchema
                        + "') AND LOWER(relname) = LOWER('" + pTable + "'); ");

        while (recResults.next()) {
            etlCnt = recResults.getInt(1);
        }

        LOGGER.debug("DEBUG_0 SQL:  " + processName + ": " + processModule + ": CaseId: " + etlCnt);

        connFSDStmt.close();

        connFSD.close();

        return etlCnt;
    }

    private enum EGpfsStorageTiers {
        GPFS_ONLINE(DSSSettings.getGpfsOnlineDirectory()),
        GPFS_NEAR_ONLINE(DSSSettings.getGpfsNearOnlineDirectory()),
        GPFS_OFFLINE(DSSSettings.getGpfsOfflineDirectory());

        private String directory;

        private EGpfsStorageTiers(String pDirectory) {
            directory = pDirectory;
        }

        public String getDirectory() {
            return directory;
        }
    }

    public static int validateIsdEnums() throws SQLException {
        final String GET_IDS_REFERENCES =
                "SELECT tc.constraint_name, " + "tc.constraint_type, " + "tc.table_name "
                        + ", kcu.column_name " + ", ccu.table_name AS ref_table "
                        + ", ccu.column_name AS ref_column "
                        + "FROM information_schema.table_constraints tc "
                        + "LEFT OUTER JOIN information_schema.key_column_usage kcu "
                        + "ON tc.constraint_catalog = kcu.constraint_catalog "
                        + "AND tc.constraint_schema = kcu.constraint_schema "
                        + "AND tc.constraint_name = kcu.constraint_name "
                        + "LEFT OUTER JOIN information_schema.referential_constraints rc "
                        + "ON tc.constraint_catalog = rc.constraint_catalog "
                        + "AND tc.constraint_schema = rc.constraint_schema "
                        + "AND tc.constraint_name = rc.constraint_name "
                        + "LEFT OUTER JOIN information_schema.constraint_column_usage ccu "
                        + "ON rc.constraint_catalog = ccu.constraint_catalog "
                        + "AND rc.constraint_schema = ccu.constraint_schema "
                        + "AND rc.constraint_name = ccu.constraint_name "
                        + "WHERE tc.table_schema = 'omega' "
                        + "AND constraint_type = 'FOREIGN KEY' "
                        + "AND ccu.column_name = 'enumvalues' " + "ORDER BY tc.table_name, "
                        + "ccu.table_name;";

        final String GET_ISD_DISTINCT_ENUMS =
                "SELECT DISTINCT t1.%s AS isdenumvalue FROM omega.%s t1 ORDER BY t1.%s;";

        final String VALIDATE_ISD_ENUM =
                "SELECT COUNT(ev.enumvalue) FROM coalesce.enumvalue ev "
                        + "WHERE ev.enumtype = '%s' AND ev.enumvalue = '%s';";

        Connection connIsd = null;
        Statement stmtIsd1 = null;
        ResultSet isdReferResults = null;
        Statement stmtIsd2 = null;
        ResultSet isdDistEnumResults = null;

        Connection connFsd = null;
        Statement stmtFsd1 = null;
        ResultSet fsdValidEnumResults = null;

        try {
            connIsd = getISDConnection();
            connFsd = getFSDConnection();
            if (connIsd != null && connFsd != null) {

                stmtIsd1 = connIsd.createStatement();
                stmtIsd2 = connIsd.createStatement();

                stmtFsd1 = connFsd.createStatement();

                if (stmtIsd1 != null) {

                    isdReferResults = stmtIsd1.executeQuery(String.format(GET_IDS_REFERENCES));

                    while (isdReferResults.next()) {
                        if (!StringHelper.isNullOrEmpty(isdReferResults.getString(1))) {
                            LOGGER.debug(isdReferResults.getString(1)
                                    + " "
                                    // + isdReferResults.getString(2) + " "
                                    + isdReferResults.getString(3) + " "
                                    + isdReferResults.getString(4) + " "
                                    + isdReferResults.getString(5) + " "
                            // + isdReferResults.getString(6)
                            );

                            if (stmtIsd2 != null) {
                                isdDistEnumResults =
                                        stmtIsd2.executeQuery(String.format(GET_ISD_DISTINCT_ENUMS,
                                                                            isdReferResults
                                                                                    .getString(4),
                                                                            isdReferResults
                                                                                    .getString(3),
                                                                            isdReferResults
                                                                                    .getString(4)));

                                while (isdDistEnumResults.next()) {
                                    if (!StringHelper
                                            .isNullOrEmpty(isdDistEnumResults.getString(1))) {

                                        String pEnumType =
                                                isdEnumTable2FsdEnumTable(isdReferResults
                                                        .getString(5));
                                        String pEnumValue = isdDistEnumResults.getString(1);

                                        switch (pEnumType) {
                                            case "platformtype":
                                                pEnumValue = parseIsdEnumValue(pEnumValue);
                                        }

                                        pEnumValue =
                                                transformIsdEnumValue(isdDistEnumResults
                                                        .getString(1));

                                        LOGGER.debug(pEnumType + " - " + pEnumValue);

                                        fsdValidEnumResults =
                                                stmtFsd1.executeQuery(String
                                                        .format(VALIDATE_ISD_ENUM, pEnumType,
                                                                pEnumValue));

                                        while (fsdValidEnumResults.next()) {
                                            if (!StringHelper.isNullOrEmpty(fsdValidEnumResults
                                                    .getString(1))) {
                                                LOGGER.debug(fsdValidEnumResults.getString(1));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    String pEnumType = "platformtype";
                    LOGGER.debug("");
                    LOGGER.debug("====== " + pEnumType + " ======");
                    LOGGER.debug("");
                    isdDistEnumResults =
                            stmtIsd2.executeQuery(String.format(GET_ISD_DISTINCT_ENUMS,
                                                                "enumvalues", pEnumType,
                                                                "enumvalues"));

                    while (isdDistEnumResults.next()) {
                        if (!StringHelper.isNullOrEmpty(isdDistEnumResults.getString(1))) {

                            String pEnumValue = isdDistEnumResults.getString(1);

                            pEnumValue = parseIsdEnumValue(pEnumValue);

                            pEnumValue = transformIsdEnumValue(pEnumValue);

                            fsdValidEnumResults =
                                    stmtFsd1.executeQuery(String.format(VALIDATE_ISD_ENUM,
                                                                        pEnumType, pEnumValue));

                            while (fsdValidEnumResults.next()) {
                                if (!StringHelper.isNullOrEmpty(fsdValidEnumResults.getString(1))) {
                                    LOGGER.debug(pEnumType + " - " + pEnumValue + " - "
                                            + fsdValidEnumResults.getString(1));
                                }
                            }
                        }
                    }
                }
            }
        } finally {
            if (stmtIsd1 != null) {
                stmtIsd1.close();
            }
            if (stmtIsd2 != null) {
                stmtIsd2.close();
            }
            if (stmtFsd1 != null) {
                stmtFsd1.close();
            }
            if (connIsd != null) {
                closeConn(connIsd);
            }
            if (connFsd != null) {
                closeConn(connFsd);
            }
        }
        return 0;
    }

    /*
     * Map ISD enum table name to FSD enumtype
     */

    public static String isdEnumTable2FsdEnumTable(String pIsdEnumTable) {
        String pFsdEnumTable = null;

        switch (pIsdEnumTable) {
            case "aekeyingintervaltype":
                pFsdEnumTable = "aekeyingtype";
                break;
            case "category":
            case "refinedcategory":
            case "refinedtype":
                pFsdEnumTable = "platformtype";
                break;
            case "classification":
            case "refinedclassification":
                pFsdEnumTable = "platformclassname";
                break;
            case "contactcolutionconfidence":
                pFsdEnumTable = "confidence";
                break;
            case "enginelocation":
            case "propellerlocation":
                pFsdEnumTable = "componentlocation";
                break;
            case "producecountry":
            case "refinedcountry":
                pFsdEnumTable = "country";
                break;
            case "pulsetype":
                pFsdEnumTable = "transmissionmode";
                break;
            case "refinedtargetflightvariant":
                pFsdEnumTable = "targetflightvariant";
                break;
            default:
                pFsdEnumTable = pIsdEnumTable;
        }

        return pFsdEnumTable;
    }

    /*
     * Transform ISD enumeration value to FSD enumeration value
     */

    public static String transformIsdEnumValue(String pIsdEnumValue) {
        String methodName = "transfromIsdEnumValue";

        String pFsdEnumValue = null;

        if (!StringHelper.isNullOrEmpty(pIsdEnumValue)) {

            pFsdEnumValue = pIsdEnumValue.trim();

            pFsdEnumValue = pFsdEnumValue.replace(" ", "_");
            pFsdEnumValue = pFsdEnumValue.replace("-", "_");
            pFsdEnumValue = pFsdEnumValue.replace(",", "_");
            pFsdEnumValue = pFsdEnumValue.replace(".", "_");
            pFsdEnumValue = pFsdEnumValue.replace("&", "_");
            pFsdEnumValue = pFsdEnumValue.replace("/", "_");
            pFsdEnumValue = pFsdEnumValue.replace(":", "_");
            pFsdEnumValue = pFsdEnumValue.replace("*", "_");

            pFsdEnumValue = pFsdEnumValue.replace("(", "");
            pFsdEnumValue = pFsdEnumValue.replace(")", "");

            pFsdEnumValue = pFsdEnumValue.replace("_____", "_");
            pFsdEnumValue = pFsdEnumValue.replace("____", "_");
            pFsdEnumValue = pFsdEnumValue.replace("___", "_");
            pFsdEnumValue = pFsdEnumValue.replace("__", "_");
            pFsdEnumValue = pFsdEnumValue.replace("__", "_");

            pFsdEnumValue = pFsdEnumValue.toUpperCase();

        }

        return pFsdEnumValue;
    }

    /*
     * Parse ISD enumeration value
     */

    public static String parseIsdEnumValue(String pIsdEnumValue) {
        String methodName = "parseIsdEnumValue";

        String pFsdEnumValue = null;

        if (!StringHelper.isNullOrEmpty(pIsdEnumValue)) {

            pFsdEnumValue = pIsdEnumValue.trim();

            int strPos = 0;

            // UPPER(SUBSTR(TRIM(enumvalues), 1, STRPOS(TRIM(enumvalues), ' ')-1))
            strPos = pFsdEnumValue.indexOf(" ");

            if (strPos > 0) {
                pFsdEnumValue = pFsdEnumValue.substring(0, strPos);
            }

            pFsdEnumValue = pFsdEnumValue.toUpperCase();
        }

        return pFsdEnumValue;
    }
}
