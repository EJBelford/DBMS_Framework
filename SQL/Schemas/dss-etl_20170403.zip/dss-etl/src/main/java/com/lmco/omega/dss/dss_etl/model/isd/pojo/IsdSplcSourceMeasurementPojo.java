/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdSplcSourceMeasurementPojo {

    private int id;
    private long contactMeasurementId;
    private Double harmonic;
    private Double measuredFrequency;
    private Double processAccuracy;
    private Double processBandwidth;
    private Double processIntegrationTime;
    private Double processResolution;
    private Integer propLossMethod;
    private String propLossMethodName;
    private String sourceDescription;
    private long sourceDescriptionId;
    private long sourceMeasurementId;
    private String gramsSplcId;

    /**
     *
     */
    public IsdSplcSourceMeasurementPojo() {}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the contactMeasurementId
     */
    public long getContactMeasurementId() {
        return contactMeasurementId;
    }

    /**
     * @param contactMeasurementId
     *            the contactMeasurementId to set
     */
    public void setContactMeasurementId(long contactMeasurementId) {
        this.contactMeasurementId = contactMeasurementId;
    }

    /**
     * @return the harmonic
     */
    public Double getHarmonic() {
        return harmonic;
    }

    /**
     * @param harmonic
     *            the harmonic to set
     */
    public void setHarmonic(Double harmonic) {
        this.harmonic = harmonic;
    }

    /**
     * @return the measuredFrequency
     */
    public Double getMeasuredFrequency() {
        return measuredFrequency;
    }

    /**
     * @param measuredFrequency
     *            the measuredFrequency to set
     */
    public void setMeasuredFrequency(Double measuredFrequency) {
        this.measuredFrequency = measuredFrequency;
    }

    /**
     * @return the processAccuracy
     */
    public Double getProcessAccuracy() {
        return processAccuracy;
    }

    /**
     * @param processAccuracy
     *            the processAccuracy to set
     */
    public void setProcessAccuracy(Double processAccuracy) {
        this.processAccuracy = processAccuracy;
    }

    /**
     * @return the processBandwidth
     */
    public Double getProcessBandwidth() {
        return processBandwidth;
    }

    /**
     * @param processBandwidth
     *            the processBandwidth to set
     */
    public void setProcessBandwidth(Double processBandwidth) {
        this.processBandwidth = processBandwidth;
    }

    /**
     * @return the processIntegrationTime
     */
    public Double getProcessIntegrationTime() {
        return processIntegrationTime;
    }

    /**
     * @param processIntegrationTime
     *            the processIntegrationTime to set
     */
    public void setProcessIntegrationTime(Double processIntegrationTime) {
        this.processIntegrationTime = processIntegrationTime;
    }

    /**
     * @return the processResolution
     */
    public Double getProcessResolution() {
        return processResolution;
    }

    /**
     * @param processResolution
     *            the processResolution to set
     */
    public void setProcessResolution(Double processResolution) {
        this.processResolution = processResolution;
    }

    /**
     * @return the propLossMethod
     */
    public Integer getPropLossMethod() {
        return propLossMethod;
    }

    /**
     * @param propLossMethod
     *            the propLossMethod to set
     */
    public void setPropLossMethod(Integer propLossMethod) {
        this.propLossMethod = propLossMethod;
    }

    /**
     * @return the propLossMethodName
     */
    public String getPropLossMethodName() {
        return propLossMethodName;
    }

    /**
     * @param propLossMethodName
     *            the propLossMethodName to set
     */
    public void setPropLossMethodName(String propLossMethodName) {
        this.propLossMethodName = propLossMethodName;
    }

    /**
     * @return the sourceDescription
     */
    public String getSourceDescription() {
        return sourceDescription;
    }

    /**
     * @param sourceDescription
     *            the sourceDescription to set
     */
    public void setSourceDescription(String sourceDescription) {
        this.sourceDescription = sourceDescription;
    }

    /**
     * @return the sourceDescriptionId
     */
    public long getSourceDescriptionId() {
        return sourceDescriptionId;
    }

    /**
     * @param sourceDescriptionId
     *            the sourceDescriptionId to set
     */
    public void setSourceDescriptionId(long sourceDescriptionId) {
        this.sourceDescriptionId = sourceDescriptionId;
    }

    /**
     * @return the sourceMeasurementId
     */
    public long getSourceMeasurementId() {
        return sourceMeasurementId;
    }

    /**
     * @param sourceMeasurementId
     *            the sourceMeasurementId to set
     */
    public void setSourceMeasurementId(long sourceMeasurementId) {
        this.sourceMeasurementId = sourceMeasurementId;
    }

    /**
     * @return the gramsSplcId
     */
    public String getGramsSplcId() {
        return gramsSplcId;
    }

    /**
     * @param gramsSplcId
     *            the gramsSplcId to set
     */
    public void setGramsSplcId(String gramsSplcId) {
        this.gramsSplcId = gramsSplcId;
    }

}
