/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.data.coi.CoiSegmentHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCoiSegmentPojo;

/**
 * @author bearyman
 */
public class CoiSegmentMigrationManager extends AbstractCoiMigrationManager {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiSegmentMigrationManager.class);

    /*
     * -- Contact Segment --
     * FSD Uniqueness Rules: based on segment name for a specific parent platform ISD to FSD
     * mapping rules: we are going to take all permutations of segments from ISD and append partial
     * UUIDs to the name to make them unique i.e. there will not be reuse of existing segments,
     * overwritting values
     */
    private static final String GET_COI_SEGMENT =
            "SELECT DISTINCT "
                    + "/* '|' AS associatedfile, */"
                    + "filecoi.filedescriptivemetadataid, "
                    + "filecoi.filename, "

                    + "/* '|' AS parent, */"
                    + "COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "    NULLIF(coiss.classification, ''), 'UNKNOWN') AS parentPlatformClass, "
                    + "COALESCE (coip.refinedname, coiss.name_, NULLIF(coip.refinedclassification, ''), "
                    + "    NULLIF(coiss.classification, '')) "
                    + "    || '_' || COALESCE (TO_CHAR(coip.refinedhull), TO_CHAR(coiss.hull), AS parentPlatformName, "
                    + "COALESCE (coip.refinedhull, coiss.hull, 0) AS parentHullNumber, "

                    + "/* '|' AS uniqueIdentifiers, */"
                    + "coiss.classification || '_' || COALESCE (coiss.usernameforsegment, 'UNKNOWN') || '_' "
                    + "    || LEFT(TO_CHAR(filecoi.filedescriptivemetadataid),8) || '_' "
                    + "    || LEFT(TO_CHAR(coiss.contactsegmentid),8) || '_' "
                    + "    || LEFT(TO_CHAR(cop.contactoperationalprofileid),8) || '_' "
                    + "    || LEFT(TO_CHAR(cge.contactgeometryestimateid),8) AS name, "

                    + "/* '|' AS requiredFields, */"
                    + "COALESCE (coiss.contactsegmentstartdtgitem, cge.starttimeitem, "
                    + "  coiss.contactgaindtgitem, coi.contactstartdtgitem) AS segment_startTime, "
                    + "COALESCE (coiss.contactsegmentenddtgitem, cge.stoptimeitem, "
                    + "  coiss.contactlostdtgitem, coi.contactenddtgitem) AS segment_endTime, "

                    + "/* '|' AS otherFields, */"
                    + "cop.comment_ AS comments, "
                    + "coiss.contactsegmentholdstatus AS holdStatus, "
                    + "cop.operatingprofile AS operatingProfile, "
                    + "cop.participantrole AS participantRole, "
                    + "cop.acousticmode AS acousticMode, "
                    + "cop.speedband AS speedBand, "
                    + "cop.depthband AS depthBand, "
                    + "COALESCE (cop.cavitationtype, coiss.cavitationtype) AS cavitationType, "
                    + "cop.cavitationmode AS cavitationMode, "
                    + "cop.propulsiontype AS propulsionType, "
                    + "cop.propulsionmode AS propulsionMode, "
                    + "coiss.weaponactivity AS weaponActivity, "
                    + "cge.contactsolutionconfidence AS platformConfidence, "
                    + "coip.papalimanumber AS papaLima, "
                    + "coi.georeferencebroadarea AS geospatialReferenceBroadArea, "
                    + "coi.georeferencerefinedarea AS geospatialReferenceRefinedArea, "
                    + "coi.georeferenceboundingbox_X1 AS boundingBoxXOneYOne_longitude, "
                    + "coi.georeferenceboundingbox_Y1 AS boundingBoxXOneYOne_latitude, "
                    + "'' AS boundingBoxXOneYOne_altitude, "
                    + "coi.georeferenceboundingbox_X2 AS boundingBoxXTwoYTwo_longitude, "
                    + "coi.georeferenceboundingbox_Y2 AS boundingBoxXTwoYTwo_latitude, "
                    + "'' AS boundingBoxXTwoYTwo_altitude, "
                    + "'TRUE' AS modifiable, "
                    + "COALESCE (coip.mandatorymetadata_security_c_0, "
                    + "    coiss.mandatorymetadata_security_c_0) AS mandatorymetadata_security_c_0, "
                    + "COALESCE (coip.mandatorymetadata_security_c_2, "
                    + "    coiss.mandatorymetadata_security_c_2) AS mandatorymetadata_security_c_2, "
                    + "COALESCE (coip.mandatorymetadata_security_c_1, "
                    + "    coiss.mandatorymetadata_security_c_1) AS mandatorymetadata_security_c_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_7, "
                    + "    coiss.mandatorymetadata_security_d_7) AS mandatorymetadata_security_d_7, "
                    + "COALESCE (coip.mandatorymetadata_security_d_6, "
                    + "    coiss.mandatorymetadata_security_d_6) AS mandatorymetadata_security_d_6, "
                    + "COALESCE (coip.mandatorymetadata_security_d_3, "
                    + "    coiss.mandatorymetadata_security_d_3) AS mandatorymetadata_security_d_3, "
                    + "COALESCE (coip.mandatorymetadata_security_d_4, "
                    + "    coiss.mandatorymetadata_security_d_4) AS mandatorymetadata_security_d_4, "
                    + "COALESCE (coip.mandatorymetadata_security_d_5, "
                    + "    coiss.mandatorymetadata_security_d_5) AS mandatorymetadata_security_d_5, "
                    + "COALESCE (coip.mandatorymetadata_security_d_1, "
                    + "    coiss.mandatorymetadata_security_d_1) AS mandatorymetadata_security_d_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_2, "
                    + "    coiss.mandatorymetadata_security_d_2) AS mandatorymetadata_security_d_2, "
                    + "COALESCE (coip.mandatorymetadata_security_d_0, "
                    + "    coiss.mandatorymetadata_security_d_0) AS mandatorymetadata_security_d_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_0, "
                    + "    coiss.mandatorymetadata_security_f_0) AS mandatorymetadata_security_f_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_1, "
                    + "    coiss.mandatorymetadata_security_f_1) AS mandatorymetadata_security_f_1, "
                    + "COALESCE (coip.mandatorymetadata_security_n_0, "
                    + "    coiss.mandatorymetadata_security_n_0) AS mandatorymetadata_security_n_0, "
                    + "COALESCE (coip.mandatorymetadata_security_o_0, "
                    + "    coiss.mandatorymetadata_security_o_0) AS mandatorymetadata_security_o_0, "
                    + "COALESCE (coip.mandatorymetadata_security_r_0, "
                    + "    coiss.mandatorymetadata_security_r_0) AS mandatorymetadata_security_r_0, "
                    + "COALESCE (coip.mandatorymetadata_security_s_1, "
                    + "    coiss.mandatorymetadata_security_s_1) AS mandatorymetadata_security_s_1, "
                    + "COALESCE (coip.mandatorymetadata_security_s_0, "
                    + "    coiss.mandatorymetadata_security_s_0) AS mandatorymetadata_security_s_0, "
                    + "COALESCE (coip.mandatorymetadata_security_t_0, "
                    + "    coiss.mandatorymetadata_security_t_0) AS mandatorymetadata_security_t_0 "
                    + "FROM "
                    + "omega.contactofinterest AS coi "
                    + "LEFT JOIN omega.contactofinterestplatform AS coip "
                    + "    ON coip.contactid = coi.contactofinterestid "
                    + "LEFT JOIN omega.metacard_contactofinterest "
                    + "    ON coi.contactofinterestid = metacard_contactofinterest.contactofinterestid "
                    + "LEFT JOIN omega.mdf_catalog_tab "
                    + "    ON metacard_contactofinterest.metacardid = mdf_catalog_tab.catalog_id "
                    + "LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "    ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "LEFT JOIN omega.filedescriptivemetadata AS filecoi "
                    + "    ON filecoi.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "LEFT JOIN "
                    + "    ( "
                    + "    SELECT "
                    + "      filecoiss.filedescriptivemetadataid AS filecoissid, "
                    + "      filecoiss.filename AS filecoissname, "
                    + "      contactofinterestsegmentsumm_0.* "
                    + "    FROM "
                    + "      omega.contactofinterestsegmentsumm_0 "
                    + "      LEFT JOIN omega.metacard_contactofinterestsegmentsummary "
                    + "        ON contactofinterestsegmentsumm_0.contactsegmentid = metacard_contactofinterestsegmentsummary.contactofinterestsegmentsummaryid "
                    + "      LEFT JOIN omega.mdf_catalog_tab "
                    + "        ON metacard_contactofinterestsegmentsummary.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "        ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.filedescriptivemetadata AS filecoiss "
                    + "        ON filecoiss.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecoiss.filedescriptivemetadataid != ''       "
                    + "      ) AS coiss "
                    + "      ON "
                    + "      ( "
                    + "      coiss.contactofinterestid = coi.contactofinterestid "
                    + "      AND filecoissid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "LEFT JOIN "
                    + "    ( "
                    + "    SELECT "
                    + "      fileccs.filedescriptivemetadataid AS fileccsid, "
                    + "      fileccs.filename AS filecoissname, "
                    + "      contactcharacterizedsources.* "
                    + "    FROM "
                    + "      omega.contactcharacterizedsources "
                    + "      LEFT JOIN omega.metacard_contactcharacterizedsources "
                    + "        ON contactcharacterizedsources.contactcharacterizedsourcesid = metacard_contactcharacterizedsources.contactcharacterizedsourcesid "
                    + "      LEFT JOIN omega.mdf_catalog_tab "
                    + "        ON metacard_contactcharacterizedsources.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "        ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.filedescriptivemetadata AS fileccs "
                    + "        ON fileccs.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        fileccs.filedescriptivemetadataid != ''       "
                    + "      ) AS ccs "
                    + "      ON "
                    + "      ( "
                    + "      ccs.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND fileccsid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "LEFT JOIN omega.contactgeometryestimate AS cge  "
                    + "    ON cge.geometryestimate_contactchar_0 = ccs.contactcharacterizedsourcesid "
                    + "LEFT JOIN "
                    + "    ( "
                    + "    SELECT "
                    + "      filecop.filedescriptivemetadataid AS filecopid, "
                    + "      filecop.filename AS filecopname, "
                    + "      contactoperationalprofile.* "
                    + "    FROM "
                    + "      omega.contactoperationalprofile "
                    + "      LEFT JOIN omega.metacard_contactoperationalprofile "
                    + "        ON contactoperationalprofile.contactoperationalprofileid = metacard_contactoperationalprofile.contactoperationalprofileid "
                    + "      LEFT JOIN omega.mdf_catalog_tab "
                    + "        ON metacard_contactoperationalprofile.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "        ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "      LEFT JOIN omega.filedescriptivemetadata AS filecop "
                    + "        ON filecop.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "    WHERE "
                    + "      filecop.filedescriptivemetadataid != ''    "
                    + "    ) AS cop "
                    + "    ON "
                    + "    ( "
                    + "    cop.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "    AND filecopid = filecoi.filedescriptivemetadataid "
                    + "    ) "
                    + "WHERE "
                    + "  filecoi.filedescriptivemetadataid != '' "
                    + "    AND COALESCE (coiss.usernameforsegment, TO_CHAR(coiss.contactsegmentstartdtgitem), TO_CHAR(cge.starttimeitem), "
                    + "                  TO_CHAR(coiss.contactgaindtgitem), TO_CHAR(coi.contactstartdtgitem), TO_CHAR(coiss.contactsegmentenddtgitem),  "
                    + "                  TO_CHAR(cge.stoptimeitem), TO_CHAR(coiss.contactlostdtgitem), TO_CHAR(coi.contactenddtgitem), cop.operatingprofile,  "
                    + "                  cop.participantrole, cop.acousticmode, cop.speedband, cop.depthband, cop.cavitationtype, coiss.cavitationtype,  "
                    + "                  cop.cavitationmode, cop.propulsiontype, cop.propulsionmode) != '' "
                    + "ORDER BY " + "parentPlatformClass ASC, " + "parentPlatformName ASC, "
                    + "    parentHullNumber ASC, " + "segment_endTime DESC, "
                    + "    segment_startTime DESC, " + "name ASC;";

    private IsdCoiSegmentPojo mPojo;
    private List<IsdCoiSegmentPojo> mPojos;

    /**
     * @throws SQLException
     */
    public CoiSegmentMigrationManager() throws SQLException {
        mTableType = EIsdTableNames.CONTACT_OF_INTEREST_SEGMENT_SUMMARY;
        mIsdConn = EtlUtilitiesDbms.getISDConnection();
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws SQLException {
        mPojos = new ArrayList<>();

        while (pResults.next()) {
            mPojo = new IsdCoiSegmentPojo();

            mPojo.setFiledescriptivemetadataid(pResults.getString("fileDescriptiveMetadataId"));
            mPojo.setFilename(pResults.getString("fileName"));
            mPojo.setParentPlatformClass(formatEnumString(pResults.getString("parentplatformclass")));
            mPojo.setParentPlatformName(formatEnumString(pResults.getString("parentPlatformName")));
            mPojo.setParentHullNumber(pResults.getString("parenthullnumber"));
            mPojo.setAcousticMode(pResults.getString("acousticmode"));
            mPojo.setBoundingBoxXOneYOne_longitude(pResults
                    .getString("boundingboxxoneyone_longitude"));
            mPojo.setBoundingBoxXOneYOne_latitude(pResults
                    .getString("boundingboxxoneyone_latitude"));
            mPojo.setBoundingBoxXOneYOne_altitude(pResults
                    .getString("boundingboxxoneyone_altitude"));
            mPojo.setBoundingBoxXOneYOne_longitude(pResults
                    .getString("boundingboxxtwoytwo_longitude"));
            mPojo.setBoundingBoxXTwoYTwo_latitude(pResults
                    .getString("boundingboxxtwoytwo_latitude"));
            mPojo.setBoundingBoxXTwoYTwo_altitude(pResults
                    .getString("boundingboxxtwoytwo_altitude"));
            mPojo.setCavitationMode(pResults.getString("cavitationmode"));
            mPojo.setCavitationType(pResults.getString("cavitationtype"));
            mPojo.setComments(pResults.getString("comments"));
            mPojo.setDepthBand(pResults.getString("depthband"));
            mPojo.setGeospatialReferenceBroadArea(pResults
                    .getString("geospatialreferencebroadarea"));
            mPojo.setGeospatialReferenceRefinedArea(pResults
                    .getString("geospatialreferencerefinedarea"));
            mPojo.setHoldStatus(pResults.getString("holdstatus"));
            mPojo.setModifiable(pResults.getBoolean("modifiable"));
            mPojo.setName(pResults.getString("name"));
            mPojo.setOperatingProfile(pResults.getString("operatingprofile"));
            mPojo.setPapaLima(pResults.getString("papalima"));
            mPojo.setParticipantRole(pResults.getString("participantrole"));
            mPojo.setPlatformConfidence(pResults.getString("platformconfidence"));
            mPojo.setPropulsionMode(pResults.getString("propulsionmode"));
            mPojo.setPropulsionType(pResults.getString("propulsiontype"));
            mPojo.setSpeedBand(pResults.getString("speedband"));
            mPojo.setSegment_startTime(pResults.getDate("segment_starttime"));
            mPojo.setSegment_endTime(pResults.getDate("segment_endtime"));
            mPojo.setWeaponActivity(pResults.getString("weaponactivity"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            mPojos.add(mPojo);
        }
        mMetrics.setTotalRecords(mPojos.size());
    }

    @Override
    protected void createHandlers() {
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (IsdCoiSegmentPojo pojo: mPojos) {
            mHandlerQueue.add(new CoiSegmentHandler(pojo));
        }
    }

    @Override
    protected String getQuery() {
        return GET_COI_SEGMENT;
    }
}
