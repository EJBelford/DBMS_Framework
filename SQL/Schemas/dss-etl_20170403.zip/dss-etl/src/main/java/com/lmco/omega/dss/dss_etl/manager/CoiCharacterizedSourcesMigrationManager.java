/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.data.coi.CoiCharacterizedSourceHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdContactCharacterizedSourcesPojo;

/**
 * @author bearyman
 */
public class CoiCharacterizedSourcesMigrationManager extends AbstractCoiMigrationManager {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiCharacterizedSourcesMigrationManager.class);
    /*
     * -- Contact Characterized Source --
     * No uniqueness requirements
     */
    private static final String GET_COI_CHARACTERIZED_SOURCE =
            "SELECT DISTINCT "
                    + "/* '|' AS parent, */ "
                    + "  COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "      NULLIF(coiss.classification, ''), 'UNKNOWN') AS parentPlatformClass, "
                    + "  COALESCE (coip.refinedname, coiss.name_, NULLIF(coip.refinedclassification, ''), "
                    + "      NULLIF(coiss.classification, '')) "
                    + "      || '_' || COALESCE (TO_CHAR(coip.refinedhull), TO_CHAR(coiss.hull), '0') AS parentPlatformName, "
                    + "  COALESCE (coip.refinedhull, coiss.hull, 0) AS parentHullNumber, "

                    + "  coiss.classification || '_' || COALESCE (coiss.usernameforsegment, 'UNKNOWN' ) || '_' "
                    + "      || LEFT(TO_CHAR(filecoi.filedescriptivemetadataid),8) || '_' "
                    + "      || LEFT(TO_CHAR(coiss.contactsegmentid),8) || '_' "
                    + "      || LEFT(TO_CHAR(cop.contactoperationalprofileid),8) || '_' "
                    + "      || LEFT(TO_CHAR(cge.contactgeometryestimateid),8) AS parentSegmentName, "

                    + "  /* '|' AS requiredFields, */ "
                    + "  COALESCE (coiss.contactgaindtgitem, cge.starttimeitem, coiss.contactsegmentstartdtgitem, "
                    + "      coi.contactstartdtgitem) AS characterizationTime, "
                    + "  COALESCE (ccs.peakfreq, 0) AS peakFrequency, "

                    + "  /* '|' otherFields, */ "
                    + "  COALESCE (coiss.contactgaindtgitem, cge.starttimeitem, "
                    + "    coiss.contactsegmentstartdtgitem, coi.contactstartdtgitem) AS characterization_startTime, "
                    + "  COALESCE (coiss.contactlostdtgitem, cge.stoptimeitem, "
                    + "    coiss.contactsegmentenddtgitem, coi.contactenddtgitem) AS characterization_stopTime, "
                    + "  'ECM' AS characterizationGeneratedBy, "

                    + "/* This might be a link or a uuid reference to Frequency Identifier */"
                    + "  COALESCE (ccs.sourceoriginname, 'UNKNOWN') AS sourceOriginName, "
                    + "/* This might be a link or a uuid reference to Frequency Identifier */"
                    + "  ccs.userlabel || '_' || LEFT(TO_CHAR(cop.contactoperationalprofileid),8) AS userLabel, "

                    + "  ccs.aekeyinginterval AS aeKeyingInterval, "
                    + "  ccs.aekeyingintervaltype AS aeKeyingType, "
                    + "  ccs.bandwidth AS bandwidth, "
                    + "  ccs.depressionelevationangle AS depressionElevationAngle, "
                    + "  ccs.freqbandstart AS minimumFrequency, "
                    + "  ccs.freqbandstop AS maximumFrequency, "
                    + "  ccs.harmonic AS harmonic, "
                    + "  ccs.homingtype AS homingType, "
                    + "  ccs.pulsetype AS transmissionMode, "
                    + "  ccs.signallevel AS signalLevel, "
                    + "  ccs.snr AS signalToNoiseRatio, "
                    + "  ccs.snrazimuthal AS signalToNoiseRatioAzimuthalAngle, "
                    + "  ccs.snrdepressionelevationangle AS signalToNoiseRatioAzimuthalDepressionElevationAngle, "
                    + "  ccs.soundtype AS soundType, "
                    + "  ccs.sourcerpm AS sourceRPM, "
                    + "  ccs.waveform AS waveForm, "
                    + "  cge.angleonthebow AS angleOnTheBow, "
                    + "  cge.aspect AS aspect, "
                    + "  cge.centerfrequency AS centerFrequency, "
                    + "  cge.comment_ AS comments, "
                    + "  cge.confidence AS geospatialConfidence, "
                    + "  cge.course AS course, "
                    + "  COALESCE (cge.depth_, cop.depth_, coiss.depth_) AS position_altitude, "
                    + "  cge.heading AS heading, "
                    + "  cge.rangefromsensor AS rangeFromSensor, "
                    + "  cge.relativebearing AS relativeBearing, "
                    + "  cge.soundvelocity AS soundVelocity, "
                    + "  COALESCE (cge.speed, cop.speed, coiss.speed) AS reportedSpeed, "
                    + "  cge.truebearing AS trueBearing, "
                    + "  cge.type_ AS geospatialSourceType, "
                    + "  cge.waterdepth AS waterDepth, "
                    + "  coiss.maxenginerpm AS maximumEngineRPM, "
                    + "  coiss.maxpropellerrpm AS maximumPropellerRPM, "
                    + "  coiss.minenginerpm AS minimumEngineRPM, "
                    + "  coiss.minpropellerrpm AS minimumPropellerRPM, "
                    + "  coiss.targetcparange AS targetCpaRange, "
                    + "  cop.enginecrankshaftrate AS engineCrankShaftRate, "
                    + "  cop.enginecylinderrate AS engineCylinderRate, "
                    + "  COALESCE (cop.enginerpm, cop.turbinerpm) AS engineRPM, "
                    + "  cop.propellerbladerate AS propellerBladeRate, "
                    + "  cop.propellerrpm AS propellerRPM, "
                    + "  cop.propellershaftrate AS propellerShaftRate, "
                    + "  cop.transientlevel AS transientLevel, "
                    + "  cop.weaponmode AS weaponMode, "
                    + "  COALESCE (coip.refinedtype, /*coip.refinedcategory,*/ coiss.platformtype, coiss.category) AS type, "
                    + "  COALESCE (coip.sconum, coiss.sconum) AS sconum, "
                    + "  COALESCE (coip.refinedpennant, coiss.pennant) AS pennant, "
                    + "  COALESCE (coip.refinedcountry, coiss.country) AS ownerCountry, "
                    + "  coip.producecountry AS producerCountry, "
                    + "  COALESCE (coip.refinedtargetflightvariant, coiss.targetflightvariant) AS targetFlightVariant, "
                    + "  COALESCE (coip.mandatorymetadata_security_c_0, "
                    + "    coiss.mandatorymetadata_security_c_0) AS mandatorymetadata_security_c_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_c_2, "
                    + "    coiss.mandatorymetadata_security_c_2) AS mandatorymetadata_security_c_2, "
                    + "  COALESCE (coip.mandatorymetadata_security_c_1, "
                    + "    coiss.mandatorymetadata_security_c_1) AS mandatorymetadata_security_c_1, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_7, "
                    + "    coiss.mandatorymetadata_security_d_7) AS mandatorymetadata_security_d_7, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_6, "
                    + "    coiss.mandatorymetadata_security_d_6) AS mandatorymetadata_security_d_6, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_3, "
                    + "    coiss.mandatorymetadata_security_d_3) AS mandatorymetadata_security_d_3, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_4, "
                    + "    coiss.mandatorymetadata_security_d_4) AS mandatorymetadata_security_d_4, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_5, "
                    + "    coiss.mandatorymetadata_security_d_5) AS mandatorymetadata_security_d_5, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_1, "
                    + "    coiss.mandatorymetadata_security_d_1) AS mandatorymetadata_security_d_1, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_2, "
                    + "    coiss.mandatorymetadata_security_d_2) AS mandatorymetadata_security_d_2, "
                    + "  COALESCE (coip.mandatorymetadata_security_d_0, "
                    + "    coiss.mandatorymetadata_security_d_0) AS mandatorymetadata_security_d_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_f_0, "
                    + "    coiss.mandatorymetadata_security_f_0) AS mandatorymetadata_security_f_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_f_1, "
                    + "    coiss.mandatorymetadata_security_f_1) AS mandatorymetadata_security_f_1, "
                    + "  COALESCE (coip.mandatorymetadata_security_n_0, "
                    + "    coiss.mandatorymetadata_security_n_0) AS mandatorymetadata_security_n_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_o_0, "
                    + "    coiss.mandatorymetadata_security_o_0) AS mandatorymetadata_security_o_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_r_0, "
                    + "    coiss.mandatorymetadata_security_r_0) AS mandatorymetadata_security_r_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_s_1, "
                    + "    coiss.mandatorymetadata_security_s_1) AS mandatorymetadata_security_s_1, "
                    + "  COALESCE (coip.mandatorymetadata_security_s_0, "
                    + "    coiss.mandatorymetadata_security_s_0) AS mandatorymetadata_security_s_0, "
                    + "  COALESCE (coip.mandatorymetadata_security_t_0, "
                    + "    coiss.mandatorymetadata_security_t_0) AS mandatorymetadata_security_t_0 "
                    + "FROM "
                    + "  omega.contactofinterest AS coi "
                    + "  LEFT JOIN omega.contactofinterestplatform AS coip "
                    + "    ON coip.contactid = coi.contactofinterestid "
                    + "  LEFT JOIN omega.metacard_contactofinterest "
                    + "    ON coi.contactofinterestid = metacard_contactofinterest.contactofinterestid "
                    + "  LEFT JOIN omega.mdf_catalog_tab "
                    + "    ON metacard_contactofinterest.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "    ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.filedescriptivemetadata AS filecoi "
                    + "    ON filecoi.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecoiss.filedescriptivemetadataid AS filecoissid, "
                    + "        filecoiss.filename AS filecoissname, "
                    + "        contactofinterestsegmentsumm_0.* "
                    + "      FROM "
                    + "        omega.contactofinterestsegmentsumm_0 "
                    + "        LEFT JOIN omega.metacard_contactofinterestsegmentsummary "
                    + "          ON contactofinterestsegmentsumm_0.contactsegmentid = metacard_contactofinterestsegmentsummary.contactofinterestsegmentsummaryid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactofinterestsegmentsummary.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecoiss "
                    + "          ON filecoiss.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecoiss.filedescriptivemetadataid != ''       "
                    + "      ) AS coiss "
                    + "    ON "
                    + "      ( "
                    + "      coiss.contactofinterestid = coi.contactofinterestid "
                    + "      AND filecoissid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        fileccs.filedescriptivemetadataid AS fileccsid, "
                    + "        fileccs.filename AS filecoissname, "
                    + "        contactcharacterizedsources.* "
                    + "      FROM "
                    + "        omega.contactcharacterizedsources "
                    + "        LEFT JOIN omega.metacard_contactcharacterizedsources "
                    + "          ON contactcharacterizedsources.contactcharacterizedsourcesid = metacard_contactcharacterizedsources.contactcharacterizedsourcesid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactcharacterizedsources.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS fileccs "
                    + "          ON fileccs.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        fileccs.filedescriptivemetadataid != '' "
                    + "      ) AS ccs "
                    + "    ON "
                    + "      ( "
                    + "      ccs.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND fileccsid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "  LEFT JOIN omega.contactgeometryestimate cge  "
                    + "    ON cge.geometryestimate_contactchar_0 = ccs.contactcharacterizedsourcesid "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecop.filedescriptivemetadataid AS filecopid, "
                    + "        filecop.filename AS filecopname, "
                    + "        contactoperationalprofile.* "
                    + "      FROM "
                    + "        omega.contactoperationalprofile "
                    + "        LEFT JOIN omega.metacard_contactoperationalprofile "
                    + "          ON contactoperationalprofile.contactoperationalprofileid = metacard_contactoperationalprofile.contactoperationalprofileid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactoperationalprofile.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecop "
                    + "          ON filecop.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecop.filedescriptivemetadataid != ''       "
                    + "      ) AS cop "
                    + "    ON "
                    + "      ( "
                    + "      cop.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND filecopid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "WHERE "
                    + "  filecoi.filedescriptivemetadataid != '' "
                    + "  AND COALESCE (TO_CHAR(coiss.contactgaindtgitem), TO_CHAR(cge.starttimeitem), TO_CHAR(coiss.contactsegmentstartdtgitem), "
                    + "                TO_CHAR(coi.contactstartdtgitem), TO_CHAR(ccs.peakfreq), TO_CHAR(ccs.bandwidth), TO_CHAR(ccs.freqbandstart),  "
                    + "                TO_CHAR(ccs.freqbandstop), TO_CHAR(cge.centerfrequency), TO_CHAR(cge.course), TO_CHAR(cge.heading),  "
                    + "                TO_CHAR(cge.speed), TO_CHAR(cop.speed), TO_CHAR(coiss.speed)) != '' "
                    + "ORDER BY " + "  parentPlatformClass ASC, " + "  parentPlatformName ASC, "
                    + "  parentHullNumber ASC, " + "  characterizationTime DESC, "
                    + "  peakFrequency ASC;";

    private IsdContactCharacterizedSourcesPojo mPojo;
    private List<IsdContactCharacterizedSourcesPojo> mPojos;

    /**
     * @throws SQLException
     */
    public CoiCharacterizedSourcesMigrationManager() throws SQLException {
        mTableType = EIsdTableNames.CONTACT_CHARACTERIZED_SOURCES;
        mIsdConn = EtlUtilitiesDbms.getISDConnection();
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws SQLException {
        mPojos = new ArrayList<>();

        while (pResults.next()) {
            mPojo = new IsdContactCharacterizedSourcesPojo();

            mPojo.setParentPlatformClass(formatEnumString(pResults.getString("parentPlatformClass")));
            mPojo.setParentPlatformName(formatEnumString(pResults.getString("parentPlatformName")));
            mPojo.setParentHullNumber(pResults.getString("parentHullNumber"));
            mPojo.setParentSegmentName(pResults.getString("parentSegmentName"));
            mPojo.setSourceOriginName(pResults.getString("sourceOriginName"));
            mPojo.setUserLabel(pResults.getString("userLabel"));

            mPojo.setAekeyinginterval(pResults.getInt("aeKeyingInterval"));
            mPojo.setAekeyingintervaltype(pResults.getString("aeKeyingType"));
            mPojo.setBandwidth(pResults.getDouble("bandwidth"));
            mPojo.setDepressionelevationangle(pResults.getDouble("depressionElevationAngle"));
            mPojo.setFreqbandstop(pResults.getDouble("minimumFrequency"));
            mPojo.setFreqbandstop(pResults.getDouble("maximumFrequency"));
            mPojo.setHarmonic(pResults.getDouble("harmonic"));
            mPojo.setHomingtype(pResults.getString("homingType"));
            mPojo.setPulsetype(pResults.getString("transmissionMode"));
            mPojo.setSignallevel(pResults.getDouble("signalLevel"));
            mPojo.setSnr(pResults.getDouble("signalToNoiseRatio"));
            mPojo.setSnrazimuthal(pResults.getDouble("signalToNoiseRatioAzimuthalAngle"));
            mPojo.setSnrdepressionelevationangle(pResults
                    .getDouble("signalToNoiseRatioAzimuthalDepressionElevationAngle"));
            mPojo.setSoundtype(pResults.getString("soundType"));
            mPojo.setSourcerpm(pResults.getDouble("sourceRPM"));
            mPojo.setWaveform(pResults.getString("waveForm"));
            mPojo.setAngleonthebow(pResults.getDouble("angleOnTheBow"));
            mPojo.setAspect(pResults.getDouble("aspect"));
            mPojo.setCenterfrequency(pResults.getDouble("centerFrequency"));
            mPojo.setComment(pResults.getString("comments"));
            mPojo.setGeospatialconfidence(pResults.getString("geospatialConfidence"));
            mPojo.setCourse(pResults.getDouble("course"));
            mPojo.setAltitude(pResults.getDouble("position_altitude"));
            mPojo.setHeading(pResults.getDouble("heading"));
            mPojo.setRangefromsensor(pResults.getDouble("rangeFromSensor"));
            mPojo.setRelativebearing(pResults.getDouble("relativeBearing"));
            mPojo.setSoundvelocity(pResults.getDouble("soundVelocity"));
            mPojo.setReportedspeed(pResults.getDouble("reportedSpeed"));
            mPojo.setTruebearing(pResults.getDouble("trueBearing"));
            // TODO
            // mPojo
            // .setGeospatialSourceType(pResults.getString("geospatialSourceType"));
            mPojo.setWaterdepth(pResults.getDouble("waterDepth"));
            mPojo.setMaxenginerpm(pResults.getDouble("maximumEngineRPM"));
            mPojo.setMaxpropellerrpm(pResults.getDouble("maximumPropellerRPM"));
            mPojo.setMinenginerpm(pResults.getDouble("minimumEngineRPM"));
            mPojo.setMinpropellerrpm(pResults.getDouble("minimumPropellerRPM"));
            // mPojo .setId(pResults.getString("targetCpaRange"));
            mPojo.setEnginecrankshaftrate(pResults.getDouble("engineCrankShaftRate"));
            mPojo.setEnginecylinderrate(pResults.getDouble("engineCylinderRate"));
            mPojo.setEnginerpm(pResults.getDouble("engineRPM"));
            mPojo.setPropellerbladerate(pResults.getDouble("propellerBladeRate"));
            mPojo.setPropellerrpm(pResults.getDouble("propellerRPM"));
            mPojo.setPropellershaftrate(pResults.getDouble("propellerShaftRate"));
            mPojo.setTransientlevel(pResults.getString("transientLevel"));
            mPojo.setWeaponmode(pResults.getString("weaponMode"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            mPojos.add(mPojo);
        }
        mMetrics.setTotalRecords(mPojos.size());
    }

    @Override
    protected void createHandlers() {
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (IsdContactCharacterizedSourcesPojo pojo: mPojos) {
            mHandlerQueue.add(new CoiCharacterizedSourceHandler(pojo));
        }
    }

    @Override
    protected String getQuery() {
        return GET_COI_CHARACTERIZED_SOURCE;
    }
}
