/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

import com.lmco.omega.dss.dss_etl.enums.EIsdFileDescriptiveMetadataTypes;

/**
 * @author bearyman
 */
public class IsdFileDescriptiveMetadataPojo {

    private String id;
    private String checksum;
    private Date dateCreated;
    private Date dateModified;
    private Boolean isDeletionCandidate;
    private String fileName;
    private String fileStatus;
    private Integer fileTypeId;
    private Boolean forRdte;
    private String groupId;
    private String lastModifiedBy;
    private Date lastUsageDate;
    private Boolean isMetacardClassificationValid;
    private String mimeType;
    private String other;
    private String permissions;
    private String productType;
    private Boolean isPublic;
    private Boolean isPublicToWeb;
    private Date releaseDate;
    private String retentionPolicyId;
    private long fileSize;
    private String tappStatus;
    private String uri;
    private String userId;
    private Integer version;
    private EIsdFileDescriptiveMetadataTypes fdMetadataType;
    private long fdMetadataId;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdFileDescriptiveMetadataPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the checksum
     */
    public String getChecksum() {
        return checksum;
    }

    /**
     * @param checksum
     *            the checksum to set
     */
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    /**
     * @return the dateCreated
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * @param dateCreated
     *            the dateCreated to set
     */
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * @return the dateModified
     */
    public Date getDateModified() {
        return dateModified;
    }

    /**
     * @param dateModified
     *            the dateModified to set
     */
    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    /**
     * @return the isDeletionCandidate
     */
    public Boolean getIsDeletionCandidate() {
        return isDeletionCandidate;
    }

    /**
     * @param isDeletionCandidate
     *            the isDeletionCandidate to set
     */
    public void setIsDeletionCandidate(Boolean isDeletionCandidate) {
        this.isDeletionCandidate = isDeletionCandidate;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName
     *            the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the fileStatus
     */
    public String getFileStatus() {
        return fileStatus;
    }

    /**
     * @param fileStatus
     *            the fileStatus to set
     */
    public void setFileStatus(String fileStatus) {
        this.fileStatus = fileStatus;
    }

    /**
     * @return the fileTypeId
     */
    public Integer getFileTypeId() {
        return fileTypeId;
    }

    /**
     * @param fileTypeId
     *            the fileTypeId to set
     */
    public void setFileTypeId(Integer fileTypeId) {
        this.fileTypeId = fileTypeId;
    }

    /**
     * @return the forRdte
     */
    public Boolean getForRdte() {
        return forRdte;
    }

    /**
     * @param forRdte
     *            the forRdte to set
     */
    public void setForRdte(Boolean forRdte) {
        this.forRdte = forRdte;
    }

    /**
     * @return the groupId
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * @param groupId
     *            the groupId to set
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * @return the lastModifiedBy
     */
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    /**
     * @param lastModifiedBy
     *            the lastModifiedBy to set
     */
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    /**
     * @return the lastUsageDate
     */
    public Date getLastUsageDate() {
        return lastUsageDate;
    }

    /**
     * @param lastUsageDate
     *            the lastUsageDate to set
     */
    public void setLastUsageDate(Date lastUsageDate) {
        this.lastUsageDate = lastUsageDate;
    }

    /**
     * @return the isMetacardClassificationValid
     */
    public Boolean getIsMetacardClassificationValid() {
        return isMetacardClassificationValid;
    }

    /**
     * @param isMetacardClassificationValid
     *            the isMetacardClassificationValid to set
     */
    public void setIsMetacardClassificationValid(Boolean isMetacardClassificationValid) {
        this.isMetacardClassificationValid = isMetacardClassificationValid;
    }

    /**
     * @return the mimeType
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * @param mimeType
     *            the mimeType to set
     */
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    /**
     * @return the other
     */
    public String getOther() {
        return other;
    }

    /**
     * @param other
     *            the other to set
     */
    public void setOther(String other) {
        this.other = other;
    }

    /**
     * @return the permissions
     */
    public String getPermissions() {
        return permissions;
    }

    /**
     * @param permissions
     *            the permissions to set
     */
    public void setPermissions(String permissions) {
        this.permissions = permissions;
    }

    /**
     * @return the productType
     */
    public String getProductType() {
        return productType;
    }

    /**
     * @param productType
     *            the productType to set
     */
    public void setProductType(String productType) {
        this.productType = productType;
    }

    /**
     * @return the isPublic
     */
    public Boolean getIsPublic() {
        return isPublic;
    }

    /**
     * @param isPublic
     *            the isPublic to set
     */
    public void setIsPublic(Boolean isPublic) {
        this.isPublic = isPublic;
    }

    /**
     * @return the isPublicToWeb
     */
    public Boolean getIsPublicToWeb() {
        return isPublicToWeb;
    }

    /**
     * @param isPublicToWeb
     *            the isPublicToWeb to set
     */
    public void setIsPublicToWeb(Boolean isPublicToWeb) {
        this.isPublicToWeb = isPublicToWeb;
    }

    /**
     * @return the releaseDate
     */
    public Date getReleaseDate() {
        return releaseDate;
    }

    /**
     * @param releaseDate
     *            the releaseDate to set
     */
    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    /**
     * @return the retentionPolicyId
     */
    public String getRetentionPolicyId() {
        return retentionPolicyId;
    }

    /**
     * @param retentionPolicyId
     *            the retentionPolicyId to set
     */
    public void setRetentionPolicyId(String retentionPolicyId) {
        this.retentionPolicyId = retentionPolicyId;
    }

    /**
     * @return the fileSize
     */
    public long getFileSize() {
        return fileSize;
    }

    /**
     * @param fileSize
     *            the fileSize to set
     */
    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * @return the tappStatus
     */
    public String getTappStatus() {
        return tappStatus;
    }

    /**
     * @param tappStatus
     *            the tappStatus to set
     */
    public void setTappStatus(String tappStatus) {
        this.tappStatus = tappStatus;
    }

    /**
     * @return the uri
     */
    public String getUri() {
        return uri;
    }

    /**
     * @param uri
     *            the uri to set
     */
    public void setUri(String puri) {
        uri = puri;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the version
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public void setVersion(Integer version) {
        this.version = version;
    }

    /**
     * @return the fdMetadataType
     */
    public EIsdFileDescriptiveMetadataTypes getFdMetadataType() {
        return fdMetadataType;
    }

    /**
     * @param fdMetadataType
     *            the fdMetadataType to set
     */
    public void setFdMetadataType(EIsdFileDescriptiveMetadataTypes fdMetadataType) {
        this.fdMetadataType = fdMetadataType;
    }

    /**
     * @return the fdMetadataId
     */
    public long getFdMetadataId() {
        return fdMetadataId;
    }

    /**
     * @param fdMetadataId
     *            the fdMetadataId to set
     */
    public void setFdMetadataId(long fdMetadataId) {
        this.fdMetadataId = fdMetadataId;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }
}
