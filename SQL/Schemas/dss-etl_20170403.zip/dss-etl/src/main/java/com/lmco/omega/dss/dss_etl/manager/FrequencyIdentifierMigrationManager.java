/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.data.coi.FrequencyIdentifierHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdFrequencyIdentifierPojo;

/**
 * @author bearyman
 */
public class FrequencyIdentifierMigrationManager extends AbstractCoiMigrationManager {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            FrequencyIdentifierMigrationManager.class);

    /*
     * Frequency Identifier
     * FSD Uniqueness Rules: based on sourceOriginName and userLabel combination for a specific
     * parent contact platform ISD to FSD mapping rules: we are going to take all permutations of
     * Freq IDs from ISD and append UUIDs to the userlabel to make them unique i.e. there will not
     * be reuse of existing frequency identifiers, overwritting values
     */
    private static final String GET_FREQUENCY_INDENTIFIER =
            "SELECT DISTINCT "
                    + "/* '|' AS parent, */"
                    + "  COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "      NULLIF(coiss.classification, ''), 'UNKNOWN') AS parentPlatformClass, "
                    + "  COALESCE (TO_CHAR(coip.refinedname), TO_CHAR(coiss.name_), "
                    + "      COALESCE (NULLIF(coip.refinedclassification, ''), "
                    + "          NULLIF(coiss.classification, '')) "
                    + "      || '_' || COALESCE (TO_CHAR(coip.refinedhull), TO_CHAR(coiss.hull), '0')) AS parentPlatformName, "
                    + "  COALESCE (coip.refinedhull, coiss.hull, 0) AS parentHullNumber, "

                    + "/*    '|' AS uniqueIdentifiers, */"
                    + "  COALESCE (ccs.sourceoriginname, 'UNKNOWN') AS sourceOriginName, "
                    + "  ccs.userlabel || '_' || LEFT(TO_CHAR(cop.contactoperationalprofileid),8) "
                    + "    AS userLabel, "

                    + "/*    '|' AS requiredFields, */"
                    + "  COALESCE (ccs.sourcecategory, 'UNKNOWN') AS sourceCatagory, "
                    + "  COALESCE (ccs.harmonic, 1) AS harmonic, "

                    + "    '|' AS otherFields, "
                    + "  COALESCE (cop.turnsperknot, coiss.turnsperknot) AS turnsperknot, "
                    + "  cop.reductionratio, "
                    + "  cop.bladesperpropeller AS numberOfBlades, "
                    + "  cop.propellerlocation, "
                    + "  cop.enginetype, "
                    + "  cop.enginelocation, "
                    + "COALESCE (coip.mandatorymetadata_security_c_0, "
                    + "    coiss.mandatorymetadata_security_c_0) AS mandatorymetadata_security_c_0, "
                    + "COALESCE (coip.mandatorymetadata_security_c_2, "
                    + "    coiss.mandatorymetadata_security_c_2) AS mandatorymetadata_security_c_2, "
                    + "COALESCE (coip.mandatorymetadata_security_c_1, "
                    + "    coiss.mandatorymetadata_security_c_1) AS mandatorymetadata_security_c_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_7, "
                    + "    coiss.mandatorymetadata_security_d_7) AS mandatorymetadata_security_d_7, "
                    + "COALESCE (coip.mandatorymetadata_security_d_6, "
                    + "    coiss.mandatorymetadata_security_d_6) AS mandatorymetadata_security_d_6, "
                    + "COALESCE (coip.mandatorymetadata_security_d_3, "
                    + "    coiss.mandatorymetadata_security_d_3) AS mandatorymetadata_security_d_3, "
                    + "COALESCE (coip.mandatorymetadata_security_d_4, "
                    + "    coiss.mandatorymetadata_security_d_4) AS mandatorymetadata_security_d_4, "
                    + "COALESCE (coip.mandatorymetadata_security_d_5, "
                    + "    coiss.mandatorymetadata_security_d_5) AS mandatorymetadata_security_d_5, "
                    + "COALESCE (coip.mandatorymetadata_security_d_1, "
                    + "    coiss.mandatorymetadata_security_d_1) AS mandatorymetadata_security_d_1, "
                    + "COALESCE (coip.mandatorymetadata_security_d_2, "
                    + "    coiss.mandatorymetadata_security_d_2) AS mandatorymetadata_security_d_2, "
                    + "COALESCE (coip.mandatorymetadata_security_d_0, "
                    + "    coiss.mandatorymetadata_security_d_0) AS mandatorymetadata_security_d_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_0, "
                    + "    coiss.mandatorymetadata_security_f_0) AS mandatorymetadata_security_f_0, "
                    + "COALESCE (coip.mandatorymetadata_security_f_1, "
                    + "    coiss.mandatorymetadata_security_f_1) AS mandatorymetadata_security_f_1, "
                    + "COALESCE (coip.mandatorymetadata_security_n_0, "
                    + "    coiss.mandatorymetadata_security_n_0) AS mandatorymetadata_security_n_0, "
                    + "COALESCE (coip.mandatorymetadata_security_o_0, "
                    + "    coiss.mandatorymetadata_security_o_0) AS mandatorymetadata_security_o_0, "
                    + "COALESCE (coip.mandatorymetadata_security_r_0, "
                    + "    coiss.mandatorymetadata_security_r_0) AS mandatorymetadata_security_r_0, "
                    + "COALESCE (coip.mandatorymetadata_security_s_1, "
                    + "    coiss.mandatorymetadata_security_s_1) AS mandatorymetadata_security_s_1, "
                    + "COALESCE (coip.mandatorymetadata_security_s_0, "
                    + "    coiss.mandatorymetadata_security_s_0) AS mandatorymetadata_security_s_0, "
                    + "COALESCE (coip.mandatorymetadata_security_t_0, "
                    + "    coiss.mandatorymetadata_security_t_0) AS mandatorymetadata_security_t_0 "
                    + "FROM "
                    + "  omega.contactofinterest AS coi "
                    + "  LEFT JOIN omega.contactofinterestplatform AS coip "
                    + "    ON coip.contactid = coi.contactofinterestid "
                    + "  LEFT JOIN omega.metacard_contactofinterest "
                    + "    ON coi.contactofinterestid = metacard_contactofinterest.contactofinterestid "
                    + "  LEFT JOIN omega.mdf_catalog_tab "
                    + "    ON metacard_contactofinterest.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "    ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "  LEFT JOIN omega.filedescriptivemetadata AS filecoi "
                    + "    ON filecoi.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecoiss.filedescriptivemetadataid AS filecoissid, "
                    + "        filecoiss.filename AS filecoissname, "
                    + "        contactofinterestsegmentsumm_0.* "
                    + "      FROM "
                    + "        omega.contactofinterestsegmentsumm_0 "
                    + "        LEFT JOIN omega.metacard_contactofinterestsegmentsummary "
                    + "          ON contactofinterestsegmentsumm_0.contactsegmentid = metacard_contactofinterestsegmentsummary.contactofinterestsegmentsummaryid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactofinterestsegmentsummary.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecoiss "
                    + "          ON filecoiss.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecoiss.filedescriptivemetadataid != ''    "
                    + "      ) AS coiss "
                    + "    ON "
                    + "      ( "
                    + "      coiss.contactofinterestid = coi.contactofinterestid "
                    + "      AND filecoissid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        fileccs.filedescriptivemetadataid AS fileccsid, "
                    + "        fileccs.filename AS filecoissname, "
                    + "        contactcharacterizedsources.* "
                    + "      FROM "
                    + "        omega.contactcharacterizedsources "
                    + "        LEFT JOIN omega.metacard_contactcharacterizedsources "
                    + "          ON contactcharacterizedsources.contactcharacterizedsourcesid = metacard_contactcharacterizedsources.contactcharacterizedsourcesid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactcharacterizedsources.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS fileccs "
                    + "          ON fileccs.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        fileccs.filedescriptivemetadataid != ''   "
                    + "      ) AS ccs "
                    + "    ON "
                    + "      ( "
                    + "      ccs.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND fileccsid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "  LEFT JOIN "
                    + "      ( "
                    + "      SELECT "
                    + "        filecop.filedescriptivemetadataid AS filecopid, "
                    + "        filecop.filename AS filecopname, "
                    + "        contactoperationalprofile.* "
                    + "      FROM "
                    + "        omega.contactoperationalprofile "
                    + "        LEFT JOIN omega.metacard_contactoperationalprofile "
                    + "          ON contactoperationalprofile.contactoperationalprofileid = metacard_contactoperationalprofile.contactoperationalprofileid "
                    + "        LEFT JOIN omega.mdf_catalog_tab "
                    + "          ON metacard_contactoperationalprofile.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.metacard_filedescriptivemetadata "
                    + "          ON metacard_filedescriptivemetadata.metacardid = mdf_catalog_tab.catalog_id "
                    + "        LEFT JOIN omega.filedescriptivemetadata AS filecop "
                    + "          ON filecop.filedescriptivemetadataid = metacard_filedescriptivemetadata.filedescriptivemetadataid "
                    + "      WHERE "
                    + "        filecop.filedescriptivemetadataid != ''       "
                    + "      ) AS cop "
                    + "    ON "
                    + "      ( "
                    + "      cop.contactofinterestsegmentsumm_2 = coiss.contactsegmentid "
                    + "      AND filecopid = filecoi.filedescriptivemetadataid "
                    + "      ) "
                    + "WHERE "
                    + "  filecoi.filedescriptivemetadataid != '' "
                    + "  AND COALESCE (ccs.sourceoriginname, ccs.userlabel, ccs.sourcecategory,  "
                    + "                TO_CHAR(cop.reductionratio), TO_CHAR(bladesperpropeller),  "
                    + "                cop.propellerlocation, cop.enginetype, cop.enginelocation) != '' "
                    + "ORDER BY " + "  parentPlatformClass ASC, " + "  parentPlatformName ASC, "
                    + "  parentHullNumber ASC, " + "  sourceOriginName ASC, " + "  userLabel ASC, "
                    + "  harmonic ASC;";

    private IsdFrequencyIdentifierPojo mPojo;
    private List<IsdFrequencyIdentifierPojo> mPojos;

    /**
     * @throws SQLException
     */
    public FrequencyIdentifierMigrationManager() throws SQLException {
        mTableType = EIsdTableNames.FREQUENCY_IDENTIFIER;
        mIsdConn = EtlUtilitiesDbms.getISDConnection();
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws SQLException {
        mPojos = new ArrayList<>();

        while (pResults.next()) {
            mPojo = new IsdFrequencyIdentifierPojo();

            mPojo.setParentPlatformClass(formatEnumString(pResults.getString("parentplatformclass")));
            mPojo.setParentPlatformName(formatEnumString(pResults.getString("parentPlatformName")));
            mPojo.setParentHullNumber(pResults.getString("parenthullnumber"));

            mPojo.setSourceOriginName(pResults.getString("sourceOriginName"));
            mPojo.setUserLabel(pResults.getString("userLabel"));
            mPojo.setSourceCatagory(pResults.getString("sourceCatagory"));
            mPojo.setHarmonic(pResults.getInt("harmonic"));
            mPojo.setTurnsperknot(pResults.getInt("turnsperknot"));
            mPojo.setReductionratio(pResults.getDouble("reductionratio"));
            mPojo.setBladesperpropeller(pResults.getInt("numberOfBlades"));
            mPojo.setPropellerlocation(pResults.getString("propellerlocation"));
            mPojo.setEnginetype(pResults.getString("enginetype"));
            mPojo.setEnginelocation(pResults.getString("enginelocation"));

            setMandatorySecurity(pResults, mPojo.getSecurity());

            mPojos.add(mPojo);
        }
        mMetrics.setTotalRecords(mPojos.size());
    }

    @Override
    protected void createHandlers() {
        mHandlerQueue = new ConcurrentLinkedQueue<>();
        for (IsdFrequencyIdentifierPojo pojo: mPojos) {
            mHandlerQueue.add(new FrequencyIdentifierHandler(pojo));
        }
    }

    @Override
    protected String getQuery() {
        return GET_FREQUENCY_INDENTIFIER;
    }
}
