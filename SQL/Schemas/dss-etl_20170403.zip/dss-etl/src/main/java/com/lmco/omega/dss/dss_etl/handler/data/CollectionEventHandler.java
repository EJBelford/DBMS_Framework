/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;
import java.sql.Statement;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCollectionEventPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.collectionevent.CollectionEventCoalesce;
import com.lmco.omega.ecm.interfaces.model.CollectionEvent;
import com.lmco.omega.ecm.interfaces.model.Coordinate;

/**
 * @author bearyman
 */
public class CollectionEventHandler extends AbstractDataHandler {

    private static final String GET_ASSOC_CASE_IDS = "SELECT hjvalue "
            + "FROM omega.collectionevent_associatedca_0 " + "WHERE collectioneventid = '%s'";
    private static final String GET_ASSOC_REEL_INFO_IDS = "SELECT hjvalue "
            + "FROM omega.collectionevent_associatedre_0 " + "WHERE collectioneventid = '%s'";
    private static final String GET_ASSOC_REEL_CUT_IDS = "SELECT hjvalue "
            + "FROM omega.collectionevent_associatedre_1 " + "WHERE collectioneventid = '%s'";
    private static final String GET_ASSOC_COLLECTOR_IDS = "SELECT hjvalue "
            + "FROM omega.collectionevent_collectorids " + "WHERE collectioneventid = '%s'";

    private IsdCollectionEventPojo mPojo;

    public CollectionEventHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdCollectionEventPojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("collectioneventid"));
            mPojo.setCollectionAgainstCode(pResults.getString("collectionagainstcode"));
            mPojo.setCollectionAgainstType(pResults.getString("collectionagainsttype"));
            mPojo.setCollectionAgainstTypeCode(pResults.getString("collectionagainsttypecode"));
            mPojo.setCollectionEventLat(pResults.getString("collectioneventlat"));
            mPojo.setCollectionEventLong(pResults.getString("collectioneventlong"));
            mPojo.setCollectionEventRemarks(pResults.getString("collectioneventremarks"));
            mPojo.setCollectionEventTitle(pResults.getString("collectioneventtitle"));
            mPojo.setRelatedCollectionEventId(pResults.getString("relatedcollectioneventid"));
            mPojo.setStartDate(pResults.getTimestamp("startdatetimeitem"));
            mPojo.setStopDate(pResults.getTimestamp("stopdatetimeitem"));
            mPojo.setSwimsCollectionEventId(pResults.getString("swimscollectioneventid"));
            mPojo.setCollectionGeoAreaX1(pResults.getDouble("collectiongeoarea_x1"));
            mPojo.setCollectionGeoAreaX2(pResults.getDouble("collectiongeoarea_x2"));
            mPojo.setCollectionGeoAreaY1(pResults.getDouble("collectiongeoarea_y1"));
            mPojo.setCollectionGeoAreaY2(pResults.getDouble("collectiongeoarea_y2"));

            setMandatorySecurity(pResults, mPojo.getSecurity());
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        CollectionEventCoalesce entity;

        IDataConverter<CollectionEvent, CollectionEventCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(CollectionEvent.class);

        CollectionEvent pojo = converter.constructPojo();

        pojo.setCollectionAgainst(mPojo.getCollectionAgainstCode());
        pojo.setName(mPojo.getCollectionEventTitle() + migrationTag);
        pojo.setStartTime(mPojo.getStartDate());
        pojo.setStopTime(mPojo.getStopDate());
        pojo.setType(mPojo.getCollectionAgainstType());
        pojo.setTypeCode(mPojo.getCollectionAgainstTypeCode());
        pojo.setComments(mPojo.getCollectionEventRemarks());
        Coordinate coordinate = new Coordinate();
        coordinate.setLat(mPojo.getCollectionGeoAreaX1());
        coordinate.setLon(mPojo.getCollectionGeoAreaY1());
        pojo.setUpperLeft(coordinate);
        coordinate = new Coordinate();
        coordinate.setLat(mPojo.getCollectionGeoAreaX2());
        coordinate.setLon(mPojo.getCollectionGeoAreaY2());
        pojo.setLowerRight(coordinate);

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);
        cEntity.setDateCreated(new DateTime(mPojo.getStartDate()));

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            // Link case
            results = stmt.executeQuery(String.format(GET_ASSOC_CASE_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, EtlUtilitiesDbms.getCaseUuid(results.getString(1)),
                             ELinkType.IS_A_PEER_OF, "case", DataObjectLinkActionType.LINK);
            }

            // Link reel info
            results = stmt.executeQuery(String.format(GET_ASSOC_REEL_INFO_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF, "reel info",
                             DataObjectLinkActionType.LINK);
            }

            // Link reel cut
            results = stmt.executeQuery(String.format(GET_ASSOC_REEL_CUT_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF, "reel cut",
                             DataObjectLinkActionType.LINK);
            }

            // Link collectors
            results = stmt.executeQuery(String.format(GET_ASSOC_COLLECTOR_IDS, mKey));

            while (results.next()) {
                linkEntities(mEntityKey, results.getString(1), ELinkType.IS_A_PEER_OF, "collector",
                             DataObjectLinkActionType.LINK);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    @Override
    protected String getCreatedBy() {
        return DSSConstants.SYSTEM_ACCOUNT;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.COLLECTION_EVENT;
    }
}
