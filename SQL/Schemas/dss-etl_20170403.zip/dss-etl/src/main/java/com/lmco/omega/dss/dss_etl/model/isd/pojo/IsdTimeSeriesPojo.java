/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdTimeSeriesPojo {

    private Double a2dConversionFactor;
    private String auditTrail;
    private String bitPrecision;
    private String comments;
    private long mediaId;
    private String mediaMode;
    private int numberOfChannels;
    private Double sampleRate;
    private IsdTimeIntervalPojo timePojo;
    private IsdSensorIdentificationPojo sensorPojo;
    private IsdFileDescriptiveMetadataPojo fdMetadataPojo;

    /**
     *
     */
    public IsdTimeSeriesPojo() {
        timePojo = new IsdTimeIntervalPojo();
        sensorPojo = new IsdSensorIdentificationPojo();
        fdMetadataPojo = new IsdFileDescriptiveMetadataPojo();
    }

    /**
     * @return the a2dConversionFactor
     */
    public Double getA2dConversionFactor() {
        return a2dConversionFactor;
    }

    /**
     * @param a2dConversionFactor
     *            the a2dConversionFactor to set
     */
    public void setA2dConversionFactor(Double a2dConversionFactor) {
        this.a2dConversionFactor = a2dConversionFactor;
    }

    /**
     * @return the auditTrail
     */
    public String getAuditTrail() {
        return auditTrail;
    }

    /**
     * @param auditTrail
     *            the auditTrail to set
     */
    public void setAuditTrail(String auditTrail) {
        this.auditTrail = auditTrail;
    }

    /**
     * @return the bitPrecision
     */
    public String getBitPrecision() {
        return bitPrecision;
    }

    /**
     * @param bitPrecision
     *            the bitPrecision to set
     */
    public void setBitPrecision(String bitPrecision) {
        this.bitPrecision = bitPrecision;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the mediaId
     */
    public long getMediaId() {
        return mediaId;
    }

    /**
     * @param mediaId
     *            the mediaId to set
     */
    public void setMediaId(long mediaId) {
        this.mediaId = mediaId;
    }

    /**
     * @return the mediaMode
     */
    public String getMediaMode() {
        return mediaMode;
    }

    /**
     * @param mediaMode
     *            the mediaMode to set
     */
    public void setMediaMode(String mediaMode) {
        this.mediaMode = mediaMode;
    }

    /**
     * @return the numberOfChannels
     */
    public int getNumberOfChannels() {
        return numberOfChannels;
    }

    /**
     * @param numberOfChannels
     *            the numberOfChannels to set
     */
    public void setNumberOfChannels(int numberOfChannels) {
        this.numberOfChannels = numberOfChannels;
    }

    /**
     * @return the sampleRate
     */
    public Double getSampleRate() {
        return sampleRate;
    }

    /**
     * @param sampleRate
     *            the sampleRate to set
     */
    public void setSampleRate(Double sampleRate) {
        this.sampleRate = sampleRate;
    }

    /**
     * @return the timePojo
     */
    public IsdTimeIntervalPojo getTimePojo() {
        return timePojo;
    }

    /**
     * @param timePojo
     *            the timePojo to set
     */
    public void setTimePojo(IsdTimeIntervalPojo timePojo) {
        this.timePojo = timePojo;
    }

    /**
     * @return the sensorPojo
     */
    public IsdSensorIdentificationPojo getSensorPojo() {
        return sensorPojo;
    }

    /**
     * @param sensorPojo
     *            the sensorPojo to set
     */
    public void setSensorPojo(IsdSensorIdentificationPojo sensorPojo) {
        this.sensorPojo = sensorPojo;
    }

    /**
     * @return the fdMetadataPojo
     */
    public IsdFileDescriptiveMetadataPojo getFdMetadataPojo() {
        return fdMetadataPojo;
    }

    /**
     * @param fdMetadataPojo
     *            the fdMetadataPojo to set
     */
    public void setFdMetadataPojo(IsdFileDescriptiveMetadataPojo fdMetadataPojo) {
        this.fdMetadataPojo = fdMetadataPojo;
    }

}
