/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lmco.omega.dss.dss_etl.EtlMigrateIsd2Fsd;

/**
 * Wrapper for log4j logger. Will also print information to output or error stream.
 * XXX Could be modified to take in output stream in constructor.
 *
 * @author bearyman
 */
public class MigrationLoggerWrapper {

    private static Logger LOGGER;

    public MigrationLoggerWrapper(Class pClass) {
        LOGGER = LoggerFactory.getLogger(pClass);
    }

    public void debug(String msg) {
        debug(msg, null);
    }

    public void debug(String msg, Throwable e) {
        LOGGER.debug(msg, e);
        if (LOGGER.isDebugEnabled()) {
            displayLog(msg);
        }
    }

    public void info(String msg) {
        info(msg, null);
    }

    public void info(String msg, Throwable e) {
        LOGGER.info(msg, e);
        if (LOGGER.isInfoEnabled()) {
            displayLog(msg);
        }
    }

    public void trace(String msg) {
        trace(msg, null);
    }

    public void trace(String msg, Throwable e) {
        LOGGER.trace(msg, e);
        if (LOGGER.isTraceEnabled()) {
            displayLog(msg);
        }
    }

    public void warn(String msg) {
        warn(msg, null);
    }

    public void warn(String msg, Throwable e) {
        LOGGER.warn(msg, e);
        if (LOGGER.isWarnEnabled()) {
            displayLog(msg);
        }
    }

    public void error(String msg) {
        error(msg, null);
    }

    public void error(String msg, Throwable e) {
        LOGGER.error(msg, e);
        if (LOGGER.isErrorEnabled()) {
            EtlMigrateIsd2Fsd.writeErrorPrintStream(msg);
        }
    }

    private void displayLog(String log) {
        EtlMigrateIsd2Fsd.writeOutputPrintStream(log);
    }
}
