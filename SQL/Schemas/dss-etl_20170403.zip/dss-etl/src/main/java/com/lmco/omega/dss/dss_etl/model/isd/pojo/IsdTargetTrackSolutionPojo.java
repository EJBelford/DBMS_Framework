/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdTargetTrackSolutionPojo {

    private Double maxDepth;
    private Double minDepth;
    private Double maxRange;
    private Double minRange;
    private Double maxSpeed;
    private Double minSpeed;
    private String trackSolutionSource;
    private IsdTimeIntervalPojo timePojo;
    private IsdFileDescriptiveMetadataPojo fdMetadataPojo;

    /**
     *
     */
    public IsdTargetTrackSolutionPojo() {
        timePojo = new IsdTimeIntervalPojo();
        fdMetadataPojo = new IsdFileDescriptiveMetadataPojo();
    }

    /**
     * @return the maxDepth
     */
    public Double getMaxDepth() {
        return maxDepth;
    }

    /**
     * @param maxDepth
     *            the maxDepth to set
     */
    public void setMaxDepth(Double maxDepth) {
        this.maxDepth = maxDepth;
    }

    /**
     * @return the minDepth
     */
    public Double getMinDepth() {
        return minDepth;
    }

    /**
     * @param minDepth
     *            the minDepth to set
     */
    public void setMinDepth(Double minDepth) {
        this.minDepth = minDepth;
    }

    /**
     * @return the maxRange
     */
    public Double getMaxRange() {
        return maxRange;
    }

    /**
     * @param maxRange
     *            the maxRange to set
     */
    public void setMaxRange(Double maxRange) {
        this.maxRange = maxRange;
    }

    /**
     * @return the minRange
     */
    public Double getMinRange() {
        return minRange;
    }

    /**
     * @param minRange
     *            the minRange to set
     */
    public void setMinRange(Double minRange) {
        this.minRange = minRange;
    }

    /**
     * @return the maxSpeed
     */
    public Double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * @param maxSpeed
     *            the maxSpeed to set
     */
    public void setMaxSpeed(Double maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    /**
     * @return the minSpeed
     */
    public Double getMinSpeed() {
        return minSpeed;
    }

    /**
     * @param minSpeed
     *            the minSpeed to set
     */
    public void setMinSpeed(Double minSpeed) {
        this.minSpeed = minSpeed;
    }

    /**
     * @return the trackSolutionSource
     */
    public String getTrackSolutionSource() {
        return trackSolutionSource;
    }

    /**
     * @param trackSolutionSource
     *            the trackSolutionSource to set
     */
    public void setTrackSolutionSource(String trackSolutionSource) {
        this.trackSolutionSource = trackSolutionSource;
    }

    /**
     * @return the timePojo
     */
    public IsdTimeIntervalPojo getTimePojo() {
        return timePojo;
    }

    /**
     * @param timePojo
     *            the timePojo to set
     */
    public void setTimePojo(IsdTimeIntervalPojo timePojo) {
        this.timePojo = timePojo;
    }

    /**
     * @return the fdMetadataPojo
     */
    public IsdFileDescriptiveMetadataPojo getFdMetadataPojo() {
        return fdMetadataPojo;
    }

    /**
     * @param fdMetadataPojo
     *            the fdMetadataPojo to set
     */
    public void setFdMetadataPojo(IsdFileDescriptiveMetadataPojo fdMetadataPojo) {
        this.fdMetadataPojo = fdMetadataPojo;
    }

}
