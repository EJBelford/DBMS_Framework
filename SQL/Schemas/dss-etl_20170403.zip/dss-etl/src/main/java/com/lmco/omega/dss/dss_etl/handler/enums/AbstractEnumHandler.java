/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.enums;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdEnumerationNames;
import com.lmco.omega.dss.dss_etl.model.EnumMigrationResult;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;
import com.lmco.omega.dss.interfaces.enumerationmanager.AssociatedEnumValue;
import com.lmco.omega.dss.interfaces.enumerationmanager.EEnumerationDataTypes;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author bearyman
 */
public abstract class AbstractEnumHandler implements Callable<EnumMigrationResult> {

    protected static final String GET_ENUM_SQL = "SELECT enumvalues FROM omega.%s";
    protected static final String ENUM_ADD_FAILED = "Failed to add %s enumeration with value (%s)";
    protected static final String ASSOC_ENUM_ADD_FAILED =
            "Failed to add associated enumeration to %s with value (%s)";
    protected static final String ENUM_EXISTS_ERR =
            "Enum value (%s) already exists in %s enumeration";
    protected static final String NOT_APPLICABLE = "NOT_APPLICABLE";

    private static final String GET_NEXT_ORDER_SQL =
            "select max(ordering)+1 as nextorder from coalesce.enumvalue where enumtype = '%s'";
    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            AbstractEnumHandler.class);

    protected String methodName;
    protected EnumMigrationResult mResult;
    protected Connection mIsdConn;
    protected Connection mFsdConn;
    protected EIsdEnumerationNames mEnumName;
    protected boolean validateOnlyFlag;

    @Override
    public EnumMigrationResult call() {
        mResult = new EnumMigrationResult();

        try {
            validateOnlyFlag = false;
            String validateVal = EtlUtilities.getEtlConfigValue("validateOnlyFlag");
            if (!StringHelper.isNullOrEmpty(validateVal) && validateVal.equals("1")) {
                validateOnlyFlag = true;
            }

            mIsdConn = EtlUtilitiesDbms.getISDConnection();
            mFsdConn = EtlUtilitiesDbms.getFSDConnection();

            executeCall();
            mResult.setSuccessful(true);
        } catch (Exception e1) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, methodName, e1.getMessage());
            logError(errMsg, e1);
            mResult.setResult(errMsg);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(mIsdConn);
                EtlUtilitiesDbms.closeConn(mFsdConn);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }

        return mResult;
    }

    protected List<String> retriveIsdEnum(String pIsdTableName) throws SQLException {
        methodName = "retriveIsdEnum";
        ResultSet results = null;
        Statement stmt = null;
        List<String> enumList = new ArrayList<>();

        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ENUM_SQL, pIsdTableName));

            while (results.next()) {
                enumList.add(results.getString("enumvalues"));
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return enumList;
    }

    protected void validateEnum(String pIsdTableName, String pIsdEnumStr, String pFsdTableName,
            String pFsdEnumStr) {
        printEnum(pIsdTableName, pIsdEnumStr, pFsdTableName, pFsdEnumStr);
    }

    protected String formatEnumString(String pEnumStr) {
        String formattedEnum = NOT_APPLICABLE;
        if (!StringHelper.isNullOrEmpty(pEnumStr)) {
            formattedEnum = pEnumStr.replaceAll("[^a-zA-Z0-9]", "_");
            formattedEnum = formattedEnum.replaceAll("[_]+", "_").toUpperCase();

            if (formattedEnum.endsWith("_")) {
                formattedEnum = formattedEnum.substring(0, formattedEnum.length() - 1);
            }
        }

        return formattedEnum;
    }

    protected void printEnum(String pIsdTableName, String pIsdEnumStr, String pFsdTableName,
            String pFsdEnumStr) {
        StringBuilder builder = new StringBuilder("ISD Table: ");
        builder.append(pIsdTableName).append(" ISD Enum: ").append(pIsdEnumStr)
                .append(", FSD Table: ").append(pFsdTableName).append(", FSD Enum: ")
                .append(pFsdEnumStr);

        LOGGER.debug(builder.toString());
    }

    protected void logError(String pMessage, Exception pException) {
        if (pException != null) {
            LOGGER.error(pMessage, pException);
        } else {
            LOGGER.error(pMessage);
        }
        LOGGER.error(pMessage);
    }

    protected int getNextOrderingValue(String pFsdTableName) throws SQLException {
        methodName = "getNextOrderingValue";
        ResultSet results = null;
        Statement stmt = null;
        int order = 0;

        try {
            stmt = mFsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_NEXT_ORDER_SQL, pFsdTableName));

            while (results.next()) {
                order = results.getInt("nextorder");
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return order;
    }

    protected void handleEnum(String pIsdTableName, String pIsdEnum, String pFsdTableName,
            String pFormattedFsdEnum, Enumeration pFsdEnumeration) throws SQLException,
            DSSPersisterNotInitializedException {
        MigrationResult result = new MigrationResult();
        if (validateOnlyFlag) {
            validateEnum(pIsdTableName, pIsdEnum, pFsdTableName, pFormattedFsdEnum);
        } else {

            boolean enumExists = false;
            for (EnumerationValue enumVal: pFsdEnumeration.getEnumValues()) {
                if (enumVal.getEnumValue().equals(pFormattedFsdEnum)) {
                    enumExists = true;
                    break;
                }
            }
            if (enumExists) {
                LOGGER.debug(String.format(ENUM_EXISTS_ERR, pFormattedFsdEnum, pFsdTableName));
            } else {
                // Add enumeration value to enumeration
                if (addEnumValue(mEnumName.getFsdTableName(), pFormattedFsdEnum, pIsdEnum)) {
                    EtlUtilitiesDbms.insertClearList(mFsdConn,
                                                     getEnumUUID(mEnumName.getFsdTableName(),
                                                                 pFormattedFsdEnum), methodName,
                                                     mEnumName + "_"
                                                             + this.getClass().getSimpleName());
                    result.setSaveSuccessful(true);
                    if (!addAssociatedEnumValue(mEnumName.getFsdTableName(), pFormattedFsdEnum,
                                                pIsdEnum)) {
                        result.addResult(String.format(ASSOC_ENUM_ADD_FAILED, pFormattedFsdEnum,
                                                       pIsdEnum));
                    }
                } else {
                    result.addResult(String.format(ENUM_ADD_FAILED, mEnumName.getFsdTableName(),
                                                   pFormattedFsdEnum));
                }
            }
        }
        mResult.addMigrationResult(result);
    }

    protected boolean addEnumValue(String pFsdTableName, String pEnumValue, String pDescription)
            throws SQLException, DSSPersisterNotInitializedException {
        boolean success = false;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);

        // Create new enumeration value
        EnumerationValue enumValue = new EnumerationValue();
        enumValue.setEnumValue(pEnumValue);
        enumValue.setConstant(false);
        enumValue.setDescription(pDescription);
        enumValue.setEnumType(enumeration.getEnumType());
        enumValue.setHidden(false);
        enumValue.setOrdering(getNextOrderingValue(pFsdTableName));

        enumeration.getEnumValues().add(enumValue);

        // Add enumeration value to enumeration
        if (CoalesceFrameworkUtil.updateEnumeration(enumeration, DSSConstants.SYSTEM_ACCOUNT)) {
            success = true;
        }

        return success;
    }

    protected boolean addAssociatedEnumValue(String pFsdTableName, String pEnumValue,
            String pAssocEnumValue) throws DSSPersisterNotInitializedException {
        boolean success = false;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);
        EnumerationValue enumValue = null;
        for (EnumerationValue enumVal: enumeration.getEnumValues()) {
            if (enumVal.getEnumValue().equals(pEnumValue)) {
                enumValue = enumVal;
                break;
            }
        }

        if (enumValue != null) {
            AssociatedEnumValue assocEnumValue = new AssociatedEnumValue();
            String assocEnumStr = pAssocEnumValue;
            if (pEnumValue.equals(NOT_APPLICABLE)) {
                assocEnumStr = "";
            }
            assocEnumValue.setAssociatedEnumValue(assocEnumStr);
            assocEnumValue.setConstant(false);
            assocEnumValue.setDataType(EEnumerationDataTypes.STRING_TYPE);
            assocEnumValue.setEnumType(enumeration.getEnumType());
            assocEnumValue.setEnumValueUuid(enumValue.getUuid());
            assocEnumValue.setValueDescriptor("name");
            enumValue.getAssociatedEnumValues().add(assocEnumValue);

            enumeration.getEnumValues().add(enumValue);

            // Add enumeration value to enumeration
            if (CoalesceFrameworkUtil.updateEnumeration(enumeration, DSSConstants.SYSTEM_ACCOUNT)) {
                success = true;
            }
        }

        return success;
    }

    protected String getEnumUUID(String pFsdTableName, String pEnumValue)
            throws DSSPersisterNotInitializedException {
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);
        String uuid = null;
        for (EnumerationValue enumVal: enumeration.getEnumValues()) {
            if (enumVal.getEnumValue().equals(pEnumValue)) {
                uuid = enumVal.getUuid();
                break;
            }
        }
        return uuid;
    }

    protected abstract void executeCall() throws Exception;
}
