/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.enums;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdEnumerationNames;
import com.lmco.omega.dss.dss_etl.model.MigrationResult;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author bearyman
 */
public class SplEnumHandler extends AbstractEnumHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            SplEnumHandler.class);
    protected static final String GET_SPL_ENUM_SQL = "SELECT * FROM omega.%s";

    /**
     *
     */
    public SplEnumHandler(final EIsdEnumerationNames pEnumName) {
        mEnumName = pEnumName;
    }

    @Override
    protected void executeCall() throws Exception {
        // Retrieve enum values
        List<SplEnumPojo> enumPojoList = retriveIsdSplEnum();

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(mEnumName.getFsdTableName(),
                                                     DSSConstants.SYSTEM_ACCOUNT);

        if (enumeration != null) {

            // Format enum
            for (SplEnumPojo enumPojo: enumPojoList) {
                MigrationResult result = new MigrationResult();

                String formattedEnum = formatEnumString(enumPojo.getEnumValue());

                if (validateOnlyFlag) {
                    validateEnum(mEnumName.getIsdTableName(), enumPojo.getEnumValue(),
                                 mEnumName.getFsdTableName(), formattedEnum);
                } else {

                    boolean enumExists = false;
                    for (EnumerationValue enumVal: enumeration.getEnumValues()) {
                        if (enumVal.getEnumValue().equals(formattedEnum)) {
                            enumExists = true;
                            break;
                        }
                    }
                    if (enumExists) {
                        LOGGER.debug(String.format(ENUM_EXISTS_ERR, formattedEnum,
                                                   mEnumName.getFsdTableName()));
                    } else {
                        // Add enumeration value to enumeration
                        if (addEnumValue(mEnumName.getFsdTableName(), formattedEnum,
                                         enumPojo.getEnumDescription())) {
                            EtlUtilitiesDbms
                                    .insertClearList(mFsdConn,
                                                     getEnumUUID(mEnumName.getFsdTableName(),
                                                                 formattedEnum), methodName,
                                                     mEnumName + "_"
                                                             + this.getClass().getSimpleName());
                            result.setSaveSuccessful(true);

                            if (!addAssociatedEnumValue(mEnumName.getFsdTableName(), formattedEnum,
                                                        enumPojo.enumValue)) {
                                result.addResult(String.format(ASSOC_ENUM_ADD_FAILED,
                                                               formattedEnum, enumPojo.enumValue));
                            }
                        } else {
                            result.addResult(String.format(ENUM_ADD_FAILED,
                                                           mEnumName.getFsdTableName(),
                                                           formattedEnum));
                        }
                    }
                }
                mResult.addMigrationResult(result);
            }
        } else {
            throw new SQLException(String.format(DSSConstants.ENUMERATION_NOT_FOUND,
                                                 mEnumName.getFsdTableName()));
        }

    }

    protected List<SplEnumPojo> retriveIsdSplEnum() throws SQLException {
        methodName = "retriveIsdSplEnum";
        ResultSet results = null;
        Statement stmt = null;
        List<SplEnumPojo> enumList = new ArrayList<>();

        try {
            stmt = mIsdConn.createStatement();

            results =
                    stmt.executeQuery(String.format(GET_SPL_ENUM_SQL, mEnumName.getIsdTableName()));

            while (results.next()) {
                SplEnumPojo pojo = new SplEnumPojo();
                pojo.setEnumValue(results.getString("enumvalues"));
                pojo.setEnumDescription(results.getString("enumdescription"));
                enumList.add(pojo);
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return enumList;
    }

    private class SplEnumPojo {

        private String enumValue;
        private String enumDescription;

        /**
         *
         */
        public SplEnumPojo() {}

        /**
         * @return the enumValue
         */
        public String getEnumValue() {
            return enumValue;
        }

        /**
         * @param enumValue
         *            the enumValue to set
         */
        public void setEnumValue(String enumValue) {
            this.enumValue = enumValue;
        }

        /**
         * @return the enumDescription
         */
        public String getEnumDescription() {
            return enumDescription;
        }

        /**
         * @param enumDescription
         *            the enumDescription to set
         */
        public void setEnumDescription(String enumDescription) {
            this.enumDescription = enumDescription;
        }
    }
}
