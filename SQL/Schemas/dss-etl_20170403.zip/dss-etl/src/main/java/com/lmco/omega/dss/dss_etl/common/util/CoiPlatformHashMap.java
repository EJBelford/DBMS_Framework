/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.sql.SQLException;
import java.util.HashMap;

import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;

/**
 * @author n67154 (Gene Belford - InCadence)
 */

public class CoiPlatformHashMap {

    public static HashMap<String, String> coiPlatformCache = new HashMap<String, String>();

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EnumerationPropertyFileUtil.class);

    private static final String PLAT_CLASS_NAME = "platformclassname";

    // private String methodName = null;

    public CoiPlatformHashMap() throws SQLException {}

    public static String getPlatformClassKey(String pPlatformName, String pHullNumber)
            throws Exception {
        String mEntityKey = null;

        System.out.println("getPlatformClassKey: pPlatformName: " + pPlatformName
                + " pHullNumber: " + pHullNumber);

        mEntityKey = coiPlatformCache.get(pPlatformName + "_" + pHullNumber);

        return mEntityKey;
    }

    // private int convertClassName(String pPlatformClassName)
    // throws DSSPersisterNotInitializedException {
    // int orderingNum = -1;
    //
    // // Retrieve enumeration from DB
    // Enumeration enumeration =
    // CoalesceFrameworkUtil.getEnumeration(PLAT_CLASS_NAME, DSSConstants.SYSTEM_ACCOUNT);
    //
    // if (enumeration != null) {
    //
    // for (EnumerationValue enumVal: enumeration.getEnumValues()) {
    // if (enumVal.getEnumValue().equals(pPlatformClassName)) {
    // orderingNum = enumVal.getOrdering();
    // break;
    // }
    // }
    // }
    // return orderingNum;
    // }

    // private void handleFsdResults(ResultSet pResults) throws SQLException {
    // methodName = "handleIsdResults";
    //
    // String mEntityKey;
    // String mName;
    // String mHullNum;
    //
    // int recLoop = 0;
    //
    // while (pResults.next()) {
    // recLoop++;
    //
    // mEntityKey = pResults.getString("entitykey");
    // mName = pResults.getString("name");
    // mHullNum = pResults.getString("hullNumber");
    //
    // coiPlatformCache.put(mName + "_" + mHullNum, mEntityKey);
    // coiPlatformCache.get(mName + "_" + mHullNum);
    //
    // LOGGER.debug("CoiPlatformHashMap" + "_" + methodName + ": #: " + recLoop
    // + " mEntityKey: " + mEntityKey + " mNamemHullNum: " + mName + "_" + mHullNum);
    // LOGGER.debug("CoiPlatformHashMap" + "_" + methodName + ": #: " + recLoop
    // + " coiPlatformCache.get: " + coiPlatformCache.get(mName + "_" + mHullNum));
    // }
    // }
}
