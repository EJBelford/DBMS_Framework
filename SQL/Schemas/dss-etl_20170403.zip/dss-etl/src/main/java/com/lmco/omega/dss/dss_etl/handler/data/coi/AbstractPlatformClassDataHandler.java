/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data.coi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.handler.AbstractHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdPlatformClassPojo;
import com.lmco.omega.dss.interfaces.enumerationmanager.AssociatedEnumValue;
import com.lmco.omega.dss.interfaces.enumerationmanager.EEnumerationDataTypes;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.platformclass.PlatformClassCoalesce;
import com.lmco.omega.ecm.interfaces.model.PlatformClass;

/**
 * @author bearyman
 */
public abstract class AbstractPlatformClassDataHandler extends AbstractHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            AbstractPlatformClassDataHandler.class);
    private static final String PLAT_CLASS_NAME = "platformclassname";
    private static final String GET_PLAT_CLASS_ID =
            "select entitykey from coalesce.platform_class_record where classificationname = '%s'";
    private static final String VERSIONING_FAILED = "Failed to version platform class ID (%s).";
    private static final String VERSIONING_ERR = VERSIONING_FAILED + " Reason: %s";
    private static final String ENUM_EXISTS_ERR =
            "Enum value (%s) already exists in %s enumeration";
    private static final String ENUM_ADD_FAILED = "Failed to add %s enumeration with value (%s)";
    private static final String ASSOC_ENUM_ADD_FAILED =
            "Failed to add associated enumeration to %s with value (%s)";
    private static final String GET_NEXT_ORDER_SQL =
            "select max(ordering)+1 as nextorder from coalesce.enumvalue where enumtype = '%s'";

    private static final String GET_PLATFORM_CLASSIFICATION_COUNT =
            "SELECT COUNT(pcr.classificationname) FROM coalesce.platform_class_record pcr "
                    + "WHERE pcr.classificationname = '%s'; ";

    protected IsdPlatformClassPojo mPojo;

    @Override
    public void executeCall() throws Exception {

        createPedigree();
        CoalesceEntity entity = mapToCoalesce();

        if (validationMode) {
            validateEntity(entity);
        } else {
            if (!entityExists()) {
                if (saveEntity(entity)) {
                    createEnum();
                    savePedigree(entity.getKey());
                    createLinkages();
                }
            } else {
                versionEntity(entity);
            }
        }
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        // DO NOTHING
    }

    protected boolean addEnumValue(String pFsdTableName, String pEnumValue, String pDescription)
            throws SQLException, DSSPersisterNotInitializedException {
        boolean success = false;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);

        // Create new enumeration value
        EnumerationValue enumValue = new EnumerationValue();
        enumValue.setEnumValue(pEnumValue);
        enumValue.setConstant(false);
        enumValue.setDescription(pDescription);
        enumValue.setEnumType(enumeration.getEnumType());
        enumValue.setHidden(false);
        enumValue.setOrdering(getNextOrderingValue(pFsdTableName));

        enumeration.getEnumValues().add(enumValue);

        // Add enumeration value to enumeration
        if (CoalesceFrameworkUtil.updateEnumeration(enumeration, DSSConstants.SYSTEM_ACCOUNT)) {
            success = true;
        }

        return success;
    }

    protected boolean addAssociatedEnumValue(String pFsdTableName, String pEnumValue,
            String pAssocEnumValue) throws DSSPersisterNotInitializedException {
        boolean success = false;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);
        EnumerationValue enumValue = null;
        for (EnumerationValue enumVal: enumeration.getEnumValues()) {
            if (enumVal.getEnumValue().equals(pEnumValue)) {
                enumValue = enumVal;
                break;
            }
        }

        if (enumValue != null) {
            AssociatedEnumValue assocEnumValue = new AssociatedEnumValue();
            String assocEnumStr = pAssocEnumValue;
            assocEnumValue.setAssociatedEnumValue(assocEnumStr);
            assocEnumValue.setConstant(false);
            assocEnumValue.setDataType(EEnumerationDataTypes.STRING_TYPE);
            assocEnumValue.setEnumType(enumeration.getEnumType());
            assocEnumValue.setEnumValueUuid(enumValue.getUuid());
            assocEnumValue.setValueDescriptor("name");
            enumValue.getAssociatedEnumValues().add(assocEnumValue);

            enumeration.getEnumValues().add(enumValue);

            // Add enumeration value to enumeration
            if (CoalesceFrameworkUtil.updateEnumeration(enumeration, DSSConstants.SYSTEM_ACCOUNT)) {
                success = true;
            }
        }

        return success;
    }

    protected int getNextOrderingValue(String pFsdTableName) throws SQLException {
        methodName = "getNextOrderingValue";
        ResultSet results = null;
        Statement stmt = null;
        int order = 0;

        try {
            stmt = mFsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_NEXT_ORDER_SQL, pFsdTableName));

            while (results.next()) {
                order = results.getInt("nextorder");
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return order;
    }

    protected String getEnumUUID(String pFsdTableName, String pEnumValue)
            throws DSSPersisterNotInitializedException {
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(pFsdTableName, DSSConstants.SYSTEM_ACCOUNT);
        String uuid = null;
        for (EnumerationValue enumVal: enumeration.getEnumValues()) {
            if (enumVal.getEnumValue().equals(pEnumValue)) {
                uuid = enumVal.getUuid();
                break;
            }
        }
        return uuid;
    }

    private boolean entityExists() throws DSSPersisterNotInitializedException {
        boolean exists = false;

        // Verify that the platform class does not exist in FSD
        int orderingNum = getPlatClassEnumOrderingNumber(mPojo.getClassificationName());
        if (orderingNum > -1) {
            int entityCnt = 0;
            entityCnt = getEntityCount(orderingNum);
            if (entityCnt > 0) {
                exists = true;
            }
        }

        return exists;
    }

    private int getPlatClassEnumOrderingNumber(String pClassName)
            throws DSSPersisterNotInitializedException {
        int orderingNum = -1;

        // Retrieve enumeration from DB
        Enumeration enumeration =
                CoalesceFrameworkUtil.getEnumeration(PLAT_CLASS_NAME, DSSConstants.SYSTEM_ACCOUNT);

        if (enumeration != null) {
            for (EnumerationValue enumVal: enumeration.getEnumValues()) {
                if (enumVal.getEnumValue().equals(pClassName)) {
                    orderingNum = enumVal.getOrdering();
                    break;
                }
            }
        }

        return orderingNum;
    }

    private void createEnum() {

        try {
            // Retrieve enumeration from DB
            Enumeration enumeration =
                    CoalesceFrameworkUtil.getEnumeration(PLAT_CLASS_NAME,
                                                         DSSConstants.SYSTEM_ACCOUNT);

            if (enumeration != null) {

                boolean enumExists = false;
                for (EnumerationValue enumVal: enumeration.getEnumValues()) {
                    if (enumVal.getEnumValue().equals(mPojo.getClassificationName())) {
                        enumExists = true;
                        break;
                    }
                }
                if (enumExists) {
                    String errMsg =
                            String.format(ENUM_EXISTS_ERR, mPojo.getClassificationName(),
                                          PLAT_CLASS_NAME);
                    LOGGER.error(errMsg, null);
                } else {
                    // Add enumeration value to enumeration
                    if (addEnumValue(PLAT_CLASS_NAME, mPojo.getClassificationName(),
                                     mPojo.getClassificationName())) {
                        EtlUtilitiesDbms
                                .insertClearList(mFsdConn,
                                                 getEnumUUID(PLAT_CLASS_NAME,
                                                             mPojo.getClassificationName()),
                                                 methodName, PLAT_CLASS_NAME + "_"
                                                         + this.getClass().getSimpleName());
                        if (!addAssociatedEnumValue(PLAT_CLASS_NAME, mPojo.getClassificationName(),
                                                    mPojo.getClassificationName())) {
                            String errMsg =
                                    String.format(ASSOC_ENUM_ADD_FAILED,
                                                  mPojo.getClassificationName(),
                                                  mPojo.getClassificationName());
                            LOGGER.error(errMsg, null);
                            mResult.addResult(errMsg);
                        }
                    } else {
                        String errMsg =
                                String.format(ENUM_ADD_FAILED, mPojo.getClassificationName(),
                                              mPojo.getClassificationName());
                        LOGGER.error(errMsg, null);
                        mResult.addResult(errMsg);
                    }
                }

            } else {
                String errMsg = String.format(DSSConstants.ENUMERATION_NOT_FOUND, PLAT_CLASS_NAME);
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }

        } catch (SQLException | DSSPersisterNotInitializedException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "create enumeration",
                                  e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        }
    }

    private int getEntityCount(int pPlatformClassOrdering) {
        Statement stmt = null;
        ResultSet results = null;
        int rowCount = 0;

        try {
            stmt = mFsdConn.createStatement();

            results =
                    stmt.executeQuery(String.format(GET_PLATFORM_CLASSIFICATION_COUNT,
                                                    pPlatformClassOrdering));

            while (results.next()) {
                rowCount = results.getInt(1);
                LOGGER.debug("PlatformClassHandler" + "_" + methodName + " c2: rowCount: "
                        + rowCount);
            }
        } catch (SQLException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "get platform class count",
                                  e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        } finally {
            if (stmt != null) {
                LOGGER.debug("PlatformClassHandler" + "_" + methodName + " d1: #: Finally");
                try {
                    stmt.close();
                } catch (SQLException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                               e.getMessage()), e);
                }
            }
        }
        LOGGER.debug("PlatformClassHandler" + "_" + methodName + " e: rowCount: " + rowCount
                + " Stop");

        return rowCount;
    }

    private void versionEntity(CoalesceEntity pEntity) throws Exception {
        methodName = "versionEntity";
        LOGGER.trace(methodName);
        Statement stmt = null;
        ResultSet results = null;

        try {
            stmt = mFsdConn.createStatement();

            String sql =
                    String.format(GET_PLAT_CLASS_ID,
                                  getPlatClassEnumOrderingNumber(mPojo.getClassificationName()));
            LOGGER.debug("Get plat class entity id sql: " + sql);

            results = stmt.executeQuery(sql);

            String id = null;
            while (results.next()) {
                id = results.getString(1);
            }
            LOGGER.debug("Entity id: " + id);

            if (id != null) {
                PlatformClassCoalesce entity = new PlatformClassCoalesce();
                entity.initialize(CoalesceFrameworkUtil.getEntityXml(id,
                                                                     DSSConstants.SYSTEM_ACCOUNT));

                IDataConverter<PlatformClass, PlatformClassCoalesce> converter =
                        ConverterFactory.INSTANCE.getConverter(PlatformClass.class);
                PlatformClass pojo = converter.constructPojo(entity);
                pojo.setPropellerCount(converter.constructPojo(pEntity).getPropellerCount());
                pojo.setPlatformDesignator(converter.constructPojo(pEntity).getPlatformDesignator());

                entity = converter.constructCoalesce(pojo);

                if (!CoalesceFrameworkUtil
                        .saveAndVersionCoalesceEntity(DSSConstants.SYSTEM_ACCOUNT, null, entity)) {
                    mResult.addResult(String.format(VERSIONING_FAILED, entity.getKey()));
                }
            } else {
                String errMsg = String.format(VERSIONING_ERR, "Null entity key");
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
