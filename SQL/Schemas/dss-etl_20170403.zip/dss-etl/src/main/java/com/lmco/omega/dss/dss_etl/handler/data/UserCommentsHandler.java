/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdUserCommentsPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.usercomments.UserCommentsCoalesce;
import com.lmco.omega.ecm.interfaces.model.UserComments;

/**
 * @author bearyman
 */
public class UserCommentsHandler extends AbstractDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            UserCommentsHandler.class);
    private static final String GET_WF_ID_FOR_ACTIVITY = "SELECT workflowactivityinstances_wo_0 "
            + "FROM omega.workflowactivityinstance WHERE workflowactivityinstanceid = '%s'";
    private IsdUserCommentsPojo mPojo;

    public UserCommentsHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdUserCommentsPojo();

        while (pResults.next()) {
            mPojo.setId(pResults.getString("workflowcommentid"));
            mPojo.setComments(pResults.getString("workflowcomment"));
            mPojo.setWorkflowInstanceId(pResults.getString("workflowusercomments_workflo_0"));
            mPojo.setWorkflowActivityInstanceId(pResults
                    .getString("workflowusercomments_workflo_1"));

            // Get security data from parent record
            if (!StringHelper.isNullOrEmpty(mPojo.getWorkflowInstanceId())) {
                setSecurityWithParentRecord(EIsdTableNames.WORKFLOW_INSTANCE,
                                            mPojo.getWorkflowInstanceId(), mPojo.getSecurity());
            } else {
                setSecurityWithActivity();
            }
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() throws Exception {
        methodName = "mapToCoalesce";
        UserCommentsCoalesce entity;

        IDataConverter<UserComments, UserCommentsCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(UserComments.class);

        UserComments pojo = converter.constructPojo();

        pojo.setComments(mPojo.getComments() + migrationTag);

        if (StringHelper.isNullOrEmpty(pojo.getComments())) {
            pojo.setComments("ETL_Test_UserComment-229(a)");
        }

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";

        if (mPojo.getWorkflowActivityInstanceId() == null) {
            // Link workflow instance
            linkEntities(mEntityKey, mPojo.getWorkflowInstanceId(), ELinkType.IS_OWNED_BY,
                         "workflow instance", DataObjectLinkActionType.LINK);
        } else {
            // Link workflow activity
            linkEntities(mEntityKey, mPojo.getWorkflowActivityInstanceId(), ELinkType.IS_OWNED_BY,
                         "workflow activity instance", DataObjectLinkActionType.LINK);
        }
    }

    @Override
    protected String getCreatedBy() {
        ResultSet results = null;
        Statement stmt = null;
        String createdBy = null;
        try {
            stmt = mIsdConn.createStatement();

            String query;
            if (!StringHelper.isNullOrEmpty(mPojo.getWorkflowInstanceId())) {
                query = String.format(GET_CREATOR_FOR_WF, mPojo.getWorkflowInstanceId());
            } else {
                query = String.format(GET_CREATOR_FOR_WFA, mPojo.getWorkflowActivityInstanceId());
            }

            results = stmt.executeQuery(query);

            if (results.next()) {
                createdBy = results.getString(1);
            }
        } catch (SQLException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "retrieve creator",
                                  e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    String errMsg =
                            String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                          e.getMessage());
                    LOGGER.error(errMsg, e);
                }
            }
        }
        return createdBy;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.WORKFLOW_USER_COMMENTS;
    }

    private void setSecurityWithActivity() throws Exception {
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            results =
                    stmt.executeQuery(String.format(GET_WF_ID_FOR_ACTIVITY,
                                                    mPojo.getWorkflowActivityInstanceId()));

            while (results.next()) {
                setSecurityWithParentRecord(EIsdTableNames.WORKFLOW_INSTANCE, results.getString(1),
                                            mPojo.getSecurity());
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
