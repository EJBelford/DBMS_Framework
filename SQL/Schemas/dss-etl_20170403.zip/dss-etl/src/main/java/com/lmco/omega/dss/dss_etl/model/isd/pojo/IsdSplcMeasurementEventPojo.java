/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdSplcMeasurementEventPojo {

    private int hjid;
    private String caseId;
    private String classification;
    private String contactNumber;
    private String cut;
    private Date eventDate;
    private String eventLocation;
    private String eventName;
    private long measurementEventId;
    private String missionNumber;
    private String omegaProjectId;
    private Date processDate;
    private String processLocation;
    private String processOperator;
    private String reel;
    private Double refLat;
    private Double refLon;
    private String releasable;
    private String remarks;
    private String sensorCode;
    private String unitsType;
    private String gramsSplcId;

    /**
     *
     */
    public IsdSplcMeasurementEventPojo() {}

    /**
     * @return the hjid
     */
    public int getHjid() {
        return hjid;
    }

    /**
     * @param hjid
     *            the hjid to set
     */
    public void setHjid(int hjid) {
        this.hjid = hjid;
    }

    /**
     * @return the caseId
     */
    public String getCaseId() {
        return caseId;
    }

    /**
     * @param caseId
     *            the caseId to set
     */
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    /**
     * @return the classification
     */
    public String getClassification() {
        return classification;
    }

    /**
     * @param classification
     *            the classification to set
     */
    public void setClassification(String classification) {
        this.classification = classification;
    }

    /**
     * @return the contactNumber
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * @param contactNumber
     *            the contactNumber to set
     */
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    /**
     * @return the cut
     */
    public String getCut() {
        return cut;
    }

    /**
     * @param cut
     *            the cut to set
     */
    public void setCut(String cut) {
        this.cut = cut;
    }

    /**
     * @return the eventDate
     */
    public Date getEventDate() {
        return eventDate;
    }

    /**
     * @param eventDate
     *            the eventDate to set
     */
    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    /**
     * @return the eventLocation
     */
    public String getEventLocation() {
        return eventLocation;
    }

    /**
     * @param eventLocation
     *            the eventLocation to set
     */
    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    /**
     * @return the eventName
     */
    public String getEventName() {
        return eventName;
    }

    /**
     * @param eventName
     *            the eventName to set
     */
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    /**
     * @return the measurementEventId
     */
    public long getMeasurementEventId() {
        return measurementEventId;
    }

    /**
     * @param measurementEventId
     *            the measurementEventId to set
     */
    public void setMeasurementEventId(long measurementEventId) {
        this.measurementEventId = measurementEventId;
    }

    /**
     * @return the missionNumber
     */
    public String getMissionNumber() {
        return missionNumber;
    }

    /**
     * @param missionNumber
     *            the missionNumber to set
     */
    public void setMissionNumber(String missionNumber) {
        this.missionNumber = missionNumber;
    }

    /**
     * @return the omegaProjectId
     */
    public String getOmegaProjectId() {
        return omegaProjectId;
    }

    /**
     * @param omegaProjectId
     *            the omegaProjectId to set
     */
    public void setOmegaProjectId(String omegaProjectId) {
        this.omegaProjectId = omegaProjectId;
    }

    /**
     * @return the processDate
     */
    public Date getProcessDate() {
        return processDate;
    }

    /**
     * @param processDate
     *            the processDate to set
     */
    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    /**
     * @return the processLocation
     */
    public String getProcessLocation() {
        return processLocation;
    }

    /**
     * @param processLocation
     *            the processLocation to set
     */
    public void setProcessLocation(String processLocation) {
        this.processLocation = processLocation;
    }

    /**
     * @return the processOperator
     */
    public String getProcessOperator() {
        return processOperator;
    }

    /**
     * @param processOperator
     *            the processOperator to set
     */
    public void setProcessOperator(String processOperator) {
        this.processOperator = processOperator;
    }

    /**
     * @return the reel
     */
    public String getReel() {
        return reel;
    }

    /**
     * @param reel
     *            the reel to set
     */
    public void setReel(String reel) {
        this.reel = reel;
    }

    /**
     * @return the refLat
     */
    public Double getRefLat() {
        return refLat;
    }

    /**
     * @param refLat
     *            the refLat to set
     */
    public void setRefLat(Double refLat) {
        this.refLat = refLat;
    }

    /**
     * @return the refLon
     */
    public Double getRefLon() {
        return refLon;
    }

    /**
     * @param refLon
     *            the refLon to set
     */
    public void setRefLon(Double refLon) {
        this.refLon = refLon;
    }

    /**
     * @return the releasable
     */
    public String getReleasable() {
        return releasable;
    }

    /**
     * @param releasable
     *            the releasable to set
     */
    public void setReleasable(String releasable) {
        this.releasable = releasable;
    }

    /**
     * @return the remarks
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * @param remarks
     *            the remarks to set
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /**
     * @return the sensorCode
     */
    public String getSensorCode() {
        return sensorCode;
    }

    /**
     * @param sensorCode
     *            the sensorCode to set
     */
    public void setSensorCode(String sensorCode) {
        this.sensorCode = sensorCode;
    }

    /**
     * @return the unitsType
     */
    public String getUnitsType() {
        return unitsType;
    }

    /**
     * @param unitsType
     *            the unitsType to set
     */
    public void setUnitsType(String unitsType) {
        this.unitsType = unitsType;
    }

    /**
     * @return the gramsSplcId
     */
    public String getGramsSplcId() {
        return gramsSplcId;
    }

    /**
     * @param gramsSplcId
     *            the gramsSplcId to set
     */
    public void setGramsSplcId(String gramsSplcId) {
        this.gramsSplcId = gramsSplcId;
    }

}
