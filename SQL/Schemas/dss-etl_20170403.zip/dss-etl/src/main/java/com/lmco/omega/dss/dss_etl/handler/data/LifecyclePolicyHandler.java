/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data;

import java.sql.ResultSet;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.model.LifeCyclePolicyDataObject;
import com.lmco.omega.dss.common.model.record.DataObjectRecord;
import com.lmco.omega.dss.common.model.record.LifeCyclePolicyRecord;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdRetentionPolicyPojo;

/**
 * @author bearyman
 */
public class LifecyclePolicyHandler extends AbstractDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            LifecyclePolicyHandler.class);
    private IsdRetentionPolicyPojo mPojo;

    public LifecyclePolicyHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        int iRow = 0;
        mPojo = new IsdRetentionPolicyPojo();

        LOGGER.debug("LifecyclePolicyHandler" + "_" + methodName + ": #: Start");

        while (pResults.next()) {
            iRow++;

            mPojo.setId(pResults.getString("retentionpolicyid"));
            mPojo.setPeriod(pResults.getInt("retentionperiod"));
            mPojo.setDescription(pResults.getString("retentionpolicydescription"));
            mPojo.setName(pResults.getString("retentionpolicyname"));
            mPojo.setSsic(pResults.getString("retentionpolicyssic"));

            LOGGER.debug("LifecyclePolicyHandler" + "_" + methodName + ": #: " + iRow);
        }

        LOGGER.debug("LifecyclePolicyHandler" + "_" + methodName + ": #: Stop");
    }

    @Override
    protected CoalesceEntity mapToCoalesce() {
        methodName = "mapToCoalesce";
        LifeCyclePolicyDataObject entity = new LifeCyclePolicyDataObject();
        entity.initialize();

        // Map pojo to coalesce
        LifeCyclePolicyRecord lcpRecord = entity.getLifeCyclePolicyRecord();
        lcpRecord.setPolicyName(mPojo.getName() + migrationTag);
        lcpRecord.setRetentionPeriodYears(mPojo.getPeriod());
        lcpRecord.setNearOnlineMigrationDays(65);
        lcpRecord.setOfflineMigrationDays(65);
        lcpRecord.setMarkForDeletionDays(90);
        lcpRecord.setUseRetentionPolicy(false);
        lcpRecord.setEnabled(false);

        DataObjectRecord dataObjectRecord = entity.getDataObjectRecord();
        dataObjectRecord.setDescription(mPojo.getDescription());

        // Set security
        // NOT NEEDED FOR LIFECYCLE POLICY
        // setCoalesceSecurity(mCasePojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mKey);

        return entity;
    }

    @Override
    protected void createLinkages() throws Exception {
        // DO NOTHING
    }

    @Override
    protected String getCreatedBy() {
        return DSSConstants.SYSTEM_ACCOUNT;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.RETENTION_POLICY;
    }
}
