/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdCollectionEventPojo {

    private String id;
    private String collectionAgainstCode;
    private String collectionAgainstType;
    private String collectionAgainstTypeCode;
    private String collectionEventLat;
    private String collectionEventLong;
    private String collectionEventRemarks;
    private String collectionEventTitle;
    private String relatedCollectionEventId;
    private Date startDate;
    private Date stopDate;
    private String swimsCollectionEventId;
    private Double collectionGeoAreaX1;
    private Double collectionGeoAreaY1;
    private Double collectionGeoAreaX2;
    private Double collectionGeoAreaY2;
    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdCollectionEventPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the collectionAgainstCode
     */
    public String getCollectionAgainstCode() {
        return collectionAgainstCode;
    }

    /**
     * @param collectionAgainstCode
     *            the collectionAgainstCode to set
     */
    public void setCollectionAgainstCode(String collectionAgainstCode) {
        this.collectionAgainstCode = collectionAgainstCode;
    }

    /**
     * @return the collectionAgainstType
     */
    public String getCollectionAgainstType() {
        return collectionAgainstType;
    }

    /**
     * @param collectionAgainstType
     *            the collectionAgainstType to set
     */
    public void setCollectionAgainstType(String collectionAgainstType) {
        this.collectionAgainstType = collectionAgainstType;
    }

    /**
     * @return the collectionAgainstTypeCode
     */
    public String getCollectionAgainstTypeCode() {
        return collectionAgainstTypeCode;
    }

    /**
     * @param collectionAgainstTypeCode
     *            the collectionAgainstTypeCode to set
     */
    public void setCollectionAgainstTypeCode(String collectionAgainstTypeCode) {
        this.collectionAgainstTypeCode = collectionAgainstTypeCode;
    }

    /**
     * @return the collectionEventLat
     */
    public String getCollectionEventLat() {
        return collectionEventLat;
    }

    /**
     * @param collectionEventLat
     *            the collectionEventLat to set
     */
    public void setCollectionEventLat(String collectionEventLat) {
        this.collectionEventLat = collectionEventLat;
    }

    /**
     * @return the collectionEventLong
     */
    public String getCollectionEventLong() {
        return collectionEventLong;
    }

    /**
     * @param collectionEventLong
     *            the collectionEventLong to set
     */
    public void setCollectionEventLong(String collectionEventLong) {
        this.collectionEventLong = collectionEventLong;
    }

    /**
     * @return the collectionEventRemarks
     */
    public String getCollectionEventRemarks() {
        return collectionEventRemarks;
    }

    /**
     * @param collectionEventRemarks
     *            the collectionEventRemarks to set
     */
    public void setCollectionEventRemarks(String collectionEventRemarks) {
        this.collectionEventRemarks = collectionEventRemarks;
    }

    /**
     * @return the collectionEventTitle
     */
    public String getCollectionEventTitle() {
        return collectionEventTitle;
    }

    /**
     * @param collectionEventTitle
     *            the collectionEventTitle to set
     */
    public void setCollectionEventTitle(String collectionEventTitle) {
        this.collectionEventTitle = collectionEventTitle;
    }

    /**
     * @return the relatedCollectionEventId
     */
    public String getRelatedCollectionEventId() {
        return relatedCollectionEventId;
    }

    /**
     * @param relatedCollectionEventId
     *            the relatedCollectionEventId to set
     */
    public void setRelatedCollectionEventId(String relatedCollectionEventId) {
        this.relatedCollectionEventId = relatedCollectionEventId;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the stopDate
     */
    public Date getStopDate() {
        return stopDate;
    }

    /**
     * @param stopDate
     *            the stopDate to set
     */
    public void setStopDate(Date stopDate) {
        this.stopDate = stopDate;
    }

    /**
     * @return the swimsCollectionEventId
     */
    public String getSwimsCollectionEventId() {
        return swimsCollectionEventId;
    }

    /**
     * @param swimsCollectionEventId
     *            the swimsCollectionEventId to set
     */
    public void setSwimsCollectionEventId(String swimsCollectionEventId) {
        this.swimsCollectionEventId = swimsCollectionEventId;
    }

    /**
     * @return the collectionGeoAreaX1
     */
    public Double getCollectionGeoAreaX1() {
        return collectionGeoAreaX1;
    }

    /**
     * @param collectionGeoAreaX1
     *            the collectionGeoAreaX1 to set
     */
    public void setCollectionGeoAreaX1(Double collectionGeoAreaX1) {
        this.collectionGeoAreaX1 = collectionGeoAreaX1;
    }

    /**
     * @return the collectionGeoAreaY1
     */
    public Double getCollectionGeoAreaY1() {
        return collectionGeoAreaY1;
    }

    /**
     * @param collectionGeoAreaY1
     *            the collectionGeoAreaY1 to set
     */
    public void setCollectionGeoAreaY1(Double collectionGeoAreaY1) {
        this.collectionGeoAreaY1 = collectionGeoAreaY1;
    }

    /**
     * @return the collectionGeoAreaX2
     */
    public Double getCollectionGeoAreaX2() {
        return collectionGeoAreaX2;
    }

    /**
     * @param collectionGeoAreaX2
     *            the collectionGeoAreaX2 to set
     */
    public void setCollectionGeoAreaX2(Double collectionGeoAreaX2) {
        this.collectionGeoAreaX2 = collectionGeoAreaX2;
    }

    /**
     * @return the collectionGeoAreaY2
     */
    public Double getCollectionGeoAreaY2() {
        return collectionGeoAreaY2;
    }

    /**
     * @param collectionGeoAreaY2
     *            the collectionGeoAreaY2 to set
     */
    public void setCollectionGeoAreaY2(Double collectionGeoAreaY2) {
        this.collectionGeoAreaY2 = collectionGeoAreaY2;
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

}
