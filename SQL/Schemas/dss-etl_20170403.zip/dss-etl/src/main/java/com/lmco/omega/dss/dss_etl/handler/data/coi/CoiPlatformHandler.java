/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data.coi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.joda.time.DateTime;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.CoiPlatformHashMap;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.PlatformClassHashMap;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdCoiPlatformPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.contactplatform.ContactPlatformCoalesce;
import com.lmco.omega.ecm.interfaces.model.ContactPlatform;

/**
 * @author bearyman
 */
public class CoiPlatformHandler extends AbstractCoiPlatformDataHandler {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            CoiPlatformHandler.class);
    private static final String GET_COI_DATE = "SELECT contactstartdtgitem "
            + "FROM omega.contactofinterest WHERE contactofinterestid = '%s'";

    public CoiPlatformHandler(IsdCoiPlatformPojo pPojo) {
        mPojo = pPojo;
        mKey = "UNKNOWN";
    }

    @Override
    protected CoalesceEntity mapToCoalesce() throws Exception {
        return mapToCoalesce(mPojo);
    }

    protected CoalesceEntity mapToCoalesce(IsdCoiPlatformPojo pPojo) throws Exception {
        methodName = "mapToCoalesce";
        ContactPlatformCoalesce entity;

        IDataConverter<ContactPlatform, ContactPlatformCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(ContactPlatform.class);

        ContactPlatform pojo = converter.constructPojo();

        if (StringHelper.isNullOrEmpty(pPojo.getName())) {
            pPojo.setName("UNKNOWN");
        }

        pojo.setName(formatEnumFieldVal(pPojo.getName()));
        pojo.setType(formatPlatformTypeEnumFieldVal(pPojo.getType()));
        pojo.setHullNumber(pPojo.getHullNumber());
        pojo.setSconum(pPojo.getScoNum());
        // pojo.setPennant(pPojo.getPennant());
        pojo.setOwnerCountry(formatEnumFieldVal(pPojo.getOwnerCountry()));
        pojo.setProducerCountry(formatEnumFieldVal(pPojo.getProducerCountry()));
        pojo.setTargetFlightVariant(formatEnumFieldVal(pPojo.getTargetFlightVariant()));

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(pPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = entity.getKey();
        mKey = entity.getKey();

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);

        LOGGER.debug("CoiPlatformHashMap" + "_" + methodName + ": " + " mEntityKey: " + mEntityKey
                + " Name and HullNum: " + pPojo.getUniqueContactPlatformName() + "_"
                + pPojo.getHullNumber());

        CoiPlatformHashMap.coiPlatformCache.put(pPojo.getUniqueContactPlatformName() + "_"
                                                        + pPojo.getHullNumber(), mEntityKey);

        // LOGGER.debug("CoiPlatformHashMap"
        // + "_"
        // + methodName
        // + ": "
        // + " coiPlatformCache.get: "
        // + CoiPlatformHashMap.getPlatformClassKey(pPojo.getUniqueContactPlatformName(),
        // Integer.toString(pPojo.getHullNumber())));

        // try {
        // cEntity.setDateCreated(getCoiStartDate());
        // } catch (SQLException e) {
        // logError(String.format(DSSConstants.EXCEPTION_OCCURRED, "setStartDate", e.getMessage()),
        // e);
        // }

        return cEntity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";
        PlatformClassHashMap platformClassHashMap = new PlatformClassHashMap();
        String parentId = platformClassHashMap.getPlatformClassKey(mPojo.getParentPlatformClass());

        // Link COI Platform to Platform Class
        linkEntities(mEntityKey, parentId, ELinkType.IS_CHILD_OF, "platform class",
                     DataObjectLinkActionType.LINK);
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.CONTACT_OF_INTEREST_PLATFORM;
    }

    private DateTime getCoiStartDate() throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        DateTime date = null;
        try {
            stmt = mIsdConn.createStatement();

            // Link case
            // results =
            // stmt.executeQuery(String.format(GET_COI_DATE, pPojo.getContactId()));

            while (results.next()) {
                date = new DateTime(results.getTimestamp(1));
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return date;
    }
}
