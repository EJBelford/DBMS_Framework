/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.factory;

import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.AbstractHandler;
import com.lmco.omega.dss.dss_etl.handler.data.CaseHandler;
import com.lmco.omega.dss.dss_etl.handler.data.CaseTrackingHandler;
import com.lmco.omega.dss.dss_etl.handler.data.CollectionEventHandler;
import com.lmco.omega.dss.dss_etl.handler.data.CollectorHandler;
import com.lmco.omega.dss.dss_etl.handler.data.EventTargetCharHandler;
import com.lmco.omega.dss.dss_etl.handler.data.GramsSplcHandler;
import com.lmco.omega.dss.dss_etl.handler.data.LifecyclePolicyHandler;
import com.lmco.omega.dss.dss_etl.handler.data.ObservedTargetSegmentSummaryHandler;
import com.lmco.omega.dss.dss_etl.handler.data.ProjectHandler;
import com.lmco.omega.dss.dss_etl.handler.data.ReelCutHandler;
import com.lmco.omega.dss.dss_etl.handler.data.ReelInfoHandler;
import com.lmco.omega.dss.dss_etl.handler.data.UserCommentsHandler;
import com.lmco.omega.dss.dss_etl.handler.data.WorkflowActivityInstanceHandler;
import com.lmco.omega.dss.dss_etl.handler.data.WorkflowInstanceHandler;
import com.lmco.omega.dss.dss_etl.handler.data.WorkflowSuspendHandler;
import com.lmco.omega.dss.dss_etl.handler.data.WorkflowTemplateHandler;
import com.lmco.omega.dss.dss_etl.handler.file.AuxiliarySupportHandler;
import com.lmco.omega.dss.dss_etl.handler.file.BtrHandler;
import com.lmco.omega.dss.dss_etl.handler.file.CGramHandler;
import com.lmco.omega.dss.dss_etl.handler.file.FanOfBeamsHandler;
import com.lmco.omega.dss.dss_etl.handler.file.FileDescriptiveMetadataHandler;
import com.lmco.omega.dss.dss_etl.handler.file.GramHandler;
import com.lmco.omega.dss.dss_etl.handler.file.HorizontalMeasurementsHandler;
import com.lmco.omega.dss.dss_etl.handler.file.HtmlPngHandler;
import com.lmco.omega.dss.dss_etl.handler.file.MSOfficeDocumentHandler;
import com.lmco.omega.dss.dss_etl.handler.file.NadHandler;
import com.lmco.omega.dss.dss_etl.handler.file.PsdHandler;
import com.lmco.omega.dss.dss_etl.handler.file.SensorIdentificationHandler;
import com.lmco.omega.dss.dss_etl.handler.file.SgrmHandler;
import com.lmco.omega.dss.dss_etl.handler.file.SummarySplHandler;
import com.lmco.omega.dss.dss_etl.handler.file.SwimsExportXmlHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TappXmlHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TargetTrackSolutionHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TimeSeriesHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TpsBearingHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TpsSoundSpeedHandler;
import com.lmco.omega.dss.dss_etl.handler.file.TpsTimestampHandler;
import com.lmco.omega.dss.dss_etl.handler.file.VerticalMeasurementsHandler;
import com.lmco.omega.dss.dss_etl.handler.file.WavfileHandler;
import com.lmco.omega.dss.dss_etl.interfaces.IDataHandlerFactory;

/**
 * @author bearyman
 */
public final class DataHandlerFactory implements IDataHandlerFactory {

    @Override
    public AbstractHandler getHandler(EIsdTableNames pTable, String pKey) {
        switch (pTable) {
            case AUXILIARY_SUPPORT:
                return new AuxiliarySupportHandler(pKey);
            case BTR:
                return new BtrHandler(pKey);
            case CASE:
                return new CaseHandler(pKey);
            case CASE_TRACKING_DATA:
                return new CaseTrackingHandler(pKey);
            case CGRAM:
                return new CGramHandler(pKey);
            case COLLECTION_EVENT:
                return new CollectionEventHandler(pKey);
            case COLLECTOR:
                return new CollectorHandler(pKey);
            case EVENT_TARGET_CHARACTERIZATION:
                return new EventTargetCharHandler(pKey);
            case FAN_OF_BEAMS:
                return new FanOfBeamsHandler(pKey);
            case FILE_DESCRIPTIVE_METADATA:
                return new FileDescriptiveMetadataHandler(pKey);
            case GRAM:
                return new GramHandler(pKey);
            case GRAMS_SPLC:
                return new GramsSplcHandler(pKey);
            case HORIZONTAL_MEASUREMENTS:
                return new HorizontalMeasurementsHandler(pKey);
            case HTML_AND_PNG:
                return new HtmlPngHandler(pKey);
            case MS_OFFICE_DOC:
                return new MSOfficeDocumentHandler(pKey);
            case NAD:
                return new NadHandler(pKey);
            case OBSERVED_TARGET_SEGMENT_SUMMARY:
                return new ObservedTargetSegmentSummaryHandler(pKey);
            case PROJECT:
                return new ProjectHandler(pKey);
            case PSD:
                return new PsdHandler(pKey);
            case REEL_CUT:
                return new ReelCutHandler(pKey);
            case REEL_INFO:
                return new ReelInfoHandler(pKey);
            case RETENTION_POLICY:
                return new LifecyclePolicyHandler(pKey);
            case SENSOR_IDENTIFICATION:
                return new SensorIdentificationHandler(pKey);
            case SGRM:
                return new SgrmHandler(pKey);
            case SUMMARY_SPL:
                return new SummarySplHandler(pKey);
            case SWIMS_EXPORT_XML:
                return new SwimsExportXmlHandler(pKey);
            case TAPP_XML:
                return new TappXmlHandler(pKey);
            case TARGET_TRACK_SOLUTION:
                return new TargetTrackSolutionHandler(pKey);
            case TIME_SERIES:
                return new TimeSeriesHandler(pKey);
            case TPS_BEARING:
                return new TpsBearingHandler(pKey);
            case TPS_SOUND_SPEED:
                return new TpsSoundSpeedHandler(pKey);
            case TPS_TIMESTAMP:
                return new TpsTimestampHandler(pKey);
            case VERTICAL_MEASUREMENTS:
                return new VerticalMeasurementsHandler(pKey);
            case WAVFILE:
                return new WavfileHandler(pKey);
            case WORKFLOW_ACTIVITY_INSTANCE:
                return new WorkflowActivityInstanceHandler(pKey);
            case WORKFLOW_INSTANCE:
                return new WorkflowInstanceHandler(pKey);
            case WORKFLOW_SUSPEND:
                return new WorkflowSuspendHandler(pKey);
            case WORKFLOW_TEMPLATE:
                return new WorkflowTemplateHandler(pKey);
            case WORKFLOW_USER_COMMENTS:
                return new UserCommentsHandler(pKey);
            default:
                return null;
        }
    }

}
