/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdCoiPlatformPojo {

    // ----- parent -----
    private String parentPlatformClass;
    // ----- uniqueIdentifiers -----
    private String uniqueContactPlatformName;
    private int hullNumber;
    // ----- otherFields -----
    private String name;
    private String type;
    private String scoNum;
    private String pennant;
    private String ownerCountry;
    private String producerCountry;
    private String targetFlightVariant;

    private IsdMandatorySecurityPojo security;

    /**
     *
     */
    public IsdCoiPlatformPojo() {
        security = new IsdMandatorySecurityPojo();
    }

    /**
     * @return the security
     */
    public IsdMandatorySecurityPojo getSecurity() {
        return security;
    }

    /**
     * @param security
     *            the security to set
     */
    public void setSecurity(IsdMandatorySecurityPojo security) {
        this.security = security;
    }

    /**
     * @return the parentPlatformClass
     */

    public String getParentPlatformClass() {
        return parentPlatformClass;
    }

    /**
     * @param parentPlatformClass
     *            the parentPlatformClass to set
     */

    public void setParentPlatformClass(String parentPlatformClass) {
        this.parentPlatformClass = parentPlatformClass;
    }

    /**
     * @return the name
     */

    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the hullNumber
     */

    public int getHullNumber() {
        return hullNumber;
    }

    /**
     * @param hullNumber
     *            the hullNumber to set
     */

    public void setHullNumber(int hullNumber) {
        this.hullNumber = hullNumber;
    }

    /**
     * @return the type
     */

    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */

    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the scoNum
     */
    public String getScoNum() {
        return scoNum;
    }

    /**
     * @param scoNum
     *            the scoNum to set
     */
    public void setScoNum(String scoNum) {
        this.scoNum = scoNum;
    }

    /**
     * @return the pennant
     */

    public String getPennant() {
        return pennant;
    }

    /**
     * @param pennant
     *            the pennant to set
     */

    public void setPennant(String pennant) {
        this.pennant = pennant;
    }

    /**
     * @return the ownerCountry
     */

    public String getOwnerCountry() {
        return ownerCountry;
    }

    /**
     * @param ownerCountry
     *            the ownerCountry to set
     */

    public void setOwnerCountry(String ownerCountry) {
        this.ownerCountry = ownerCountry;
    }

    /**
     * @return the producerCountry
     */

    public String getProducerCountry() {
        return producerCountry;
    }

    /**
     * @param producerCountry
     *            the producerCountry to set
     */

    public void setProducerCountry(String producerCountry) {
        this.producerCountry = producerCountry;
    }

    /**
     * @return the targetFlightVariant
     */

    public String getTargetFlightVariant() {
        return targetFlightVariant;
    }

    /**
     * @param targetFlightVariant
     *            the targetFlightVariant to set
     */

    public void setTargetFlightVariant(String targetFlightVariant) {
        this.targetFlightVariant = targetFlightVariant;
    }

    /**
     * @return uniqueContactPlatformName
     */

    public String getUniqueContactPlatformName() {
        return uniqueContactPlatformName;
    }

    /**
     * @param uniqueContactPlatformName
     *            the uniqueContactPlatformName to set
     */

    public void setUniqueContactPlatformName(String uniqueContactPlatformName) {
        this.uniqueContactPlatformName = uniqueContactPlatformName;
    }

}
