/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.exceptions.DSSPersisterNotInitializedException;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.enums.EIsdEnumerationNames;
import com.lmco.omega.dss.interfaces.enumerationmanager.Enumeration;
import com.lmco.omega.dss.interfaces.enumerationmanager.EnumerationValue;

/**
 * @author bearyman
 */
public final class EnumerationPropertyFileUtil {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EnumerationPropertyFileUtil.class);
    private static final String NO_FILE_DIR = "No such file or directory (%s)";
    private static final String NULL_VARIABLE = "Argument is null or empty (%s)";
    private static final String GET_ISD_ENUM_SQL = "SELECT enumvalues FROM omega.%s";
    private static final String FILE_CREATION_FAIL = "Failed to create file or directory (%s)";
    private static final String NULL_ENUM_VALUE = "Enum values for %s enumeration is null";
    private static final String NULL_ENUM = "Enumeration %s is null";
    private static final String READ_ENUM_FAIL =
            "Failed to read enumeration (%s) property file. Reason: %s";
    private static final String GET_COLLECTOR_SQL = "SELECT %s FROM omega.collector";
    private static final String NOT_APPLICABLE = "NOT_APPLICABLE";
    private static final String COLLECTOR_NAME = "collectorname";
    private static final String COLLECTOR_TYPE = "collectortype";

    private static Connection mIsdConn;

    /**
     * Creates enumeration property files in directory where DSS_CONFIG_LOCATION is set to
     *
     * @throws IOException
     * @throws SQLException
     * @throws IllegalStateException
     * @throws DSSPersisterNotInitializedException
     */
    public static void createEnumPropertyFiles(boolean pFsdAvailable) throws IOException,
            IllegalStateException, SQLException, DSSPersisterNotInitializedException {
        createEnumPropertyFiles(pFsdAvailable, System.getenv("DSS_CONFIG_LOCATION"));
    }

    /**
     * Creates enumeration property files in directory specified. Assumes the directory already
     * exists.
     *
     * @param pDirectory
     *            Where property files will be created
     * @throws IOException
     * @throws SQLException
     * @throws IllegalStateException
     * @throws DSSPersisterNotInitializedException
     */
    public static void createEnumPropertyFiles(boolean pFsdAvailable, String pDirectory)
            throws IOException, IllegalStateException, SQLException,
            DSSPersisterNotInitializedException {

        try {
            mIsdConn = EtlUtilitiesDbms.getISDConnection();
            if (!StringHelper.isNullOrEmpty(pDirectory)) {
                File dir = new File(pDirectory);
                if (dir.exists()) {
                    // Create enum property dir
                    Path propertyDir = Paths.get(dir.toString(), "enum_properties");

                    if (!propertyDir.toFile().exists()) {
                        if (!propertyDir.toFile().mkdirs()) {
                            throw new IOException(String.format(FILE_CREATION_FAIL,
                                                                propertyDir.toString()));
                        }
                    }

                    if (pFsdAvailable) {
                        createEnumPropertyFileFromFsd(propertyDir.toString());
                    } else {
                        for (EIsdEnumerationNames _enum: EIsdEnumerationNames.values()) {
                            createEnumPropertyFileFromIsd(_enum, propertyDir.toString());
                        }
                    }

                } else {
                    throw new IOException(String.format(NO_FILE_DIR, pDirectory));
                }
            } else {
                throw new IllegalArgumentException(String.format(NULL_VARIABLE, "directory"));
            }
        } finally {
            EtlUtilitiesDbms.closeConn(mIsdConn);
        }
    }

    private static void
            createEnumPropertyFileFromIsd(EIsdEnumerationNames pEnum, String pDirectory)
                    throws IOException, SQLException, DSSPersisterNotInitializedException {
        String filename;
        File propertyFile;

        if (pEnum == EIsdEnumerationNames.COLLECTOR) {
            // Collector name
            handleCollectorEnum(COLLECTOR_NAME, pDirectory);

            // Collector type
            handleCollectorEnum(COLLECTOR_TYPE, pDirectory);
        } else {
            filename = pEnum.getFsdTableName() + ".values";
            propertyFile = Paths.get(pDirectory, filename).toFile();

            boolean fileCreated = true;
            if (!propertyFile.exists()) {
                fileCreated = propertyFile.createNewFile();
            }

            if (fileCreated) {
                for (String value: readEnumValuesFromIsd(pEnum.getIsdTableName())) {
                    if (!getValues(propertyFile.toString()).contains(value)) {
                        formatAndWriteProperty(pEnum, value, propertyFile);
                    }
                }
            } else {
                throw new IOException(String.format(FILE_CREATION_FAIL, propertyFile.toString()));
            }
        }
    }

    private static void createEnumPropertyFileFromFsd(String pDirectory)
            throws DSSPersisterNotInitializedException, IOException {
        String filename;
        File propertyFile;

        List<String> enumerationNames =
                CoalesceFrameworkUtil.getEnumerationNames(DSSConstants.SYSTEM_ACCOUNT);

        for (String _enum: enumerationNames) {
            filename = _enum + ".values";
            propertyFile = Paths.get(pDirectory, filename).toFile();

            if (propertyFile.exists()) {
                propertyFile.delete();
            }

            if (propertyFile.createNewFile()) {
                Enumeration enumeration =
                        CoalesceFrameworkUtil.getEnumeration(_enum, DSSConstants.SYSTEM_ACCOUNT);
                if (enumeration != null) {
                    for (EnumerationValue enumValue: enumeration.getEnumValues()) {
                        if (enumValue != null) {
                            FileUtils.write(propertyFile, enumValue.getEnumValue() + "\n", true);
                        } else {
                            LOGGER.error(String.format(NULL_ENUM_VALUE, _enum));
                        }
                    }
                } else {
                    LOGGER.error(String.format(NULL_ENUM, _enum));
                }
            } else {
                throw new IOException(String.format(FILE_CREATION_FAIL, propertyFile.toString()));
            }
        }
    }

    private static List<String> readEnumValuesFromIsd(String pEnumeration) throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<String> enumList = new ArrayList<>();

        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_ISD_ENUM_SQL, pEnumeration));

            while (results.next()) {
                enumList.add(results.getString("enumvalues"));
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return enumList;
    }

    private static String formatEnumString(String pEnumStr) {
        String formattedEnum = NOT_APPLICABLE;
        if (!StringHelper.isNullOrEmpty(pEnumStr)) {
            formattedEnum = pEnumStr.replaceAll("[^a-zA-Z0-9]", "_");
            formattedEnum = formattedEnum.replaceAll("[_]+", "_").toUpperCase();

            if (formattedEnum.endsWith("_")) {
                formattedEnum = formattedEnum.substring(0, formattedEnum.length() - 1);
            }
        }

        return formattedEnum;
    }

    private static String formatPlatformTypeEnumString(String pEnumStr) {
        String formattedEnum = NOT_APPLICABLE;
        if (!StringHelper.isNullOrEmpty(pEnumStr)) {
            Pattern pat = Pattern.compile("[A-Z]+");
            Matcher mat = pat.matcher(pEnumStr);

            if (mat.find()) {
                formattedEnum = pEnumStr.substring(0, mat.end());
            }
        }
        return formattedEnum;
    }

    private static void formatAndWriteProperty(EIsdEnumerationNames pEnum, String pEnumValue,
            File pPropertyFile) throws IOException {
        // Format enum
        String formattedEnum;
        if (pEnum != EIsdEnumerationNames.PLATFORM_TYPE) {
            formattedEnum = formatEnumString(pEnumValue);
        } else {
            formattedEnum = formatPlatformTypeEnumString(pEnumValue);
        }

        FileUtils.write(pPropertyFile, formattedEnum + "\n", true);
    }

    private static List<String> retrieveCollectorData(String pName) throws SQLException {
        ResultSet results = null;
        Statement stmt = null;
        List<String> enumList = new ArrayList<>();

        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_COLLECTOR_SQL, pName));

            while (results.next()) {
                enumList.add(results.getString(1));
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        return enumList;
    }

    private static void handleCollectorEnum(String pCollectorType, String pDirectory)
            throws IOException, SQLException {
        String filename = pCollectorType + ".values";
        File propertyFile = Paths.get(pDirectory, filename).toFile();

        if (propertyFile.exists()) {
            propertyFile.delete();
        }

        if (propertyFile.createNewFile()) {
            String enumName = pCollectorType + "code";
            for (String value: retrieveCollectorData(enumName)) {
                formatAndWriteProperty(EIsdEnumerationNames.COLLECTOR, value, propertyFile);
            }
        } else {
            throw new IOException(String.format(FILE_CREATION_FAIL, propertyFile.toString()));
        }
    }

    private static List<String> getValues(String enumPropertyFile) {
        List<String> results = null;

        File file = new File(enumPropertyFile);

        if (file.exists()) {
            LineIterator iterator;
            try {
                iterator = FileUtils.lineIterator(file, "UTF-8");

                try {
                    // Read Keys as Values
                    results = new ArrayList<String>();

                    while (iterator.hasNext()) {
                        results.add(iterator.nextLine());
                    }
                } finally {
                    iterator.close();
                }
            } catch (IOException e) {
                LOGGER.error(String.format(READ_ENUM_FAIL, enumPropertyFile, e.getMessage()));
            }

        }

        return results;
    }
}
