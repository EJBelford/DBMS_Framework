/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.file;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.common.model.BaseFileObject;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.enums.EIsdFileDescriptiveMetadataTypes;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdFileDescriptiveMetadataPojo;

/**
 * @author bearyman
 */
public class FileDescriptiveMetadataHandler extends AbstractFileHandler {

    private IsdFileDescriptiveMetadataPojo mPojo;

    public FileDescriptiveMetadataHandler(final String pKey) {
        mKey = pKey;
    }

    @Override
    protected void handleIsdResults(ResultSet pResults) throws Exception {
        methodName = "handleIsdResults";
        mPojo = new IsdFileDescriptiveMetadataPojo();

        if (pResults.next()) {
            mPojo.setId(pResults.getString("filedescriptivemetadataid"));
            mPojo.setChecksum(pResults.getString("checksum"));
            mPojo.setDateCreated(pResults.getDate("datecreateditem"));
            mPojo.setDateModified(pResults.getDate("datemodifieditem"));
            mPojo.setIsDeletionCandidate(pResults.getBoolean("deletioncandidate"));
            mPojo.setFileName(pResults.getString("filename"));
            mPojo.setFileStatus(pResults.getString("filestatus"));
            mPojo.setFileTypeId(pResults.getInt("filetypeid"));
            mPojo.setForRdte(pResults.getBoolean("forrdte"));
            mPojo.setGroupId(pResults.getString("groupid"));
            mPojo.setLastModifiedBy(pResults.getString("lastmodifiedby"));
            mPojo.setLastUsageDate(pResults.getDate("lastusagedatetimeitem"));
            mPojo.setIsMetacardClassificationValid(pResults
                    .getBoolean("metacardclassificationvalid"));
            mPojo.setMimeType(pResults.getString("mimetype"));
            mPojo.setOther(pResults.getString("other"));
            mPojo.setPermissions(pResults.getString("permissions"));
            mPojo.setProductType(pResults.getString("producttype"));
            mPojo.setIsPublic(pResults.getBoolean("public_"));
            mPojo.setIsPublicToWeb(pResults.getBoolean("publictoweb"));
            mPojo.setReleaseDate(pResults.getDate("releasedateitem"));
            mPojo.setRetentionPolicyId(pResults.getString("retentionpolicyid"));
            mPojo.setFileSize(pResults.getLong("size_"));
            mPojo.setTappStatus(pResults.getString("tappstatus"));
            mPojo.setUri(pResults.getString("uri"));
            mPojo.setUserId(pResults.getString("userid"));
            mPojo.setVersion(pResults.getInt("version_"));

            setMandatorySecurity(pResults, mPojo.getSecurity());
        } else {
            throw new SQLException(String.format(NO_METADATA_ERR, getFileDescriptiveMetadataType()
                    .toString(), mKey));
        }
    }

    @Override
    protected BaseDataObject mapToCoalesce() {
        methodName = "mapToCoalesce";

        BaseFileObject entity = new BaseFileObject();
        entity.initialize();

        // Set file object metadata
        setCoalesceFileObjectMetadata(mPojo, entity);

        // Set security
        setCoalesceSecurity(mPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = setCoalesceKey(entity, mPojo.getId());

        return entity;
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.FILE_DESCRIPTIVE_METADATA;
    }

    @Override
    protected EIsdFileDescriptiveMetadataTypes getFileDescriptiveMetadataType() {
        return EIsdFileDescriptiveMetadataTypes.FILE_DESCRIPTIVE_METADATA;
    }

    @Override
    protected IsdFileDescriptiveMetadataPojo getFileDescriptiveMetadataPojo() {
        return mPojo;
    }
}
