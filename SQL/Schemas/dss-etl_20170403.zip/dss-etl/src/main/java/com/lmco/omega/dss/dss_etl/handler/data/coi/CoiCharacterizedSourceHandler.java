/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.data.coi;

import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.dss_etl.common.util.CoiSegmentHashMap;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.FrequencyIdentifierHashMap;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdContactCharacterizedSourcesPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.ecm.dal.server.ConverterFactory;
import com.lmco.omega.ecm.dal.server.IDataConverter;
import com.lmco.omega.ecm.dal.server.model.contactcharacterizedsource.ContactCharacterizedSourceCoalesce;
import com.lmco.omega.ecm.interfaces.model.ContactCharacterizedSource;

/**
 * @author n67154 - Gene Belford - InCadence
 */
public class CoiCharacterizedSourceHandler extends AbstractCoiDataHandler {

    private IsdContactCharacterizedSourcesPojo mPojo;

    public CoiCharacterizedSourceHandler(IsdContactCharacterizedSourcesPojo pPojo) {
        mPojo = pPojo;
        mKey = "UNKNOWN";
    }

    @Override
    protected CoalesceEntity mapToCoalesce() throws Exception {
        return mapToCoalesce(mPojo);
    }

    protected CoalesceEntity mapToCoalesce(IsdContactCharacterizedSourcesPojo pPojo)
            throws Exception {
        methodName = "mapToCoalesce";
        ContactCharacterizedSourceCoalesce entity;

        IDataConverter<ContactCharacterizedSource, ContactCharacterizedSourceCoalesce> converter =
                ConverterFactory.INSTANCE.getConverter(ContactCharacterizedSource.class);

        ContactCharacterizedSource pojo = converter.constructPojo();

        pojo.setAeKeyingInterval(pPojo.getAekeyinginterval());
        pojo.setAeKeyingType(formatEnumFieldVal(pPojo.getAekeyingintervaltype()));
        pojo.setDepth(pPojo.getAltitude());
        pojo.setAngleOnTheBow(pPojo.getAngleonthebow());
        pojo.setAspect(pPojo.getAspect());
        pojo.setBandwidth(pPojo.getBandwidth());
        pojo.setCenterFrequency(pPojo.getCenterfrequency());
        pojo.setComments(pPojo.getComment() + migrationTag + " [" + mPojo.getSourceOriginName()
                + "_" + mPojo.getUserLabel() + "]");
        pojo.setCourse(pPojo.getCourse());
        pojo.setDepressionElevationAngle(pPojo.getDepressionelevationangle());
        pojo.setEngineCrankShaftRate(pPojo.getEnginecrankshaftrate());
        pojo.setEngineCylinderRate(pPojo.getEnginecylinderrate());
        pojo.setEngineRPM(pPojo.getEnginerpm());
        // pojo. .setDepth(pPojo.getFreqbandstart());
        // pojo. .setDepth(pPojo.getFreqbandstop());
        pojo.setGeospatialConfidence(formatEnumFieldVal(pPojo.getGeospatialconfidence()));
        pojo.setHarmonic(pPojo.getHarmonic());
        pojo.setHeading(pPojo.getHeading());
        pojo.setHomingType(formatEnumFieldVal(pPojo.getHomingtype()));
        pojo.setMaximumEngineRPM(pPojo.getMaxenginerpm());
        pojo.setMaximumPropellerRPM(pPojo.getMaxpropellerrpm());
        pojo.setMinimumEngineRPM(pPojo.getMinenginerpm());
        pojo.setMinimumPropellerRPM(pPojo.getMinpropellerrpm());
        pojo.setPeakFrequency(pPojo.getPeakfreq());
        pojo.setPropellerBladeRate(pPojo.getPropellerbladerate());
        pojo.setPropellerRPM(pPojo.getPropellerrpm());
        pojo.setPropellerShaftRate(pPojo.getPropellershaftrate());
        pojo.setTransmissionMode(formatEnumFieldVal(pPojo.getPulsetype()));
        pojo.setRangeFromSensor(pPojo.getRangefromsensor());
        pojo.setRelativeBearing(pPojo.getRelativebearing());
        pojo.setReportedSpeed(pPojo.getReportedspeed());
        pojo.setSignalLevel(pPojo.getSignallevel());
        pojo.setSignalToNoiseRatio(pPojo.getSnr());
        pojo.setSignalToNoiseRatioAzimuthalAngle(pPojo.getSnrazimuthal());
        pojo.setSignalToNoiseRatioAzimuthalDepressionElevationAngle(pPojo
                .getSnrdepressionelevationangle());
        pojo.setSoundType(formatEnumFieldVal(pPojo.getSoundtype()));
        pojo.setSoundVelocity(pPojo.getSoundvelocity());
        pojo.setSourceRPM(pPojo.getSourcerpm());
        // pojo.setSpeed(pPojo.getSpeed());
        // pojo.setStartDtg(pPojo.getStarttime());
        // pojo.setEndDtg(pPojo.getStoptime());
        // pojo.setTransientLevel(pPojo.getTransientlevel());
        pojo.setTrueBearing(pPojo.getTruebearing());
        // pojo. .setDepth(pPojo.getType());
        pojo.setWaterDepth(pPojo.getWaterdepth());
        pojo.setWaveForm(formatEnumFieldVal(pPojo.getWaveform()));
        pojo.setWeaponMode(formatEnumFieldVal(pPojo.getWeaponmode()));

        // TODO
        // pojo.setGeospatialSourceType(formatEnumFieldVal(pPojo
        // .getGeospatialSourceType()));

        entity = converter.constructCoalesce(pojo);

        // Set security
        setCoalesceSecurity(pPojo.getSecurity(), entity);

        // Set mandatory fields
        EtlFieldSetterUtil.setMandatoryBaseFields(entity);

        // Set the key
        mEntityKey = entity.getKey();
        mKey = entity.getKey();

        // Set date created
        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(entity);

        // try {
        // cEntity.setDateCreated(getCoiStartDate());
        // } catch (SQLException e) {
        // logError(String.format(DSSConstants.EXCEPTION_OCCURRED, "setStartDate", e.getMessage()),
        // e);
        // }

        return cEntity;
    }

    @Override
    protected void createLinkages() throws Exception {
        methodName = "createLinkages";

        CoiSegmentHashMap contactSegmentHashMap = new CoiSegmentHashMap();
        FrequencyIdentifierHashMap frequencyIdentifierHashMap = new FrequencyIdentifierHashMap();

        System.out.println("CoiCharacterizedSourceHandler: " + methodName + ": " + " mEntityKey: "
                + mEntityKey + " mSourceOriginName_mUserLabel: " + mPojo.getSourceOriginName()
                + "_" + mPojo.getUserLabel());

        String parentContactSegmentId =
                contactSegmentHashMap.getCoiSegmentKey(mPojo.getParentSegmentName());
        String parentFrequencyIdentifierId =
                frequencyIdentifierHashMap.getFrequencyIndentifierKey(mPojo.getSourceOriginName(),
                                                                      mPojo.getUserLabel());

        // Link to COI
        linkEntities(mEntityKey, parentContactSegmentId, ELinkType.IS_CHILD_OF, "coi segment",
                     DataObjectLinkActionType.LINK);

        linkEntities(mEntityKey, parentFrequencyIdentifierId, ELinkType.IS_A_PEER_OF,
                     "frequency identifier", DataObjectLinkActionType.LINK);
    }

    @Override
    protected EIsdTableNames getTableType() {
        return EIsdTableNames.CONTACT_CHARACTERIZED_SOURCES;
    }

}
