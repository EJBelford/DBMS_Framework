/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

/**
 * @author bearyman
 */
public class IsdSplcAspectMeasurementPojo {

    private int id;
    private int aspectId;
    private String aspectName;
    private double bandwidthAvg;
    private double bandwidthStd;
    private double centerFreqAvg;
    private double m1Avg;
    private double m1Std;
    private double m2Avg;
    private double m2Std;
    private double m3Avg;
    private double m3Std;
    private double measuredFrequency;
    private double peakFreqAvg;
    private int pointCount;
    private double snrAvg;
    private double snrStd;
    private long sourceMeasurementId;
    private String gramsSplId;

    /**
     *
     */
    public IsdSplcAspectMeasurementPojo() {}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the aspectId
     */
    public int getAspectId() {
        return aspectId;
    }

    /**
     * @param aspectId
     *            the aspectId to set
     */
    public void setAspectId(int aspectId) {
        this.aspectId = aspectId;
    }

    /**
     * @return the aspectName
     */
    public String getAspectName() {
        return aspectName;
    }

    /**
     * @param aspectName
     *            the aspectName to set
     */
    public void setAspectName(String aspectName) {
        this.aspectName = aspectName;
    }

    /**
     * @return the bandwidthAvg
     */
    public double getBandwidthAvg() {
        return bandwidthAvg;
    }

    /**
     * @param bandwidthAvg
     *            the bandwidthAvg to set
     */
    public void setBandwidthAvg(double bandwidthAvg) {
        this.bandwidthAvg = bandwidthAvg;
    }

    /**
     * @return the bandwidthStd
     */
    public double getBandwidthStd() {
        return bandwidthStd;
    }

    /**
     * @param bandwidthStd
     *            the bandwidthStd to set
     */
    public void setBandwidthStd(double bandwidthStd) {
        this.bandwidthStd = bandwidthStd;
    }

    /**
     * @return the centerFreqAvg
     */
    public double getCenterFreqAvg() {
        return centerFreqAvg;
    }

    /**
     * @param centerFreqAvg
     *            the centerFreqAvg to set
     */
    public void setCenterFreqAvg(double centerFreqAvg) {
        this.centerFreqAvg = centerFreqAvg;
    }

    /**
     * @return the m1Avg
     */
    public double getM1Avg() {
        return m1Avg;
    }

    /**
     * @param m1Avg
     *            the m1Avg to set
     */
    public void setM1Avg(double m1Avg) {
        this.m1Avg = m1Avg;
    }

    /**
     * @return the m1Std
     */
    public double getM1Std() {
        return m1Std;
    }

    /**
     * @param m1Std
     *            the m1Std to set
     */
    public void setM1Std(double m1Std) {
        this.m1Std = m1Std;
    }

    /**
     * @return the m2Avg
     */
    public double getM2Avg() {
        return m2Avg;
    }

    /**
     * @param m2Avg
     *            the m2Avg to set
     */
    public void setM2Avg(double m2Avg) {
        this.m2Avg = m2Avg;
    }

    /**
     * @return the m2Std
     */
    public double getM2Std() {
        return m2Std;
    }

    /**
     * @param m2Std
     *            the m2Std to set
     */
    public void setM2Std(double m2Std) {
        this.m2Std = m2Std;
    }

    /**
     * @return the m3Avg
     */
    public double getM3Avg() {
        return m3Avg;
    }

    /**
     * @param m3Avg
     *            the m3Avg to set
     */
    public void setM3Avg(double m3Avg) {
        this.m3Avg = m3Avg;
    }

    /**
     * @return the m3Std
     */
    public double getM3Std() {
        return m3Std;
    }

    /**
     * @param m3Std
     *            the m3Std to set
     */
    public void setM3Std(double m3Std) {
        this.m3Std = m3Std;
    }

    /**
     * @return the measuredFrequency
     */
    public double getMeasuredFrequency() {
        return measuredFrequency;
    }

    /**
     * @param measuredFrequency
     *            the measuredFrequency to set
     */
    public void setMeasuredFrequency(double measuredFrequency) {
        this.measuredFrequency = measuredFrequency;
    }

    /**
     * @return the peakFreqAvg
     */
    public double getPeakFreqAvg() {
        return peakFreqAvg;
    }

    /**
     * @param peakFreqAvg
     *            the peakFreqAvg to set
     */
    public void setPeakFreqAvg(double peakFreqAvg) {
        this.peakFreqAvg = peakFreqAvg;
    }

    /**
     * @return the pointCount
     */
    public int getPointCount() {
        return pointCount;
    }

    /**
     * @param pointCount
     *            the pointCount to set
     */
    public void setPointCount(int pointCount) {
        this.pointCount = pointCount;
    }

    /**
     * @return the snrAvg
     */
    public double getSnrAvg() {
        return snrAvg;
    }

    /**
     * @param snrAvg
     *            the snrAvg to set
     */
    public void setSnrAvg(double snrAvg) {
        this.snrAvg = snrAvg;
    }

    /**
     * @return the snrStd
     */
    public double getSnrStd() {
        return snrStd;
    }

    /**
     * @param snrStd
     *            the snrStd to set
     */
    public void setSnrStd(double snrStd) {
        this.snrStd = snrStd;
    }

    /**
     * @return the sourceMeasurementId
     */
    public long getSourceMeasurementId() {
        return sourceMeasurementId;
    }

    /**
     * @param sourceMeasurementId
     *            the sourceMeasurementId to set
     */
    public void setSourceMeasurementId(long sourceMeasurementId) {
        this.sourceMeasurementId = sourceMeasurementId;
    }

    /**
     * @return the gramsSplId
     */
    public String getGramsSplId() {
        return gramsSplId;
    }

    /**
     * @param gramsSplId
     *            the gramsSplId to set
     */
    public void setGramsSplId(String gramsSplId) {
        this.gramsSplId = gramsSplId;
    }

}
