/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.ProgressMonitor;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.CoiPlatformHashMap;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilities;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.manager.CoiCharacterizedSourcesMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.CoiPlatformMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.CoiSegmentMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.FrequencyIdentifierMigrationManager;
import com.lmco.omega.dss.dss_etl.manager.PlatformClassMigrationManager;

/**
 * -+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 * Module Name: etl_isd_verification
 * Author:..... Gene Belford /n67154
 * Description:
 * Date:....... 2016-02-25
 * Source File: etl_isd_verification.java
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 * Change History
 * ==============
 * Date...... Chng_Ctrl Name................ Description
 * ========== ========= ==================== =============================
 * 2016-02-25 ......... Gene Belford........ Created
 * 2016-03-02 ......... Gene Belford........ verificationMain - A simple shell for unit testing
 * and debugging.
 * 2016-03-02 ......... Gene Belford........ loopIsdDbmsRecs - Uses a list of entries found in the
 * ISD database to verify that a files exist for that record. Writes performance metrics out to
 * etl_process_log.
 * 2016-03-02 ......... Gene Belford........ doesMetacardFileExist - Test to see if the file exists
 * at the recorded location. If the file is not found a functional warning is generated.
 * --+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 */

public class EtlIsdMigration extends JFrame implements ActionListener, Runnable {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlIsdMigration.class);
    private static final long serialVersionUID = 8829297579213173229L;

    static String processName = "EtlIsdMigration";

    Timer timer = null;

    static ProgressMonitor progressMonitor;
    static int steps = 46;
    static int stepsCompleted;
    static int percentComplete;
    static String taskInProcessName;

    private Thread t;
    private String threadName;

    public EtlIsdMigration(String name) {
        super("Migration Progress");
        setSize(400, 100);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); // EXIT_ON_CLOSE);

        threadName = name;

        LOGGER.debug("****1 Progress Monitor - Starting 1****");
        LOGGER.debug("****1 Creating " + threadName + " 1****");
    }

    /*
     * Start
     */

    public void start() {
        LOGGER.debug("Starting " + threadName);
        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }

    /*
     * run
     */

    @Override
    public void run() {

        String processModule = "run";

        Connection conn = null;
        Statement connStmt = null;

        ResultSet connResults = null;

        Integer recCnt;

        timer = new Timer(1000, this);
        timer.start();

        LOGGER.trace("DEBUG_0 Java: " + processName + " : " + processModule + " : Line 148");

        progressMonitor = new ProgressMonitor(null, "Migration Progress", "", 0, 100);

        LOGGER.trace("****2 Progress Monitor 2****");

        stepsCompleted = 0;
        percentComplete = 0;
        taskInProcessName = "ISD Table Count";

        recCnt = 0;

        /*
         * 01: ISD record count by table
         */

        try {
            doIsdTableCount();
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "doIsdTableCount",
                                       e.getMessage()), e);

        }

        try {
            conn = EtlUtilitiesDbms.getFSDConnection();
            try {
                connStmt = EtlUtilitiesDbms.getStmt(conn);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "create statement",
                                           e.getMessage()), e);
            }
        } catch (IllegalStateException | SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "get FSD Connection",
                                       e.getMessage()), e);
        }

        try {
            connResults = connStmt.executeQuery("SELECT migrate_isd2fsd.migrate_isd_2_fsd();");
            if (connResults.next()) {
                LOGGER.debug(connResults.getString(1));
            }
        } catch (SQLException e1) {
            LOGGER.error(e1.getClass().getName() + ": " + e1.getMessage(), e1);
            // System.exit(0);
        }

        EtlIsdVerification.loopIsdDbmsRecs();

        try {
            if (connStmt != null) {
                connStmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e1) {
            LOGGER.error(e1.getClass().getName() + ": " + e1.getMessage(), e1);
            // System.exit(0);
        }

        /*
         * 02: Enumerations
         */

        taskInProcessName = "Enumerations";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeEnumMigration();

        /*
         * 03: Life-Cycle Policy
         */

        taskInProcessName = "Life-Cycle Policy";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.RETENTION_POLICY,
                                               EtlMigrateIsd2Fsd.buttonLCPolicy);

        /*
         * 04: Project
         */

        taskInProcessName = "Project";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.PROJECT,
                                               EtlMigrateIsd2Fsd.buttonPrjct);

        taskInProcessName = "Workflow Template";
        stepsCompleted++;

        /*
         * 05: Workflow Template
         */

        taskInProcessName = "Workflow Template";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WORKFLOW_TEMPLATE,
                                               EtlMigrateIsd2Fsd.buttonWrkflTemp);

        /*
         * 06: Workflow Instance
         */

        taskInProcessName = "Workflow Instance";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WORKFLOW_INSTANCE,
                                               EtlMigrateIsd2Fsd.buttonWrkflInst);

        /*
         * 07: Workflow Activity Instance
         */

        taskInProcessName = "Workflow Activity Instance";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WORKFLOW_ACTIVITY_INSTANCE,
                                               EtlMigrateIsd2Fsd.buttonWrkflActInst);

        /*
         * 08: Workflow Suspend
         */

        taskInProcessName = "Workflow Suspend";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WORKFLOW_SUSPEND,
                                               EtlMigrateIsd2Fsd.buttonWrkflSuspend);

        /*
         * 09: User Comments
         */

        taskInProcessName = "User Comments";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WORKFLOW_USER_COMMENTS,
                                               EtlMigrateIsd2Fsd.buttonUserCmnts);

        /*
         * 10: Case
         */

        taskInProcessName = "Case";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.CASE, EtlMigrateIsd2Fsd.buttonCase);

        /*
         * 11: Collector
         */

        taskInProcessName = "Collector";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.COLLECTOR,
                                               EtlMigrateIsd2Fsd.buttonCollector);

        /*
         * 12: Case Tracking
         */

        taskInProcessName = "Case Tracking";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.CASE_TRACKING_DATA,
                                               EtlMigrateIsd2Fsd.buttonCaseTrk);

        /*
         * 13: Reel Info
         */

        taskInProcessName = "Reel Info";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.REEL_INFO,
                                               EtlMigrateIsd2Fsd.buttonReelInfo);

        /*
         * 14: Reel Cut
         */

        taskInProcessName = "Reel Cut";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.REEL_CUT,
                                               EtlMigrateIsd2Fsd.buttonReelCut);

        taskInProcessName = "Collection Event";
        stepsCompleted++;

        /*
         * 15: Collection Event
         */

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.COLLECTION_EVENT,
                                               EtlMigrateIsd2Fsd.buttonCollectionEvent);

        /*
         * 16: Event Target Characterization
         */

        taskInProcessName = "Event Target Characterization";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.EVENT_TARGET_CHARACTERIZATION,
                                               EtlMigrateIsd2Fsd.buttonEventTargetChar);

        /*
         * 17: GRAM SPLC
         */

        taskInProcessName = "GRAM SPLC";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.GRAMS_SPLC,
                                               EtlMigrateIsd2Fsd.buttonGramSplc);

        // taskInProcessName = "SPLC Aspect Measurement";
        // stepsCompleted++;
        // taskInProcessName = "SPLC Contact Measurement";
        // stepsCompleted++;
        // taskInProcessName = "SPLC  Measurement Event";
        // stepsCompleted++;
        // taskInProcessName = "SPLC Point Measurement";
        // stepsCompleted++;
        // taskInProcessName = "SPLC Source Measurement";
        // stepsCompleted++;
        // taskInProcessName = "SPLC Version";
        // stepsCompleted++;

        /*
         * 18:
         */

        taskInProcessName = "AUXILIARY SUPPORT,";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.AUXILIARY_SUPPORT,
                                               EtlMigrateIsd2Fsd.buttonAuxSupport);

        /*
         * 19:
         */

        taskInProcessName = "BTR";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.BTR, EtlMigrateIsd2Fsd.buttonBtr);

        /*
         * 20:
         */

        taskInProcessName = "CGRAM";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.CGRAM, EtlMigrateIsd2Fsd.buttonCGram);

        /*
         * 21:
         */

        taskInProcessName = "FAN OF BEAMS";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.FAN_OF_BEAMS,
                                               EtlMigrateIsd2Fsd.buttonFanOfBeams);

        /*
         * 22:
         */

        taskInProcessName = "GRAM";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.GRAM, EtlMigrateIsd2Fsd.buttonGram);

        /*
         * 23:
         */

        taskInProcessName = "HORIZONTAL MEASUREMENTS";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.HORIZONTAL_MEASUREMENTS,
                                               EtlMigrateIsd2Fsd.buttonHorizontalMeasurement);

        /*
         * 24:
         */

        taskInProcessName = "HTML AND PNG";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.HTML_AND_PNG,
                                               EtlMigrateIsd2Fsd.buttonHtmlAndPng);

        /*
         * 25:
         */

        taskInProcessName = "MS OFFICE DOC";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.MS_OFFICE_DOC,
                                               EtlMigrateIsd2Fsd.buttonMSOfficeDoc);

        /*
         * 26:
         */

        taskInProcessName = "NAD";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.NAD, EtlMigrateIsd2Fsd.buttonNad);

        /*
         * 27:
         */

        taskInProcessName = "PSD";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.PSD, EtlMigrateIsd2Fsd.buttonPsd);

        /*
         * 28:
         */

        taskInProcessName = "SENSOR IDENTIFICATION";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.SENSOR_IDENTIFICATION,
        // EtlMigrateIsd2Fsd.buttonSensorId);

        /*
         * 29:
         */

        taskInProcessName = "SGRM";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.SGRM,
        // EtlMigrateIsd2Fsd.buttonSGrm);

        /*
         * 30:
         */

        taskInProcessName = "SUMMARY SPL";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.SUMMARY_SPL,
        // EtlMigrateIsd2Fsd.buttonSummarySpl);

        /*
         * 31:
         */

        taskInProcessName = "SWIMS EXPORT XML";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.SWIMS_EXPORT_XML,
        // EtlMigrateIsd2Fsd.buttonSwimsExportXml);

        /*
         * 32:
         */

        taskInProcessName = "TAPP XML";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TAPP_XML,
        // EtlMigrateIsd2Fsd.buttonTappXml);

        /*
         * 33:
         */

        taskInProcessName = "TARGET TRACK SOLUTION";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TARGET_TRACK_SOLUTION,
        // EtlMigrateIsd2Fsd.buttonTgtTrackSolution);

        /*
         * 34:
         */

        taskInProcessName = "TIME SERIES";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TIME_SERIES,
                                               EtlMigrateIsd2Fsd.buttonTimeSeries);

        /*
         * 35:
         */

        taskInProcessName = "TPS BEARING";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TPS_BEARING,
                                               EtlMigrateIsd2Fsd.buttonTpsBearing);

        /*
         * 36:
         */

        taskInProcessName = "TPS SOUND SPEED";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TPS_SOUND_SPEED,
                                               EtlMigrateIsd2Fsd.buttonTpsSoundSp);

        /*
         * 37:
         */

        taskInProcessName = "TPS TIMESTAMP";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.TPS_TIMESTAMP,
                                               EtlMigrateIsd2Fsd.buttonTpsTimestamp);

        /*
         * 38:
         */

        taskInProcessName = "VERTICAL MEASUREMENTS";
        stepsCompleted++;

        // EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.VERTICAL_MEASUREMENTS,
        // EtlMigrateIsd2Fsd.buttonVertMeasurements);

        /*
         * 39:
         */

        taskInProcessName = "WAV FILE";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.WAVFILE,
                                               EtlMigrateIsd2Fsd.buttonWavFile);

        /*
         * 40: FILE DESCRIPTIVE METADATA'
         */

        taskInProcessName = "FILE DESCRIPTIVE METADATA";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.executeDataMigration(EIsdTableNames.FILE_DESCRIPTIVE_METADATA,
                                               EtlMigrateIsd2Fsd.buttonFileDescMeta);

        /*
         * 41: Platform Class
         */

        taskInProcessName = "Platform Class";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.buttonPlatformClass.setBackground(Color.RED);
        PlatformClassMigrationManager manager = null;
        try {
            manager = new PlatformClassMigrationManager();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        EtlMigrateIsd2Fsd.executeCoiDataMigration(manager, EtlMigrateIsd2Fsd.buttonPlatformClass);

        /*
         * 42: Contact Of Interest Platform
         */

        taskInProcessName = "Contact Of Interest Platform";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.buttonContactOfInterestPlatform.setBackground(Color.RED);
        try {
            EtlMigrateIsd2Fsd.coiPlatMap = new CoiPlatformHashMap();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        CoiPlatformMigrationManager manager2 = null;
        try {
            manager2 = new CoiPlatformMigrationManager();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        EtlMigrateIsd2Fsd
                .executeCoiDataMigration(manager2,
                                         EtlMigrateIsd2Fsd.buttonContactOfInterestPlatform);

        /*
         * 43: Contact Of Interest
         */

        taskInProcessName = "Contact Of Segment";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.buttonCOISegment.setBackground(Color.RED);

        CoiSegmentMigrationManager manager3;
        try {
            manager3 = new CoiSegmentMigrationManager();
            EtlMigrateIsd2Fsd.executeCoiDataMigration(manager3, EtlMigrateIsd2Fsd.buttonCOISegment);
        } catch (SQLException e) {
            e.printStackTrace();

        }

        /*
         * 44: Frequency Identifier
         */

        taskInProcessName = "Frequency Identifier";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.buttonFreqIdent.setBackground(Color.RED);

        FrequencyIdentifierMigrationManager manager4;
        try {
            manager4 = new FrequencyIdentifierMigrationManager();
            EtlMigrateIsd2Fsd.executeCoiDataMigration(manager4, EtlMigrateIsd2Fsd.buttonFreqIdent);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        /*
         * 46: Contact Characterized Sources
         */

        taskInProcessName = "Contact Characterized Sources";
        stepsCompleted++;

        EtlMigrateIsd2Fsd.buttonContactCharacterizedSources.setBackground(Color.RED);

        CoiCharacterizedSourcesMigrationManager manager5;
        try {
            manager5 = new CoiCharacterizedSourcesMigrationManager();
            EtlMigrateIsd2Fsd
                    .executeCoiDataMigration(manager5,
                                             EtlMigrateIsd2Fsd.buttonContactCharacterizedSources);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        /*
         * 46: Observed Target Segment Summary
         */

        taskInProcessName = "Observed Target Segment Summary";
        stepsCompleted++;

        EtlMigrateIsd2Fsd
                .executeDataMigration(EIsdTableNames.OBSERVED_TARGET_SEGMENT_SUMMARY,
                                      EtlMigrateIsd2Fsd.buttonObservedTargetSegmentSummary);

        /*
         * end of migration
         */

        taskInProcessName = "End of Migration";
        stepsCompleted++;

        /*
         * end of RUN
         */

        LOGGER.debug("DEBUG_0 SQL : " + processModule + ": 'migrate_isd_2_fsd()' was successful");
    }

    /*
     * 2016-03-02 ......... Gene Belford........ loopIsdDbmsRecs - Uses a list of entries found in
     * the ISD database to verify that a files exist for that record. Writes performance metrics out
     * to etl_process_log.
     */

    static void loopIsdDbmsRecs(Connection connISD) throws IllegalStateException, SQLException {

        String processModule = "loopIsdDbmsRecs";

        Boolean fileExistsBool = null;

        Statement connFsdStmt = null;
        Statement updtStmt = null;
        ResultSet connResults = null;

        int recId;
        int recIdDBMS;

        int recUpdated;

        String pathname = null;
        String sqlStr = null;

        String sqlLimit = EtlUtilities.getEtlConfigValue("sqlLimit");

        pathname = EtlUtilities.getEtlConfigValue("isdBulkStorage");

        Connection connFSD = EtlUtilitiesDbms.getFSDConnection();
        connFsdStmt = EtlUtilitiesDbms.getStmt(connFSD);

        LOGGER.debug("DEBUG_0 sqlLimit:" + sqlLimit);

        try {
            sqlStr =
                    "SELECT * FROM migrate_isd2fsd.etl_metacard_tracking_list "
                            + "WHERE catalog_dao_uri IS NOT NULL LIMIT " + sqlLimit + ";";
            connResults = connFsdStmt.executeQuery(sqlStr);
        } catch (SQLException e1) {
            LOGGER.error(e1.getMessage(), e1);
            System.exit(0);
        }

        updtStmt = EtlUtilitiesDbms.getStmt(connFSD);

        recUpdated = 0;

        recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");

        try {
            while (connResults.next()) {
                recId = connResults.getInt("rec_id");
                String isdfiletype = connResults.getString("isdfiletype");
                String catalog_dao_uri = connResults.getString("catalog_dao_uri");

                LOGGER.debug("DEBUG_0 RecId: " + recId + "  ISD File Type: " + isdfiletype);
                // LOGGER.debug("DEBUG_0 pathname: " + pathname);
                // LOGGER.debug("DEBUG_0 catalog_dao_uri: " +
                // catalog_dao_uri.substring(12));
                LOGGER.debug("DEBUG_0 URI: " + pathname + catalog_dao_uri.substring(12));

                fileExistsBool =
                        doesMetacardFileExist(connFSD, pathname, catalog_dao_uri.substring(12));

                LOGGER.debug("DEBUG_0 File exisits: " + fileExistsBool);

                sqlStr =
                        "UPDATE migrate_isd2fsd.etl_metacard_tracking_list "
                                + "SET isdfileexists = " + fileExistsBool
                                + ", updatedatetime = clock_timestamp() " + "WHERE rec_id = "
                                + recId + ";";
                updtStmt.executeUpdate(sqlStr);

                recUpdated = recUpdated + 1;
            }
        } catch (SQLException e2) {
            LOGGER.error(e2.getMessage(), e2);
            System.exit(0);
        }

        recIdDBMS =
                EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", recUpdated,
                                                  "File verification ended");

        try {
            if (updtStmt != null) {
                updtStmt.close();
            }
        } catch (SQLException e3) {
            LOGGER.error(e3.getMessage(), e3);
            System.exit(0);
        }
    }

    /*
     * 2016-03-02 ......... Gene Belford........ doesMetacardFileExist - Test to see if the file
     * exists at the recorded location. If the file is not found a functional warning is generated.
     */

    static Boolean doesMetacardFileExist(Connection connISD, String pathname, String filename)
            throws IllegalStateException, SQLException {

        String processModule = "doesMetacardFileExist";

        Boolean fileExistsBool = false;

        LOGGER.debug("========================");
        LOGGER.debug(pathname + filename);

        fileExistsBool = new File(pathname + filename).isFile();

        String errMsg =
                "etl_utilities Module: " + processModule + pathname + filename + " exisits: "
                        + fileExistsBool;

        if (fileExistsBool == false) {
            EtlUtilitiesDbms.processFuncWarnInsert(processName, processModule, "ExistsFailed",
                                                   errMsg, pathname + filename);
        }

        LOGGER.error("DEBUG_0 " + errMsg);
        return fileExistsBool;
    }

    public static void retrieveIsdMetadata(String etlProcessingTarget, Connection connISD,
            Connection connFSD) throws SQLException {

        String processModule = "retrieveIsdMetadata";

        int recIdDBMS;

        @SuppressWarnings("unused")
        Statement connFsdStmt = null;

        recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");

        LOGGER.trace("DEBUG_0 processName: " + processName + " processModule: " + processModule);

        String sqlLimit = EtlUtilities.getEtlConfigValue("sqlLimit");

        connFsdStmt = EtlUtilitiesDbms.getStmt(connFSD);

        LOGGER.debug("DEBUG_0 sqlLimit:" + sqlLimit);

        deleteTrackingTbl(connFSD);

        loadTrackingTbl(connISD, connFSD);

        EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", 0, processModule + " closed");
    }

    /*
     * deleteTrackingTbl
     */

    private static void deleteTrackingTbl(Connection conn) throws SQLException {

        String processModule = "deleteTrackingTbl";

        int recIdDBMS = 0;

        Statement pStmt = null;
        PreparedStatement pCallStmt = null;
        ResultSet rs = null;
        int rowCntBefore = 0;
        int rowCntAfter = 0;

        LOGGER.trace("DEBUG_0 SQL : processName: " + processName + " processModule: "
                + processModule);

        recIdDBMS = EtlUtilitiesDbms.processLogInit(conn, "S", processModule + " started");

        try {
            pStmt = conn.createStatement();
            rs =
                    pStmt.executeQuery("SELECT COUNT(*) AS rowcnt "
                            + "FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            while (rs.next()) {
                rowCntBefore = rs.getInt("rowcnt");
            }

            LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: "
                    + processModule + " rowCntBefore: " + rowCntBefore);

            pCallStmt =
                    conn.prepareStatement("DELETE FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            pCallStmt.executeUpdate();

            rs = null;
            rs =
                    pStmt.executeQuery("SELECT COUNT(*) AS rowcnt "
                            + "FROM migrate_isd2fsd.etl_metacard_tracking_list;");
            while (rs.next()) {
                rowCntAfter = rs.getInt("rowcnt");
            }

            LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: "
                    + processModule + " rowCntAfter: " + rowCntAfter);

            int rowCntDel = rowCntBefore - rowCntAfter;

            LOGGER.debug("DEBUG_0 Java: " + processModule + "SQL: rowCntDel: " + rowCntDel);

            pCallStmt = null;
            pCallStmt =
                    conn.prepareStatement("UPDATE migrate_isd2fsd.etl_process_log "
                            + "SET rec_delete  = ? " + "WHERE rec_id = ?; ");

            pCallStmt.setInt(1, rowCntDel);
            pCallStmt.setInt(2, recIdDBMS);

            EtlUtilitiesDbms.processLogUpdate(conn, recIdDBMS, "E", 0, processModule + " closed");
            pCallStmt.executeUpdate();

        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /*
     * loadTrackingTbl
     */

    private static void loadTrackingTbl(Connection connISD, Connection connFSD) throws SQLException {

        String processModule = "loadTrackingTbl";

        Statement connIsdStmt = null;
        PreparedStatement pFsdStmt = null;
        ResultSet connResults = null;

        int recIdDBMS = 0;

        int recInsert = 0;

        int debugFlag = 0;

        recIdDBMS = EtlUtilitiesDbms.processLogInit(connFSD, "S", processModule + " started");

        connIsdStmt = EtlUtilitiesDbms.getStmt(connISD);
        connResults = null;
        try {
            connResults =
                    connIsdStmt
                            .executeQuery("SELECT mct.catalog_id::uuid, "
                                    + "    mct.catalog_dao_id::uuid, "
                                    + "    REVERSE(LEFT(REVERSE(mct.catalog_dao_classname), STRPOS(REVERSE(mct.catalog_dao_classname), '.')-1))::text AS dao_class, "
                                    + "    mct.catalog_dao_uri, "
                                    + "    mct.catalog_created_timestamp, "
                                    + "    mct.catalog_modified_timestamp, "
                                    + "    m_c.caseid,  "
                                    + "    m_ce.collectioneventid,  "
                                    + "    m_cr.collectorid, "
                                    + "    m_fd.filedescriptivemetadataid, "
                                    + "    m_p.projectid, "
                                    + "    m_ri.reelinfoid, "
                                    + "    m_rp.retentionpolicyid, "
                                    + "    m_rpd.retentionpolicydefaultid, "
                                    + "    m_wfi.workflowinstanceid, "
                                    + "    m_wft.workflowtemplateid "
                                    + ", '|', mct.* "
                                    + "FROM omega.mdf_catalog_tab mct "
                                    + "LEFT OUTER JOIN omega.metacard_case m_c                                     ON m_c.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_collectionevent m_ce                         ON m_ce.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_collector m_cr                               ON m_cr.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactcharacterizedsources m_ccs            ON m_ccs.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactgeospatialtracks m_cgdt               ON m_cgdt.metacardid  = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactofinterest m_coi                      ON m_coi.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactofinterestsegmentsummary m_coiss      ON m_coiss.metacardid = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_contactoperationalprofile m_cop              ON m_cop.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_filedescriptivemetadata m_fd                 ON m_fd.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_networksearchfiledescriptivemetadata m_nsfdm ON m_nsfdm.metacardid = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_operation m_o                                ON m_o.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_project m_p                                  ON m_p.metacardid     = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_reelinfo m_ri                                ON m_ri.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_retentionpolicy m_rp                         ON m_rp.metacardid    = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_retentionpolicydefault m_rpd                 ON m_rpd.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_splinstance m_spl                            ON m_spl.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_workflowinstance m_wfi                       ON m_wfi.metacardid   = mct.catalog_id "
                                    + "LEFT OUTER JOIN omega.metacard_workflowtemplate m_wft                       ON m_wft.metacardid   = mct.catalog_id  "
                                    + "ORDER BY m_c.caseid, m_ce.collectioneventid,  "
                                    + "    m_cr.collectorid, m_fd.filedescriptivemetadataid, "
                                    + "    m_p.projectid, m_ri.reelinfoid, "
                                    + "    m_rp.retentionpolicyid, "
                                    + "    m_rpd.retentionpolicydefaultid, "
                                    + "    m_wfi.workflowinstanceid, "
                                    + "    m_wft.workflowtemplateid; ");
        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }

        try {
            while (connResults.next()) {
                String catalog_id = connResults.getString("catalog_id");
                String catalog_dao_id = connResults.getString("catalog_dao_id");
                String dao_class = connResults.getString("dao_class");
                String catalog_dao_uri = connResults.getString("catalog_dao_uri");
                Date catalog_created_timestamp = connResults.getDate("catalog_created_timestamp");
                Date catalog_modified_timestamp = connResults.getDate("catalog_modified_timestamp");
                String caseid = connResults.getString("caseid");
                String collectioneventid = connResults.getString("collectioneventid");
                String collectorid = connResults.getString("collectorid");
                String filedescriptivemetadataid =
                        connResults.getString("filedescriptivemetadataid");
                String projectid = connResults.getString("projectid");
                String reelinfoid = connResults.getString("reelinfoid");
                String retentionpolicyid = connResults.getString("retentionpolicyid");
                String retentionpolicydefaultid = connResults.getString("retentionpolicydefaultid");
                String workflowinstanceid = connResults.getString("workflowinstanceid");
                String workflowtemplateid = connResults.getString("workflowtemplateid");

                LOGGER.debug("catalog_id: " + catalog_id);

                try {
                    pFsdStmt = null;
                    pFsdStmt =
                            connFSD.prepareCall("INSERT INTO migrate_isd2fsd.etl_metacard_tracking_list ( "
                                    + "catalog_id, catalog_dao_id, dao_class, catalog_dao_uri, "
                                    + "catalog_created_timestamp, catalog_modified_timestamp, "
                                    + "caseid, collectioneventid, collectorid, filedescriptivemetadataid, "
                                    + "projectid, reelinfoid, retentionpolicyid, retentionpolicydefaultid, "
                                    + "workflowinstanceid, workflowtemplateid "
                                    + ") VALUES (?::uuid, ?::uuid, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

                    pFsdStmt.setString(1, catalog_id);
                    pFsdStmt.setString(2, catalog_dao_id);
                    pFsdStmt.setString(3, dao_class);
                    pFsdStmt.setString(4, catalog_dao_uri);

                    pFsdStmt.setDate(5, catalog_created_timestamp);
                    pFsdStmt.setDate(6, catalog_modified_timestamp);

                    pFsdStmt.setString(7, caseid);
                    pFsdStmt.setString(8, collectioneventid);
                    pFsdStmt.setString(9, collectorid);
                    pFsdStmt.setString(10, filedescriptivemetadataid);

                    pFsdStmt.setString(11, projectid);
                    pFsdStmt.setString(12, reelinfoid);
                    pFsdStmt.setString(13, retentionpolicyid);
                    pFsdStmt.setString(14, retentionpolicydefaultid);

                    pFsdStmt.setString(15, workflowinstanceid);
                    pFsdStmt.setString(16, workflowtemplateid);

                    LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + pFsdStmt);

                    pFsdStmt.execute();

                    LOGGER.debug("DEBUG_0 SQL:  " + processModule + ": Results: " + 0);

                } catch (SQLException e1) {
                    LOGGER.error(e1.getMessage(), e1);
                }
                recInsert++;
            }

        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "access result set",
                                       e.getMessage()), e);
        }

        LOGGER.debug("DEBUG_0 SQL processName: " + processName + " processModule: " + processModule
                + " recInsert: " + recInsert);

        pFsdStmt = null;
        try {
            pFsdStmt =
                    connFSD.prepareStatement("UPDATE migrate_isd2fsd.etl_process_log "
                            + "SET rec_insert  = ? " + "WHERE rec_id = ?; ");

            pFsdStmt.setInt(1, recInsert);
            pFsdStmt.setInt(2, recIdDBMS);

            EtlUtilitiesDbms
                    .processLogUpdate(connFSD, recIdDBMS, "E", 0, processModule + " closed");
            pFsdStmt.executeUpdate();

        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }

        EtlUtilitiesDbms.closeConn(connISD);
    }

    /**
     * doIsdTableCount
     *
     * @throws SQLException
     */

    public static void doIsdTableCount() throws SQLException {

        String processModule = "doIsdTableCount";

        Connection connISD = null;
        Statement connIsdStmt1 = null;
        Statement connIsdStmt2 = null;

        Connection connFSD = null;
        Statement connFsdStmt1 = null;

        int recIdDBMS = 0;

        ResultSet connResults1;
        ResultSet connResults2;

        String v_stmt = null;

        LOGGER.trace("DEBUG_0 Java: " + processName + " : " + processModule + " : Line 628");

        connISD = EtlUtilitiesDbms.getISDConnection();
        connIsdStmt1 = EtlUtilitiesDbms.getStmt(connISD);
        connIsdStmt2 = EtlUtilitiesDbms.getStmt(connISD);

        connFSD = EtlUtilitiesDbms.getFSDConnection();
        connFsdStmt1 = EtlUtilitiesDbms.getStmt(connFSD);

        recIdDBMS =
                EtlUtilitiesDbms.processLogInit(connFSD, "S", processName + "_" + processModule
                        + " started");

        v_stmt = "DELETE FROM migrate_isd2fsd.isd_db_object_facts; ";

        try {
            connFsdStmt1.executeUpdate(v_stmt);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "execute update",
                                       e.getMessage()), e);
        }

        try {
            LOGGER.trace("DEBUG_0 Java: " + processName + " : " + processModule + " : Line 643");

            connResults1 =
                    connIsdStmt1.executeQuery("SELECT schemaname, relname "
                            + "FROM pg_stat_all_tables "
                            + "WHERE UPPER(schemaname) = UPPER('omega') "
                            + "ORDER BY schemaname, relname " + "; ");

            while (connResults1.next()) {
                connResults2 =
                        connIsdStmt2.executeQuery("SELECT COUNT(*) " + "FROM "
                                + connResults1.getString(1) + "." + connResults1.getString(2) + " "
                                + "; ");

                while (connResults2.next()) {
                    LOGGER.debug("Row: " + connResults1.getString(1) + " "
                            + connResults1.getString(2) + " " + connResults2.getString(1));

                    v_stmt =
                            "INSERT INTO migrate_isd2fsd.isd_db_object_facts "
                                    + " (schemaname, relname, indexrelname, row_cnt_date, row_cnt) "
                                    + " VALUES('" + connResults1.getString(1) + "', '"
                                    + connResults1.getString(2) + "', NULL, clock_timestamp(), '"
                                    + connResults2.getString(1) + "') " + "; ";

                    connFsdStmt1.executeUpdate(v_stmt);
                }
            }
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED,
                                       "perform database function", e.getMessage()), e);
        }

        // Load the FSD enumeration counts

        v_stmt = null;
        v_stmt =
                "UPDATE migrate_isd2fsd.isd_db_object_facts " + "SET etl_entity_cnt = ( "
                        + "SELECT COUNT(ev.ordering) " + "FROM coalesce.enumvalue ev "
                        + "WHERE relname = ev.enumtype " + "), "
                        + "last_updated = clock_timestamp() " + "WHERE ( "
                        + "SELECT COUNT(ev.ordering) " + "FROM coalesce.enumvalue ev "
                        + "WHERE relname = ev.enumtype " + ") > 0; ";

        try {
            connFsdStmt1.executeUpdate(v_stmt);
        } catch (SQLException e) {
            LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "execute update",
                                       e.getMessage()), e);
        }

        EtlUtilitiesDbms.processLogUpdate(connFSD, recIdDBMS, "E", 0, "Close " + processName + "_"
                + processModule);

        EtlUtilitiesDbms.closeConn(connIsdStmt1);
        EtlUtilitiesDbms.closeConn(connIsdStmt2);
        EtlUtilitiesDbms.closeConn(connFsdStmt1);

        EtlUtilitiesDbms.closeConn(connISD);
        EtlUtilitiesDbms.closeConn(connFSD);
    }

    /*
     * Progress Bar test
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        SwingUtilities.invokeLater(new Update());
    }

    class Update implements Runnable {

        @Override
        public void run() {
            if (progressMonitor.isCanceled()) {
                progressMonitor.close();
                timer.stop();
            }

            percentComplete = (int) ((double) stepsCompleted / (double) steps * 100);

            progressMonitor.setProgress(percentComplete);
            progressMonitor.setNote(taskInProcessName + " - " + percentComplete + "% complete");
        }
    }
}
