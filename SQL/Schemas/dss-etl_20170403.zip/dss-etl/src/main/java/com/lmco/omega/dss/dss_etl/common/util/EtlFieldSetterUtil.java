/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2016 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.common.util;

import java.util.Date;
import java.util.zip.DataFormatException;

import com.incadencecorp.coalesce.common.classification.helpers.StringHelper;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.common.types.classification.EClassification;
import com.lmco.omega.daq.datamodel.ReelCut;
import com.lmco.omega.daq.datamodel.ReelInfo;
import com.lmco.omega.daq.datamodel.record.ReelInfoRecord;
import com.lmco.omega.daq.datamodel.record.interfaces.IReelCutRecord;
import com.lmco.omega.dss.common.model.AccessControl;
import com.lmco.omega.dss.common.model.BaseDataObject;
import com.lmco.omega.dss.common.model.BaseFileObject;
import com.lmco.omega.dss.common.model.enums.EDataObjectCategory;
import com.lmco.omega.dss.common.model.enums.EDataObjectOrigin;
import com.lmco.omega.dss.common.model.enums.EDataObjectReviewState;
import com.lmco.omega.dss.common.model.enums.EFileType;
import com.lmco.omega.dss.common.model.enums.EProductDevType;
import com.lmco.omega.dss.common.model.record.AccessControlsRecord;
import com.lmco.omega.dss.common.model.record.DataObjectRecord;
import com.lmco.omega.dss.common.model.record.FileObjectRecord;
import com.lmco.omega.dss.common.model.record.PhysicalFileMetadataRecord;
import com.lmco.omega.dss.common.model.record.SecurityObjectRecord;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.ecm.dal.server.model.project.ProjectCoalesce;
import com.lmco.omega.ecm.dal.server.model.usercomments.UserCommentsCoalesce;
import com.lmco.omega.ecm.dal.server.model.workflowactivityinstance.WorkflowActivityInstanceCoalesce;
import com.lmco.omega.ecm.dal.server.model.workflowinstance.WorkflowInstanceCoalesce;
import com.lmco.omega.ecm.dal.server.model.workflowsuspend.WorkflowSuspendCoalesce;
import com.lmco.omega.ecm.dal.server.model.workflowtemplate.WorkflowTemplateCoalesce;

/**
 * @author n67154
 */

public final class EtlFieldSetterUtil {

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            EtlFieldSetterUtil.class);
    private static final String PROCESS_NAME = "EtlFieldSetterUtil";

    private static Integer debugFlag = 0;

    private EtlFieldSetterUtil() {}

    public static void setMandatoryBaseFields(CoalesceEntity pEntity) {

        String processModule = "setMandatoryBaseFields";

        if (pEntity instanceof WorkflowActivityInstanceCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule
                    + ": Line 71: WorkflowActivityInstanceObjectEtl");
            WorkflowActivityInstanceCoalesce object = (WorkflowActivityInstanceCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof UserCommentsCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": Line 81: UserCommentObjectEtl");
            UserCommentsCoalesce object = (UserCommentsCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof WorkflowInstanceCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule
                    + ": Line 91: WorkflowInstanceObjectEtl");
            WorkflowInstanceCoalesce object = (WorkflowInstanceCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof WorkflowTemplateCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule
                    + ": Line 101: WorkflowTemplateObjectEtl");
            WorkflowTemplateCoalesce object = (WorkflowTemplateCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof ProjectCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": Line 111: ProjectObjectEtl");
            ProjectCoalesce object = (ProjectCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof WorkflowSuspendCoalesce) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule
                    + ": Line 123: WorkflowSuspendObjectEtl");
            WorkflowSuspendCoalesce object = (WorkflowSuspendCoalesce) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof ReelInfo) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": Line 160: ReelInfo");
            ReelInfo object = (ReelInfo) pEntity;
            populateReelInfoRecord(object.getReelInfoRecord());
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof ReelCut) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": Line 170: ReelCut");
            ReelCut object = (ReelCut) pEntity;
            populateReelCutRecord(object.getReelCutRecord());
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof BaseFileObject) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": BaseFileObject");
            BaseFileObject object = (BaseFileObject) pEntity;
            populateFileObjectRecord(object.getFileObjectRecord());
            populatePhysicalFileMetadataRecord(object.getCurrentPhysicalFileMetadataRecord());
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof BaseDataObject) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": BaseDataObject");
            BaseDataObject object = (BaseDataObject) pEntity;
            populateDataObjectRecord(object.getDataObjectRecord());
            populateSecurityObjectRecord(object.getSecurityRecord());
            populateAccessControlsRecord(object.getAccessControlRecord());
        } else if (pEntity instanceof AccessControl) {
            LOGGER.trace(PROCESS_NAME + ": " + processModule + ": AccessControl");
            AccessControl object = (AccessControl) pEntity;
            populateAccessControlsRecord(object.getAccessControlRecord());
        }
    }

    private static void populateAccessControlsRecord(AccessControlsRecord pRecord) {
        // pRecord.setAccessScope(EAccessScope.ALL);
    }

    private static void populateDataObjectRecord(DataObjectRecord pRecord) {
        if (StringHelper.isNullOrEmpty(pRecord.getDescription())) {
            pRecord.setDescription("ETL_Isd2Fsd (default)");
        }
        if (pRecord.getOrigin() == null) {
            pRecord.setOrigin(EDataObjectOrigin.SUPPORT);
        }
        if (pRecord.getCategory() == null) {
            pRecord.setCategory(EDataObjectCategory.OTHER);
        }
        if (pRecord.getReviewState() == null) {
            pRecord.setReviewState(EDataObjectReviewState.NOT_REVIEWED);
        }
        if (pRecord.getReviewTarget() == null) {
            pRecord.setReviewTarget(EDataObjectReviewState.NOT_REVIEWED);
        }
        if (pRecord.getProductDevelopmentType() == null) {
            pRecord.setProductDevelopmentType(EProductDevType.WORKING);
        }
    }

    private static void populateSecurityObjectRecord(SecurityObjectRecord pRecord) {
        if (pRecord.getClassification() == null) {
            pRecord.setClassification(EClassification.UNCLASSIFIED);
        }
        if (StringHelper.isNullOrEmpty(pRecord.getClassificationReason())) {
            pRecord.setClassificationReason("NA");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getClassifiedBy())) {
            pRecord.setClassifiedBy("");
        }
        try {
            if (pRecord.getDateOfExemptedSource() == null) {
                pRecord.setDateOfExemptedSource(new Date());
            }
        } catch (DataFormatException e) {
            pRecord.setDateOfExemptedSource(new Date());
        }
        try {
            if (pRecord.getDeclassificationDate() == null) {
                pRecord.setDeclassificationDate(new Date());
            }
        } catch (DataFormatException e) {
            pRecord.setDateOfExemptedSource(new Date());
        }
        if (StringHelper.isNullOrEmpty(pRecord.getDeclassificationEvent())) {
            pRecord.setDeclassificationEvent("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getDeclassificationExemption())) {
            pRecord.setDeclassificationExemption("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getDerivativelyClassifiedBy())) {
            pRecord.setDerivativelyClassifiedBy("NA");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getDerivedFrom())) {
            pRecord.setDerivedFrom("NA");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getDisseminationControls())) {
            pRecord.setDisseminationControls("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getFGISourceOpen())) {
            pRecord.setFGISourceOpen("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getFGISourceProtected())) {
            pRecord.setFGISourceProtected("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getNonICMarkings())) {
            pRecord.setNonICMarkings("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getOwnerProducer())) {
            pRecord.setOwnerProducer("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getReleasableTo())) {
            pRecord.setReleasableTo("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getTypeOfExemptedSource())) {
            pRecord.setTypeOfExemptedSource("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getACCMControls())) {
            pRecord.setACCMControls("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getSAPControls())) {
            pRecord.setSAPControls("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getSARIdentifier())) {
            pRecord.setSARIdentifier("");
        }
        if (StringHelper.isNullOrEmpty(pRecord.getSCIControls())) {
            pRecord.setSCIControls("");
        }
    }

    private static void populateFileObjectRecord(FileObjectRecord pRecord) {
        if (pRecord.getFileType() == null) {
            pRecord.setFileType(EFileType.UNKNOWN);
        }
    }

    private static void populatePhysicalFileMetadataRecord(PhysicalFileMetadataRecord pRecord) {
        if (StringHelper.isNullOrEmpty(pRecord.getDisplayableFileName())) {
            pRecord.setDisplayableFileName("UNKNOWN");
        }
        try {
            if (pRecord.getSize() < 1) {
                pRecord.setSize(1L);
            }
        } catch (DataFormatException e) {
            pRecord.setSize(1L);
        }
    }

    private static void populateReelInfoRecord(ReelInfoRecord reelInfoRecord) {
        LOGGER.trace("**** Reel Info pRecord: " + reelInfoRecord);
        if (StringHelper.isNullOrEmpty(reelInfoRecord.getRemarks())) {
            reelInfoRecord.setRemarks("ETL_Test_ReelInfo-329(a)");
        }
    }

    private static void populateReelCutRecord(IReelCutRecord iReelCutRecord) {
        LOGGER.trace("**** Reel Cut pRecord: " + iReelCutRecord);
        if (StringHelper.isNullOrEmpty(iReelCutRecord.getComments())) {
            iReelCutRecord.setComments("ETL_Test_CutInfo-336(a)");
        }
    }

}
