/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdMandatorySecurityPojo {

    // Security Fields
    private String mandatorySecurity_c0;
    private String mandatorySecurity_c1;
    private String mandatorySecurity_c2;
    private String mandatorySecurity_d0;
    private String mandatorySecurity_d1;
    private String mandatorySecurity_d2;
    private String mandatorySecurity_d3;
    private String mandatorySecurity_d4;
    private Boolean mandatorySecurity_d5;
    private Date mandatorySecurity_d6;
    private Date mandatorySecurity_d7;
    private String mandatorySecurity_f0;
    private String mandatorySecurity_f1;
    private String mandatorySecurity_n0;
    private String mandatorySecurity_o0;
    private String mandatorySecurity_r0;
    private String mandatorySecurity_s1;
    private String mandatorySecurity_s0;
    private String mandatorySecurity_t0;

    /**
     *
     */
    public IsdMandatorySecurityPojo() {}

    /**
     * @return the mandatorySecurity_c0
     */
    public String getMandatorySecurity_c0() {
        return mandatorySecurity_c0;
    }

    /**
     * @param mandatorySecurity_c0
     *            the mandatorySecurity_c0 to set
     */
    public void setMandatorySecurity_c0(String mandatorySecurity_c0) {
        this.mandatorySecurity_c0 = mandatorySecurity_c0;
    }

    /**
     * @return the mandatorySecurity_c1
     */
    public String getMandatorySecurity_c1() {
        return mandatorySecurity_c1;
    }

    /**
     * @param mandatorySecurity_c1
     *            the mandatorySecurity_c1 to set
     */
    public void setMandatorySecurity_c1(String mandatorySecurity_c1) {
        this.mandatorySecurity_c1 = mandatorySecurity_c1;
    }

    /**
     * @return the mandatorySecurity_c2
     */
    public String getMandatorySecurity_c2() {
        return mandatorySecurity_c2;
    }

    /**
     * @param mandatorySecurity_c2
     *            the mandatorySecurity_c2 to set
     */
    public void setMandatorySecurity_c2(String mandatorySecurity_c2) {
        this.mandatorySecurity_c2 = mandatorySecurity_c2;
    }

    /**
     * @return the mandatorySecurity_d0
     */
    public String getMandatorySecurity_d0() {
        return mandatorySecurity_d0;
    }

    /**
     * @param mandatorySecurity_d0
     *            the mandatorySecurity_d0 to set
     */
    public void setMandatorySecurity_d0(String mandatorySecurity_d0) {
        this.mandatorySecurity_d0 = mandatorySecurity_d0;
    }

    /**
     * @return the mandatorySecurity_d1
     */
    public String getMandatorySecurity_d1() {
        return mandatorySecurity_d1;
    }

    /**
     * @param mandatorySecurity_d1
     *            the mandatorySecurity_d1 to set
     */
    public void setMandatorySecurity_d1(String mandatorySecurity_d1) {
        this.mandatorySecurity_d1 = mandatorySecurity_d1;
    }

    /**
     * @return the mandatorySecurity_d2
     */
    public String getMandatorySecurity_d2() {
        return mandatorySecurity_d2;
    }

    /**
     * @param mandatorySecurity_d2
     *            the mandatorySecurity_d2 to set
     */
    public void setMandatorySecurity_d2(String mandatorySecurity_d2) {
        this.mandatorySecurity_d2 = mandatorySecurity_d2;
    }

    /**
     * @return the mandatorySecurity_d3
     */
    public String getMandatorySecurity_d3() {
        return mandatorySecurity_d3;
    }

    /**
     * @param mandatorySecurity_d3
     *            the mandatorySecurity_d3 to set
     */
    public void setMandatorySecurity_d3(String mandatorySecurity_d3) {
        this.mandatorySecurity_d3 = mandatorySecurity_d3;
    }

    /**
     * @return the mandatorySecurity_d4
     */
    public String getMandatorySecurity_d4() {
        return mandatorySecurity_d4;
    }

    /**
     * @param mandatorySecurity_d4
     *            the mandatorySecurity_d4 to set
     */
    public void setMandatorySecurity_d4(String mandatorySecurity_d4) {
        this.mandatorySecurity_d4 = mandatorySecurity_d4;
    }

    /**
     * @return the mandatorySecurity_d5
     */
    public Boolean getMandatorySecurity_d5() {
        return mandatorySecurity_d5;
    }

    /**
     * @param mandatorySecurity_d5
     *            the mandatorySecurity_d5 to set
     */
    public void setMandatorySecurity_d5(Boolean mandatorySecurity_d5) {
        this.mandatorySecurity_d5 = mandatorySecurity_d5;
    }

    /**
     * @return the mandatorySecurity_d6
     */
    public Date getMandatorySecurity_d6() {
        return mandatorySecurity_d6;
    }

    /**
     * @param mandatorySecurity_d6
     *            the mandatorySecurity_d6 to set
     */
    public void setMandatorySecurity_d6(Date mandatorySecurity_d6) {
        this.mandatorySecurity_d6 = mandatorySecurity_d6;
    }

    /**
     * @return the mandatorySecurity_d7
     */
    public Date getMandatorySecurity_d7() {
        return mandatorySecurity_d7;
    }

    /**
     * @param mandatorySecurity_d7
     *            the mandatorySecurity_d7 to set
     */
    public void setMandatorySecurity_d7(Date mandatorySecurity_d7) {
        this.mandatorySecurity_d7 = mandatorySecurity_d7;
    }

    /**
     * @return the mandatorySecurity_f0
     */
    public String getMandatorySecurity_f0() {
        return mandatorySecurity_f0;
    }

    /**
     * @param mandatorySecurity_f0
     *            the mandatorySecurity_f0 to set
     */
    public void setMandatorySecurity_f0(String mandatorySecurity_f0) {
        this.mandatorySecurity_f0 = mandatorySecurity_f0;
    }

    /**
     * @return the mandatorySecurity_f1
     */
    public String getMandatorySecurity_f1() {
        return mandatorySecurity_f1;
    }

    /**
     * @param mandatorySecurity_f1
     *            the mandatorySecurity_f1 to set
     */
    public void setMandatorySecurity_f1(String mandatorySecurity_f1) {
        this.mandatorySecurity_f1 = mandatorySecurity_f1;
    }

    /**
     * @return the mandatorySecurity_n0
     */
    public String getMandatorySecurity_n0() {
        return mandatorySecurity_n0;
    }

    /**
     * @param mandatorySecurity_n0
     *            the mandatorySecurity_n0 to set
     */
    public void setMandatorySecurity_n0(String mandatorySecurity_n0) {
        this.mandatorySecurity_n0 = mandatorySecurity_n0;
    }

    /**
     * @return the mandatorySecurity_o0
     */
    public String getMandatorySecurity_o0() {
        return mandatorySecurity_o0;
    }

    /**
     * @param mandatorySecurity_o0
     *            the mandatorySecurity_o0 to set
     */
    public void setMandatorySecurity_o0(String mandatorySecurity_o0) {
        this.mandatorySecurity_o0 = mandatorySecurity_o0;
    }

    /**
     * @return the mandatorySecurity_r0
     */
    public String getMandatorySecurity_r0() {
        return mandatorySecurity_r0;
    }

    /**
     * @param mandatorySecurity_r0
     *            the mandatorySecurity_r0 to set
     */
    public void setMandatorySecurity_r0(String mandatorySecurity_r0) {
        this.mandatorySecurity_r0 = mandatorySecurity_r0;
    }

    /**
     * @return the mandatorySecurity_s1
     */
    public String getMandatorySecurity_s1() {
        return mandatorySecurity_s1;
    }

    /**
     * @param mandatorySecurity_s1
     *            the mandatorySecurity_s1 to set
     */
    public void setMandatorySecurity_s1(String mandatorySecurity_s1) {
        this.mandatorySecurity_s1 = mandatorySecurity_s1;
    }

    /**
     * @return the mandatorySecurity_s0
     */
    public String getMandatorySecurity_s0() {
        return mandatorySecurity_s0;
    }

    /**
     * @param mandatorySecurity_s0
     *            the mandatorySecurity_s0 to set
     */
    public void setMandatorySecurity_s0(String mandatorySecurity_s0) {
        this.mandatorySecurity_s0 = mandatorySecurity_s0;
    }

    /**
     * @return the mandatorySecurity_t0
     */
    public String getMandatorySecurity_t0() {
        return mandatorySecurity_t0;
    }

    /**
     * @param mandatorySecurity_t0
     *            the mandatorySecurity_t0 to set
     */
    public void setMandatorySecurity_t0(String mandatorySecurity_t0) {
        this.mandatorySecurity_t0 = mandatorySecurity_t0;
    }

}
