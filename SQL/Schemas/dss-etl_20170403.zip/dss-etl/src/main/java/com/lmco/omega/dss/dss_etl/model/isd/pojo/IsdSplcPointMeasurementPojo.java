/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.model.isd.pojo;

import java.util.Date;

/**
 * @author bearyman
 */
public class IsdSplcPointMeasurementPojo {

    private int id;
    private Double bandwidth;
    private Double contactAspect;
    private Double contactBearing;
    private Double contactDepth;
    private Double contactRangeYds;
    private Double contactVelocityKts;
    private Double depressionAngle;
    private Boolean include;
    private long lineNumber;
    private Double lowerFreq;
    private Double m1;
    private Double m2;
    private Double m3;
    private Double noiseCorrect;
    private String octantName;
    private Double peakFreq;
    private Double propLoss;
    private Boolean rangePass;
    private Double snr;
    private Integer sensorChannel;
    private Boolean snrPass;
    private long sourceMeasurementId;
    private Double systemCal;
    private Date timestamp;
    private String gramsSplcId;

    /**
     *
     */
    public IsdSplcPointMeasurementPojo() {}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the bandwidth
     */
    public Double getBandwidth() {
        return bandwidth;
    }

    /**
     * @param bandwidth
     *            the bandwidth to set
     */
    public void setBandwidth(Double bandwidth) {
        this.bandwidth = bandwidth;
    }

    /**
     * @return the contactAspect
     */
    public Double getContactAspect() {
        return contactAspect;
    }

    /**
     * @param contactAspect
     *            the contactAspect to set
     */
    public void setContactAspect(Double contactAspect) {
        this.contactAspect = contactAspect;
    }

    /**
     * @return the contactBearing
     */
    public Double getContactBearing() {
        return contactBearing;
    }

    /**
     * @param contactBearing
     *            the contactBearing to set
     */
    public void setContactBearing(Double contactBearing) {
        this.contactBearing = contactBearing;
    }

    /**
     * @return the contactDepth
     */
    public Double getContactDepth() {
        return contactDepth;
    }

    /**
     * @param contactDepth
     *            the contactDepth to set
     */
    public void setContactDepth(Double contactDepth) {
        this.contactDepth = contactDepth;
    }

    /**
     * @return the contactRangeYds
     */
    public Double getContactRangeYds() {
        return contactRangeYds;
    }

    /**
     * @param contactRangeYds
     *            the contactRangeYds to set
     */
    public void setContactRangeYds(Double contactRangeYds) {
        this.contactRangeYds = contactRangeYds;
    }

    /**
     * @return the contactVelocityKts
     */
    public Double getContactVelocityKts() {
        return contactVelocityKts;
    }

    /**
     * @param contactVelocityKts
     *            the contactVelocityKts to set
     */
    public void setContactVelocityKts(Double contactVelocityKts) {
        this.contactVelocityKts = contactVelocityKts;
    }

    /**
     * @return the depressionAngle
     */
    public Double getDepressionAngle() {
        return depressionAngle;
    }

    /**
     * @param depressionAngle
     *            the depressionAngle to set
     */
    public void setDepressionAngle(Double depressionAngle) {
        this.depressionAngle = depressionAngle;
    }

    /**
     * @return the include
     */
    public Boolean getInclude() {
        return include;
    }

    /**
     * @param include
     *            the include to set
     */
    public void setInclude(Boolean include) {
        this.include = include;
    }

    /**
     * @return the lineNumber
     */
    public long getLineNumber() {
        return lineNumber;
    }

    /**
     * @param lineNumber
     *            the lineNumber to set
     */
    public void setLineNumber(long lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * @return the lowerFreq
     */
    public Double getLowerFreq() {
        return lowerFreq;
    }

    /**
     * @param lowerFreq
     *            the lowerFreq to set
     */
    public void setLowerFreq(Double lowerFreq) {
        this.lowerFreq = lowerFreq;
    }

    /**
     * @return the m1
     */
    public Double getM1() {
        return m1;
    }

    /**
     * @param m1
     *            the m1 to set
     */
    public void setM1(Double m1) {
        this.m1 = m1;
    }

    /**
     * @return the m2
     */
    public Double getM2() {
        return m2;
    }

    /**
     * @param m2
     *            the m2 to set
     */
    public void setM2(Double m2) {
        this.m2 = m2;
    }

    /**
     * @return the m3
     */
    public Double getM3() {
        return m3;
    }

    /**
     * @param m3
     *            the m3 to set
     */
    public void setM3(Double m3) {
        this.m3 = m3;
    }

    /**
     * @return the noiseCorrect
     */
    public Double getNoiseCorrect() {
        return noiseCorrect;
    }

    /**
     * @param noiseCorrect
     *            the noiseCorrect to set
     */
    public void setNoiseCorrect(Double noiseCorrect) {
        this.noiseCorrect = noiseCorrect;
    }

    /**
     * @return the octantName
     */
    public String getOctantName() {
        return octantName;
    }

    /**
     * @param octantName
     *            the octantName to set
     */
    public void setOctantName(String octantName) {
        this.octantName = octantName;
    }

    /**
     * @return the peakFreq
     */
    public Double getPeakFreq() {
        return peakFreq;
    }

    /**
     * @param peakFreq
     *            the peakFreq to set
     */
    public void setPeakFreq(Double peakFreq) {
        this.peakFreq = peakFreq;
    }

    /**
     * @return the propLoss
     */
    public Double getPropLoss() {
        return propLoss;
    }

    /**
     * @param propLoss
     *            the propLoss to set
     */
    public void setPropLoss(Double propLoss) {
        this.propLoss = propLoss;
    }

    /**
     * @return the rangePass
     */
    public Boolean getRangePass() {
        return rangePass;
    }

    /**
     * @param rangePass
     *            the rangePass to set
     */
    public void setRangePass(Boolean rangePass) {
        this.rangePass = rangePass;
    }

    /**
     * @return the snr
     */
    public Double getSnr() {
        return snr;
    }

    /**
     * @param snr
     *            the snr to set
     */
    public void setSnr(Double snr) {
        this.snr = snr;
    }

    /**
     * @return the sensorChannel
     */
    public Integer getSensorChannel() {
        return sensorChannel;
    }

    /**
     * @param sensorChannel
     *            the sensorChannel to set
     */
    public void setSensorChannel(Integer sensorChannel) {
        this.sensorChannel = sensorChannel;
    }

    /**
     * @return the snrPass
     */
    public Boolean getSnrPass() {
        return snrPass;
    }

    /**
     * @param snrPass
     *            the snrPass to set
     */
    public void setSnrPass(Boolean snrPass) {
        this.snrPass = snrPass;
    }

    /**
     * @return the sourceMeasurementId
     */
    public long getSourceMeasurementId() {
        return sourceMeasurementId;
    }

    /**
     * @param sourceMeasurementId
     *            the sourceMeasurementId to set
     */
    public void setSourceMeasurementId(long sourceMeasurementId) {
        this.sourceMeasurementId = sourceMeasurementId;
    }

    /**
     * @return the systemCal
     */
    public Double getSystemCal() {
        return systemCal;
    }

    /**
     * @param systemCal
     *            the systemCal to set
     */
    public void setSystemCal(Double systemCal) {
        this.systemCal = systemCal;
    }

    /**
     * @return the timestamp
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the gramsSplcId
     */
    public String getGramsSplcId() {
        return gramsSplcId;
    }

    /**
     * @param gramsSplcId
     *            the gramsSplcId to set
     */
    public void setGramsSplcId(String gramsSplcId) {
        this.gramsSplcId = gramsSplcId;
    }

}
