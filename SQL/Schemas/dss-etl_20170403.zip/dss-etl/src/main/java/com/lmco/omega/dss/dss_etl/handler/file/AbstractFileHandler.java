/**
 * ///-----------SECURITY CLASSIFICATION: UNCLASSIFIED------------------------
 * /// Copyright 2014 - Lockheed Martin Corporation, All Rights Reserved
 * ///
 * /// Notwithstanding any contractor copyright notice, the government has
 * /// Unlimited Rights in this work as defined by DFARS 252.227-7013 and
 * /// 252.227-7014. Use of this work other than as specifically authorized by
 * /// these DFARS Clauses may violate government rights in this work.
 * ///
 * /// DFARS Clause reference: 252.227-7013 (a)(16) and 252.227-7014 (a)(16)
 * /// Unlimited Rights. The Government has the right to use, modify,
 * /// reproduce, perform, display, release or disclose this computer software
 * /// in whole or in part, in any manner, and for any purpose whatsoever,
 * /// and to have or authorize others to do so.
 * ///
 * /// Distribution Statement D. Distribution authorized to the Department of
 * /// Defense and U.S. DoD contractors only in support of US DoD efforts.
 * /// Other requests shall be referred to the ACINT Modernization Program
 * /// Management under the Director of the Office of Naval Intelligence.
 * ///
 * -------------------------------UNCLASSIFIED---------------------------------
 */

package com.lmco.omega.dss.dss_etl.handler.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.geotools.factory.CommonFactoryFinder;
import org.joda.time.DateTime;
import org.opengis.filter.Filter;
import org.opengis.filter.FilterFactory;

import com.incadencecorp.coalesce.common.exceptions.CoalescePersistorException;
import com.incadencecorp.coalesce.framework.datamodel.CoalesceEntity;
import com.lmco.omega.dss.client.api.IFileManagerClient;
import com.lmco.omega.dss.client.api.IMetadataSearchClient;
import com.lmco.omega.dss.client.api.IProductManagerClient;
import com.lmco.omega.dss.client.api.factory.DSSClientFactoryUtil;
import com.lmco.omega.dss.client.api.objects.EntityResult;
import com.lmco.omega.dss.common.DSSConstants;
import com.lmco.omega.dss.common.configuration.DSSSettings;
import com.lmco.omega.dss.common.core.util.ChecksumUtil;
import com.lmco.omega.dss.common.exceptions.DataObjectNotFoundException;
import com.lmco.omega.dss.common.model.BaseFileObject;
import com.lmco.omega.dss.common.model.BaseProductObject;
import com.lmco.omega.dss.common.model.WorkflowEvent;
import com.lmco.omega.dss.common.model.enums.EFileType;
import com.lmco.omega.dss.common.model.record.FileObjectRecord;
import com.lmco.omega.dss.common.model.record.PhysicalFileMetadataRecord;
import com.lmco.omega.dss.common.model.record.interfaces.ITimeIntervalRecord;
import com.lmco.omega.dss.common.model.record.interfaces.legacy.ILegacyBeamAngleRecord;
import com.lmco.omega.dss.common.model.record.interfaces.legacy.ILegacyFrequencyInfoRecord;
import com.lmco.omega.dss.common.model.record.interfaces.legacy.ILegacySensorIdentificationRecord;
import com.lmco.omega.dss.common.model.record.interfaces.legacy.ILegacyTimeSeriesRecord;
import com.lmco.omega.dss.common.util.CoalesceFrameworkUtil;
import com.lmco.omega.dss.dss_etl.common.MigrationLoggerWrapper;
import com.lmco.omega.dss.dss_etl.common.util.EtlFieldSetterUtil;
import com.lmco.omega.dss.dss_etl.common.util.EtlUtilitiesDbms;
import com.lmco.omega.dss.dss_etl.enums.EIsdFileDescriptiveMetadataTypes;
import com.lmco.omega.dss.dss_etl.enums.EIsdTableNames;
import com.lmco.omega.dss.dss_etl.handler.AbstractHandler;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdBeamAnglePojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdFileDescriptiveMetadataPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdFrequencyInfoPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdSensorIdentificationPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdTimeIntervalPojo;
import com.lmco.omega.dss.dss_etl.model.isd.pojo.IsdTimeSeriesPojo;
import com.lmco.omega.dss.interfaces.common.ELinkType;
import com.lmco.omega.dss.interfaces.common.EResultStatusType;
import com.lmco.omega.dss.interfaces.metadatamanager.DataObjectLinkActionType;
import com.lmco.omega.dss.interfaces.productmanager.ProductDataObjectPair;
import com.lmco.omega.dss.mdc.metadatacatalog.util.ProductConverterUtil;

/**
 * @author bearyman
 */
public abstract class AbstractFileHandler extends AbstractHandler {

    protected static final String NO_METADATA_ERR =
            "No file descriptive metadata exists for %s with key %s";
    protected static final String NO_METACARD_ERR = "No metacard exists for file (%s)";
    protected static final String GET_ASSOC_WAI_IDS = "select workflowdataobjects_workflow_0 from "
            + "omega.workflowdataobjects where filedescriptivemetadataid = '%s'";
    protected static final String GET_ASSOC_WF_IDS = "select workflowactivityinstances_wo_0 from "
            + "omega.workflowactivityinstance where workflowactivityinstanceid = '%s'";

    private static final MigrationLoggerWrapper LOGGER = new MigrationLoggerWrapper(
            AbstractFileHandler.class);
    private static final String GET_METADATA_SQL =
            "select * from omega.filedescriptivemetadata where %s = %s";
    private static final String GET_METACARD_SQL =
            "select catalog_metadata from omega.mdf_catalog_tab where catalog_id in ("
                    + "select metacardid from omega.metacard_filedescriptivemetadata where "
                    + "filedescriptivemetadataid = '%s')";
    private static final String IMPORT_FAILED = "Failed to import file (%s). Reason: %s";
    private static final String SAVE_PRODUCT_FAILED =
            "Failed to save product (%s) to database. Reason: %s";
    private static final String PUBLISH_PRODUCT_FAILED = "Failed to publish file (%s). Reason: %s";
    private static final String FILE_ALREADY_PROCESSED =
            "File descriptive data with key (%s) has already been processed";
    private static final String FILE_PERMISSIONS_ERR =
            "File %s does not have read permissions user %s";

    private IFileManagerClient fmClient;
    private IProductManagerClient productClient;
    private IMetadataSearchClient msClient;
    private BaseFileObject importedFile;

    @Override
    public void executeCall() throws Exception {
        mResult.setRecordId(mKey);

        try {
            createPedigree();

            fmClient = DSSClientFactoryUtil.getFileManagerClient(null);
            fmClient.setCredentials(DSSConstants.SYSTEM_PRINCIPAL);

            productClient = DSSClientFactoryUtil.getProductManagerClient(null);
            productClient.setCredentials(DSSConstants.SYSTEM_PRINCIPAL);

            msClient = DSSClientFactoryUtil.getMetadataSearchClient(null);
            msClient.setCredentials(DSSConstants.SYSTEM_PRINCIPAL);

            // Check if this is file descriptive metadata. If so, verify key does not exist in
            // FSD DB, else return success as it was already done by other metadata handlers.
            if (getTableType() == EIsdTableNames.FILE_DESCRIPTIVE_METADATA
                    && CoalesceFrameworkUtil.coalesceEntityExists(convertIsdKeyToUUID(mKey))) {
                LOGGER.debug(String.format(FILE_ALREADY_PROCESSED, mKey));
            } else {

                retrieveIsdData();
                CoalesceEntity entity = mapToCoalesce();
                BaseFileObject fileObject = (BaseFileObject) entity;
                if (validationMode) {
                    validateFile(getFileDescriptiveMetadataPojo(), fileObject);
                    updateFileObjectMetadata(getFileDescriptiveMetadataPojo(), fileObject);
                    validateEntity(fileObject);
                } else {

                    EntityResult<BaseFileObject> result =
                            importFileToFsd(getFileDescriptiveMetadataPojo(), fileObject);

                    if (result.getStatus() == EResultStatusType.SUCCESS) {
                        mResult.setSaveSuccessful(true);

                        importedFile = new BaseFileObject();
                        importedFile.initialize(result.getEntity());

                        EtlUtilitiesDbms.insertClearList(mFsdConn, importedFile.getKey(),
                                                         getTableType().toString(), getTableType()
                                                                 + "_"
                                                                 + this.getClass().getSimpleName());

                        updateFileObjectMetadata(getFileDescriptiveMetadataPojo(), importedFile);
                        if (saveEntity(importedFile)) {
                            // If file descriptive metadata is public then publish.
                            if (getFileDescriptiveMetadataPojo().getIsPublic()) {
                                publishProduct();
                            }
                            savePedigree(importedFile.getKey());
                            createLinkages();
                        }
                    } else {
                        String errMsg =
                                String.format(IMPORT_FAILED, fileObject.getKey(), result.getError());
                        LOGGER.error(errMsg, null);
                        mResult.addResult(errMsg);
                    }
                }
            }
        } catch (Exception e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, methodName, e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        } finally {
            try {
                EtlUtilitiesDbms.closeConn(mIsdConn);
                EtlUtilitiesDbms.closeConn(mFsdConn);
            } catch (SQLException e) {
                LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close connection",
                                           e.getMessage()), e);
            }
        }
    }

    @Override
    protected void createLinkages() {
        methodName = "createLinkages";

        ResultSet results = null;
        ResultSet results2 = null;
        Statement stmt = null;
        Statement stmt2 = null;
        FilterFactory FF = CommonFactoryFinder.getFilterFactory();
        Filter query;

        try {
            stmt = mIsdConn.createStatement();
            stmt2 = mIsdConn.createStatement();

            // Link workflow activity instances
            results =
                    stmt.executeQuery(String.format(GET_ASSOC_WAI_IDS,
                                                    getFileDescriptiveMetadataPojo().getId()));

            LOGGER.debug("GET WF ACTIVITY SQL: "
                    + String.format(GET_ASSOC_WAI_IDS, getFileDescriptiveMetadataPojo().getId()));

            while (results.next()) {
                try {
                    String wfaIdIsd = results.getString("workflowdataobjects_workflow_0");
                    String wfaIdFsd = convertIsdKeyToUUID(wfaIdIsd);

                    LOGGER.debug("WFA ID: " + wfaIdFsd);

                    // Search for pedigree
                    if (mWfa2PedigreeMap.containsKey(wfaIdFsd)) {
                        LOGGER.debug("Retrieving pedigree event: " + mWfa2PedigreeMap.get(wfaIdFsd));

                        WorkflowEvent event = new WorkflowEvent();
                        event.initialize(CoalesceFrameworkUtil.getEntityXml(mWfa2PedigreeMap
                                .get(wfaIdFsd), DSSConstants.SYSTEM_ACCOUNT));
                        LOGGER.debug("Pedigree event found");
                        event.addOutput(importedFile);
                        if (mmClient.updatePedigreeEvent(event)) {
                            LOGGER.debug("Pedigree event updated successfully");
                            // Link file to workflow
                            results2 =
                                    stmt2.executeQuery(String.format(GET_ASSOC_WF_IDS, wfaIdIsd));

                            LOGGER.debug("GET WORKFLOW ID SQL: "
                                    + String.format(GET_ASSOC_WF_IDS, wfaIdIsd));
                            while (results2.next()) {
                                linkEntities(mEntityKey, results2.getString(1),
                                             ELinkType.IS_USED_BY, "queue",
                                             DataObjectLinkActionType.LINK);
                            }
                        } else {
                            LOGGER.debug("Pedigree event failed to update");
                            String errMsg =
                                    String.format(PEDIGREE_SAVE_FAILED, wfaIdFsd,
                                                  mmClient.getLastResult()[0].getResult());
                            LOGGER.error(errMsg, null);
                            mResult.addResult(errMsg);
                        }
                    } else {
                        LOGGER.debug("Pedigree event ID not in map");
                        String errMsg =
                                String.format(PEDIGREE_SAVE_FAILED, wfaIdFsd, "Key not in map");
                        LOGGER.error(errMsg, null);
                        mResult.addResult(errMsg);
                    }
                } catch (SQLException | CoalescePersistorException | DataObjectNotFoundException e) {
                    String errMsg =
                            String.format(DSSConstants.EXCEPTION_OCCURRED, "createLinkages",
                                          e.getMessage());
                    LOGGER.error(errMsg, e);
                    mResult.addResult(errMsg);
                }
            }

        } catch (SQLException | IOException e) {
            String errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "retrieve workflow activity ID",
                                  e.getMessage());
            LOGGER.error(errMsg, e);
            mResult.addResult(errMsg);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                               e.getMessage()), e);
                }
            }
            if (stmt2 != null) {
                try {
                    stmt2.close();
                } catch (SQLException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                               e.getMessage()), e);
                }
            }
        }
    }

    /**
     * Maps the ISD File Descriptive Metadata in the database to a pojo.
     *
     * @param pMetadatapPojo
     *            {@link IsdFileDescriptiveMetadataPojo} to map data to
     * @throws SQLException
     */
    protected void mapFileDescriptiveMetadata(IsdFileDescriptiveMetadataPojo pMetadatapPojo)
            throws Exception {
        methodName = "mapFileDescriptiveMetadata";
        ResultSet results = null;
        Statement stmt = null;
        try {
            stmt = mIsdConn.createStatement();

            results =
                    stmt.executeQuery(String
                            .format(GET_METADATA_SQL, getFileDescriptiveMetadataType()
                                    .getFieldName(), mKey));

            if (results.next()) {
                pMetadatapPojo.setId(results.getString("filedescriptivemetadataid"));
                pMetadatapPojo.setChecksum(results.getString("checksum"));
                pMetadatapPojo.setDateCreated(results.getDate("datecreateditem"));
                pMetadatapPojo.setDateModified(results.getDate("datemodifieditem"));
                pMetadatapPojo.setIsDeletionCandidate(results.getBoolean("deletioncandidate"));
                pMetadatapPojo.setFileName(results.getString("filename"));
                pMetadatapPojo.setFileStatus(results.getString("filestatus"));
                pMetadatapPojo.setFileTypeId(results.getInt("filetypeid"));
                pMetadatapPojo.setForRdte(results.getBoolean("forrdte"));
                pMetadatapPojo.setGroupId(results.getString("groupid"));
                pMetadatapPojo.setLastModifiedBy(results.getString("lastmodifiedby"));
                pMetadatapPojo.setLastUsageDate(results.getDate("lastusagedatetimeitem"));
                pMetadatapPojo.setIsMetacardClassificationValid(results
                        .getBoolean("metacardclassificationvalid"));
                pMetadatapPojo.setMimeType(results.getString("mimetype"));
                pMetadatapPojo.setOther(results.getString("other"));
                pMetadatapPojo.setPermissions(results.getString("permissions"));
                pMetadatapPojo.setProductType(results.getString("producttype"));
                pMetadatapPojo.setIsPublic(results.getBoolean("public_"));
                pMetadatapPojo.setIsPublicToWeb(results.getBoolean("publictoweb"));
                pMetadatapPojo.setReleaseDate(results.getDate("releasedateitem"));
                pMetadatapPojo.setRetentionPolicyId(results.getString("retentionpolicyid"));
                pMetadatapPojo.setFileSize(results.getLong("size_"));
                pMetadatapPojo.setTappStatus(results.getString("tappstatus"));
                pMetadatapPojo.setUri(results.getString("uri"));
                pMetadatapPojo.setUserId(results.getString("userid"));
                pMetadatapPojo.setVersion(results.getInt("version_"));

                setMandatorySecurity(results, pMetadatapPojo.getSecurity());
            } else {
                throw new SQLException(String.format(NO_METADATA_ERR,
                                                     getFileDescriptiveMetadataType().toString(),
                                                     mKey));
            }

        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    /**
     * Sets the beam angle data from the database to a pojo
     *
     * @param pResults
     *            Result set from query
     * @param pPojo
     *            {@link IsdBeamAnglePojo} to map data to
     * @throws SQLException
     */
    protected void setBeamAngleData(ResultSet pResults, IsdBeamAnglePojo pPojo) throws SQLException {
        methodName = "setBeamAngleData";

        pPojo.setStartAngle(pResults.getDouble("startangle"));
        pPojo.setEndAngle(pResults.getDouble("endangle"));
    }

    /**
     * Sets the time series data from the database to a pojo
     *
     * @param pResults
     *            Result set from query
     * @param pPojo
     *            {@link IsdTimeSeriesPojo} to map data to
     * @throws SQLException
     */
    protected void setTimeSeriesData(ResultSet pResults, IsdTimeSeriesPojo pPojo)
            throws SQLException {
        methodName = "setTimeSeriesData";

        pPojo.setA2dConversionFactor(pResults.getDouble("timeseries_a2dconversionfact_0"));
        pPojo.setAuditTrail(pResults.getString("timeseries_audittrail"));
        pPojo.setBitPrecision(pResults.getString("timeseries_bitprecision"));
        pPojo.setComments(pResults.getString("timeseries_comments"));
        pPojo.setMediaId(pResults.getLong("timeseries_mediaid"));
        pPojo.setMediaMode(pResults.getString("timeseries_mediamode"));
        pPojo.setNumberOfChannels(pResults.getInt("timeseries_numberofchannels"));
        pPojo.setSampleRate(pResults.getDouble("timeseries_samplerate"));

        pPojo.getSensorPojo().setSensorName(pResults.getString("timeseries_timesensordata_se_0"));
        pPojo.getSensorPojo()
                .setAssociatedArray(pResults.getString("timeseries_timesensordata_se_1"));

        pPojo.getTimePojo().setStartTime(pResults.getTimestamp("timeseries_timesensordata_ti_0"));
        pPojo.getTimePojo().setEndTime(pResults.getTimestamp("timeseries_timesensordata_ti_1"));
    }

    /**
     * Sets the sensor identification data from the database to a pojo
     *
     * @param pResults
     *            Result set from query
     * @param pPojo
     *            {@link IsdSensorIdentificationPojo} to map data to
     * @throws SQLException
     */
    protected void
            setSensorIdentificationData(ResultSet pResults, IsdSensorIdentificationPojo pPojo)
                    throws SQLException {
        methodName = "setSensorIdentificationData";

        pPojo.setAssociatedArray(pResults.getString("timeseries_timesensordata_se_1"));
        pPojo.setSensorName(pResults.getString(""));
    }

    /**
     * Sets the time interval data from the database to a pojo
     *
     * @param pResults
     *            Result set from query
     * @param pPojo
     *            {@link IsdTimeIntervalPojo} to map data to
     * @throws SQLException
     */
    protected void setTimeIntervalData(ResultSet pResults, IsdTimeIntervalPojo pPojo)
            throws SQLException {
        methodName = "setTimeIntervalData";

        pPojo.setStartTime(pResults.getTimestamp("timeperiod_starttimeitem"));
        pPojo.setEndTime(pResults.getTimestamp("timeperiod_stoptimeitem"));
    }

    /**
     * Sets the frequency info data from the database to a pojo
     *
     * @param pResults
     *            Result set from query
     * @param pPojo
     *            {@link IsdFrequencyInfoPojo} to map data to
     * @throws SQLException
     */
    protected void setFrequencyInfoData(ResultSet pResults, IsdFrequencyInfoPojo pPojo)
            throws SQLException {
        methodName = "setFrequencyInfoData";

        pPojo.setResolution(pResults.getDouble("frequencyinfo_frequencyresol_0"));
        pPojo.setScanRate(pResults.getDouble("frequencyinfo_scanrate"));
        pPojo.setStartFrequency(pResults.getDouble("frequencyinfo_startfrequency"));
        pPojo.setStopFrequency(pResults.getDouble("frequencyinfo_stopfrequency"));
    }

    /**
     * Sets the file metadata in the coalesce entity with that from the ISD pojo
     *
     * @param pPojo
     *            {@link IsdFileDescriptiveMetadataPojo} containing the info
     * @param pEntity
     *            {@link BaseFileObject} to be set
     */
    protected void setCoalesceFileObjectMetadata(IsdFileDescriptiveMetadataPojo pPojo,
            BaseFileObject pEntity) {
        methodName = "setCoalesceFileObjectMetadata";

        FileObjectRecord fileObjectRecord = pEntity.getFileObjectRecord();
        fileObjectRecord.setLastAccessedDate(pPojo.getLastUsageDate(), pPojo.getUserId());
        fileObjectRecord.setLifecyclePolicyId(convertIsdKeyToUUID(pPojo.getRetentionPolicyId()));
        fileObjectRecord.setFileType(getFsdFileType(pPojo.getFileTypeId()));
        fileObjectRecord.setDirectory(DSSSettings.getDropboxDirectory());

        PhysicalFileMetadataRecord fileMetadataRecord =
                pEntity.getCurrentPhysicalFileMetadataRecord();
        fileMetadataRecord.setDeletionCandidate(pPojo.getIsDeletionCandidate());
        fileMetadataRecord.setSize(pPojo.getFileSize());

        File isdFile = new File(pPojo.getUri());
        fileMetadataRecord.setDisplayableFileName(isdFile.getName());
    }

    protected void setCoalesceTimeIntervalRecord(IsdTimeIntervalPojo pPojo,
            ITimeIntervalRecord pRecord) {
        methodName = "setCoalesceTimeIntervalRecord";
        pRecord.setStartTime(pPojo.getStartTime());
        pRecord.setEndTime(pPojo.getEndTime());
    }

    protected void setCoalesceLegacyTimeSeriesRecord(IsdTimeSeriesPojo pPojo,
            ILegacyTimeSeriesRecord pRecord) {
        methodName = "setCoalesceLegacyTimeSeriesRecord";
        pRecord.setA2DConversionFactor(pPojo.getA2dConversionFactor());
        pRecord.setAuditTrail(pPojo.getAuditTrail());
        pRecord.setBitPrecision(pPojo.getBitPrecision());
        pRecord.setComments(pPojo.getComments());
        pRecord.setMediaId(pPojo.getMediaId());
        pRecord.setMediaMode(formatEnumFieldVal(pPojo.getMediaMode()));
        pRecord.setNumberOfChannels(pPojo.getNumberOfChannels());
        pRecord.setSampleRate(pPojo.getSampleRate());
    }

    protected void setCoalesceLegacyFrequencyInfoRecord(IsdFrequencyInfoPojo pPojo,
            ILegacyFrequencyInfoRecord pRecord) {
        methodName = "setCoalesceLegacyFrequencyInfoRecord";
        pRecord.setFrequencyResolution(pPojo.getResolution());
        pRecord.setScanRate(pPojo.getScanRate());
        pRecord.setStartFrequency(pPojo.getStartFrequency());
        pRecord.setStopFrequency(pPojo.getStopFrequency());
    }

    protected void setCoalesceLegacySensorIdentificationRecord(IsdSensorIdentificationPojo pPojo,
            ILegacySensorIdentificationRecord pRecord) {
        methodName = "setCoalesceLegacySensorIdentificationRecord";
        pRecord.setAssociatedArray(pPojo.getAssociatedArray());
        pRecord.setSensorName(pPojo.getSensorName());
    }

    protected void setCoalesceLegacyBeamAngleRecord(IsdBeamAnglePojo pPojo,
            ILegacyBeamAngleRecord pRecord) {
        methodName = "setCoalesceLegacyBeamAngleRecord";
        pRecord.setStartAngle(pPojo.getStartAngle());
        pRecord.setEndAngle(pPojo.getEndAngle());
    }

    /**
     * Converts the ISD file type ID to an FSD {@link EFileType}
     *
     * @param pIsdFileTypeId
     *            ID of ISD file type
     * @return {@link EFileType}
     */
    protected EFileType getFsdFileType(int pIsdFileTypeId) {
        switch (pIsdFileTypeId) {
            case 1: // TIMESERIES_ETS - TPS ETS
                return EFileType.TPS_ETS;
            case 2: // TIMESERIES_CTS - TPS CTS
                return EFileType.TPS_CTS;
            case 3: // TIMESERIES_WAV - WAV
                return EFileType.WAV;
            case 4: // TPS_NAD - TPS NAD
                return EFileType.TPS_NAD;
            case 5: // TPS_OWNSHIP - TPS OWNSHIP TXT
                return EFileType.LEGACY_TPS_OWNSHIP;
            case 6: // TPS_SENSOR_CONFIG - TPS SENSOR CONFIG XML
                return EFileType.LEGACY_TPS_SENSOR_CONFIG;
            case 7: // TPS_SOUND_SPEED - TPS SOUND SPEED TXT
                return EFileType.LEGACY_TPS_SOUND_SPEED;
            case 8: // TPS_TIMESTAMP - TPS TIMESTAMP TXT
                return EFileType.TPS_TIMESTAMP;
            case 9: // TPS_PSD - TPS PSD
                return EFileType.LEGACY_PSD;
            case 10: // TIMESERIES_SBTS - TPS SBTS
                return EFileType.TPS_SBTS;
            case 11: // TPS_BEARING_CVS - TPS Bearing Time History CSV
                return EFileType.LEGACY_BEARING_TIME_HISTORY_CSV;
            case 12: // TPS_BEARING_TXT - TPS Bearing Time History TXT
                return EFileType.LEGACY_BEARING_TIME_HISTORY_TXT;
            case 13: // IMAGE_TIFF - TIFF Image
                return EFileType.TIFF;
            case 14: // TPS_AUXILIARY_SUPPORT_CSV - TPS Auxiliary Support CSV
                return EFileType.LEGACY_AUXILIARY_SUPPORT_CSV;
            case 15: // TPS_AUXILIARY_SUPPORT_BIN - TPS Auxiliary Support BIN
                return EFileType.LEGACY_AUXILIARY_SUPPORT_BIN;
            case 16: // TPS_ARRAY_GAIN_HISTORY - TPS Array Gain History TXT
                return EFileType.LEGACY_ARRAY_GAIN_HISTORY;
            case 17: // TIMESERIES_TAPS_DAT - DAT
                return EFileType.LEGACY_DAT;
            case 18: // ACINT_AUXML_XML - ACINT AuxiliaryML XML
                return EFileType.LEGACY_ACINT_AUXML;
            case 19: // TPS_FAN_OF_BEAMS - TPS FOB
                return EFileType.TPS_FOB;
            case 20: // TPS_BTR - TPS BTR
                return EFileType.LEGACY_TPS_BTR;
            case 21: // A_21_HTML_PNG - ACINT 21 HTML + PNG ZIP
                return EFileType.LEGACY_HTML_PNG;
            case 22: // TPS_A_21_VERT_MSMTS_CSV - ACINT 21 Vertical Measurement Bearing CSV
                return EFileType.LEGACY_A21_VERT_MSMTS;
            case 23: // TPS_A_21_HORZ_MSMTS_CSV - ACINT 21 Horizontal Measurement Bearing CSV
                return EFileType.LEGACY_A21_HORZ_MSMTS_CSV;
            case 24: // TPS_A_21_HORZ_MSMTS_XLS - ACINT 21 Horizontal Measurement Bearing XLS
                return EFileType.LEGACY_A21_HORZ_MSMTS_XLS;
            case 25: // TIMESERIES_DIFTS - DIFTS
                return EFileType.TPS_DIFTS;
            case 26: // A_21_WORKPACKAGE - ACINT 21 Workpackage
                return EFileType.ZIP;
            case 27: // TPS_SGRM - TPS SGRM
                return EFileType.LEGACY_TPS_SGRM;
            case 30: // IMAGE_JPEG - JPEG Image
                return EFileType.JPEG;
            case 31: // IMAGE_PNG - PNG Image
                return EFileType.PNG;
            case 36: // MSOFFICE_PPT - MS Oficce PPT
                return EFileType.MSOFFICE_PPT;
            case 37: // IMAGE_PNG - TAPP PNG
                return EFileType.PNG;
            case 48: // FORN_PKT_MDF - MDF
                return EFileType.LEGACY_MDF;
            case 49: // FORN_PKT_GFF - GFF
                return EFileType.LEGACY_GFF;
            case 50: // MPX_RAW - GRAMS TAPS RAW
                return EFileType.LEGACY_TAPS_RAW;
            case 53: // IMAGE_GIF - GIF Image
                return EFileType.GIF;
            case 54: // IMAGE_BMP - BMP Imagge
                return EFileType.BMP;
            case 56: // TAPS_SPLC_NODB - GRAMS TAPS SPLc XML(File Copy Only)
                return EFileType.LEGACY_TAPS_SPLC_NODB;
            case 57: // TAPS_SPLC - GRAMS TAPS SPLc XML(Populate SPLc DB)
                return EFileType.LEGACY_TAPS_SPLC;
            case 58: // TAPS_SPLC_TXT - GRAMS TAPS SPLc TXT
                return EFileType.LEGACY_TAPS_SPLC_TXT;
            case 60: // TAPS_TMDB - GRAM TAPS TMDB
                return EFileType.LEGACY_TAPS_TMDB;
            case 61: // TAPS_TAP - GRAMS TAP
                return EFileType.LEGACY_TAPS_TAP;
            case 62: // GRAMS_PROJECT_XML - GRAMS New Project XML
                return EFileType.LEGACY_GRAMS_PROJECT;
            case 63: // GRAMS_WORKPACKAGE_XML - GRAMS Workpackage XML
                return EFileType.XML;
            case 64: // GRAMS_WORKPACKAGE_TAR - GRAMS TAPS Workpackage
                return EFileType.ZIP;
            case 65: // GRAMS_GRM - GRAMS GRM
                return EFileType.LEGACY_GRAMS_GRM;
            case 67: // MSOFFICE_XLS - MS Office Excel
                return EFileType.MSOFFICE_XLS;
            case 68: // MSOFFICE_DOC - MS Office Doc
                return EFileType.MSOFFICE_DOC;
            case 69: // MSOFFICE_DOCX - MS Office Docx
                return EFileType.MSOFFICE_DOCX;
            case 70: // MSOFFICE_XLSX - MS Office Excel XLSX
                return EFileType.MSOFFICE_XLSX;
            case 75: // ORION_ODB - GRAMS Orion ODB
                return EFileType.LEGACY_ORION_ODB;
            case 76: // ORION_OII - GRAMS Orion OII
                return EFileType.LEGACY_ORION_OII;
            case 77: // ORION_RAW - GRAMS Orion RAW
                return EFileType.LEGACY_ORION_RAW;
            case 96: // ORION_KML - GRAMS Orion KML
                return EFileType.LEGACY_ORION_KML;
            case 97: // ORION_KMZ - GRAMS Orion KMZ
                return EFileType.LEGACY_ORION_KMZ;
            case 98: // ORION_WORKPACKAGE - GRAMS Orion Workpackage
                return EFileType.UNKNOWN;
            case 105: // GLOBALMAX_TARGET_TRACK - GRAMS GLOBALMAX Target Track Solution CSV
                return EFileType.LEGACY_GLOBALMAX_TARGET_TRACK;
            case 106: // GLOBALMAX_TABLE_TXT - GRAMS GLOBALMAX Table TXT
                return EFileType.LEGACY_GLOBALMAX_TABLE_TXT;
            case 107: // GLOBALMAX_TABLE_CSV - GRAMS GLOBALMAX Table CSV
                return EFileType.LEGACY_GLOBALMAX_TABLE_CSV;
            case 108: // GLOBALMAX_BATHY_TXT - GRAMS GLOBALMAX Bathy TXT
                return EFileType.LEGACY_GLOBALMAX_BATHY_TXT;
            case 109: // GLOBALMAX_BATHY_CSV - GRAMS GLOBALMAX Bathy CSV
                return EFileType.LEGACY_GLOBALMAX_BATHY_CSV;
            case 110: // GLOBALMAX_TUNING_TXT - GRAMS GLOBALMAX Tuning TXT
                return EFileType.LEGACY_GLOBALMAX_TUNING_TXT;
            case 111: // GLOBALMAX_TUNING_CSV - GRAMS GLOBALMAX Tuning CSV
                return EFileType.LEGACY_GLOBALMAX_TUNING_CSV;
            case 112: // PCAMAP_TRACK_CSV - PCAMAP Track CSV
                return EFileType.LEGACY_PCAMAP_TRACK;
            case 113: // PCAMAP_LOSS_CSV - PCAMAP Loss CSV
                return EFileType.LEGACY_PCAMAP_PROP_LOSS;
            case 114: // GAI_CSV - GAI CSV
                return EFileType.LEGACY_GAI;
            case 300: // UNKNOWN
            default:
                return EFileType.UNKNOWN;
        }
    }

    /**
     * Imports the ISD file into FSD
     *
     * @param pPojo
     *            {@link IsdFileDescriptiveMetadataPojo}
     * @param pEntity
     *            {@link BaseFileObject}
     * @return Updated {@link BaseFileObject} containing information about the new FSD entity
     * @throws IOException
     * @throws NoSuchAlgorithmException
     * @throws URISyntaxException
     * @throws ClassNotFoundException
     */
    protected EntityResult<BaseFileObject> importFileToFsd(IsdFileDescriptiveMetadataPojo pPojo,
            BaseFileObject pEntity) throws Exception {
        methodName = "importFileToFsd";

        EntityResult<BaseFileObject> result = null;

        // Check if file exists
        URI uri = new URI(pPojo.getUri()); // XXX MIGHT BE SAFER TO JUST PARSE STRING
        File isdFile = new File(uri.getPath());
        if (isdFile.exists()) {

            // Copy file to dropbox
            Path dropboxPath =
                    Paths.get(DSSSettings.getDropboxDirectory()).resolve(isdFile.getName());
            Files.copy(isdFile.toPath(), dropboxPath, StandardCopyOption.REPLACE_EXISTING);

            // Calculate partial checksum
            String checksum = ChecksumUtil.generatePartialChecksum(dropboxPath.toString());
            pEntity.getCurrentPhysicalFileMetadataRecord().setChecksum(checksum);

            EntityResult<BaseFileObject>[] results = fmClient.importFile(pEntity);

            if (results[0].getStatus() == EResultStatusType.SUCCESS) {
                result = new EntityResult<BaseFileObject>(results[0].getEntity());
            } else {
                result = new EntityResult<BaseFileObject>(results[0].getError());
            }

        } else {
            throw new FileNotFoundException(String.format(DSSConstants.FILE_VERIFY_FAILED,
                                                          isdFile.getName(), isdFile.getParent()));
        }

        return result;
    }

    protected void updateFileObjectMetadata(IsdFileDescriptiveMetadataPojo pPojo,
            BaseFileObject pEntity) {
        methodName = "updateFileObjectMetadata";
        pEntity.getCurrentPhysicalFileMetadataRecord().setDisplayableFileName(pPojo.getFileName());
        pEntity.getFileObjectRecord().setLastAccessedDate(pPojo.getLastUsageDate(),
                                                          pPojo.getUserId());
        pEntity.getDataObjectRecord().setCreatedBy(pPojo.getUserId());

        if (pPojo.getDateModified() != null) {
            pEntity.getFileObjectRecord().setLastModified(new DateTime(pPojo.getDateModified()));
        }

        CoalesceEntity cEntity = new CoalesceEntity();
        cEntity.initialize(pEntity);
        cEntity.setDateCreated(new DateTime(pPojo.getDateCreated()));
        cEntity.setModifiedBy(DSSConstants.SYSTEM_ACCOUNT);
        if (pPojo.getLastModifiedBy() != null) {
            cEntity.setModifiedBy(pPojo.getLastModifiedBy());
        }
    }

    private void publishProduct() {
        methodName = "publishProduct";
        ResultSet results = null;
        Statement stmt = null;
        String errMsg = null;
        try {
            stmt = mIsdConn.createStatement();

            results = stmt.executeQuery(String.format(GET_METACARD_SQL, mEntityKey));

            if (results.next()) {
                String metacard = results.getString(1);

                BaseProductObject product = ProductConverterUtil.metacardToProduct(metacard);
                // TODO should we set the security of the imported file object?
                EtlFieldSetterUtil.setMandatoryBaseFields(product);
                if (mmClient.createDataObject(product)) {
                    ProductDataObjectPair pair = new ProductDataObjectPair();
                    pair.setDataObjectId(mEntityKey);
                    pair.setProductId(product.getKey());
                    if (!productClient.publishProduct(pair)) {
                        errMsg =
                                String.format(PUBLISH_PRODUCT_FAILED, mEntityKey,
                                              productClient.getLastResult()[0].getResult());
                    }
                } else {
                    errMsg =
                            String.format(SAVE_PRODUCT_FAILED, product.getKey(),
                                          mmClient.getLastResult()[0].getResult());
                }
            } else {
                errMsg = String.format(NO_METACARD_ERR, mEntityKey);
            }
        } catch (Exception e) {
            errMsg =
                    String.format(DSSConstants.EXCEPTION_OCCURRED, "publishProduct", e.getMessage());
        } finally {
            if (errMsg != null) {
                LOGGER.error(errMsg, null);
                mResult.addResult(errMsg);
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    LOGGER.error(String.format(DSSConstants.EXCEPTION_OCCURRED, "close statement",
                                               e.getMessage()), e);
                }
            }
        }
    }

    private void validateFile(IsdFileDescriptiveMetadataPojo pPojo, BaseFileObject pEntity) {
        methodName = "validateFile";

        // Check if file exists
        try {
            URI uri = new URI(pPojo.getUri());
            File isdFile = new File(uri.getPath());
            if (isdFile.exists()) {

                // Check permissions
                if (!isdFile.canRead()) {
                    mResult.addResult(String.format(FILE_PERMISSIONS_ERR,
                                                    isdFile.getAbsolutePath(),
                                                    DSSConstants.SYSTEM_ACCOUNT));
                }

            } else {
                mResult.addResult(String.format(DSSConstants.FILE_VERIFY_FAILED, isdFile.getName(),
                                                isdFile.getParent()));
            }
        } catch (URISyntaxException e) {
            mResult.addResult(String.format(DSSConstants.EXCEPTION_OCCURRED, "get ISD file URI",
                                            e.getMessage()));
        }
    }

    protected abstract EIsdFileDescriptiveMetadataTypes getFileDescriptiveMetadataType();

    protected abstract IsdFileDescriptiveMetadataPojo getFileDescriptiveMetadataPojo();

}
