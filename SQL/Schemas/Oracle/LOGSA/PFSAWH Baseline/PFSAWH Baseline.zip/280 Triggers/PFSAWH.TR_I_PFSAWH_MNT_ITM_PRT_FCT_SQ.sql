--
-- TR_I_PFSAWH_MNT_ITM_PRT_FCT_SQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_MNT_ITM_PRT_FCT_SQ" 
BEFORE INSERT
ON PFSAWH.PFSAWH_MAINT_ITM_PRT_FACT REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT pfsawh_maint_itm_prt_fact_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;
    :new.status   := 'C';
    :new.lst_updt := sysdate;
    :new.updt_by  := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        RAISE;
       
END tr_i_pfsawh_mnt_itm_prt_fct_sq;
/


