--
-- TR_U_PFSAWH_CODE_DEF_UPDT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_U_PFSAWH_CODE_DEF_UPDT" 
BEFORE UPDATE
ON     pfsawh_code_definition_ref
FOR EACH ROW
DECLARE

-- Exception handling variables (ps_)

ps_procedure_name                std_pfsawh_debug_tbl.ps_procedure%TYPE  
    := 'tr_u_pfsawh_code_def_updt';  /*  */
ps_location                      std_pfsawh_debug_tbl.ps_location%TYPE  
    := 'Begin';                /*  */
ps_oerr                          std_pfsawh_debug_tbl.ps_oerr%TYPE   
    := null;                   /*  */
ps_msg                           std_pfsawh_debug_tbl.ps_msg%TYPE 
    := null;                   /*  */
ps_id_key                        std_pfsawh_debug_tbl.ps_id_key%TYPE 
    := 'tr_u_pfsawh_code_def_updt';  /*  */
    -- coder responsible for identying key for debug

-- module variables (v_)

v_update_date pfsawh_code_definition_ref.update_date%TYPE  := sysdate;
v_update_by   pfsawh_code_definition_ref.update_by%TYPE    := user;

BEGIN
    
    :new.update_date := v_update_date;
    :new.update_by   := v_update_by;

    EXCEPTION
        WHEN no_data_found THEN
            NULL;
        WHEN others THEN
		    ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := '';
		     INSERT 
            INTO std_pfsawh_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
		     VALUES 
                (
                ps_procedure_name, ps_oerr, ps_location, user, 
                ps_id_key, ps_msg, sysdate);

--        RAISE;
       
END tr_u_pfsawh_code_def_updt;
/


