--
-- TR_I_PFSAWH_FRC_UNT_TOE_FCT_SQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_FRC_UNT_TOE_FCT_SQ" 
BEFORE INSERT
ON pfsawh_force_unit_mtoe_fact
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT pfsawh_force_unit_mtoe_fact_sq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;
    :new.status   := 'C';
    :new.lst_updt := sysdate;
    :new.updt_by  := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        RAISE;
       
END tr_i_pfsawh_frc_unt_toe_fct_sq;
/


