--
-- TR_PFSAWH_FCT_LD_SN_CTRL_AUDT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_pfsawh_fct_ld_sn_ctrl_audt 
BEFORE UPDATE OR DELETE ON PFSAWH.PFSAWH_FACT_LD_SN_CNTRL 
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_pfsawh_fct_ld_sn_ctrl_audt 
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
-- ASSUMPTIONS:
-- 
-- LIMITATIONS:
-- 
--       NOTES:
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- 
-- Date       ECP #            Author           Description
-- ---------  ---------------  ---------------  --------------------------------
-- 24FEB2009                   Gene Belford     Trigger Created 
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
DECLARE

ps_oerr             VARCHAR2(6)   := NULL;
ps_location         VARCHAR2(10)  := NULL;
ps_procedure_name   VARCHAR2(30)  := 'tr_pfsawh_fct_ld_sn_ctrl_audt';
ps_msg              VARCHAR2(200) := 'Trigger failed';
ps_id_key           VARCHAR2(200) := NULL;  

BEGIN

    IF UPDATING THEN
        INSERT 
        INTO pfsawh_fact_ld_sn_cntrl_audt 
            (
            rec_id,
            update_by,
            update_date,
            old_physical_item_id,
            new_physical_item_id,
            old_niin,
            new_niin,
            old_physical_item_sn_id,
            new_physical_item_sn_id,
            old_serial_number,
            new_serial_number,
            old_item_nomen_standard,
            new_item_nomen_standard,
            old_status,
            new_status,
            old_serial_number_new_flag, 
            new_serial_number_new_flag, 
            old_new_period_data_flag, 
            new_new_period_data_flag, 
            old_touch_count, 
            new_touch_count, 
            old_load_date,
            new_load_date,
            old_scheduled_load_date, 
            new_scheduled_load_date 
            )
        VALUES 
            (
            :old.rec_id, 
            user, 
            sysdate,
            :old.physical_item_id,
            :new.physical_item_id,
            :old.niin,
            :new.niin,
            :old.physical_item_sn_id,
            :new.physical_item_sn_id,
            :old.serial_number,
            :new.serial_number,
            :old.item_nomen_standard,
            :new.item_nomen_standard,
            :old.status,
            :new.status,
            :old.serial_number_new_flag, 
            :new.serial_number_new_flag, 
            :old.new_period_data_flag, 
            :new.new_period_data_flag, 
            :old.touch_count, 
            :new.touch_count, 
            :old.load_date,
            :new.load_date,
            :old.scheduled_load_date, 
            :new.scheduled_load_date 
             );
    ELSE 
        INSERT 
        INTO pfsawh_fact_ld_sn_cntrl_audt 
            (
            rec_id,
            update_by,
            update_date,
            old_physical_item_id,
            old_niin,
            old_physical_item_sn_id,
            old_serial_number,
            old_item_nomen_standard,
            old_status,
            old_serial_number_new_flag, 
            old_new_period_data_flag, 
            old_touch_count, 
            old_load_date,
            old_scheduled_load_date 
            )
        VALUES 
            (
            :old.rec_id, 
            user, 
            sysdate,
            :old.physical_item_id,
            :old.niin,
            :old.physical_item_sn_id,
            :old.serial_number,
            :old.item_nomen_standard,
            :old.status,
            :old.serial_number_new_flag, 
            :old.new_period_data_flag, 
            :old.touch_count, 
            :old.load_date,
            :old.scheduled_load_date 
             );
    END IF;
    

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.rec_id; 
    
    INSERT 
    INTO std_pfsawh_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of trigger
/


