--
-- TR_I_PFSAWH_ITEM_SN_DIM_SEQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_ITEM_SN_DIM_SEQ" 
BEFORE INSERT
ON PFSAWH.PFSAWH_ITEM_SN_DIM REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_item_sn_dim_id NUMBER;

begin
   v_item_sn_dim_id := 0;

   select pfsawh_item_sn_seq.nextval into v_item_sn_dim_id from dual;
   :new.rec_id := v_item_sn_dim_id;
--   :new.status := 'Z';
   :new.lst_updt := sysdate;
   :new.updt_by  := user;

   exception
     when others then
       -- consider logging the error and then re-raise
       raise;
       
end tr_i_gb_pfsa_item_sn_seq;
/


