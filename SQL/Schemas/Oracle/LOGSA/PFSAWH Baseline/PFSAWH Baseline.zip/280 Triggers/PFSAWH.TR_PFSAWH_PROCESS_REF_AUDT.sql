--
-- TR_PFSAWH_PROCESS_REF_AUDT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_pfsawh_process_ref_audt
BEFORE UPDATE OR DELETE ON PFSAWH.PFSAWH_PROCESS_REF 
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_pfsawh_process_ref_audt 
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
-- ASSUMPTIONS:
-- 
-- LIMITATIONS:
-- 
--       NOTES:
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- 
-- Date       ECP #            Author           Description
-- ---------  ---------------  ---------------  --------------------------------
-- 23FEB2009                   Gene Belford     Trigger Created 
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
DECLARE

ps_oerr             VARCHAR2(6)   := NULL;
ps_location         VARCHAR2(10)  := NULL;
ps_procedure_name   VARCHAR2(30)  := 'tr_pfsawh_process_ref_audt';
ps_msg              VARCHAR2(200) := 'Trigger failed';
ps_id_key           VARCHAR2(200) := NULL; -- set in cases 

BEGIN 

    IF UPDATING THEN 
        INSERT 
        INTO pfsawh_process_ref_audt 
            (
            process_recid,
            update_by,
            update_date,
            old_process_key,
            new_process_key,
            old_process_description,
            new_process_description,
            old_status,
            new_status,
            old_run_cntrl,
            new_run_cntrl,
            old_override_run_cntrl,
            new_override_run_cntrl
            )
        VALUES 
            (
            :old.process_recid, 
            user, 
            sysdate,
            :old.process_key, 
            :new.process_key, 
            :old.process_description, 
            :new.process_description, 
            :old.status, 
            :new.status, 
            :old.run_cntrl, 
            :new.run_cntrl, 
            :old.override_run_cntrl,
            :new.override_run_cntrl
            );
    ELSE
        INSERT 
        INTO pfsawh_process_ref_audt 
            (
            process_recid,
            update_by,
            update_date,
            old_process_key,
            old_process_description,
            old_status,
            old_run_cntrl,
            old_override_run_cntrl
            )
        VALUES 
            (
            :old.process_recid, 
            user, 
            sysdate,
            :old.process_key, 
            :old.process_description, 
            :old.status, 
            :old.run_cntrl, 
            :old.override_run_cntrl
            );
    END IF;

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.process_recid; 
    
    INSERT 
    INTO std_pfsawh_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of trigger
/


