--
-- TR_I_PFSAWH_MV_REFRESH_SEQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_i_pfsawh_mv_refresh_seq
BEFORE INSERT
ON PFSAWH.PFSAWH_MV_REFRESH_STATUS REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
DECLARE
v_rec_id NUMBER;

/******************** TEAM ITSS ************************************************

       NAME:    tr_i_pfsawh_mv_refresh_seq

    PURPOSE:    To perform work as each row is inserted.
   
ASSUMPTIONS:

LIMITATIONS:

      NOTES:

  Date      ECP #            Author           Description
----------  ---------------  ---------------  ---------------------------------
01/29/2009                   Daniel Shrider   Trigger Created'
*/

BEGIN
    v_rec_id := 0;
    
    SELECT PFSAWH_MV_REFRESH_SEQ.nextval 
    INTO  v_rec_id 
    FROM dual;
    
    :new.MV_REFRESH_ID      := v_rec_id;
--    :new.status      := 'Z';
    :new.lst_updt    := SYSDATE;
    :new.updt_by     := USER;
    
    :new.insert_date := SYSDATE;
    
    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        
        RAISE;
       
END tr_i_pfsawh_mv_refresh_seq;
/


