--
-- TR_PFSAWH_PROCESSES  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_pfsawh_processes
BEFORE UPDATE ON PFSAWH.PFSAWH_PROCESSES FOR EACH ROW
-- 
-- 
-- TR_PFSAWH_PROCESSES  (Trigger) 
--
--
-- This trigger creates a history record for each update record in the pfsa_processes table.
-- created 19-JAN-2004   
-- created by dave hendricks
-- 
-- PRODUCTION DATE:  25-SEP-2004 
-- 
-- Copied and modified for use in PFSAWH 
-- Created By:   Gene Belford 
-- Created Date: 23-Mar-2008 
--
DECLARE

ps_oerr             VARCHAR2(6)   := NULL;
ps_location         VARCHAR2(10)  := NULL;
ps_procedure_name   VARCHAR2(30)  := 'TR_PFSAWH_PROCESSES';
ps_msg              VARCHAR2(200) := 'Trigger_failed';
ps_id_key           VARCHAR2(200) := NULL; -- set in cases 


BEGIN

    INSERT 
    INTO pfsawh_processes_hist 
        (
        pfsa_process, 
        last_run, 
        who_ran, 
        last_run_status, 
        last_run_status_time, 
        last_run_compl, 
        lst_updt
        )
    VALUES 
        (
        :new.pfsa_process, 
        :new.last_run, 
        :new.who_ran, 
        :new.last_run_status, 
        :new.last_run_status_time, 
        :new.last_run_compl, 
        sysdate
        );

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :new.pfsa_process; 
    
    INSERT 
    INTO std_pfsawh_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of trigger
/


