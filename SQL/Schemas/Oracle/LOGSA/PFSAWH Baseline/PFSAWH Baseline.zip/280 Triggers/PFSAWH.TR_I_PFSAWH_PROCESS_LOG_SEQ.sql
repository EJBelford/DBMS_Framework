--
-- TR_I_PFSAWH_PROCESS_LOG_SEQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_PROCESS_LOG_SEQ" 
BEFORE INSERT
ON pfsawh_process_log 
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_process_key NUMBER;

BEGIN
   v_process_key := 0;

   SELECT pfsawh_process_log_seq.nextval 
   INTO   v_process_key 
   FROM   dual; 
   
   :new.process_key := v_process_key;

   EXCEPTION
     WHEN others THEN
       -- consider logging the error and then re-raise
       RAISE;
       
END tr_i_pfsawh_process_log_seq;
/


