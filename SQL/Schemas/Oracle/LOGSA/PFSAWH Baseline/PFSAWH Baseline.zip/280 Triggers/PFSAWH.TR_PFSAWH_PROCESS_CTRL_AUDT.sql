--
-- TR_PFSAWH_PROCESS_CTRL_AUDT  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_pfsawh_process_ctrl_audt
BEFORE UPDATE OR DELETE ON PFSAWH.PFSAWH_PROCESS_CONTROL 
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_pfsawh_process_ctrl_audt
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
-- ASSUMPTIONS:
-- 
-- LIMITATIONS:
-- 
--       NOTES:
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- 
-- Date       ECP #            Author           Description
-- ---------  ---------------  ---------------  --------------------------------
-- 24FEB2009                   Gene Belford     Trigger Created 
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
DECLARE

ps_oerr             VARCHAR2(6)   := NULL;
ps_location         VARCHAR2(10)  := NULL;
ps_procedure_name   VARCHAR2(30)  := 'tr_pfsawh_process_ctrl_audt';
ps_msg              VARCHAR2(200) := 'Trigger failed';
ps_id_key           VARCHAR2(200) := NULL; 

BEGIN

    IF UPDATING THEN 
        INSERT 
        INTO pfsawh_process_control_audt 
            (
            process_control_id,
            update_by,
            update_date,
            old_process_control_name,
            new_process_control_name,
            old_process_control_value,
            new_process_control_value,
            old_status,
            new_status,  
            old_process_control_desc,
            new_process_control_desc 
            )
        VALUES 
            (
            :old.process_control_id, 
            user, 
            sysdate,
            :old.process_control_name, 
            :new.process_control_name, 
            :old.process_control_value, 
            :new.process_control_value, 
            :old.status, 
            :new.status, 
            :old.process_control_description, 
            :new.process_control_description 
            ); 
    ELSE 
        INSERT 
        INTO pfsawh_process_control_audt 
            (
            process_control_id,
            update_by,
            update_date,
            old_process_control_name,
            old_process_control_value,
            old_status,
            old_process_control_desc 
            )
        VALUES 
            (
            :old.process_control_id, 
            user, 
            sysdate,
            :old.process_control_name, 
            :old.process_control_value, 
            :old.status, 
            :old.process_control_description 
            ); 
    END IF;

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.process_control_id; 
    
    INSERT 
    INTO std_pfsawh_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of trigger
/


