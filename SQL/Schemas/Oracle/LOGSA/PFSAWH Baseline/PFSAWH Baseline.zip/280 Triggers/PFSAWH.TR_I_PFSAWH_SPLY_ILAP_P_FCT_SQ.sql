--
-- TR_I_PFSAWH_SPLY_ILAP_P_FCT_SQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_SPLY_ILAP_P_FCT_SQ" 
BEFORE INSERT
ON pfsawh_supply_ilap_p_fact
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT pfsawh_supply_ilap_p_fact_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;
    :new.status   := 'C';
    :new.lst_updt := sysdate;
    :new.updt_by  := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        RAISE;
       
END tr_i_pfsawh_sply_ilap_p_fct_sq;
/


