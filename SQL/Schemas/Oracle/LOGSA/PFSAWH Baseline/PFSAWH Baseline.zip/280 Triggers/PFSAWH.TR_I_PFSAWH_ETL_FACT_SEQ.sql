--
-- TR_I_PFSAWH_ETL_FACT_SEQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH.tr_i_pfsawh_etl_fact_seq 

BEFORE INSERT
ON PFSAWH.PFSAWH_ETL_FACT REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_i_pfsawh_etl_fact_sq.sql 
-- 
--     PURPOSE:    To perform work as each row is inserted.
--    
-- ASSUMPTIONS:
-- 
-- LIMITATIONS:
-- 
--       NOTES:
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- 
-- Date       ECP #            Author           Description
-- ---------  ---------------  ---------------  --------------------------------
-- 02MAR009                   Gene Belford     Trigger Created
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
DECLARE
v_rec_id NUMBER;

-- module variables (v_)

v_update_date pfsawh_fact_ld_niin_cntrl.update_date%TYPE  := sysdate;
v_update_by   pfsawh_fact_ld_niin_cntrl.update_by%TYPE    := user;

BEGIN 

    v_rec_id := 0;

    SELECT pfsawh_etl_fact_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id      := v_rec_id;
    :new.status      := 'C';
    :new.lst_updt    := sysdate;
    :new.updt_by     := user;

    :new.active_flag := 'Y';
    :new.active_date := sysdate;
    :new.insert_by   := user;
    :new.insert_date := sysdate;
    
    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        RAISE;
       
END tr_i_pfsawh_fct_ld_nin_cntl_sq;
/


