--
-- TR_I_PFSAWH_SOURCE_STAT_SEQ  (Trigger) 
--
CREATE OR REPLACE TRIGGER PFSAWH."TR_I_PFSAWH_SOURCE_STAT_SEQ" 
BEFORE INSERT
ON PFSAWH.PFSAWH_SOURCE_STAT_REF REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT pfsawh_source_stat_ref_id.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.source_hist_stat_id := v_rec_id;
    :new.status              := 'Z';
    :new.lst_updt            := sysdate;
    :new.updt_by             := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise
        RAISE;
       
END tr_i_gb_pfsawh_source_stat_seq;
/


