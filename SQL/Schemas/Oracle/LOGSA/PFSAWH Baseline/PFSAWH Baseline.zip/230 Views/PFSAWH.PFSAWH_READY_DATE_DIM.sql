--
-- PFSAWH_READY_DATE_DIM  (Materialized View) 
--
CREATE MATERIALIZED VIEW PFSAWH.PFSAWH_READY_DATE_DIM 
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD IMMEDIATE
USING INDEX
            TABLESPACE PFSA
            PCTFREE    10
            INITRANS   2
            MAXTRANS   255
            STORAGE    (
                        INITIAL          64K
                        MINEXTENTS       1
                        MAXEXTENTS       UNLIMITED
                        PCTINCREASE      0
                        BUFFER_POOL      DEFAULT
                       )
REFRESH FORCE ON COMMIT
WITH ROWID
AS 
/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
SELECT date_dim_id, ORACLE_DATE, ready_date
FROM   date_dim;

COMMENT ON MATERIALIZED VIEW PFSAWH.PFSAWH_READY_DATE_DIM IS 'snapshot table for snapshot PFSAWH.PFSAWH_READY_DATE_DIM';

-- Note: Index I_SNAP$_PFSAWH_READY_DATE_ will be created automatically 
--       by Oracle with the associated materialized view.

