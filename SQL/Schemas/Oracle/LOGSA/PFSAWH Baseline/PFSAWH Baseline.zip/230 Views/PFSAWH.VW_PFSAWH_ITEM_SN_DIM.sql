/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
--
-- VW_PFSAWH_ITEM_SN_DIM  (View) 
--
CREATE OR REPLACE FORCE VIEW pfsawh.vw_pfsawh_item_sn_dim( rec_id
                                                         , rec_id_sn
                                                         , physical_item_id
                                                         , physical_item_sn_id
                                                         , niin
                                                         , fsc
                                                         , lin
                                                         , item_nomen_standard
                                                         , unit_price
                                                         , eic
                                                         , item_serial_number
                                                         , item_registration_num
                                                         , item_location
                                                         )
AS
    SELECT itm.rec_id, itm_sn.rec_id, itm.physical_item_id
         , itm_sn.physical_item_sn_id, itm.niin, itm.fsc, itm.lin
         , itm.item_nomen_standard, itm.unit_price, itm.eic
         , itm_sn.item_serial_number, itm_sn.item_registration_num
         , itm_sn.item_location
    FROM   pfsawh_item_dim itm, pfsawh_item_sn_dim itm_sn
    WHERE  itm.physical_item_id = itm_sn.physical_item_id(+)
    AND    itm.status = itm_sn.status
    AND    itm.status = 'C';


