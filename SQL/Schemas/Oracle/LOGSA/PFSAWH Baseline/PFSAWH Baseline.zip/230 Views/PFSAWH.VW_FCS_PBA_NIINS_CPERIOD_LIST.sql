/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
--
-- VW_FCS_PBA_NIINS_CPERIOD_LIST  (View) 
--
CREATE OR REPLACE FORCE VIEW pfsawh.vw_fcs_pba_niins_cperiod_list( pba_id
                                                                 , niin
                                                                 , physical_item_id
                                                                 , current_period_date
                                                                 )
AS
    SELECT pba_id, item_type_value, physical_item_id, equip_avail_period_date
    FROM   pfsa_pba_items_ref, pfsa_fcs_sys_dates
    WHERE  item_identifier_type_id = 13 AND pba_id <> 1000001
/*ADVICE(13): Elements in the SELECT list (either columns or expressions) are
              not qualified by a table/view name [403] */
                                                             ;


