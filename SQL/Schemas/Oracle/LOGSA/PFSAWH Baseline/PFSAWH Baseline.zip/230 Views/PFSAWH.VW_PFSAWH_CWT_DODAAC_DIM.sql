/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
--
-- VW_PFSAWH_CWT_DODAAC_DIM  (View) 
--
CREATE OR REPLACE FORCE VIEW pfsawh.vw_pfsawh_cwt_dodaac_dim( cnsgne_dodaac )
AS
    SELECT DISTINCT cnsgne_dodaac
    FROM            mv_source_pfsa_supply_daily;


