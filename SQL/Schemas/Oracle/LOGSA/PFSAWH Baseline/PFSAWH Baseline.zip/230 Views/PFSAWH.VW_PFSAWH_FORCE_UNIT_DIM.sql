/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
--
-- VW_PFSAWH_FORCE_UNIT_DIM  (View) 
--
CREATE OR REPLACE FORCE VIEW pfsawh.vw_pfsawh_force_unit_dim( force_unit_id
                                                            , uic
                                                            , unit_description
                                                            )
AS
    SELECT force_unit_id, uic, unit_description
    FROM   pfsawh_force_unit_dim
    WHERE  status = 'C';


