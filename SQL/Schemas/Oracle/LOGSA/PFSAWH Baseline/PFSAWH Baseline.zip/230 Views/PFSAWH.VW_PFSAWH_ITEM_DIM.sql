/* Formatted on 2009/05/22 14:06 (Formatter Plus v4.8.8) */
--
-- VW_PFSAWH_ITEM_DIM  (View) 
--
CREATE OR REPLACE FORCE VIEW pfsawh.vw_pfsawh_item_dim( view_extract_date
                                                      , view_extract_time
                                                      , physical_item_id
                                                      , niin
                                                      , item_nomen_standard
                                                      , cl_of_supply_cd
                                                      , unit_price
                                                      , fsc
                                                      , eic
                                                      )
AS
    SELECT To_char( Sysdate, 'YYYY-MM-DD' ) AS view_extract_date
         , To_char( Sysdate, 'HH24:MI:SS' ) AS view_extract_time
         , itm.physical_item_id, itm.niin, itm.item_nomen_standard
         , itm.cl_of_supply_cd, itm.unit_price, itm.fsc, itm.eic
    FROM   pfsawh_item_dim itm
    WHERE  status = 'C';


