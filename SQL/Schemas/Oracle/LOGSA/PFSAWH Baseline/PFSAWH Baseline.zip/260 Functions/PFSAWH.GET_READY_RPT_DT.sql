--
-- GET_READY_RPT_DT  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH."GET_READY_RPT_DT" (i_date in DATE) RETURN DATE IS
  rpt_dt_out DATE;
  rpt_day  varchar2(2);
  rpt_month  varchar2(2);
  rpt_year   varchar2(4);
  add_month  boolean;
/*
This function takes an incoming date and converts it to the applicable
readiness report date (15 of the month).  Errors/exceptions return null
             
PRODUCTION DATE:  25-SEP-2004        CODER: Dave Hendricks
*/
BEGIN
    rpt_day   := '15';
    rpt_month := to_char(i_date, 'MM');
    rpt_year  := to_char(i_date, 'YYYY'); 
    
    IF to_number(to_char(i_date, 'DD')) < 16 THEN
     add_month := FALSE;
    ELSE
     add_month := TRUE;
    END IF;
    
    IF add_month THEN
        IF rpt_month = '12' THEN
            rpt_month := '01';
            rpt_year := to_char(to_number(rpt_year) + 1);
        ELSE
            rpt_month := to_char(to_number(trim(rpt_month)) + 1);
            IF LENGTH(rpt_month) = 1 then 
                rpt_month :='0'||rpt_month;
            END IF;
        END IF;
    END IF;
    
    return to_date(rpt_day||rpt_month||rpt_year, 'DDMMYYYY');
    
    EXCEPTION
        WHEN OTHERS THEN 
            RETURN NULL;
            
END;
/


