--
-- DOES_SN_ID_HAVE_HOURS_USAGE  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.does_sn_id_have_hours_usage 
    (
    v_physical_item_sn_id        IN pfsawh_item_sn_dim.physical_item_sn_id%TYPE 
    ) 
    RETURN BOOLEAN 

IS

/********************************* TEAM ITSS ***********************************

         NAME: does_sn_id_have_hours_usage 
      PURPOSE: Tells if the niin has Miles usage values. 

   CREATED BY: Gene Belford 
 CREATED DATE: 30 December 2008 

   PARAMETERS: 

        INPUT: niin 

       OUTPUT: true or false

  ASSUMPTIONS:


  LIMITATIONS:

        NOTES:


HISTORY of REVISIONS:

  Date    ECP #         Author             Description
-------   ------------  -----------------  ---------------------------------
30DEC08                 Gene Belford       Function Created 

*********************************** TEAM ITSS *********************************/

/*----- Test -----*/

/* 

BEGIN 

    IF does_sn_id_have_hours_usage(92488) THEN 
        dbms_output.put_line('true'); 
    ELSE
        dbms_output.put_line('false'); 
    END IF; 

    IF does_sn_id_have_hours_usage(141158) THEN 
        dbms_output.put_line('true'); 
    ELSE
        dbms_output.put_line('false'); 
    END IF; 

    IF does_sn_id_have_hours_usage(0) THEN 
        dbms_output.put_line('true'); 
    ELSE
        dbms_output.put_line('false'); 
    END IF; 

END;

*/ 

l_dummy                          NUMBER;
l_any_exist                      BOOLEAN; 

CURSOR any_exist_cur 
IS 
    SELECT 1 rec_id 
    FROM   pfsa_usage_event 
    WHERE  physical_item_sn_id = v_physical_item_sn_id 
        AND usage_mb = 'H' 
        AND delete_flag = 'N'; 

BEGIN

    OPEN any_exist_cur; 
    
    FETCH any_exist_cur 
    INTO  l_dummy; 
    
    l_any_exist := any_exist_cur%FOUND;
    
    CLOSE any_exist_cur;
    
    RETURN l_any_exist;
    
END does_sn_id_have_hours_usage;
/


