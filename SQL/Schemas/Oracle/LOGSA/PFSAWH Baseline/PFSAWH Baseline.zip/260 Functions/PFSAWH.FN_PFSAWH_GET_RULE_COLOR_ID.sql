--
-- FN_PFSAWH_GET_RULE_COLOR_ID  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.fn_pfsawh_get_rule_color_id
    (
    v_rule_id number 
    ) 
    RETURN varchar2 
     
IS 

-- Exception handling variables (ps_)

ps_procedure_name        VARCHAR2(30)  := 'fn_pfsawh_get_rule_color_id';
ps_location              VARCHAR2(30)  := 'Begin'; 
ps_oerr                  VARCHAR2(6)   := NULL;
ps_msg                   VARCHAR2(200) := NULL;
ps_id_key                VARCHAR2(200) := 'fn_pfsawh_get_rule_color_id';
                                                      
-- Process status variables (s0_ & s1_)

s0_userLoginId           VARCHAR2(30)  := USER;

-- module variables (v_)

v_result                 varchar2(2);

BEGIN

    SELECT  c.bi_color_id
    INTO    v_result 
    FROM    pfsa_pba_rules_ref c
    WHERE   c.rule_id = v_rule_id
            AND c.status = 'C';
            
    RETURN (v_result); 
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN ('U'); 
    
        WHEN OTHERS THEN
		    ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := 'fn_pfsawh_get_rule_color_id';
            
		     INSERT 
            INTO    std_pfsawh_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, 
                called_by, ps_id_key, ps_msg, msg_dt
                )
		     VALUES 
                (
                ps_procedure_name, ps_oerr, ps_location, 
                s0_userLoginId, ps_id_key, ps_msg, sysdate
                );
               
    RETURN ('U');
    
END fn_pfsawh_get_rule_color_id;
/


