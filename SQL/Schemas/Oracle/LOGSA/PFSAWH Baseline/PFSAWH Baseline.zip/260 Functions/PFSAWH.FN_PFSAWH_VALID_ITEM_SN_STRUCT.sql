--
-- FN_PFSAWH_VALID_ITEM_SN_STRUCT  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH."FN_PFSAWH_VALID_ITEM_SN_STRUCT" 
    (
    v_niin  IN pfsawh_item_sn_dim.item_niin%TYPE, 
    v_sn    IN pfsawh_item_sn_dim.item_serial_number%TYPE 
    ) 
    RETURN NUMBER 

IS

tmpvar NUMBER; 

l_sn    pfsawh_item_sn_dim.item_serial_number%TYPE; 
l_len   NUMBER; 

l_physical_item_id pfsawh_item_sn_dim.physical_item_id%TYPE;

BEGIN

    tmpvar := 0;
    
    l_sn   := LTRIM(RTRIM(UPPER(v_sn))); 
    l_len  := LENGTH(v_sn); 
        
    IF v_niin = '014172886' THEN 
    
       l_physical_item_id := 141227; 
        
        IF l_len = 8   
            AND l_sn LIKE '10KA____' THEN 
                tmpvar := 1;  
        ELSIF l_len = 9   
            AND l_sn LIKE '10KA____R' THEN 
                tmpvar := 1;
        END IF; 
    END IF;  
    
    IF tmpvar = 1 THEN 
    
        tmpvar := fn_pfsawh_get_dim_identity('PFSAWH_ITEM_SN_DIM');
    
        INSERT 
        INTO   pfsawh_item_sn_dim 
            (
            physical_item_sn_id,
            physical_item_id, 
            mimosa_item_sn_id, 
            item_niin, 
            item_serial_number
            )
        VALUES 
            (
            tmpvar,
            l_physical_item_id, 
            LPAD(LTRIM(TO_CHAR(tmpvar, 'XXXXXXX')), 8, '0'), 
            v_niin, 
            l_sn
            );
    
    END IF; 
    
    RETURN tmpvar; 
    
    EXCEPTION
        WHEN no_data_found THEN
            NULL;
        WHEN others THEN
            -- consider logging the error and then re-raise
        RAISE;
        
END fn_pfsawh_valid_item_sn_struct;
/


