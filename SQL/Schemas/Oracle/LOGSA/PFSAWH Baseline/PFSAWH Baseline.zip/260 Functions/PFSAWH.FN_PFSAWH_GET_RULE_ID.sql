--
-- FN_PFSAWH_GET_RULE_ID  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.fn_pfsawh_get_rule_id
    (
    v_pba_id    number,
    v_physical_item_id number,
    v_metric_id number,
    v_value number  
    ) 
    RETURN number

IS
-- Exception handling variables (ps_) 

ps_exception                 std_pfsawh_debug_tbl%ROWTYPE; 

s0_userLoginId                   pfsawh_process_log.user_Login_Id%TYPE  
    := user;                 /* VARCHAR2(30) */
s0_message                       pfsawh_process_log.message%TYPE 
    := '';                   /* VARCHAR2(255) */
    
-- module variables (v_)

v_rule_id number := 0;
v_continue boolean := true;
v_rounded_value number := 0;

cursor c1 is
  select d.pba_id, d.metric_id, e.rule_id, e.rule_lower_limit, e.rule_upper_limit
    from pfsa_pba_itm_metric_rul_map d, pfsa_pba_rules_ref e
    where d.pba_id = v_pba_id
    and d.metric_id = v_metric_id
    and d.physical_item_id = v_physical_item_id
    and d.metric_id = e.metric_id
    and d.rule_id = e.rule_id;

cursor c2 is
  select d.pba_id, d.metric_id, e.rule_id, e.rule_lower_limit, e.rule_upper_limit
    from pfsa_pba_itm_metric_rul_map d, pfsa_pba_rules_ref e
    where d.pba_id = v_pba_id
    and d.metric_id = v_metric_id
    and d.physical_item_id = 0
    and d.metric_id = e.metric_id
    and d.rule_id = e.rule_id;
    
cursor c3 is
  select d.pba_id, d.metric_id, e.rule_id, e.rule_lower_limit, e.rule_upper_limit
    from pfsa_pba_itm_metric_rul_map d, pfsa_pba_rules_ref e
    where d.pba_id = 1000001
    and d.metric_id = v_metric_id
    and d.physical_item_id = 0
    and d.metric_id = e.metric_id
    and d.rule_id = e.rule_id;
    
BEGIN 

    ps_exception.ps_procedure := 'fn_pfsawh_get_metric_rule_text'; 
    ps_exception.ps_location  := ''; 
    ps_exception.ps_id_key    := 'metric rule not found: metric_id:' || v_metric_id || ' pba_id:' || v_pba_id || ' physical_item_id:' || v_physical_item_id;

-- value in is rounded to one decimal position     
    v_rounded_value := round(v_value,1);
    
    for c1_row in c1
    loop
        if v_rounded_value >= c1_row.rule_lower_limit and v_rounded_value <= c1_row.rule_upper_limit then
            v_rule_id := c1_row.rule_id;
            v_continue := false;  
        end if;       
    end loop;
    
    if v_continue then
        for c2_row in c2
        loop
            if v_rounded_value >= c2_row.rule_lower_limit and v_rounded_value <= c2_row.rule_upper_limit then
                v_rule_id := c2_row.rule_id;
                v_continue := false;  
            end if;       
        end loop;
    end if;
        
    if v_continue then
        for c3_row in c3
        loop
            if v_rounded_value >= c3_row.rule_lower_limit and v_rounded_value <= c3_row.rule_upper_limit then
                v_rule_id := c3_row.rule_id;
                v_continue := false;  
            end if;       
        end loop;                        
     end if;            
        
     
     if v_continue then
        v_rule_id := 0;
     end if;
     
     return(v_rule_id);
     
    EXCEPTION
        WHEN OTHERS THEN
		    ps_exception.ps_oerr   := sqlcode;
            ps_exception.ps_msg    := sqlerrm;
            ps_exception.ps_id_key := 'fn_pfsawh_get_metric_rule_text';
            
            INSERT 
            INTO std_pfsawh_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
            VALUES 
                (
                ps_exception.ps_procedure, ps_exception.ps_oerr, 
                ps_exception.ps_location, s0_userLoginId, 
                ps_exception.ps_id_key, ps_exception.ps_msg, sysdate
                );  
               
    RETURN (0);

END;
/


