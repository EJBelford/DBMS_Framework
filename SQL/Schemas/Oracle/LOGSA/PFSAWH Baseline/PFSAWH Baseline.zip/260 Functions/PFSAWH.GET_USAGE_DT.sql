--
-- GET_USAGE_DT  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH."GET_USAGE_DT" (i_date in DATE) RETURN DATE IS
  usage_dt_out   DATE;

/*

This function takes an incoming date and converts it to the applicable
PFSA defined usage date (15 of the month or the last day of the month).
Errors/exceptions return null
             
PRODUCTION DATE:  25 Sep 2004       CODER: Dave Hendricks
             
*/
BEGIN
    IF to_number(to_char(i_date, 'DD')) > 15 THEN
      usage_dt_out := last_day(i_date);
    ELSE
      usage_dt_out := add_months(last_day(i_date) + 1, -1) + 14;
    END IF;
    
    RETURN usage_dt_out; 
    
    EXCEPTION
        WHEN OTHERS THEN 
            RETURN NULL;
            
END;
/


