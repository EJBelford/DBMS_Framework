--
-- FN_PFSAWH_GET_ITEM_SN_DIM_ID  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH."FN_PFSAWH_GET_ITEM_SN_DIM_ID" 
    (
    v_item       VARCHAR2,   
    v_item_sn    VARCHAR2  
    ) 
    RETURN NUMBER 

IS

-- Exception handling variables (ps_) 

ps_exception                 std_pfsawh_debug_tbl%ROWTYPE; 

s0_userLoginId                   pfsawh_process_log.user_Login_Id%TYPE  
    := user;                 /* VARCHAR2(30) */
s0_message                       pfsawh_process_log.message%TYPE 
    := '';                   /* VARCHAR2(255) */
    
-- module variables (v_)

v_debug                      NUMBER        
     := 0;   -- Controls debug options (0 -Off) 
v_item_id                    NUMBER; 

BEGIN 

    IF v_debug > 0 THEN
        DBMS_OUTPUT.PUT_LINE('get item sn id: ' || v_item || ', ' 
           || v_item_sn );

    END IF;  

    ps_exception.ps_procedure := 'fn_pfsawh_get_item_sn_dim_id'; 
    ps_exception.ps_location  := 'get_itm_sn'; 
    ps_exception.ps_id_key    := 'Item SN not found: ' 
                                 || v_item || ' - ' || v_item_sn;

    SELECT physical_item_sn_id
    INTO   v_item_id 
    FROM   pfsawh_item_sn_dim 
    WHERE  item_niin = v_item 
        AND  item_serial_number = v_item_sn; 
    
    RETURN NVL(v_item_id, 0); 
            
    EXCEPTION
        WHEN OTHERS THEN
            ps_exception.ps_oerr   := sqlcode;
            ps_exception.ps_msg    := sqlerrm;
--            ps_exception.ps_id_key := '';

/*            INSERT 
            INTO std_pfsawh_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
            VALUES 
                (
                ps_exception.ps_procedure, ps_exception.ps_oerr, 
                ps_exception.ps_location, s0_userLoginId, 
                ps_exception.ps_id_key, ps_exception.ps_msg, sysdate
                );  */ 
                
            RETURN 0; 
            
END fn_pfsawh_get_item_sn_dim_id; 

/* 

SELECT fn_pfsawh_get_item_dim_field(141155, 'NIIN') FROM dual; 
    
SELECT fn_pfsawh_get_item_sn_dim_id('013285964', 'LA27204M') FROM dual; 
    
SELECT fn_pfsawh_get_item_sn_dim_id('014360005', '2AGR0466Y') FROM dual; 
    
SELECT fn_pfsawh_get_item_sn_dim_id('014360005', '0000error') FROM dual; 
    
*/
/


