--
-- TO_BASE32  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.to_base32( in_num NUMBER )
    RETURN VARCHAR2 
    
IS

/********************************* TEAM ITSS ***********************************

         NAME: to_base32 
      PURPOSE: Converts a positive integer to a base32 value. 

   CREATED BY: Leslie Johnson  
 CREATED DATE: 12 January 2009 

   PARAMETERS: 

        INPUT: number

       OUTPUT: base32 value (VARCHAR2)  

  ASSUMPTIONS:


  LIMITATIONS:

        NOTES:


HISTORY of REVISIONS:

  Date    ECP #         Author             Description
-------   ------------  -----------------  ---------------------------------
12JAN09                 Leslie Johnson     Function Created 

*********************************** TEAM ITSS *********************************/

/*----- Test -----*/

/* 

BEGIN 

    dbms_output.put_line('0 ' || to_base32(0)); 

    dbms_output.put_line('1 ' || to_base32(1)); 

    dbms_output.put_line('10 ' || to_base32(10)); 

    dbms_output.put_line('-1 ' || to_base32(-1)); 

    dbms_output.put_line('31 ' || to_base32(31)); 

    dbms_output.put_line('32 ' || to_base32(32)); 

    dbms_output.put_line('33 ' || to_base32(33)); 

    dbms_output.put_line('10000 ' || to_base32(10000)); 

    dbms_output.put_line('10001 ' || to_base32(10001)); 

    dbms_output.put_line('100000 ' || to_base32(100000)); 

    dbms_output.put_line('1000000 ' || to_base32(1000000)); 

    dbms_output.put_line('2000000 ' || to_base32(2000000)); 

END;

*/ 

    val_32      VARCHAR2( 64 );
    val_str     VARCHAR2( 33 );
    wrk_num     NUMBER;
    wrk_rem     NUMBER;
    d_wrk_num   NUMBER;
    
BEGIN
    wrk_num          := in_num;
    val_str          := '123456789ABCDEFGHJKLMNPQRTUVWXYZ';

    IF FLOOR( wrk_num ) = wrk_num THEN
        WHILE wrk_num > 32
        LOOP
            wrk_rem          := MOD( wrk_num, 32 );
            d_wrk_num        := wrk_num / 32;
            wrk_num          := FLOOR( wrk_num / 32 );
            val_32           := SUBSTR( val_str, wrk_rem, 1 ) || TRIM( val_32 );
        END LOOP;

        val_32           := SUBSTR( val_str, wrk_num, 1 ) || TRIM( val_32 );
    END IF;

    RETURN val_32;
    
END to_base32;
/


