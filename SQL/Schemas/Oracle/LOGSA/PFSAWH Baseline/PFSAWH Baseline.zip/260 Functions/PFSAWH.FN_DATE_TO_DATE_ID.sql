--
-- FN_DATE_TO_DATE_ID  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH."FN_DATE_TO_DATE_ID" 
    (
    v_date  DATE 
    ) 
    RETURN NUMBER 

IS

v_date_id NUMBER;

BEGIN

    v_date_id := 0; 
    
    v_date_id := (TO_DATE(v_date) - TO_DATE('01-Jan-1950')) + 10001;
    
    RETURN v_date_id;
    
    EXCEPTION
        WHEN no_data_found THEN
            NULL;
        WHEN others THEN
            -- consider logging the error and then re-raise
        RAISE;
        
END;
/


