--
-- GENERATE_FAKE_BASE32_UIC  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.generate_fake_base32_uic
    RETURN VARCHAR2
    
IS

/********************************* TEAM ITSS ***********************************

         NAME: generate_fake_base32_uic 
      PURPOSE: Generates a fake UIC for values that do not meet UIC 
               business rules.   
 
   CREATED BY: Gene Belford  
 CREATED DATE: 14 January 2009 

   PARAMETERS: 

        INPUT: 

       OUTPUT: 6 charcater value starting with #  

  ASSUMPTIONS:


  LIMITATIONS:

        NOTES:


HISTORY of REVISIONS:

  Date    ECP #         Author             Description
-------   ------------  -----------------  ---------------------------------
14JAN09                 Gene Belford       Function Created 

*********************************** TEAM ITSS *********************************/

/*----- Test -----*/

/*

BEGIN 

    dbms_output.put_line(generate_fake_base32_uic); 
    
    COMMIT; 

END; 

*/

-- Exception handling variables (ps_)

ps_procedure_name        VARCHAR2(30)  := 'generate_fake_base32_uic';
ps_location              VARCHAR2(30)  := 'Begin'; 
ps_oerr                  VARCHAR2(6)   := NULL;
ps_msg                   VARCHAR2(200) := NULL;
ps_id_key                VARCHAR2(200) := NULL;       -- coder responsible for
                                                      -- identying key for debug 
-- module variables (v_)

v_next_value                      NUMBER; 
v_base32_str                      VARCHAR2(10); 

BEGIN

--    v_next_value := 1082401;  
    
    v_next_value := fn_pfsawh_get_dim_identity('GENERATE_FAKE_BASE32_UIC');   
    
    v_base32_str := '#' || to_base32(v_next_value); 

    RETURN v_base32_str;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ps_oerr   := sqlcode;
        ps_msg    := sqlerrm;
        ps_id_key := 'GENERATE_FAKE_BASE32_UIC';
            
        INSERT 
        INTO    std_pfsawh_debug_tbl 
           (
           ps_procedure, ps_oerr, ps_location, 
           called_by, ps_id_key, ps_msg, msg_dt
           )
         VALUES 
           (
           ps_procedure_name, ps_oerr, ps_location, 
          USER, ps_id_key, ps_msg, sysdate
           );
               
        COMMIT; 
               
        INSERT INTO pfsawh_identities 
            (dimension_tablename, last_dimension_identity) 
            VALUES ('GENERATE_FAKE_BASE32_UIC', 1082401);
    
        RETURN 1;
            
    WHEN OTHERS THEN
        ps_oerr   := sqlcode;
        ps_msg    := sqlerrm;
        ps_id_key := 'GENERATE_FAKE_BASE32_UIC';
            
        INSERT 
        INTO    std_pfsawh_debug_tbl 
           (
           ps_procedure, ps_oerr, ps_location, 
           called_by, ps_id_key, ps_msg, msg_dt
           )
         VALUES 
           (
           ps_procedure_name, ps_oerr, ps_location, 
           USER, ps_id_key, ps_msg, sysdate
           );
               
        RETURN '#00000';
            
END generate_fake_base32_uic;
/


