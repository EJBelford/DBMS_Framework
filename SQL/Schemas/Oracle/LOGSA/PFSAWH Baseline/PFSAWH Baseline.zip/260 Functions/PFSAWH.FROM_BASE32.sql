--
-- FROM_BASE32  (Function) 
--
CREATE OR REPLACE FUNCTION PFSAWH.from_base32( in_val VARCHAR2 )
    RETURN NUMBER
    
IS

/********************************* TEAM ITSS ***********************************

         NAME: from_base32 
      PURPOSE: Converts a base32 value back to a integer value.  

   CREATED BY: Leslie Johnson  
 CREATED DATE: 12 January 2009 

   PARAMETERS: 

        INPUT: base32 value (VARCHAR2) 

       OUTPUT: number 

  ASSUMPTIONS:


  LIMITATIONS:

        NOTES:


HISTORY of REVISIONS:

  Date    ECP #         Author             Description
-------   ------------  -----------------  ---------------------------------
12JAN09                 Leslie Johnson     Function Created 

*********************************** TEAM ITSS *********************************/

/*----- Test -----*/

/* 

BEGIN 

    dbms_output.put_line('a ' || from_base32('a')); 

    dbms_output.put_line('A ' || from_base32('A')); 

    dbms_output.put_line('Y ' || from_base32('Y')); 

    dbms_output.put_line('Z ' || from_base32('Z')); 

    dbms_output.put_line('11 ' || from_base32('11')); 

    dbms_output.put_line('111 ' || from_base32('111')); 

    dbms_output.put_line('1ZZ ' || from_base32('1ZZ')); 

    dbms_output.put_line('8ZZ ' || from_base32('8ZZ')); 

    dbms_output.put_line('9MZ ' || from_base32('9MZ')); 

    dbms_output.put_line('9NN ' || from_base32('9NN')); 

    dbms_output.put_line('9ZZ ' || from_base32('9ZZ')); 

    dbms_output.put_line('ZZZ ' || from_base32('ZZZ')); 

    dbms_output.put_line('1111 ' || from_base32('1111')); 

    dbms_output.put_line('11111 ' || from_base32('11111')); 

    dbms_output.put_line('a1b2c ' || from_base32('a1b2c')); 

    dbms_output.put_line('A1b2c ' || from_base32('A1b2c')); 

END;

*/ 

    val_32      VARCHAR2( 64 );
    val_str     VARCHAR2( 33 );
    val_chr     VARCHAR2( 1 );
    wrk_num     NUMBER;
    pos_num     NUMBER;
    wrk_rem     NUMBER;
    d_wrk_num   NUMBER;
    pos_cnt     NUMBER;
    
BEGIN
    val_32           := UPPER(in_val);
    pos_cnt          := 0;
    wrk_num          := 0;
    val_str          := '123456789ABCDEFGHJKLMNPQRTUVWXYZ';

    IF INSTR( val_32, '.' ) = 0 THEN
        WHILE LENGTH( val_32 ) > 0
        LOOP
            val_chr          := SUBSTR( val_32, LENGTH( val_32 ), 1 );
            pos_num          := INSTR( val_str, val_chr );
            wrk_num          := wrk_num +( pos_num * POWER( 32, pos_cnt ));
            val_32           := SUBSTR( val_32, 1, LENGTH( val_32 ) - 1 );
            pos_cnt          := pos_cnt + 1;
        END LOOP;
    END IF;

    RETURN wrk_num; 
    
END from_base32;
/


