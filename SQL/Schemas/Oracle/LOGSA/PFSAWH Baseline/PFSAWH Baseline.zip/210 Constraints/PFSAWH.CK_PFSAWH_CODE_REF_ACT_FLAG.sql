-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_REF ADD (
  CONSTRAINT CK_PFSAWH_CODE_REF_ACT_FLAG
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

