-- 
-- Non Foreign Key Constraints for Table PFSAWH_FACT_LD_SN_CNTRL 
-- 
ALTER TABLE PFSAWH.PFSAWH_FACT_LD_SN_CNTRL ADD (
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_STATUS
 CHECK (status='C' OR status='W' OR status='Z'));

