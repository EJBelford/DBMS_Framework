-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_A_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_ITEM_SN_A_FACT ADD (
  CONSTRAINT CK_ITEM_SN_A_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='Z' OR status='N'
        ));

