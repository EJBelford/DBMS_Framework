-- 
-- Non Foreign Key Constraints for Table PFSAWH_FORCE_UNIT_DIM 
-- 
ALTER TABLE PFSAWH.PFSAWH_FORCE_UNIT_DIM ADD (
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

