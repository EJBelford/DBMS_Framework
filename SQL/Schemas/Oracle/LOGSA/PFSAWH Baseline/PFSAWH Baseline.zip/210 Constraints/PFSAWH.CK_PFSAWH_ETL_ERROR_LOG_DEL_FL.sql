-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_ERROR_LOG 
-- 
ALTER TABLE PFSAWH.PFSAWH_ETL_ERROR_LOG ADD (
  CONSTRAINT CK_PFSAWH_ETL_ERROR_LOG_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

