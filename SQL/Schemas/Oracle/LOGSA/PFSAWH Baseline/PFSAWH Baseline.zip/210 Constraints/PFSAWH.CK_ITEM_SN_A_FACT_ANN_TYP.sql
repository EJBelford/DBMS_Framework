-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_A_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_ITEM_SN_A_FACT ADD (
  CONSTRAINT CK_ITEM_SN_A_FACT_ANN_TYP
 CHECK (year_type='CY' OR year_type='FY' OR year_type='OT'  
        ));

