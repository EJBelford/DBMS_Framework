-- 
-- Non Foreign Key Constraints for Table PFSAWH_MAINT_ITM_WRK_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_MAINT_ITM_WRK_FACT ADD (
  CONSTRAINT CK_PFSAWH_MNTITMWRK_FCT_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

