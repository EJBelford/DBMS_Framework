-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_RULES_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_RULES_REF ADD (
  CONSTRAINT CK_PFSA_PBA_MET_REF_COLOR
 CHECK (bi_color_id='B' OR bi_color_id='W' OR bi_color_id='R' 
        OR bi_color_id='A' OR bi_color_id='G' 
        ));

