-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_REF ADD (
  CONSTRAINT CK_PFSAWH_CODE_REF_HIDE_FLG
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

