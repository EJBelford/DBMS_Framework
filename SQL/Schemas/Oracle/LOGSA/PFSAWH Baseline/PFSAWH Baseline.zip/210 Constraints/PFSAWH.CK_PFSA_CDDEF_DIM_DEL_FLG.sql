-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_DEFINITION_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_DEFINITION_REF ADD (
  CONSTRAINT CK_PFSA_CDDEF_DIM_DEL_FLG
 CHECK (delete_flag='N' OR delete_flag='Y'));

