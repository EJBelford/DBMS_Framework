-- 
-- Non Foreign Key Constraints for Table PFSAWH_FORCE_UNIT_DIM 
-- 
ALTER TABLE PFSAWH.PFSAWH_FORCE_UNIT_DIM ADD (
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ));

