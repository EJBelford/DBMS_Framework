-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_PROCESS_REF ADD (
  CONSTRAINT CK_ITEM_DIM_SUBJ_FLG
 CHECK (override_run_cntrl='Y'    OR override_run_cntrl='N'));

