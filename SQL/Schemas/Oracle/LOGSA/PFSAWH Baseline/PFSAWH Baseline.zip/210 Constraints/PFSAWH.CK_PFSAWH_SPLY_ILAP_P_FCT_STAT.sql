-- 
-- Non Foreign Key Constraints for Table PFSAWH_SUPPLY_ILAP_P_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_SUPPLY_ILAP_P_FACT ADD (
  CONSTRAINT CK_PFSAWH_SPLY_ILAP_P_FCT_STAT
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ));

