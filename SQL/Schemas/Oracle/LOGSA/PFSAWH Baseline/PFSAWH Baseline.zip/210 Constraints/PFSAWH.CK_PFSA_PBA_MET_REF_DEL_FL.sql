-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_METRICS_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_METRICS_REF ADD (
  CONSTRAINT CK_PFSA_PBA_MET_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

