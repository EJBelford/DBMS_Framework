-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_REF ADD (
  CONSTRAINT CK_PFSAWH_CODE_REF_DEL_FLG
 CHECK (delete_flag='N' OR delete_flag='Y'));

