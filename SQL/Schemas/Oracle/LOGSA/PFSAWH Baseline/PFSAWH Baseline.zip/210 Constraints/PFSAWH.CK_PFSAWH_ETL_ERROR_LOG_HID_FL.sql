-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_ERROR_LOG 
-- 
ALTER TABLE PFSAWH.PFSAWH_ETL_ERROR_LOG ADD (
  CONSTRAINT CK_PFSAWH_ETL_ERROR_LOG_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

