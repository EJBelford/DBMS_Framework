-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_PROCESS_REF ADD (
  CONSTRAINT CK_PFSAWH_PROCESS_REF_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

