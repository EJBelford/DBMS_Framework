-- 
-- Non Foreign Key Constraints for Table PFSAWH_SOURCE_STAT_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_SOURCE_STAT_REF ADD (
  CONSTRAINT CK_PFSAWH_SRC_STAT_REF_ACT_FLG
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

