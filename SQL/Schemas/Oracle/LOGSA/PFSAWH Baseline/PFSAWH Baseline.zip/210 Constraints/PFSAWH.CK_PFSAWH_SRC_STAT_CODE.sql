-- 
-- Non Foreign Key Constraints for Table PFSAWH_SOURCE_STAT_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_SOURCE_STAT_REF ADD (
  CONSTRAINT CK_PFSAWH_SRC_STAT_CODE
 CHECK (source_for_code='D' OR source_for_code='F'));

