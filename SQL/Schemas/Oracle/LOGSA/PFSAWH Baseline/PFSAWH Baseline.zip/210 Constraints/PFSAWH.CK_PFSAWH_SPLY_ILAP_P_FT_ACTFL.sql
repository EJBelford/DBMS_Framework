-- 
-- Non Foreign Key Constraints for Table PFSAWH_SUPPLY_ILAP_P_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_SUPPLY_ILAP_P_FACT ADD (
  CONSTRAINT CK_PFSAWH_SPLY_ILAP_P_FT_ACTFL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

