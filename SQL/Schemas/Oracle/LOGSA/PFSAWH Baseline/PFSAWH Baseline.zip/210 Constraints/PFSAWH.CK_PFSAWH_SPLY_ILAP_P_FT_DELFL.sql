-- 
-- Non Foreign Key Constraints for Table PFSAWH_SUPPLY_ILAP_P_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_SUPPLY_ILAP_P_FACT ADD (
  CONSTRAINT CK_PFSAWH_SPLY_ILAP_P_FT_DELFL
 CHECK (delete_flag='N' OR delete_flag='Y'));

