-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_ITM_METRIC_RUL_MAP 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_ITM_METRIC_RUL_MAP ADD (
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

