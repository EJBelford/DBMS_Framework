-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_LOG 
-- 
ALTER TABLE PFSAWH.PFSAWH_PROCESS_LOG ADD (
  CONSTRAINT CK_PFSA_PROCESS_STATUS_CODE
 CHECK (process_status_code=-1 OR process_status_code=0 OR process_status_code=1));

