-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_TYPE_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_TYPE_REF ADD (
  CONSTRAINT CK_PFSA_PBA_TYP_REF_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

