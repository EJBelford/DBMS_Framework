-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_DEFINITION_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_DEFINITION_REF ADD (
  CONSTRAINT CK_PFSA_CDDEF_DIM_ACT_FLAG
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

