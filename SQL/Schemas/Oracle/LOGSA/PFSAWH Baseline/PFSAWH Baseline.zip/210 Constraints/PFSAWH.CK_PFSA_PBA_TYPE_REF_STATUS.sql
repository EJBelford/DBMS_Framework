-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_TYPE_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_TYPE_REF ADD (
  CONSTRAINT CK_PFSA_PBA_TYPE_REF_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ));

