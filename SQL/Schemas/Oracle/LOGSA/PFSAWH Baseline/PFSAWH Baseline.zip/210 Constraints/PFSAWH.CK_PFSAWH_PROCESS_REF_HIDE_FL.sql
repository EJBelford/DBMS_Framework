-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_PROCESS_REF ADD (
  CONSTRAINT CK_PFSAWH_PROCESS_REF_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

