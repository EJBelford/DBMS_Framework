-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_ITM_METRIC_RUL_MAP 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_ITM_METRIC_RUL_MAP ADD (
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

