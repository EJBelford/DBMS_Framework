-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_ETL_FACT ADD (
  CONSTRAINT CK_PFSAWH_ETL_FACT_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

