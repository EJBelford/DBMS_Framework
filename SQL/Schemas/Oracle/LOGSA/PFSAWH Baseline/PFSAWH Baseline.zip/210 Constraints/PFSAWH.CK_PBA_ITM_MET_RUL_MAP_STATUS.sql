-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_ITM_METRIC_RUL_MAP 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_ITM_METRIC_RUL_MAP ADD (
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ));

