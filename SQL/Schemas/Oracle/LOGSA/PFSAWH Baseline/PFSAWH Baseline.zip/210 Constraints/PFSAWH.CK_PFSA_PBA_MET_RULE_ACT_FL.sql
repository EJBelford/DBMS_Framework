-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_RULES_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_RULES_REF ADD (
  CONSTRAINT CK_PFSA_PBA_MET_RULE_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

