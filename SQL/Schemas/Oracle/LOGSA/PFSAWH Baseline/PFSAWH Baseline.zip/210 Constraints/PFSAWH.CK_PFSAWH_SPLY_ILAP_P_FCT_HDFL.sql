-- 
-- Non Foreign Key Constraints for Table PFSAWH_SUPPLY_ILAP_P_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_SUPPLY_ILAP_P_FACT ADD (
  CONSTRAINT CK_PFSAWH_SPLY_ILAP_P_FCT_HDFL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

