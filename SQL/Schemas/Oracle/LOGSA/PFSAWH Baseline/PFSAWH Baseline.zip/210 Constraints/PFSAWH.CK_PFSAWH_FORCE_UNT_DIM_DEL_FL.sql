-- 
-- Non Foreign Key Constraints for Table PFSAWH_FORCE_UNIT_DIM 
-- 
ALTER TABLE PFSAWH.PFSAWH_FORCE_UNIT_DIM ADD (
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

