-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_ETL_FACT ADD (
  CONSTRAINT CK_PFSAWH_ETL_FACT_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'));

