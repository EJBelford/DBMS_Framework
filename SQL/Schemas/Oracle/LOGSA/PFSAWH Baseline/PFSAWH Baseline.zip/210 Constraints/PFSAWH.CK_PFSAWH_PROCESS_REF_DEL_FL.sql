-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_PROCESS_REF ADD (
  CONSTRAINT CK_PFSAWH_PROCESS_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

