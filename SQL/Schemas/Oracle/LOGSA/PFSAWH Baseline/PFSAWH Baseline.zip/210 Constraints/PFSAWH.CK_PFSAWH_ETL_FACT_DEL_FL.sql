-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_FACT 
-- 
ALTER TABLE PFSAWH.PFSAWH_ETL_FACT ADD (
  CONSTRAINT CK_PFSAWH_ETL_FACT_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

