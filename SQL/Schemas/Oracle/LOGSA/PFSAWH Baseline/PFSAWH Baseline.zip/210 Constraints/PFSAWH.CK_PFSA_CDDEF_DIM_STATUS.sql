-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_DEFINITION_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_DEFINITION_REF ADD (
  CONSTRAINT CK_PFSA_CDDEF_DIM_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R' 
        OR status='Z' OR status='N' 
        ));

