-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_DEFINITION_REF 
-- 
ALTER TABLE PFSAWH.PFSAWH_CODE_DEFINITION_REF ADD (
  CONSTRAINT CK_PFSA_CDDEF_DIM_HIDE_FLAG
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

