-- 
-- Non Foreign Key Constraints for Table PFSAWH_FACT_LD_SN_CNTRL 
-- 
ALTER TABLE PFSAWH.PFSAWH_FACT_LD_SN_CNTRL ADD (
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

