-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_TYPE_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_TYPE_REF ADD (
  CONSTRAINT CK_PFSA_PBA_TYPE_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'));

