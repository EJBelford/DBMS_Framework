-- 
-- Non Foreign Key Constraints for Table PFSA_SN_EI 
-- 
ALTER TABLE PFSAWH.PFSA_SN_EI ADD (
  CONSTRAINT PK1_PFSA_SN_EI
 PRIMARY KEY
 (SYS_EI_NIIN, SYS_EI_SN));

