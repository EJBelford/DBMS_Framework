-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_RULES_REF 
-- 
ALTER TABLE PFSAWH.PFSA_PBA_RULES_REF ADD (
  CONSTRAINT CK_PFSA_PBA_RULE_REF_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

