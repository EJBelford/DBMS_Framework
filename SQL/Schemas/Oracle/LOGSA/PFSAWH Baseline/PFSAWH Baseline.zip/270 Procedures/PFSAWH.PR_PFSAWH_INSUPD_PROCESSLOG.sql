--
-- PR_PFSAWH_INSUPD_PROCESSLOG  (Procedure) 
--
CREATE OR REPLACE PROCEDURE PFSAWH.pr_pfsawh_insupd_processlog 
    (
    v_processRecId          IN      pfsawh_process_log.process_recid%TYPE, 
    v_processKey            IN      pfsawh_process_log.process_key%TYPE,
    v_moduleNum             IN      pfsawh_process_log.module_num%TYPE          := NULL,
    v_stepNum               IN      pfsawh_process_log.step_num%TYPE            := NULL,
    v_processStartDt        IN      pfsawh_process_log.process_Start_Date%TYPE  := NULL,
    v_processEndDt          IN      pfsawh_process_log.process_End_Date%TYPE    := NULL,
    v_processStatusCd       IN      pfsawh_process_log.process_Status_Code%TYPE := NULL,
    v_sqlErrorCode          IN      pfsawh_process_log.sql_Error_Code%TYPE      := NULL,
    v_recReadInt            IN      pfsawh_process_log.rec_Read_Int%TYPE        := NULL,
    v_recValidInt           IN      pfsawh_process_log.rec_Valid_Int%TYPE       := NULL,
    v_recLoadInt            IN      pfsawh_process_log.rec_Load_Int%TYPE        := NULL,
    v_recInsertedInt        IN      pfsawh_process_log.rec_Inserted_Int%TYPE    := NULL,
    v_recMergedInt          IN      pfsawh_process_log.rec_Merged_Int%TYPE      := NULL,
    v_recSelectedInt        IN      pfsawh_process_log.rec_Selected_Int%TYPE    := NULL,
    v_recUpdatedInt         IN      pfsawh_process_log.rec_Updated_Int%TYPE     := NULL,
    v_recDeletedInt         IN      pfsawh_process_log.rec_Deleted_Int%TYPE     := NULL,
    v_userLoginId           IN      pfsawh_process_log.user_Login_Id%TYPE       := '',
    v_message               IN      pfsawh_process_log.message%TYPE             := '', 
    v_rec_Id                IN OUT  pfsawh_process_log.process_RecId%TYPE  
    )

IS

-- Exception handling variables (ps_)

ps_procedure_name                std_pfsawh_debug_tbl.ps_procedure%TYPE  
    := 'pr_pfsawh_insupd_processlog';
ps_location                      std_pfsawh_debug_tbl.ps_location%TYPE  
    := 'Needed'; 
ps_oerr                          std_pfsawh_debug_tbl.ps_oerr%TYPE   
    := null;                 /*  */
ps_msg                           std_pfsawh_debug_tbl.ps_msg%TYPE 
    := null;                 /*  */
ps_id_key                        std_pfsawh_debug_tbl.ps_id_key%TYPE 
    := null;                 /*  */
    -- coder responsible for identying key for debug

tmpVar                  NUMBER;

v_debug                 NUMBER; 

CURSOR process_cur IS
    SELECT   a.process_key, a.message
    FROM     pfsawh_process_log a
    ORDER BY a.process_key DESC;
        
process_rec    process_cur%ROWTYPE;
        
BEGIN
    DBMS_OUTPUT.ENABLE(1000000);
    
    DBMS_OUTPUT.NEW_LINE;
    
    v_debug := 0;

    IF v_debug > 0 THEN
        DBMS_OUTPUT.PUT_LINE('v_rec_Id: ' || v_rec_Id 
            || ' | ' || v_processRecId || ' | ' || v_processKey
            );
    END IF;  


-- If the v_rec_Id is NULL then we assume that a new log record is required

    IF v_rec_Id IS NULL THEN
 
        ps_location := 'Insert'; 
        
        IF v_debug > 0 THEN 
            DBMS_OUTPUT.PUT_LINE('Insert'); 
        END IF;

        INSERT 
        INTO   pfsawh_process_log                
            (
            process_key,
            process_start_date, 
            process_RecId, 
            user_login_id, 
            module_num,
            step_num, 
            message        
            )
        VALUES 
            (
            v_ProcessKey, 
            v_processStartDt, 
            v_processRecId, 
            v_userLoginId, 
            v_moduleNum,
            v_stepNum, 
            v_message
            ); 

-- Get the IDENTITY of the new record to pass back out for 
-- updates to the log entry

        SELECT MAX(process_key) 
        INTO   v_rec_Id 
        FROM   pfsawh_process_log;                 

    ELSE
    
        ps_location := 'Update'; 
        
        IF v_debug > 0 THEN 
            DBMS_OUTPUT.PUT_LINE('Update v_rec_Id: ' || v_rec_Id); 
        END IF;

        UPDATE pfsawh_process_log                
        SET    module_num          = v_moduleNum, 
               step_num            = v_stepNum, 
               process_End_Date    = v_processEndDt,
               process_Status_Code = NVL(v_processStatusCd, v_sqlErrorCode),
               sql_Error_Code      = v_sqlErrorCode,
               rec_Read_Int        = v_recReadInt,
               rec_Valid_Int       = v_recValidInt,
               rec_Load_Int        = v_recLoadInt,
               rec_Inserted_Int    = v_recInsertedInt,
               rec_Merged_Int      = v_recMergedInt,
               rec_Selected_Int    = v_recSelectedInt,
               rec_Updated_Int     = v_recUpdatedInt,
               rec_Deleted_Int     = v_recDeletedInt,
               message             = v_message 
        WHERE  process_key = v_rec_Id;
    END IF;

    IF v_debug > 0 THEN 
    
        DBMS_OUTPUT.NEW_LINE;

        OPEN process_cur;
    
        LOOP
            FETCH process_cur 
            INTO  process_rec;
        
            EXIT WHEN process_cur%NOTFOUND;
        
            DBMS_OUTPUT.PUT_LINE(process_rec.process_key 
                || ', ' || process_rec.message
                );
        
        END LOOP;
    
        CLOSE process_cur;
    
    END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
		    ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := '';
            
		    INSERT 
            INTO   std_pfsawh_debug_tbl (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
		    VALUES (
                ps_procedure_name, ps_oerr, ps_location, v_userLoginId, 
                ps_id_key, ps_msg, sysdate
                );

--          RAISE;
            
END pr_pfsawh_insupd_processlog;
/


