--
-- TRUNCATE_A_TABLE  (Procedure) 
--
CREATE OR REPLACE PROCEDURE PFSAWH.truncate_a_table (my_test VARCHAR2)
AS
   w_test     VARCHAR2 (128);
   sql_stmt   VARCHAR2 (256);
BEGIN
   w_test := my_test;
   sql_stmt := 'truncate table ' || trim(w_test) || ' reuse storage';

   EXECUTE IMMEDIATE sql_stmt;
END truncate_a_table;
/


