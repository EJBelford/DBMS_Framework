--
-- ETL_PFSA_ILAP  (Procedure) 
--
CREATE OR REPLACE PROCEDURE PFSAWH.etl_pfsa_ilap 
    (
    type_maintenance    IN    VARCHAR2 -- calling procedure name, used in 
                                       -- debugging, calling procedure 
                                       -- responsible for maintaining 
                                       --  heirachy 
    )
    
IS

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--            SP Name: etl_pfsa_ilap 
--            SP Desc: 
--
--      SP Created By: Gene Belford
--    SP Created Date: 23 October 2008 
--
--          SP Source: etl_pfsa_ilap.sql 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--      SP Parameters: 
--              Input: 
-- 
--             Output:   
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Used in the following:
--
--         
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 23OCT08 - GB  -          -      - Created 
-- 18MAR09 - GB  - ECPTSK10357     - Implementation of DIACAP requirements 
--                 PFSAWH remove obsolete objects 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/

-- Testing Scripts 

/* 

BEGIN 

    etl_pfsa_ilap ('GBelford'); 
    
    COMMIT; 

END; 

*/ 

-- Exception handling variables (ps_) 

ps_procedure_name                std_pfsawh_debug_tbl.ps_procedure%TYPE  
    := 'ETL_PFSA_ILAP';  /*  */
ps_location                      std_pfsawh_debug_tbl.ps_location%TYPE  
    := 'Begin';              /*  */
ps_oerr                          std_pfsawh_debug_tbl.ps_oerr%TYPE   
    := null;                 /*  */
ps_msg                           std_pfsawh_debug_tbl.ps_msg%TYPE 
    := 'no message defined'; /*  */
ps_id_key                        std_pfsawh_debug_tbl.ps_id_key%TYPE 
    := null;                 /*  */
    -- coder responsible for identying key for debug

-- standard variables

ps_status                        VARCHAR2(10)  := 'STARTED';

ps_main_status                   VARCHAR2(10)  := NULL;

l_ps_start                       DATE          := SYSDATE;
l_now_is                         DATE          := SYSDATE;

l_call_error                     VARCHAR2(20)  := NULL;
ls_start                         DATE          := NULL;

proc0_recId                      pfsawh_process_log.process_RecId%TYPE
    := NULL;                 
proc1_recId                      pfsawh_process_log.process_RecId%TYPE
    := NULL;                 

proc0                            pfsawh_process_log%ROWTYPE; 
proc1                            pfsawh_process_log%ROWTYPE; 

ps_last_process                  pfsawh_processes%ROWTYPE;
ps_this_process                  pfsawh_processes%ROWTYPE;
ls_current_process               pfsawh_processes%ROWTYPE; 

-- module variables (v_) 

v_iss_mon_pfsaw                  VARCHAR2(5)   := NULL;     
v_iss_mon_pfsawh                 VARCHAR2(5)   := NULL;     

v_debug                          NUMBER        := 0; 

-- add  by lmj 10/10/08 variables to manaage truncation and index control --

myrowcount                       NUMBER;
mytablename                      VARCHAR2(32);

v_index_cnt             NUMBER; 

w_rec_id                pfsa_supply_ilap_tmp.rec_id%TYPE;
w_sof                   pfsa_supply_ilap_tmp.sof%TYPE;

CURSOR  updt_flag_cur IS
    SELECT rec_id, sof
    FROM   pfsa_supply_ilap_tmp;

----------------------------------- START --------------------------------------

BEGIN 

    proc0.process_RecId      := 575; 
    proc0.process_Key        := NULL;
    proc0.module_Num         := 0;
    proc0.process_Start_Date := SYSDATE;
    proc0.user_Login_Id      := USER; 
  
    pr_pfsawh_insupd_processlog 
        (
        proc0.process_RecId, proc0.process_Key, 
        proc0.module_Num, proc0.step_Num,  
        proc0.process_Start_Date, NULL, 
        NULL, NULL, 
        NULL, NULL, NULL, 
        NULL, NULL, NULL, NULL, NULL, 
        proc0.user_Login_Id, NULL, proc0_recId
        );  
        
    COMMIT;     
        
    IF v_debug > 0 THEN
        DBMS_OUTPUT.ENABLE(1000000);
        DBMS_OUTPUT.NEW_LINE;
        DBMS_OUTPUT.PUT_LINE
           ( 
           'proc0_recId: ' || proc0_recId || ', ' || 
           proc0.process_RecId || ', ' || proc0.process_Key
           );
    END IF;  

-- 23DEC08 - GB  -  Start 
-- Added batch id to support integration of NIIN and SN reload  

   proc0.process_batch_id := fn_pfsawh_get_prcss_run_id;
   proc1.process_batch_id := proc0.process_batch_id; 
   
   UPDATE pfsawh_process_log 
   SET    process_batch_id = proc0.process_batch_id 
   WHERE  process_key = proc0_recId; 

-- 23DEC08 - GB  -  Stop  

-- Housekeeping for the process 
  
    ps_location := 'PFSAWH 00';            -- For std_pfsawh_debug_tbl logging. 

    ps_this_process.last_run             := l_ps_start;
    ps_this_process.who_ran              := type_maintenance;
    ps_this_process.last_run_status      := 'BEGAN';
    ps_this_process.last_run_status_time := sysdate;
    ps_this_process.last_run_compl       := null;

-- get the run criteria from the pfsa_processes table for the last run of this 
-- main process 
  
    get_pfsawh_process_info ( 
        ps_procedure_name, ps_procedure_name, ps_last_process.last_run, 
        ps_last_process.who_ran, ps_last_process.last_run_status, 
        ps_last_process.last_run_status_time, ps_last_process.last_run_compl
        );

-- Update the PFSA_PROCESSES table to indicate MAIN process began.  

    updt_pfsawh_processes (
        ps_procedure_name, ps_procedure_name, ps_this_process.last_run,  
        ps_this_process.who_ran, ps_this_process.last_run_status, 
        ps_this_process.last_run_status_time, ps_last_process.last_run_compl
        );
      
    COMMIT;

-- Call the MERGE PBA REF routine.  

    ls_current_process.pfsa_process := ps_procedure_name; 
  
-- Get the run criteria from the PFSA_PROCESSES table for the last run of 
-- the MAINTAIN_PFSA_DATES process 
  
    get_pfsawh_process_info
        (
        ps_procedure_name, ls_current_process.pfsa_process, 
        ls_current_process.last_run, ls_current_process.who_ran, 
        ls_current_process.last_run_status, 
        ls_current_process.last_run_status_time, 
        ls_current_process.last_run_compl
        );

    ls_start                             := sysdate;
    ls_current_process.last_run          := ls_start;
    ls_current_process.last_run_status   := 'BEGAN';
    ls_current_process.who_ran           := type_maintenance;
    ps_this_process.last_run_status_time := sysdate;
    ps_this_process.last_run_status      := ps_location;

-- Update the pfsa_processes table to indicate MAIN process location.  

    updt_pfsawh_processes
        (
        ps_procedure_name, ps_procedure_name, ps_this_process.last_run, 
        ps_this_process.who_ran, ps_this_process.last_run_status, 
        ps_this_process.last_run_status_time, ps_last_process.last_run_compl
        );

    COMMIT;

-- Update the pfsa_processes table to indicate the sub-process 
-- MERGE PBA REF has started.  

    updt_pfsawh_processes
        (
        ps_procedure_name, ls_current_process.pfsa_process, ls_start, 
        ps_this_process.who_ran, ls_current_process.last_run_status, 
        l_now_is, ls_current_process.last_run_compl
        );

    COMMIT;
  
/*----------------------------------------------------------------------------*/  

    ls_current_process.pfsa_process := ps_procedure_name; 
  
-- Get the run criteria for the PFSA_SUPPLY_ILAP from pfsa_process table 

    get_pfsawh_process_info
        (
        ps_procedure_name, ls_current_process.pfsa_process, 
        ls_current_process.last_run, ls_current_process.who_ran, 
        ls_current_process.last_run_status, 
        ls_current_process.last_run_status_time, 
        ls_current_process.last_run_compl
        );
  
    ls_start                           := SYSDATE;
    ls_current_process.last_run        := ls_start;
    l_call_error                       := NULL;
    ls_current_process.last_run_status := 'BEGAN';
    ls_current_process.who_ran         := type_maintenance;
 
-- Update the pfsa_process table to indicate STATUS of PFSA_SUPPLY_ILAP.  

    updt_pfsawh_processes
        (
        ps_procedure_name, ls_current_process.pfsa_process, ls_start, 
        ps_this_process.who_ran, ls_current_process.last_run_status, 
        l_now_is, ls_current_process.last_run_compl
        );

    ps_status := ps_location;
  
-- Update main process to indicate where its at 

    updt_pfsawh_processes
        (ps_procedure_name, ps_procedure_name, ps_this_process.last_run, 
        ps_this_process.who_ran, ps_status, l_now_is, 
        ps_this_process.last_run_compl
        ); 
      
    COMMIT;  
  
/*----------------------------------------------------------------------------*/ 
/*----- Start of actual work                                             -----*/  
/*----------------------------------------------------------------------------*/ 

    ps_location := 'PFSAWH 10';            -- For std_pfsawh_debug_tbl logging. 
    
    SELECT TO_CHAR(MAX(TO_DATE(iss_mon, 'MM/YY')), 'MM/YY') 
    INTO   v_iss_mon_pfsaw  
    FROM   pfsa_supply_ilap@pfsaw.lidb; 
    
    SELECT TO_CHAR(MAX(TO_DATE(iss_mon, 'MM/YY')), 'MM/YY')  
    INTO   v_iss_mon_pfsawh  
    FROM   pfsa_supply_ilap; 
    
/* Use for historical data loading */ 
/* Need for future developement    */     
--    v_iss_mon_pfsaw  := '10/06'; 
--    v_iss_mon_pfsawh := '09/06'; 
    
    IF v_iss_mon_pfsaw <> v_iss_mon_pfsawh THEN 

        proc1.process_RecId      := 575; 
        proc1.process_Key        := NULL;
        proc1.module_Num         := 10;
        proc1.process_Start_Date := SYSDATE;
        proc1.user_Login_Id      := USER; 
      
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_RecId, proc1.process_Key, 
            proc1.module_Num, proc1.step_Num,  
            proc1.process_Start_Date, NULL, 
            NULL, NULL, 
            NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL, 
            proc1.user_Login_Id, NULL, proc1_recId
            ); 
        
        COMMIT;     
        
        myrowcount := 0;
    
        SELECT COUNT(*) 
        INTO   myrowcount
        FROM   pfsa_supply_ilap_tmp;
        
        IF myrowcount > 0 THEN
           mytablename := 'pfsa_supply_ilap_tmp';
           truncate_a_table (mytablename);
        END IF;
        
        proc0.rec_deleted_int := NVL(proc0.rec_deleted_int, 0) + myrowcount;
        proc1.rec_deleted_int := NVL(proc1.rec_deleted_int, 0) + myrowcount;
    
        INSERT 
        INTO   pfsa_supply_ilap_tmp 
            (
            rec_id, docno, ric_stor, ipg, pniin, iss_niin,
            wh_period_date, wh_period_date_id, docno_uic, docno_force_unit_id,
            niin, pniin_item_id, physical_item_niin, physical_item_id,
            physical_item_sn, physical_item_sn_id, cwt, d_cust_iss,
            rcpt_docno, rcpt_dic, d_rcpt, rcpt_ric_fr, pseudo,
            sof, price, cat_sos, sc, scmc, ami,
            dlr, msc_spt, instl, corps, macom, d_upd,
            ssfcoc_flag, component, d_docno, d_sarss1, d_sarss2b,
            age_doc_s1, age_s1_s2b, fund, conus, qty,
            ext_price, prj, d_iss_month, iss_mon, dodaac,
            age_s1_iss, sfx, status, updt_by, lst_updt,
            grab_stamp, proc_stamp, active_flag, active_date,
            inactive_date, source_rec_id, insert_by, insert_date,
            lst_update_rec_id, update_by, update_date,
            delete_flag, delete_date, hidden_flag, hidden_date
            )
        SELECT 
            rec_id, docno, ric_stor, ipg, pniin, iss_niin,
            wh_period_date, wh_period_date_id, docno_uic, docno_force_unit_id,
            niin, pniin_item_id, physical_item_niin, physical_item_id,
            physical_item_sn, physical_item_sn_id, cwt, d_cust_iss,
            rcpt_docno, rcpt_dic, d_rcpt, rcpt_ric_fr, pseudo,
            sof, price, cat_sos, sc, scmc, ami,
            dlr, msc_spt, instl, corps, macom, d_upd,
            ssfcoc_flag, component, d_docno, d_sarss1, d_sarss2b,
            age_doc_s1, age_s1_s2b, fund, conus, qty,
            ext_price, prj, d_iss_month, iss_mon, dodaac,
            age_s1_iss, sfx, status, updt_by, lst_updt,
            grab_stamp, proc_stamp, active_flag, active_date,
            inactive_date, source_rec_id, insert_by, insert_date,
            lst_update_rec_id, update_by, update_date,
            delete_flag, delete_date, hidden_flag, hidden_date
        FROM   pfsa_supply_ilap@pfsaw.lidb
        WHERE  iss_mon = v_iss_mon_pfsaw; 
        
        proc0.rec_inserted_int := NVL(proc0.rec_inserted_int, 0) + SQL%ROWCOUNT;
        proc1.rec_inserted_int := NVL(proc1.rec_inserted_int, 0) + SQL%ROWCOUNT;
        
        COMMIT; 
        
        proc1.process_end_date := sysdate;
        proc1.sql_error_code := sqlcode;
        proc1.process_status_code := NVL(proc1.sql_error_code, sqlcode);
        proc1.message := sqlcode || ' - ' || sqlerrm; 
        
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_recid, proc1.process_key, 
            proc1.module_num, proc1.step_num,  
            proc1.process_start_date, proc1.process_end_date, 
            proc1.process_status_code, proc1.sql_error_code, 
            proc1.rec_read_int, proc1.rec_valid_int, proc1.rec_load_int, 
            proc1.rec_inserted_int, proc1.rec_merged_int, proc1.rec_selected_int, 
            proc1.rec_updated_int, proc1.rec_deleted_int, 
            proc1.user_login_id, proc1.message, proc1_recid
            );

/*----------------------------------------------------------------------------*/        

        ps_location := 'PFSAWH 20';            -- For std_pfsawh_debug_tbl logging. 
    
        proc1_recId              := NULL; 
        proc1.rec_inserted_int   := NULL;
        proc1.rec_merged_int     := NULL;
        proc1.rec_selected_int   := NULL;
        proc1.rec_deleted_int    := NULL;
        proc1.rec_updated_int    := NULL;
          
        proc1.process_RecId      := 575; 
        proc1.process_Key        := NULL;
        proc1.module_Num         := 20;
        proc1.process_Start_Date := SYSDATE;
        proc1.user_Login_Id      := USER; 
      
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_RecId, proc1.process_Key, 
            proc1.module_Num, proc1.step_Num,  
            proc1.process_Start_Date, NULL, 
            NULL, NULL, 
            NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL, 
            proc1.user_Login_Id, NULL, proc1_recId
            ); 
        
        COMMIT;     
        
--  Set the warehouse period 

        ps_location := 'PFSAWH 20a';            -- For std_pfsawh_debug_tbl logging. 
    
        UPDATE pfsa_supply_ilap_tmp psi
        SET    (wh_period_date, wh_period_date_id) = 
               (
               SELECT ready_date, fn_date_to_date_id(ready_date) 
               FROM   pfsawh_ready_date_dim 
               WHERE  oracle_date = psi.d_cust_iss    
               ); 
               
        proc0.rec_updated_int := NVL(proc0.rec_updated_int, 0) + SQL%ROWCOUNT;
        proc1.rec_updated_int := NVL(proc1.rec_updated_int, 0) + SQL%ROWCOUNT; 

        COMMIT; 

--  Set the force_unit_id 

        ps_location := 'PFSAWH 20b';            -- For std_pfsawh_debug_tbl logging. 
    
        UPDATE pfsa_supply_ilap_tmp pue
        SET    docno_force_unit_id = 
                NVL((
                SELECT force_unit_id  
                FROM   pfsawh_force_unit_dim 
                WHERE  dim_code = pue.docno_uic 
                    AND status = 'C'
                ), -1)
        WHERE  (pue.docno_force_unit_id IS NULL 
            OR pue.docno_force_unit_id < 1); 

        proc0.rec_updated_int := NVL(proc0.rec_updated_int, 0) + SQL%ROWCOUNT;
        proc1.rec_updated_int := NVL(proc1.rec_updated_int, 0) + SQL%ROWCOUNT;

        ps_location := 'PFSAWH 20c';            -- For std_pfsawh_debug_tbl logging. 
        
        UPDATE pfsa_supply_ilap_tmp pue
        SET    docno_force_unit_id = 
                NVL((
                SELECT force_unit_id  
                FROM   pfsawh_force_unit_dim 
                WHERE  dim_code = pue.docno_uic 
                    AND status = 'Q'
                ), -1)
        WHERE  (pue.docno_force_unit_id IS NULL 
            OR pue.docno_force_unit_id < 1); 

        proc0.rec_updated_int := NVL(proc0.rec_updated_int, 0) + SQL%ROWCOUNT;
        proc1.rec_updated_int := NVL(proc1.rec_updated_int, 0) + SQL%ROWCOUNT; 
        
        ps_location := 'PFSAWH 20d';            -- For std_pfsawh_debug_tbl logging. 
        
        UPDATE pfsa_supply_ilap_tmp pue
        SET    docno_force_unit_id = 
                NVL((
                SELECT force_unit_id  
                FROM   pfsawh_force_unit_dim 
                WHERE  pfsa_org = pue.docno_uic 
                    AND status = 'C'
                ), -1)
        WHERE  (pue.docno_force_unit_id IS NULL 
            OR pue.docno_force_unit_id < 1); 

        proc0.rec_updated_int := NVL(proc0.rec_updated_int, 0) + SQL%ROWCOUNT;
        proc1.rec_updated_int := NVL(proc1.rec_updated_int, 0) + SQL%ROWCOUNT;

        ps_location := 'PFSAWH 80';            -- For std_pfsawh_debug_tbl logging. 
    
-- Replace update statements 

-- Delete the tmp index if it exists 

        SELECT COUNT(*) 
        INTO   v_index_cnt 
        FROM   all_indexes
        WHERE  owner = 'PFSAWH' 
            AND index_name = UPPER('pfsa_supply_ilap_tmp_pk_idx');
            
        ps_location := 'PFSA 81';            -- For std_pfsawh_debug_tbl logging. 
        
        IF v_index_cnt > 0 THEN

            EXECUTE IMMEDIATE 
                'DROP INDEX pfsa_supply_ilap_tmp_pk_idx'; 
                
        END IF;
        
        ps_location := 'PFSA 82';            -- For std_pfsawh_debug_tbl logging. 
        
        EXECUTE IMMEDIATE 
            'CREATE UNIQUE INDEX pfsa_supply_ilap_tmp_pk_idx ON ' || 
                'pfsa_supply_ilap_tmp(rec_id)';
       
        ps_location := 'PFSA 85';            -- For std_pfsawh_debug_tbl logging. 
        
        OPEN updt_flag_cur;
      
        LOOP

            FETCH updt_flag_cur INTO w_rec_id, w_sof;
            
            EXIT WHEN updt_flag_cur%NOTFOUND;
               
            CASE UPPER(w_sof)
                WHEN 'DVD'     THEN  UPDATE pfsa_supply_ilap_tmp SET sof_dvd_flag = 1     WHERE  rec_id = w_rec_id;
                WHEN 'DVD_BO'  THEN  UPDATE pfsa_supply_ilap_tmp SET sof_dvd_bo_flag = 1  WHERE  rec_id = w_rec_id; 
                WHEN 'LAT_OFF' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_lat_off_flag = 1 WHERE  rec_id = w_rec_id; 
                WHEN 'LAT_ON'  THEN  UPDATE pfsa_supply_ilap_tmp SET sof_lat_on_flag = 1  WHERE  rec_id = w_rec_id; 
                WHEN 'LP'      THEN  UPDATE pfsa_supply_ilap_tmp SET sof_lp_flag = 1      WHERE  rec_id = w_rec_id; 
                WHEN 'MAINT'   THEN  UPDATE pfsa_supply_ilap_tmp SET sof_maint_flag = 1   WHERE  rec_id = w_rec_id; 
                WHEN 'REF_OFF' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_ref_off_flag = 1 WHERE  rec_id = w_rec_id; 
                WHEN 'REF_ON'  THEN  UPDATE pfsa_supply_ilap_tmp SET sof_ref_on_flag = 1  WHERE  rec_id = w_rec_id; 
                WHEN 'SSA'     THEN  UPDATE pfsa_supply_ilap_tmp SET sof_ssa_flag = 1     WHERE  rec_id = w_rec_id; 
                WHEN 'TI'      THEN  UPDATE pfsa_supply_ilap_tmp SET sof_ti_flag = 1      WHERE  rec_id = w_rec_id; 
                WHEN 'UNK'     THEN  UPDATE pfsa_supply_ilap_tmp SET sof_unk_flag = 1     WHERE  rec_id = w_rec_id; 
                WHEN 'WHSL'    THEN  UPDATE pfsa_supply_ilap_tmp SET sof_whsl_flag = 1    WHERE  rec_id = w_rec_id; 
                WHEN 'WHSL_BO' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_whsl_bo_flag = 1 WHERE  rec_id = w_rec_id; 
                WHEN 'WHSL_GE' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_whsl_ge_flag = 1 WHERE  rec_id = w_rec_id; 
                WHEN 'WHSL_KO' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_whsl_ko_flag = 1 WHERE  rec_id = w_rec_id; 
                WHEN 'WHSL_KU' THEN  UPDATE pfsa_supply_ilap_tmp SET sof_whsl_ku_flag = 1 WHERE  rec_id = w_rec_id;
                ELSE  w_rec_id := w_rec_id;
            END CASE; 
        
        END LOOP;

        CLOSE updt_flag_cur;

        proc1.process_end_date := sysdate;
        proc1.sql_error_code := sqlcode;
        proc1.process_status_code := NVL(proc1.sql_error_code, sqlcode);
        proc1.message := sqlcode || ' - ' || sqlerrm; 
        
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_recid, proc1.process_key, 
            proc1.module_num, proc1.step_num,  
            proc1.process_start_date, proc1.process_end_date, 
            proc1.process_status_code, proc1.sql_error_code, 
            proc1.rec_read_int, proc1.rec_valid_int, proc1.rec_load_int, 
            proc1.rec_inserted_int, proc1.rec_merged_int, proc1.rec_selected_int, 
            proc1.rec_updated_int, proc1.rec_deleted_int, 
            proc1.user_login_id, proc1.message, proc1_recid
            );

/*----------------------------------------------------------------------------*/        

        ps_location := 'PFSAWH 30';            -- For std_pfsawh_debug_tbl logging. 
    
        proc1_recId              := NULL; 
        proc1.rec_inserted_int   := NULL;
        proc1.rec_merged_int     := NULL;
        proc1.rec_selected_int   := NULL;
        proc1.rec_deleted_int    := NULL;
        proc1.rec_updated_int    := NULL;
          
        proc1.process_RecId      := 575; 
        proc1.process_Key        := NULL;
        proc1.module_Num         := 30;
        proc1.process_Start_Date := SYSDATE;
        proc1.user_Login_Id      := USER; 
      
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_RecId, proc1.process_Key, 
            proc1.module_Num, proc1.step_Num,  
            proc1.process_Start_Date, NULL, 
            NULL, NULL, 
            NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL, 
            proc1.user_Login_Id, NULL, proc1_recId
            ); 
        
        COMMIT;     
        
        MERGE  
        INTO   pfsa_supply_ilap psi 
        USING  (SELECT 
                    rec_id, docno, ric_stor, ipg, pniin, iss_niin,
                    wh_period_date, wh_period_date_id, docno_uic, 
                    docno_force_unit_id, niin, pniin_item_id, 
                    physical_item_niin, physical_item_id,
                    physical_item_sn, physical_item_sn_id, cwt, d_cust_iss,
                    rcpt_docno, rcpt_dic, d_rcpt, rcpt_ric_fr, pseudo,
                    sof, price, cat_sos, sc, scmc, ami,
                    dlr, msc_spt, instl, corps, macom, d_upd,
                    ssfcoc_flag, component, d_docno, d_sarss1, d_sarss2b,
                    age_doc_s1, age_s1_s2b, fund, conus, qty,
                    ext_price, prj, d_iss_month, iss_mon, dodaac,
                    age_s1_iss, sfx, status, updt_by, lst_updt,
                    grab_stamp, proc_stamp, active_flag, active_date,
                    inactive_date, source_rec_id, insert_by, insert_date,
                    lst_update_rec_id, update_by, update_date,
                    delete_flag, delete_date, hidden_flag, hidden_date,
                    sof_dvd_flag,      sof_dvd_bo_flag,  sof_lat_off_flag,
                    sof_lat_on_flag,   sof_lp_flag,      sof_maint_flag,
                    sof_ref_off_flag,  sof_ref_on_flag,  sof_ssa_flag,
                    sof_ti_flag,       sof_unk_flag,     sof_whsl_flag,
                    sof_whsl_bo_flag,  sof_whsl_ge_flag, sof_whsl_ko_flag,
                    sof_whsl_ku_flag
                FROM   pfsa_supply_ilap_tmp ) tmp 
        ON     (psi.rec_id = tmp.rec_id)  
        WHEN MATCHED THEN 
            UPDATE SET   
--                psi.rec_id              = tmp.rec_id,            
                psi.docno = tmp.docno,
                psi.ric_stor = tmp.ric_stor,
                psi.ipg = tmp.ipg,
                psi.pniin = tmp.pniin,
                psi.iss_niin= tmp.iss_niin,
                psi.wh_period_date = tmp.wh_period_date,
                psi.wh_period_date_id = tmp.wh_period_date_id,
                psi.docno_uic = tmp.docno_uic,
                psi.docno_force_unit_id = tmp.docno_force_unit_id,
                psi.niin = tmp.niin,
                psi.pniin_item_id = tmp.pniin_item_id,
                psi.physical_item_niin = tmp.physical_item_niin,
                psi.physical_item_id= tmp.physical_item_id,
                psi.physical_item_sn = tmp.physical_item_sn,
                psi.physical_item_sn_id = tmp.physical_item_sn_id,
                psi.cwt = tmp.cwt,
                psi.d_cust_iss= tmp.d_cust_iss,
                psi.rcpt_docno = tmp.rcpt_docno,
                psi.rcpt_dic = tmp.rcpt_dic,
                psi.d_rcpt = tmp.d_rcpt,
                psi.rcpt_ric_fr = tmp.rcpt_ric_fr,
                psi.pseudo= tmp.pseudo,
                psi.sof = tmp.sof,
                psi.price = tmp.price,
                psi.cat_sos = tmp.cat_sos,
                psi.sc = tmp.sc,
                psi.scmc = tmp.scmc,
                psi.ami= tmp.ami,
                psi.dlr = tmp.dlr,
                psi.msc_spt = tmp.msc_spt,
                psi.instl = tmp.instl,
                psi.corps = tmp.corps,
                psi.macom = tmp.macom,
                psi.d_upd= tmp.d_upd,
                psi.ssfcoc_flag = tmp.ssfcoc_flag,
                psi.component = tmp.component,
                psi.d_docno = tmp.d_docno,
                psi.d_sarss1 = tmp.d_sarss1,
                psi.d_sarss2b= tmp.d_sarss2b,
                psi.age_doc_s1 = tmp.age_doc_s1,
                psi.age_s1_s2b = tmp.age_s1_s2b,
                psi.fund = tmp.fund,
                psi.conus = tmp.conus,
                psi.qty= tmp.qty,
                psi.ext_price = tmp.ext_price,
                psi.prj = tmp.prj,
                psi.d_iss_month = tmp.d_iss_month,
                psi.iss_mon = tmp.iss_mon,
                psi.dodaac= tmp.dodaac,
                psi.age_s1_iss = tmp.age_s1_iss,
                psi.sfx = tmp.sfx,
                psi.status = tmp.status,
                psi.updt_by = tmp.updt_by,
                psi.lst_updt= tmp.lst_updt,
                psi.grab_stamp = tmp.grab_stamp,
                psi.proc_stamp = tmp.proc_stamp,
                psi.active_flag = tmp.active_flag,
                psi.active_date= tmp.active_date,
                psi.inactive_date = tmp.inactive_date,
                psi.source_rec_id = tmp.source_rec_id,
                psi.insert_by = tmp.insert_by,
                psi.insert_date= tmp.insert_date,
                psi.lst_update_rec_id = tmp.lst_update_rec_id,
                psi.update_by = tmp.update_by,
                psi.update_date= tmp.update_date,
                psi.delete_flag = tmp.delete_flag,
                psi.delete_date = tmp.delete_date,
                psi.hidden_flag = tmp.hidden_flag,
                psi.hidden_date = tmp.hidden_date,
                psi.sof_dvd_flag      = tmp.sof_dvd_flag,
                psi.sof_dvd_bo_flag   = tmp.sof_dvd_bo_flag,
                psi.sof_lat_off_flag  = tmp.sof_lat_off_flag,
                psi.sof_lat_on_flag   = tmp.sof_lat_on_flag,
                psi.sof_lp_flag       = tmp.sof_lp_flag,
                psi.sof_maint_flag    = tmp.sof_maint_flag,
                psi.sof_ref_off_flag  = tmp.sof_ref_off_flag,
                psi.sof_ref_on_flag   = tmp.sof_ref_on_flag,
                psi.sof_ssa_flag      = tmp.sof_ssa_flag,
                psi.sof_ti_flag       = tmp.sof_ti_flag,
                psi.sof_unk_flag      = tmp.sof_unk_flag,
                psi.sof_whsl_flag     = tmp.sof_whsl_flag,
                psi.sof_whsl_bo_flag  = tmp.sof_whsl_bo_flag,
                psi.sof_whsl_ge_flag  = tmp.sof_whsl_ge_flag,
                psi.sof_whsl_ko_flag  = tmp.sof_whsl_ko_flag,
                psi.sof_whsl_ku_flag  = tmp.sof_whsl_ku_flag 
        WHEN NOT MATCHED THEN 
            INSERT (
                    rec_id, docno, ric_stor, ipg, pniin, iss_niin,
                    wh_period_date, wh_period_date_id, docno_uic, 
                    docno_force_unit_id, niin, pniin_item_id, 
                    physical_item_niin, physical_item_id,
                    physical_item_sn, physical_item_sn_id, cwt, d_cust_iss,
                    rcpt_docno, rcpt_dic, d_rcpt, rcpt_ric_fr, pseudo,
                    sof, price, cat_sos, sc, scmc, ami,
                    dlr, msc_spt, instl, corps, macom, d_upd,
                    ssfcoc_flag, component, d_docno, d_sarss1, d_sarss2b,
                    age_doc_s1, age_s1_s2b, fund, conus, qty,
                    ext_price, prj, d_iss_month, iss_mon, dodaac,
                    age_s1_iss, sfx, status, updt_by, lst_updt,
                    grab_stamp, proc_stamp, active_flag, active_date,
                    inactive_date, source_rec_id, insert_by, insert_date,
                    lst_update_rec_id, update_by, update_date,
                    delete_flag, delete_date, hidden_flag, hidden_date,
                    sof_dvd_flag,
                    sof_dvd_bo_flag,
                    sof_lat_off_flag,
                    sof_lat_on_flag,
                    sof_lp_flag,
                    sof_maint_flag,
                    sof_ref_off_flag,
                    sof_ref_on_flag,
                    sof_ssa_flag,
                    sof_ti_flag,
                    sof_unk_flag,
                    sof_whsl_flag,
                    sof_whsl_bo_flag,
                    sof_whsl_ge_flag,
                    sof_whsl_ko_flag,
                    sof_whsl_ku_flag 
                    )
            VALUES (
                    tmp.rec_id, tmp.docno, tmp.ric_stor, tmp.ipg, tmp.pniin, tmp.iss_niin,
                    tmp.wh_period_date, tmp.wh_period_date_id, tmp.docno_uic, 
                    tmp.docno_force_unit_id, tmp.niin, tmp.pniin_item_id, 
                    tmp.physical_item_niin, tmp.physical_item_id,
                    tmp.physical_item_sn, tmp.physical_item_sn_id, tmp.cwt, tmp.d_cust_iss,
                    tmp.rcpt_docno, tmp.rcpt_dic, tmp.d_rcpt, tmp.rcpt_ric_fr, tmp.pseudo,
                    tmp.sof, tmp.price, tmp.cat_sos, tmp.sc, tmp.scmc, tmp.ami,
                    tmp.dlr, tmp.msc_spt, tmp.instl, tmp.corps, tmp.macom, tmp.d_upd,
                    tmp.ssfcoc_flag, tmp.component, tmp.d_docno, tmp.d_sarss1, tmp.d_sarss2b,
                    tmp.age_doc_s1, tmp.age_s1_s2b, tmp.fund, tmp.conus, tmp.qty,
                    tmp.ext_price, tmp.prj, tmp.d_iss_month, tmp.iss_mon, tmp.dodaac,
                    tmp.age_s1_iss, tmp.sfx, tmp.status, tmp.updt_by, tmp.lst_updt,
                    tmp.grab_stamp, tmp.proc_stamp, tmp.active_flag, tmp.active_date,
                    tmp.inactive_date, tmp.source_rec_id, tmp.insert_by, tmp.insert_date,
                    tmp.lst_update_rec_id, tmp.update_by, tmp.update_date,
                    tmp.delete_flag, tmp.delete_date, tmp.hidden_flag, tmp.hidden_date,
                    tmp.sof_dvd_flag,
                    tmp.sof_dvd_bo_flag,
                    tmp.sof_lat_off_flag,
                    tmp.sof_lat_on_flag,
                    tmp.sof_lp_flag,
                    tmp.sof_maint_flag,
                    tmp.sof_ref_off_flag,
                    tmp.sof_ref_on_flag,
                    tmp.sof_ssa_flag,
                    tmp.sof_ti_flag,
                    tmp.sof_unk_flag,
                    tmp.sof_whsl_flag,
                    tmp.sof_whsl_bo_flag,
                    tmp.sof_whsl_ge_flag,
                    tmp.sof_whsl_ko_flag,
                    tmp.sof_whsl_ku_flag  
                   ); 
                   
        proc0.rec_merged_int := NVL(proc0.rec_merged_int, 0) + SQL%ROWCOUNT;
        proc1.rec_merged_int := NVL(proc1.rec_merged_int, 0) + SQL%ROWCOUNT;

        COMMIT;            

        ps_location := 'PFSAWH 30a';            -- For std_pfsawh_debug_tbl logging.

        UPDATE pfsa_supply_ilap  
        SET    pniin_item_id = fn_pfsawh_get_item_dim_id(niin) 
        WHERE  pniin_item_id = '0'
            AND wh_period_date = TO_DATE(v_iss_mon_pfsaw, 'MM/YY') + 14; 

        proc0.rec_updated_int := NVL(proc0.rec_updated_int, 0) + SQL%ROWCOUNT;
        proc1.rec_updated_int := NVL(proc1.rec_updated_int, 0) + SQL%ROWCOUNT;

        COMMIT;    
    
        DELETE pfsa_supply_ilap_tmp; 
        
        proc0.rec_deleted_int := NVL(proc0.rec_deleted_int, 0) + SQL%ROWCOUNT;
        proc1.rec_deleted_int := NVL(proc1.rec_deleted_int, 0) + SQL%ROWCOUNT;

        COMMIT; 
         
        proc1.process_end_date := sysdate;
        proc1.sql_error_code := sqlcode;
        proc1.process_status_code := NVL(proc1.sql_error_code, sqlcode);
        proc1.message := sqlcode || ' - ' || sqlerrm; 
        
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_recid, proc1.process_key, 
            proc1.module_num, proc1.step_num,  
            proc1.process_start_date, proc1.process_end_date, 
            proc1.process_status_code, proc1.sql_error_code, 
            proc1.rec_read_int, proc1.rec_valid_int, proc1.rec_load_int, 
            proc1.rec_inserted_int, proc1.rec_merged_int, proc1.rec_selected_int, 
            proc1.rec_updated_int, proc1.rec_deleted_int, 
            proc1.user_login_id, proc1.message, proc1_recid
            );

        COMMIT;

/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
/*                                                                            */
/*                               Populate fact                                */
/*                                                                            */
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/ 

        ps_location := 'PFSAWH 40';            -- For std_pfsawh_debug_tbl logging. 
    
        proc1_recId              := NULL; 
        proc1.rec_inserted_int   := NULL;
        proc1.rec_merged_int     := NULL;
        proc1.rec_selected_int   := NULL;
        proc1.rec_deleted_int    := NULL;
        proc1.rec_updated_int    := NULL;
          
        proc1.process_RecId      := 575; 
        proc1.process_Key        := NULL;
        proc1.module_Num         := 40;
        proc1.process_Start_Date := SYSDATE;
        proc1.user_Login_Id      := USER; 
      
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_RecId, proc1.process_Key, 
            proc1.module_Num, proc1.step_Num,  
            proc1.process_Start_Date, NULL, 
            NULL, NULL, 
            NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL, 
            proc1.user_Login_Id, NULL, proc1_recId
            ); 
            
        COMMIT; 
            
        MERGE  
        INTO pfsawh_supply_ilap_p_fact ft 
        USING 
            (
            SELECT 
                bpsi.pniin,
                bpsi.iss_niin,
                NVL(bpsi.docno_uic, '000000') AS docno_uic,
                bpsi.docno_force_unit_id,
                bpsi.niin,
                bpsi.pniin_item_id,
                bpsi.physical_item_niin,
                bpsi.physical_item_id,
                bpsi.physical_item_sn,
                bpsi.physical_item_sn_id,
                bpsi.wh_period_date,
                bpsi.wh_period_date_id,
                bpsi.dodaac,
                bpsi.d_docno,
                bpsi.d_sarss1,
                COUNT(bpsi.cwt) AS cwt_cnt, 
                MIN(bpsi.cwt) AS cwt_min, 
                MAX(bpsi.cwt) AS cwt_max, 
                SUM(bpsi.cwt) AS cwt_sum, 
                TO_CHAR(ROUND(SUM(bpsi.cwt)/COUNT(bpsi.cwt), 1), '99999.9') AS cwt_avg, 
                TO_CHAR(-1, '99999.9') AS cwt_mean, 
                TO_CHAR(PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY bpsi.cwt), '99999.9') AS cwt_50, 
                TO_CHAR(PERCENTILE_CONT(0.85) WITHIN GROUP (ORDER BY cwt), '99999.9') AS cwt_85,
                SUM(sof_dvd_flag)     AS sof_dvd_cnt,
                SUM(sof_dvd_bo_flag)  AS sof_dvd_bo_cnt,
                SUM(sof_lat_off_flag) AS sof_lat_off_cnt,
                SUM(sof_lat_on_flag)  AS sof_lat_on_cnt,
                SUM(sof_lp_flag)      AS sof_lp_cnt,
                SUM(sof_maint_flag)   AS sof_maint_cnt,
                SUM(sof_ref_off_flag) AS sof_ref_off_cnt,
                SUM(sof_ref_on_flag)  AS sof_ref_on_cnt,
                SUM(sof_ssa_flag)     AS sof_ssa_cnt,
                SUM(sof_ti_flag)      AS sof_ti_cnt,
                SUM(sof_unk_flag)     AS sof_unk_cnt,
                SUM(sof_whsl_flag)    AS sof_whsl_cnt,
                SUM(sof_whsl_bo_flag) AS sof_whsl_bo_cnt,
                SUM(sof_whsl_ge_flag) AS sof_whsl_ge_cnt,
                SUM(sof_whsl_ko_flag) AS sof_whsl_ko_cnt,
                SUM(sof_whsl_ku_flag) AS sof_whsl_ku_cnt 
            FROM  pfsa_supply_ilap bpsi 
            WHERE iss_mon =  v_iss_mon_pfsaw
            GROUP BY bpsi.pniin,
                bpsi.iss_niin,
                bpsi.docno_uic,
                bpsi.docno_force_unit_id,
                bpsi.niin,
                bpsi.pniin_item_id,
                bpsi.physical_item_niin,
                bpsi.physical_item_id,
                bpsi.physical_item_sn,
                bpsi.physical_item_sn_id,
                bpsi.wh_period_date,
                bpsi.wh_period_date_id,  
                bpsi.dodaac,
                bpsi.d_docno,
                bpsi.d_sarss1 
            ) bpsi 
       ON ( ft.pniin                    = bpsi.pniin 
            AND ft.iss_niin            = bpsi.iss_niin 
            AND ft.docno_uic           = bpsi.docno_uic 
            AND ft.docno_force_unit_id = bpsi.docno_force_unit_id 
            AND ft.niin                = bpsi.niin 
            AND ft.pniin_item_id       = bpsi.pniin_item_id 
            AND ft.physical_item_niin  = bpsi.physical_item_niin 
            AND ft.physical_item_id    = bpsi.physical_item_id 
            AND ft.physical_item_sn    = bpsi.physical_item_sn 
            AND ft.physical_item_sn_id = bpsi.physical_item_sn_id 
            AND ft.wh_period_date      = bpsi.wh_period_date 
            AND ft.wh_period_date_id   = bpsi.wh_period_date_id   
            AND ft.dodaac              = bpsi.dodaac 
            AND ft.d_docno             = bpsi.d_docno 
            AND ft.d_sarss1            = bpsi.d_sarss1
          )
       WHEN MATCHED THEN 
           UPDATE SET 
                ft.cwt_cnt  = bpsi.cwt_cnt, 
                ft.cwt_min  = bpsi.cwt_min, 
                ft.cwt_max  = bpsi.cwt_max, 
                ft.cwt_sum  = bpsi.cwt_sum, 
                ft.cwt_avg  = bpsi.cwt_avg, 
                ft.cwt_mean = bpsi.cwt_mean, 
                ft.cwt_50   = bpsi.cwt_50, 
                ft.cwt_85   = bpsi.cwt_85, 
--                
                ft.sof_dvd_cnt     = bpsi.sof_dvd_cnt,
                ft.sof_dvd_bo_cnt  = bpsi.sof_dvd_bo_cnt,
                ft.sof_lat_off_cnt = bpsi.sof_lat_off_cnt,
                ft.sof_lat_on_cnt  = bpsi.sof_lat_on_cnt,
                ft.sof_lp_cnt      = bpsi.sof_lp_cnt,
                ft.sof_maint_cnt   = bpsi.sof_maint_cnt,
                ft.sof_ref_off_cnt = bpsi.sof_ref_off_cnt,
                ft.sof_ref_on_cnt  = bpsi.sof_ref_on_cnt,
                ft.sof_ssa_cnt     = bpsi.sof_ssa_cnt,
                ft.sof_ti_cnt      = bpsi.sof_ti_cnt,
                ft.sof_unk_cnt     = bpsi.sof_unk_cnt,
                ft.sof_whsl_cnt    = bpsi.sof_whsl_cnt,
                ft.sof_whsl_bo_cnt = bpsi.sof_whsl_bo_cnt,
                ft.sof_whsl_ge_cnt = bpsi.sof_whsl_ge_cnt,
                ft.sof_whsl_ko_cnt = bpsi.sof_whsl_ko_cnt,
                ft.sof_whsl_ku_cnt = bpsi.sof_whsl_ku_cnt 
       WHEN NOT MATCHED THEN    
            INSERT 
                ( 
                pniin,
                iss_niin,
                docno_uic,
                docno_force_unit_id,
                niin,
                pniin_item_id,
                physical_item_niin,
                physical_item_id,
                physical_item_sn,
                physical_item_sn_id,
                wh_period_date,
                wh_period_date_id,
                dodaac,
                d_docno,
                d_sarss1,
--
                cwt_cnt, 
                cwt_min, 
                cwt_max, 
                cwt_sum, 
                cwt_avg, 
                cwt_mean, 
                cwt_50, 
                cwt_85,
--                
                sof_dvd_cnt,
                sof_dvd_bo_cnt,
                sof_lat_off_cnt,
                sof_lat_on_cnt,
                sof_lp_cnt,
                sof_maint_cnt,
                sof_ref_off_cnt,
                sof_ref_on_cnt,
                sof_ssa_cnt,
                sof_ti_cnt,
                sof_unk_cnt,
                sof_whsl_cnt,
                sof_whsl_bo_cnt,
                sof_whsl_ge_cnt,
                sof_whsl_ko_cnt 
                ) 
            VALUES 
                (
                bpsi.pniin,
                bpsi.iss_niin,
                bpsi.docno_uic,
                bpsi.docno_force_unit_id,
                bpsi.niin,
                bpsi.pniin_item_id,
                bpsi.physical_item_niin,
                bpsi.physical_item_id,
                bpsi.physical_item_sn,
                bpsi.physical_item_sn_id,
                bpsi.wh_period_date,
                bpsi.wh_period_date_id,
                bpsi.dodaac,
                bpsi.d_docno,
                bpsi.d_sarss1,
--
                bpsi.cwt_cnt, 
                bpsi.cwt_min, 
                bpsi.cwt_max, 
                bpsi.cwt_sum, 
                bpsi.cwt_avg, 
                bpsi.cwt_mean, 
                bpsi.cwt_50, 
                bpsi.cwt_85,
--                
                bpsi.sof_dvd_cnt,
                bpsi.sof_dvd_bo_cnt,
                bpsi.sof_lat_off_cnt,
                bpsi.sof_lat_on_cnt,
                bpsi.sof_lp_cnt,
                bpsi.sof_maint_cnt,
                bpsi.sof_ref_off_cnt,
                bpsi.sof_ref_on_cnt,
                bpsi.sof_ssa_cnt,
                bpsi.sof_ti_cnt,
                bpsi.sof_unk_cnt,
                bpsi.sof_whsl_cnt,
                bpsi.sof_whsl_bo_cnt,
                bpsi.sof_whsl_ge_cnt,
                bpsi.sof_whsl_ko_cnt 
                );  
            
        proc0.rec_merged_int := NVL(proc0.rec_merged_int, 0) + SQL%ROWCOUNT;
        proc1.rec_merged_int := NVL(proc1.rec_merged_int, 0) + SQL%ROWCOUNT;

        COMMIT;     
        
/*----------------------------------------------------------------------------*/ 
/*----- End of actual work                                               -----*/  
/*----------------------------------------------------------------------------*/ 
  
        proc1.process_end_date := sysdate;
        proc1.sql_error_code := sqlcode;
        proc1.process_status_code := NVL(proc1.sql_error_code, sqlcode);
        proc1.message := sqlcode || ' - ' || sqlerrm; 
        
        pr_pfsawh_insupd_processlog 
            (
            proc1.process_recid, proc1.process_key, 
            proc1.module_num, proc1.step_num,  
            proc1.process_start_date, proc1.process_end_date, 
            proc1.process_status_code, proc1.sql_error_code, 
            proc1.rec_read_int, proc1.rec_valid_int, proc1.rec_load_int, 
            proc1.rec_inserted_int, proc1.rec_merged_int, proc1.rec_selected_int, 
            proc1.rec_updated_int, proc1.rec_deleted_int, 
            proc1.user_login_id, proc1.message, proc1_recid
            );

        COMMIT;

    END IF;
    
/*----------------------------------------------------------------------------*/  

    ps_location := 'PFSAWH 999';            -- For std_pfsawh_debug_tbl logging. 
        
    l_now_is := SYSDATE; 
  
    IF l_call_error IS NULL THEN
        ls_current_process.last_run_status := 'COMPLETE';
        ls_current_process.last_run_compl  := l_now_is;
    ELSE
        ls_current_process.last_run_status := 'ERROR';
        ps_main_status                     := 'ERROR';
    END IF;
  
-- Update the status of the sub-process PFSA_SUPPLY_ILAP. 

    updt_pfsawh_processes
      (
      ps_procedure_name, ls_current_process.pfsa_process, ls_start, 
      ps_this_process.who_ran, ls_current_process.last_run_status, 
      l_now_is, ls_current_process.last_run_compl
      ); 
          
    COMMIT;
  
-- Update the pfsa_process table to indicate main process has ended.  

-- Housekeeping for the end of the MAIN process 

    ps_this_process.last_run_status_time := SYSDATE; 
    ps_this_process.last_run_compl       := ps_this_process.last_run_status_time; 
  
    IF ps_main_status IS NULL THEN
        ps_main_status := 'COMPLETE';
    ELSE
        ps_main_status := 'CMPLERROR';
    END IF;
      
    updt_pfsawh_processes
        (
        ps_procedure_name, ps_procedure_name, ps_this_process.last_run, 
        ps_this_process.who_ran, ps_main_status,  
        ps_this_process.last_run_status_time, ps_this_process.last_run_compl
        );

    proc0.process_end_date := sysdate;
    proc0.sql_error_code := sqlcode;
    proc0.process_status_code := NVL(proc0.sql_error_code, sqlcode);
    proc0.message := sqlcode || ' - ' || sqlerrm; 
    
    pr_pfsawh_insupd_processlog 
        (
        proc0.process_recid, proc0.process_key, 
        proc0.module_num, proc0.step_num,  
        proc0.process_start_date, proc0.process_end_date, 
        proc0.process_status_code, proc0.sql_error_code, 
        proc0.rec_read_int, proc0.rec_valid_int, proc0.rec_load_int, 
        proc0.rec_inserted_int, proc0.rec_merged_int, proc0.rec_selected_int, 
        proc0.rec_updated_int, proc0.rec_deleted_int, 
        proc0.user_login_id, proc0.message, proc0_recid
        );

    COMMIT;

EXCEPTION 
    WHEN OTHERS THEN
        ps_oerr := sqlcode; 
        
        INSERT 
        INTO std_pfsawh_debug_tbl 
        (
        ps_procedure,      ps_oerr, ps_location, called_by, 
        ps_id_key, ps_msg, msg_dt
        )
        VALUES 
        (
        ps_procedure_name, ps_oerr, ps_location, type_maintenance, 
        ps_id_key, ps_msg, SYSDATE
        );
        
    COMMIT; 

END; -- end of procedure
/


