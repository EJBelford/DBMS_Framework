--
-- REFRESH_PFSAWH_MV_FILES  (Procedure) 
--
CREATE OR REPLACE PROCEDURE PFSAWH."REFRESH_PFSAWH_MV_FILES" (
    in_called_by    in    varchar2,   -- calling procedure name, used in
    in_run_set      in    varchar2 default 'ALL'   -- otther options: 'ETL', or 'FACTS'

-- debugging, calling procedure
-- responsible for maintaining
--  heirachy
)
is
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--      SP Name: refresh_pfsawh_mv_files
--      SP Desc:
--
--      SP Created By: Daniel Shrider
--      SP Created Date: 28 Jan 2009'
--
--      SP Source: refresh_pfsawh_mv_files.sql
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--      SP Parameters:
--              Input: in_called_by VARCHAR2    calling procedure name.
--              Input: in_run_set   VARCHAR2    ALL', 'ETL', or 'FACTS'.
--
--             Output:
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Used in the following:
--
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details'
-- 28JAN09 - DS  -          -      - Created 
-- 19MAR09 - DS  -          -      - Modified 
-- 20MAY09 - GB  -          -      - Turned of the "debug" and commented out 
--                                   "raise" error. 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/

    -- Exception handling variables (ps_)
    ps_procedure_name             std_pfsawh_debug_tbl.ps_procedure%type
                                                        := 'REFRESH_PFSAWH_MV_FILES';   /*  */
    ps_location                   std_pfsawh_debug_tbl.ps_location%type := 'Begin';   /*  */
    ps_oerr                       std_pfsawh_debug_tbl.ps_oerr%type := null;   /*  */
    ps_msg                        std_pfsawh_debug_tbl.ps_msg%type
                                                             := 'no message defined';   /*  */
    ps_id_key                     std_pfsawh_debug_tbl.ps_id_key%type := null;   /*  */
    -- coder responsible for identying key for debug

    -- standard variables
    ps_status                     varchar2 ( 10 ) := 'STARTED';
    ps_main_status                varchar2 ( 10 ) := null;
    l_ps_start                    date := sysdate;
    l_now_is                      date := sysdate;
    l_call_error                  varchar2 ( 20 ) := null;
    ls_start                      date := null;
    -- module variables (v_)
    v_debug                       number := 0;   --  TURN ON DEBUG'
    v_date_stamp                  date := null;
    v_status                      varchar2 ( 1 ) := null;
    v_sql                         varchar2 ( 500 ) := null;

    cursor c1
    is
        select distinct mv_name
                   from pfsawh_mv_refresh_status
                  where mv_status = 'E';

    cursor c2
    is
        select distinct src_name
                   from pfsawh_mv_refresh_status
                  where mv_status <> 'E';

    cursor c3
    is
        select distinct mv_name
                   from pfsawh_mv_refresh_status
                  where mv_status = 'R';
begin
    if v_debug > 0 then
        dbms_output.enable ( 1000000 );
        dbms_output.put_line ( '...' );
        dbms_output.put_line ( 'Debug is on...' );
        dbms_output.put_line ( '...' );
        dbms_output.put_line ( 'ps_location = ' || ps_location );
        dbms_output.put_line ( 'in_run_set = ' || in_run_set );
    end if;

    --
    -- Refresh the SOURCE_DATA materialized views...
    --
    if upper( in_run_set ) <> 'FACTS' then   -- only do this section if ETL or ALL...
        ps_location := 'ETL MV';

        if v_debug > 0 then
            dbms_output.put_line ( '...' );
            dbms_output.put_line ( 'ps_location = ' || ps_location );
        end if;

        for r in c1
        loop
            ps_id_key := r.mv_name;

            if v_debug > 0 then
                dbms_output.put_line ( 'r.src_name = ' || r.mv_name );
            end if;

            source_data_wh_refresh.refresh_source_mview ( r.mv_name,
                                                          'PFSAWH ETL MView Refresh',
                                                          'C' );
        end loop;
    end if;

    --
    -- Refresh the local materialized views...
    --
    if upper( in_run_set ) <> 'ETL' then   -- only do this section if FACTS or ALL...
        ps_location := 'LST UPDT';

        if v_debug > 0 then
            dbms_output.put_line ( '...' );
            dbms_output.put_line ( 'ps_location = ' || ps_location );
        end if;

        --
        -- Check for new data...
        --
        for r in c2
        loop
            ps_id_key := r.src_name;
            v_sql :=
                   'update pfsawh_mv_refresh_status '
                || '   set src_lst_updt = ( select max( lst_updt ) '
                || '                          from '
                || r.src_name
                || ' ) '
                || ' where src_name = :1';

            if v_debug > 0 then
                dbms_output.put_line ( 'r.src_name = ' || r.src_name );
                dbms_output.put_line ( 'v_sql = ' || v_sql );
            end if;

            execute immediate v_sql
                        using r.src_name;
        end loop;

        commit;
        ps_location := 'LOCAL MV';

        if v_debug > 0 then
            dbms_output.put_line ( '...' );
            dbms_output.put_line ( 'ps_location = ' || ps_location );
        end if;

        --
        -- Refresh the views as needed...
        --
        for r in c3
        loop
            begin
                v_date_stamp := sysdate;
                v_status := 'U';
                ps_id_key := r.mv_name;

                if v_debug > 0 then
                    dbms_output.put_line ( 'r.src_name = ' || r.mv_name );
                end if;

                dbms_mview.refresh ( r.mv_name, 'C' );
                v_status := 'S';

                update pfsawh_mv_refresh_status
                   set mv_lst_run = v_date_stamp,
                       mv_status = v_status
                 where mv_name = r.mv_name;
            exception
                when others then
                    ps_oerr := sqlcode;
                    ps_msg := sqlerrm;

                    if v_debug > 0 then
                        dbms_output.put_line ( 'ps_oerr = ' || ps_oerr );
                        dbms_output.put_line ( 'ps_msg = ' || ps_msg );
                    end if;

                    update pfsawh_mv_refresh_status
                       set mv_status = v_status
                     where mv_name = r.mv_name;

--  20MAY09 - GB - Commented out.
--                    raise;
            end;
        end loop;

        commit;
    end if;

    ps_location := 'Complete';

    if v_debug > 0 then
        dbms_output.put_line ( '...' );
        dbms_output.put_line ( 'ps_location = ' || ps_location );
    end if;
exception
    when others then
        ps_oerr := sqlcode;
        ps_msg := sqlerrm;

        insert into std_pfsawh_debug_tbl
                    ( ps_procedure, ps_oerr, ps_location, called_by,
                      ps_id_key, ps_msg, msg_dt
                    )
             values ( ps_procedure_name, ps_oerr, ps_location, in_called_by,
                      ps_id_key, ps_msg, sysdate
                    );

        commit;
end;   -- end of REFRESH_PFSAWH_MV_FILES procedure
/


