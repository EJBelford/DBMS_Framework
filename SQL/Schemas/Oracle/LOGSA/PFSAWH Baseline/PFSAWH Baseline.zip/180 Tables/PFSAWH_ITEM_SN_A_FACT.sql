--
-- PFSAWH_ITEM_SN_A_FACT  (Table) 
--
CREATE TABLE PFSAWH_ITEM_SN_A_FACT
(
  REC_ID                          NUMBER        NOT NULL,
  REC_YEAR                        NUMBER        NOT NULL,
  YEAR_TYPE                       VARCHAR2(2 BYTE) DEFAULT 'CY',
  DATE_ID                         NUMBER        NOT NULL,
  PHYSICAL_ITEM_ID                NUMBER        NOT NULL,
  PHYSICAL_ITEM_SN_ID             NUMBER        NOT NULL,
  MIMOSA_ITEM_SN_ID               VARCHAR2(8 BYTE) DEFAULT '00000000',
  ITEM_FORCE_ID                   NUMBER        DEFAULT 0,
  ITEM_LOCATION_ID                NUMBER        DEFAULT 0,
  MANUFACTURED_DATE               DATE,
  ITEM_USAGE_0                    NUMBER,
  ITEM_USAGE_TYPE_0               VARCHAR2(12 BYTE),
  YEAR_MC_HRS                     NUMBER,
  YEAR_FMC_HRS                    NUMBER,
  YEAR_PMC_HRS                    NUMBER,
  YEAR_PMCM_HRS                   NUMBER,
  YEAR_PMCM_USER_HRS              NUMBER,
  YEAR_PMCM_INT_HRS               NUMBER,
  YEAR_PMCS_HRS                   NUMBER,
  YEAR_PMCS_USER_HRS              NUMBER,
  YEAR_PMCS_INT_HRS               NUMBER,
  YEAR_NMC_HRS                    NUMBER,
  YEAR_NMCM_HRS                   NUMBER,
  YEAR_NMCM_USER_HRS              NUMBER,
  YEAR_NMCM_INT_HRS               NUMBER,
  YEAR_NMCS_HRS                   NUMBER,
  YEAR_NMCS_USER_HRS              NUMBER,
  YEAR_NMCS_INT_HRS               NUMBER,
  YEAR_DEP_HRS                    NUMBER,
  YEAR_NMCM_DEP_HRS               NUMBER,
  YEAR_NMCS_DEP_HRS               NUMBER,
  YEAR_OPERAT_READINESS_RATE      NUMBER,
  YEAR_OPERAT_COST_PER_HOUR       NUMBER,
  YEAR_COST_PARTS                 NUMBER,
  YEAR_COST_MANPOWER              NUMBER,
  YEAR_DEFERRED_MAINT_ITEMS       NUMBER,
  YEAR_OPERAT_HRS_SINCE_LST_OVHL  NUMBER,
  YEAR_MAINT_HRS_SINCE_LST_OVHL   NUMBER,
  YEAR_TIME_SINCE_LST_OVHL        NUMBER,
  STATUS                          VARCHAR2(1 BYTE) DEFAULT 'C',
  UPDT_BY                         VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                        DATE          DEFAULT SYSDATE,
  ACTIVE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'Y',
  ACTIVE_DATE                     DATE          DEFAULT '01-JAN-1900',
  INACTIVE_DATE                   DATE          DEFAULT '31-DEC-2099',
  INSERT_BY                       VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                     DATE          DEFAULT SYSDATE,
  UPDATE_BY                       VARCHAR2(30 BYTE),
  UPDATE_DATE                     DATE          DEFAULT '01-JAN-1900',
  DELETE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                     DATE          DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'Y',
  HIDDEN_DATE                     DATE          DEFAULT '01-JAN-1900',
  NOTES                           VARCHAR2(255 BYTE) DEFAULT '',
  PBA_ID                          NUMBER        DEFAULT 1000000,
  YEAR_MAINT_ACTION_CNT           NUMBER,
  YEAR_MEANTIME_BTWN_ACT          NUMBER,
  YEAR_MEANDOWN_TIME              NUMBER,
  YEAR_CUSTOMER_WAIT_TIME         NUMBER,
  ITEM_USAGE_1                    NUMBER,
  ITEM_USAGE_TYPE_1               VARCHAR2(12 BYTE),
  ITEM_USAGE_2                    NUMBER,
  ITEM_USAGE_TYPE_2               VARCHAR2(12 BYTE),
  ETL_PROCESSED_BY                VARCHAR2(50 BYTE),
  YEAR_TOTAL_DOWN_TIME            NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_ITEM_SN_A_FACT IS 'PFSAWH_ITEM_SN_A_FACT - This table serves as the annual fact for a particular item/serial number combination.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_item_sn_p_fact table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.REC_YEAR IS 'REC_YEAR - The year this annual or fiscal record is for.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_TYPE IS 'YEAR_TYPE - Allows for different rollups (annual, fiscal, etc.).';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.DATE_ID IS 'DATE_ID - Foreign key of the PFSAWH_DATE_DIM table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key of the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key of the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ITEM_FORCE_ID IS 'ITEM_FORCE_ID - Foreign key of the PFSAWH_FORCE_DIM table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ITEM_LOCATION_ID IS 'ITEM_LOCATION_ID - Foreign key of the PFSAWH_LOCATION_DIM table.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.MANUFACTURED_DATE IS 'MANUFACTURED_DATE  - The date the item was manufactuerd.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ITEM_USAGE_0 IS 'ITEM_USAGE - The actual usage of the system/end item accumulated during the period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ITEM_USAGE_TYPE_0 IS 'ITEM_USAGE_TYPE - An indicator of the type of usage captured.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_MC_HRS IS 'YEAR_MC_HRS - The total number of hours in a mission capable status (fully or partially) during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_FMC_HRS IS 'YEAR_FMC_HRS - The total number of hours in a fully mission capable status during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMC_HRS IS 'YEAR_PMC_HRS - The total number of hours in a partially mission capable status during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCM_HRS IS 'YEAR_PMCM_HRS - The total number of hours in a partial mission capable maintenance status during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCM_USER_HRS IS 'YEAR_PMCM_USER_HRS - The total number of hours in a partially mission capability maintenance status at the user level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCM_INT_HRS IS 'YEAR_PMCM_INT_HRS - The total number of hours in a partially mission capability maintenance status at the intermediate level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCS_HRS IS 'YEAR_PMCS_HRS - The total number of hours in a partial mission capable supply status during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCS_USER_HRS IS 'YEAR_PMCS_USER_HRS - The total number of hours in a partially mission capability supply status at the user level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_PMCS_INT_HRS IS 'YEAR_PMCS_INT_HRS - The total number of hours in a partially mission capability supply status at the intermediate level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMC_HRS IS 'YEAR_NMC_HRS - The total number of hours in a not mission capable status during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCM_HRS IS 'YEAR_NMCM_HRS - The total number of hours in a not mission capable maintenance status durint the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCM_USER_HRS IS 'YEAR_NMCM_USER_HRS - The total number of hours in a non mission capable maintenance status at the user level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCM_INT_HRS IS 'YEAR_NMCM_INT_HRS - The total number of hours in a non mission capable maintenance status at the intermediate level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCS_HRS IS 'YEAR_NMCS_HRS - The total number of hours in a not mission capable supply status durint the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCS_USER_HRS IS 'YEAR_NMCS_USER_HRS - The total number of hours in a non mission capable supply status at the user level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCS_INT_HRS IS 'YEAR_NMCS_INT_HRS - The total number of hours in a non mission capable supply status at the intermediate level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_DEP_HRS IS 'YEAR_DEP_HRS - The total number of hours in a non mission capable status at the depot level.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCM_DEP_HRS IS 'YEAR_NMCM_DEP_HRS - The total number of hours in a non mission capable maintenance status at the depot level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_NMCS_DEP_HRS IS 'YEAR_NMCS_DEP_HRS - The total number of hours in a non mission capable supply status at the depot level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_OPERAT_READINESS_RATE IS 'YEAR_OPERAT_READINESS_RATE - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_OPERAT_COST_PER_HOUR IS 'YEAR_OPERAT_COST_PER_HOUR - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_COST_PARTS IS 'YEAR_COST_PARTS - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_COST_MANPOWER IS 'YEAR_COST_MANPOWER - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_DEFERRED_MAINT_ITEMS IS 'YEAR_DEFERRED_MAINT_ITEMS - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_OPERAT_HRS_SINCE_LST_OVHL IS 'YEAR_OPERAT_HRS_SINCE_LST_OVHL - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_MAINT_HRS_SINCE_LST_OVHL IS 'YEAR_MAINT_HRS_SINCE_LST_OVHL - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_TIME_SINCE_LST_OVHL IS 'YEAR_TIME_SINCE_LST_OVHL - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ACTIVE_DATE IS 'ACTIVE_DATE - Addition control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.INACTIVE_DATE IS 'INACTIVE_DATE - Addition control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.DELETE_DATE IS 'DELETE_DATE - Addition control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.NOTES IS 'NOTES - Processing notes from the ETL process.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.YEAR_MAINT_ACTION_CNT IS 'YEAR_MAINT_ACTION_CNT -  The number of maintenance actions that have been identified during the year';

COMMENT ON COLUMN PFSAWH_ITEM_SN_A_FACT.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';


--
-- PK_ITEM_SN_A_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_ITEM_SN_A_FACT ON PFSAWH_ITEM_SN_A_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_ITEM_SN_A_FACT  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_ITEM_SN_A_FACT ON PFSAWH_ITEM_SN_A_FACT
(YEAR_TYPE, REC_YEAR, PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID, ITEM_FORCE_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ITEM_SN_A_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ITEM_SN_A_FACT FOR PFSAWH_ITEM_SN_A_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_A_FACT 
-- 
ALTER TABLE PFSAWH_ITEM_SN_A_FACT ADD (
  CONSTRAINT CK_ITEM_SN_A_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='Z' OR status='N'
        ),
  CONSTRAINT CK_ITEM_SN_A_FACT_ANN_TYP
 CHECK (year_type='CY' OR year_type='FY' OR year_type='OT'  
        ),
  CONSTRAINT PK_ITEM_SN_A_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_ITEM_SN_A_FACT TO S_PFSAW;

