--
-- PFSAWH_PROCESS_REF  (Table) 
--
CREATE TABLE PFSAWH_PROCESS_REF
(
  PROCESS_RECID        NUMBER                   NOT NULL,
  PROCESS_KEY          NUMBER                   NOT NULL,
  PROCESS_DESCRIPTION  VARCHAR2(50 BYTE)        NOT NULL,
  STATUS               VARCHAR2(1 BYTE)         DEFAULT 'N',
  UPDT_BY              VARCHAR2(30 BYTE)        DEFAULT user,
  LST_UPDT             DATE                     DEFAULT sysdate,
  ACTIVE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'I',
  ACTIVE_DATE          DATE                     DEFAULT '01-JAN-1900',
  INACTIVE_DATE        DATE                     DEFAULT '31-DEC-2099',
  INSERT_BY            VARCHAR2(30 BYTE)        DEFAULT user,
  INSERT_DATE          DATE                     DEFAULT sysdate,
  UPDATE_BY            VARCHAR2(30 BYTE),
  UPDATE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  DELETE_DATE          DATE                     DEFAULT '01-JAN-1900',
  HIDDEN_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'Y',
  HIDDEN_DATE          DATE                     DEFAULT '01-JAN-1900',
  RUN_CNTRL            NUMBER,
  OVERRIDE_RUN_CNTRL   VARCHAR2(1 BYTE)         DEFAULT 'N'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_PROCESS_REF IS 'Contains a mapping to the name of the stored procedure or function';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.STATUS IS 'The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.ACTIVE_DATE IS 'Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.INACTIVE_DATE IS 'Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_PROCESS_REF.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- IXU_PFSAWH_PROCESS_REF  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_PROCESS_REF ON PFSAWH_PROCESS_REF
(PROCESS_KEY)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_PROCESS_REF_ID  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_PROCESS_REF_ID ON PFSAWH_PROCESS_REF
(PROCESS_RECID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_PROCESS_REF_DESC  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_PROCESS_REF_DESC ON PFSAWH_PROCESS_REF
(PROCESS_DESCRIPTION)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_PROCESS_REF  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_PROCESS_REF FOR PFSAWH_PROCESS_REF;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_REF 
-- 
ALTER TABLE PFSAWH_PROCESS_REF ADD (
  CONSTRAINT CK_PFSAWH_PROCESS_REF_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_REF_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_REF_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT CK_ITEM_DIM_SUBJ_FLG
 CHECK (override_run_cntrl='Y'    OR override_run_cntrl='N'),
  CONSTRAINT PFSAWH_PROCESS_REF
 PRIMARY KEY
 (PROCESS_KEY));

GRANT DELETE, INSERT, SELECT, UPDATE ON PFSAWH_PROCESS_REF TO C_PFSAW_DB_IN;

GRANT SELECT ON PFSAWH_PROCESS_REF TO S_PFSAW;

