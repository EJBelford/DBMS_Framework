--
-- FRZ_PFSA_MAINT_WORK  (Table) 
--
CREATE TABLE FRZ_PFSA_MAINT_WORK
(
  REC_ID                NUMBER                  NOT NULL,
  SOURCE_REC_ID         NUMBER                  DEFAULT 0,
  PBA_ID                NUMBER                  NOT NULL,
  PHYSICAL_ITEM_ID      NUMBER                  DEFAULT 0,
  PHYSICAL_ITEM_SN_ID   NUMBER                  DEFAULT 0,
  FORCE_UNIT_ID         NUMBER                  DEFAULT 0,
  MIMOSA_ITEM_SN_ID     VARCHAR2(8 BYTE)        DEFAULT '00000000',
  MAINT_EV_ID           VARCHAR2(40 BYTE)       NOT NULL,
  MAINT_TASK_ID         VARCHAR2(50 BYTE)       NOT NULL,
  MAINT_WORK_ID         VARCHAR2(12 BYTE)       NOT NULL,
  MAINT_WORK_MH         NUMBER,
  MIL_CIV_KON           VARCHAR2(1 BYTE),
  MOS                   VARCHAR2(10 BYTE),
  SPEC_PERSON           VARCHAR2(20 BYTE),
  REPAIR                VARCHAR2(1 BYTE),
  MOS_SENT              VARCHAR2(10 BYTE),
  HEIR_ID               VARCHAR2(20 BYTE),
  PRIORITY              NUMBER,
  STATUS                VARCHAR2(1 BYTE),
  LST_UPDT              DATE,
  UPDT_BY               VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE        DATE,
  FRZ_INPUT_DATE_ID     NUMBER,
  REC_FRZ_FLAG          VARCHAR2(1 BYTE)        DEFAULT 'N',
  FRZ_DATE              DATE                    DEFAULT '31-DEC-2099',
  INSERT_BY             VARCHAR2(30 BYTE)       DEFAULT USER,
  INSERT_DATE           DATE                    DEFAULT SYSDATE,
  UPDATE_BY             VARCHAR2(30 BYTE),
  UPDATE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  DELETE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_BY             VARCHAR2(30 BYTE),
  HIDDEN_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  HIDDEN_DATE           DATE                    DEFAULT '01-JAN-1900',
  HIDDEN_BY             VARCHAR2(30 BYTE),
  MAINT_EVENT_ID_PART1  VARCHAR2(25 BYTE),
  MAINT_EVENT_ID_PART2  VARCHAR2(30 BYTE),
  ACTIVE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  ACTIVE_DATE           DATE                    DEFAULT sysdate,
  INACTIVE_DATE         DATE                    DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          3M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--
-- FRZ_PFSA_MAINT_WORK  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_MAINT_WORK FOR FRZ_PFSA_MAINT_WORK;


GRANT SELECT ON FRZ_PFSA_MAINT_WORK TO S_PFSAW;

