--
-- PFSAWH_ETL_ERROR_LOG  (Table) 
--
CREATE TABLE PFSAWH_ETL_ERROR_LOG
(
  REC_ID              NUMBER                    NOT NULL,
  REC_SOURCE          VARCHAR2(65 BYTE)         DEFAULT '',
  SOURCE_REC_ID       NUMBER                    DEFAULT 0,
  ETL_PROCESSED_BY    VARCHAR2(50 BYTE),
  ETL_ERROR_FIELD     VARCHAR2(30 BYTE),
  ETL_ERROR_VALUE     VARCHAR2(50 BYTE),
  ETL_ERROR_CODE      NUMBER,
  ETL_MESSAGE         VARCHAR2(255 BYTE),
  PROCESS_KEY         NUMBER                    DEFAULT 0,
  PROCESS_RECID       NUMBER                    DEFAULT 0,
  MODULE_NUM          NUMBER                    DEFAULT 0,
  STEP_NUM            NUMBER                    DEFAULT 0,
  PROCESS_START_DATE  DATE,
  SOURCE_RECORD       VARCHAR2(2000 BYTE)       DEFAULT '',
  STATUS              VARCHAR2(1 BYTE)          DEFAULT 'E',
  UPDT_BY             VARCHAR2(30 BYTE)         DEFAULT USER,
  LST_UPDT            DATE                      DEFAULT SYSDATE,
  INSERT_BY           VARCHAR2(20 BYTE)         DEFAULT USER,
  INSERT_DATE         DATE                      DEFAULT SYSDATE,
  UPDATE_BY           VARCHAR2(20 BYTE),
  UPDATE_DATE         DATE                      DEFAULT '01-JAN-1900',
  DELETE_FLAG         VARCHAR2(1 BYTE)          DEFAULT 'N',
  DELETE_BY           VARCHAR2(30 BYTE),
  DELETE_DATE         DATE                      DEFAULT '01-JAN-1900',
  HIDDEN_FLAG         VARCHAR2(1 BYTE)          DEFAULT 'N',
  HIDDEN_BY           VARCHAR2(30 BYTE),
  HIDDEN_DATE         DATE                      DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_ETL_ERROR_LOG IS 'PFSAWH_ETL_ERROR_LOG - This table is used to record the DISTINCT value that the ETL has an issue will.  ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.REC_ID IS 'REC_ID - Sequence/identity for dimension/fact table.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.REC_SOURCE IS 'REC_SOURCE - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.SOURCE_REC_ID IS 'SOURCE_REC_ID - Identifier to the orginial record received from the outside source.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.ETL_ERROR_FIELD IS 'ETL_ERROR_FIELD - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.ETL_ERROR_VALUE IS 'ETL_ERROR_VALUE - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.ETL_ERROR_CODE IS 'ETL_ERROR_CODE - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.ETL_MESSAGE IS 'ETL_MESSAGE - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.PROCESS_KEY IS 'PROCESS_KEY - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.PROCESS_RECID IS 'PROCESS_RECID - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.MODULE_NUM IS 'MODULE_NUM - Identities module within a give mutli-step process.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.STEP_NUM IS 'STEP_NUM - Identities steps within a give mutli-step process.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.PROCESS_START_DATE IS 'PROCESS_START_DATE - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.SOURCE_RECORD IS 'SOURCE_RECORD - ';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.DELETE_BY IS 'DELETE_BY - Reports who deleted the record.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.HIDDEN_BY IS 'HIDDEN_BY -  Reports who last hide the record.';

COMMENT ON COLUMN PFSAWH_ETL_ERROR_LOG.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- IDX_PFSAWH_ETL_ERROR_LOG  (Index) 
--
CREATE INDEX IDX_PFSAWH_ETL_ERROR_LOG ON PFSAWH_ETL_ERROR_LOG
(REC_SOURCE, SOURCE_REC_ID, ETL_ERROR_CODE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_ELT_ERROR_LOG  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ELT_ERROR_LOG ON PFSAWH_ETL_ERROR_LOG
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_ELT_ERROR_LOGL  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_ELT_ERROR_LOGL ON PFSAWH_ETL_ERROR_LOG
(ETL_ERROR_VALUE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ETL_ERROR_LOG  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ETL_ERROR_LOG FOR PFSAWH_ETL_ERROR_LOG;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_ERROR_LOG 
-- 
ALTER TABLE PFSAWH_ETL_ERROR_LOG ADD (
  CONSTRAINT CK_PFSAWH_ETL_ERROR_LOG_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_ETL_ERROR_LOG_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT PK_PFSAWH_ELT_ERROR_LOG
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ),
  CONSTRAINT IXU_PFSAWH_ELT_ERROR_LOGL
 UNIQUE (ETL_ERROR_VALUE)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_ETL_ERROR_LOG TO S_PFSAW;

