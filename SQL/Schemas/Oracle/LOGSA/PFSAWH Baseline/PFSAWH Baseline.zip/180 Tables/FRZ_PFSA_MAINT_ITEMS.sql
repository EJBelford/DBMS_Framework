--
-- FRZ_PFSA_MAINT_ITEMS  (Table) 
--
CREATE TABLE FRZ_PFSA_MAINT_ITEMS
(
  REC_ID                NUMBER                  NOT NULL,
  SOURCE_REC_ID         NUMBER                  DEFAULT 0,
  PBA_ID                NUMBER                  NOT NULL,
  PHYSICAL_ITEM_ID      NUMBER                  DEFAULT 0,
  PHYSICAL_ITEM_SN_ID   NUMBER                  DEFAULT 0,
  FORCE_UNIT_ID         NUMBER                  DEFAULT 0,
  MIMOSA_ITEM_SN_ID     VARCHAR2(8 BYTE)        DEFAULT '00000000',
  MAINT_EV_ID           VARCHAR2(40 BYTE)       NOT NULL,
  MAINT_TASK_ID         VARCHAR2(50 BYTE)       NOT NULL,
  MAINT_ITEM_ID         VARCHAR2(37 BYTE)       NOT NULL,
  CAGE_CD               VARCHAR2(5 BYTE),
  PART_NUM              VARCHAR2(32 BYTE),
  NIIN                  VARCHAR2(9 BYTE),
  PART_SN               VARCHAR2(32 BYTE),
  NUM_ITEMS             NUMBER,
  CNTLD_EXCHNG          VARCHAR2(1 BYTE),
  REMOVED               VARCHAR2(1 BYTE),
  FAILURE               VARCHAR2(1 BYTE),
  HEIR_ID               VARCHAR2(20 BYTE),
  PRIORITY              NUMBER,
  DOC_NO                VARCHAR2(14 BYTE),
  DOC_NO_EXPAND         VARCHAR2(18 BYTE),
  PART_UID              VARCHAR2(78 BYTE),
  STATUS                VARCHAR2(1 BYTE),
  LST_UPDT              DATE,
  UPDT_BY               VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE        DATE,
  FRZ_INPUT_DATE_ID     NUMBER,
  REC_FRZ_FLAG          VARCHAR2(1 BYTE)        DEFAULT 'N',
  FRZ_DATE              DATE                    DEFAULT '31-DEC-2099',
  INSERT_BY             VARCHAR2(30 BYTE)       DEFAULT USER,
  INSERT_DATE           DATE                    DEFAULT SYSDATE,
  UPDATE_BY             VARCHAR2(30 BYTE),
  UPDATE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  DELETE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_BY             VARCHAR2(30 BYTE),
  HIDDEN_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  HIDDEN_DATE           DATE                    DEFAULT '01-JAN-1900',
  HIDDEN_BY             VARCHAR2(30 BYTE),
  MAINT_EVENT_ID_PART1  VARCHAR2(25 BYTE),
  MAINT_EVENT_ID_PART2  VARCHAR2(30 BYTE),
  ACTIVE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  ACTIVE_DATE           DATE                    DEFAULT sysdate,
  INACTIVE_DATE         DATE                    DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE FRZ_PFSA_MAINT_ITEMS IS 'FRZ_PFSA_MAINT_ITEMS - This table documents all items used/consumed during a maintenance event';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_item_sn_p_fact table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.SOURCE_REC_ID IS 'SOURCE_REC_ID - Identifier to the orginial record received from the outside source.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key of the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key of the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.FORCE_UNIT_ID IS 'FORCE_UNIT_ID - Foreign key of the PFSAWH_FORCE_UNIT_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.MAINT_EV_ID IS 'MAINT_EV_ID - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.MAINT_TASK_ID IS 'MAINT_TASK_ID - The identifier that when combined with the MAINT_EV_ID creates a unique maintenance task id.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.MAINT_ITEM_ID IS 'MAINT_ITEM_ID - The identifier that when combined with the MAINT_EV_ID and MAINT_TASK_ID creates a unique maintenance task part id.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS.CAGE_CD IS 'COMMERCIAL AND GOVERNMENT ENTITY (CAGE) CODE - The Commercial and Government Entity (CAGE) Code is a five-character code assigned by the Defense Logistics Information Service (DLIS) to the design control activity or actual manufacturer of an item.';


--
-- FRZ_PFSA_MAINT_ITEMS  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_MAINT_ITEMS FOR FRZ_PFSA_MAINT_ITEMS;


GRANT SELECT ON FRZ_PFSA_MAINT_ITEMS TO S_PFSAW;

