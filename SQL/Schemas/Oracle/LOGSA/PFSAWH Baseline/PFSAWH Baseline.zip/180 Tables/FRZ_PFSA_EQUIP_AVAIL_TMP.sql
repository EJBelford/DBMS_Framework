--
-- FRZ_PFSA_EQUIP_AVAIL_TMP  (Table) 
--
CREATE TABLE FRZ_PFSA_EQUIP_AVAIL_TMP
(
  REC_ID                  NUMBER                NOT NULL,
  SOURCE_REC_ID           NUMBER                DEFAULT 0,
  PBA_ID                  NUMBER                DEFAULT '1000000',
  PHYSICAL_ITEM_ID        NUMBER                DEFAULT 0,
  PHYSICAL_ITEM_SN_ID     NUMBER                DEFAULT 0,
  FORCE_UNIT_ID           NUMBER                DEFAULT 0,
  MIMOSA_ITEM_SN_ID       VARCHAR2(8 BYTE)      DEFAULT '00000000',
  SYS_EI_NIIN             VARCHAR2(9 BYTE)      NOT NULL,
  PFSA_ITEM_ID            VARCHAR2(20 BYTE)     NOT NULL,
  RECORD_TYPE             VARCHAR2(1 BYTE)      NOT NULL,
  FROM_DT                 DATE                  NOT NULL,
  TO_DT                   DATE,
  READY_DATE              DATE                  NOT NULL,
  DAY_DATE                DATE,
  MONTH_DATE              DATE,
  PFSA_ORG                VARCHAR2(32 BYTE),
  SYS_EI_SN               VARCHAR2(32 BYTE),
  ITEM_DAYS               NUMBER,
  PERIOD_HRS              NUMBER,
  NMCM_HRS                NUMBER,
  NMCS_HRS                NUMBER,
  NMC_HRS                 NUMBER,
  FMC_HRS                 NUMBER,
  PMC_HRS                 NUMBER,
  MC_HRS                  NUMBER,
  NMCM_USER_HRS           NUMBER,
  NMCM_INT_HRS            NUMBER,
  NMCM_DEP_HRS            NUMBER,
  NMCS_USER_HRS           NUMBER,
  NMCS_INT_HRS            NUMBER,
  NMCS_DEP_HRS            NUMBER,
  PMCM_HRS                NUMBER,
  PMCS_HRS                NUMBER,
  SOURCE_ID               VARCHAR2(20 BYTE),
  PMCS_USER_HRS           NUMBER,
  PMCS_INT_HRS            NUMBER,
  PMCM_USER_HRS           NUMBER,
  PMCM_INT_HRS            NUMBER,
  DEP_HRS                 NUMBER,
  HEIR_ID                 VARCHAR2(20 BYTE),
  PRIORITY                NUMBER,
  UIC                     VARCHAR2(6 BYTE),
  GRAB_STAMP              DATE,
  PROC_STAMP              DATE,
  SYS_EI_UID              VARCHAR2(78 BYTE),
  STATUS                  VARCHAR2(1 BYTE),
  LST_UPDT                DATE,
  UPDT_BY                 VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE          DATE,
  FRZ_INPUT_DATE_ID       NUMBER,
  REC_FRZ_FLAG            VARCHAR2(1 BYTE)      DEFAULT 'N',
  FRZ_DATE                DATE                  DEFAULT '31-DEC-2099',
  INSERT_BY               VARCHAR2(30 BYTE)     DEFAULT USER,
  INSERT_DATE             DATE                  DEFAULT SYSDATE,
  UPDATE_BY               VARCHAR2(30 BYTE),
  UPDATE_DATE             DATE                  DEFAULT '01-JAN-1900',
  DELETE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'N',
  DELETE_DATE             DATE                  DEFAULT '01-JAN-1900',
  DELETE_BY               VARCHAR2(30 BYTE),
  HIDDEN_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'N',
  HIDDEN_DATE             DATE                  DEFAULT '01-JAN-1900',
  HIDDEN_BY               VARCHAR2(30 BYTE),
  ACTIVE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'Y',
  ACTIVE_DATE             DATE                  DEFAULT sysdate,
  INACTIVE_DATE           DATE                  DEFAULT '01-JAN-1900',
  RIDB_ON_TIME_FLAG       VARCHAR2(1 BYTE),
  READINESS_REPORTED_QTY  NUMBER,
  READY_DATE_ID           NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--
-- FRZ_PFSA_EQUIP_AVAIL_TMP  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_EQUIP_AVAIL_TMP FOR FRZ_PFSA_EQUIP_AVAIL_TMP;


GRANT SELECT ON FRZ_PFSA_EQUIP_AVAIL_TMP TO S_PFSAW;

