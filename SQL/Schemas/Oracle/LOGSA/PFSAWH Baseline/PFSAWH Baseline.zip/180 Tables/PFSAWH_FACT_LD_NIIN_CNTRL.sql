--
-- PFSAWH_FACT_LD_NIIN_CNTRL  (Table) 
--
CREATE TABLE PFSAWH_FACT_LD_NIIN_CNTRL
(
  REC_ID                    NUMBER              NOT NULL,
  PHYSICAL_ITEM_ID          NUMBER              NOT NULL,
  NIIN                      VARCHAR2(9 BYTE)    DEFAULT 'unk',
  ITEM_NOMEN_STANDARD       VARCHAR2(35 BYTE)   DEFAULT 'unk',
  SCHEDULED_LOAD_DATE       DATE,
  SCHEDULED_LOAD_DATE_ID    NUMBER,
  LOAD_DATE                 DATE,
  LOAD_DATE_ID              NUMBER,
  STATUS                    VARCHAR2(1 BYTE)    DEFAULT 'W',
  UPDT_BY                   VARCHAR2(30 BYTE)   DEFAULT USER,
  LST_UPDT                  DATE                DEFAULT SYSDATE,
  ACTIVE_FLAG               VARCHAR2(1 BYTE)    DEFAULT 'Y',
  ACTIVE_DATE               DATE                DEFAULT '01-JAN-1900',
  INACTIVE_DATE             DATE                DEFAULT '31-DEC-2099',
  INSERT_BY                 VARCHAR2(50 BYTE)   DEFAULT USER,
  INSERT_DATE               DATE                DEFAULT SYSDATE,
  UPDATE_BY                 VARCHAR2(50 BYTE),
  UPDATE_DATE               DATE                DEFAULT '01-JAN-1900',
  DELETE_BY                 VARCHAR2(50 BYTE),
  DELETE_FLAG               VARCHAR2(1 BYTE)    DEFAULT 'N',
  DELETE_DATE               DATE                DEFAULT '01-JAN-1900',
  HIDDEN_BY                 VARCHAR2(50 BYTE),
  HIDDEN_FLAG               VARCHAR2(1 BYTE)    DEFAULT 'N',
  HIDDEN_DATE               DATE                DEFAULT '01-JAN-1900',
  PROCESS_BATCH_ID          NUMBER,
  RELOAD_NIIN_PROCESS_TIME  NUMBER,
  PFSA_SN_EI_CNT            NUMBER,
  EQUIP_AVAIL_CNT           NUMBER,
  USAGE_EVENT_CNT           NUMBER,
  MAINT_EVENT_CNT           NUMBER,
  RELD_PROC_CAT             NUMBER,
  RELD_PROC_PRIY            NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_FACT_LD_NIIN_CNTRL IS 'PFSAWH_FACT_LD_NIIN_CNTRL - Identifies what niin are scheduled to be reloaded in the fact tables, or whne they were last reloaded. ';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.PROCESS_BATCH_ID IS 'PROCESS_BATCH_ID - Is the REC_ID for the MAINTAIN_PFSAW_WORLD for a given run.  It is designed to allow easy retrival of the major steps for a give run.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.RELOAD_NIIN_PROCESS_TIME IS 'RELOAD_NIIN_PROCESS_TIME - The elapsed time it took to process the NIIN during its last processing cycle.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.PFSA_SN_EI_CNT IS 'PFSA_SN_EI_CNT - The number of records for the given NIIN in the PFSA_SN_EI.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.RELD_PROC_CAT IS 'RELD_PROC_CAT - This is a classification of the processing time to allow rescheduer best schedule NIINs in the available processing window.  (Specific to avoid running NIINs with long processing times on business days.)';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.EQUIP_AVAIL_CNT IS 'EQUIP_AVAIL_CNT - The number of records for the given NIIN in the PFSA_EQUIP_AVAIL.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.USAGE_EVENT_CNT IS 'USAGE_EVENT_CNT - The number of records for the given NIIN in the PFSA_USAGE_EVENT.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.MAINT_EVENT_CNT IS 'MAINT_EVENT_CNT - The number of records for the given NIIN in the PFSA_MAINT_EVENT.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.RELD_PROC_PRIY IS 'RELD_PROC_PRIY - This is a classification of the NIINs importance to allow rescheduer best schedule NIINs in the available processing window.  (1: High, 2: Normal, 3: Low)';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_fact_ld_niin_cntrl table.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key of the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.NIIN IS 'NIIN - NATIONAL ITEM IDENTIFICATION NUMBER - A nine-digit number sequentially assigned to each approved item identification number under the federal cataloging program.  The first two digits are the NATO code and the remaining seven are what was formerly the federal item identification number.  These nine digits are the latter part of the 13-digit National Stock Number (NSN).';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.ITEM_NOMEN_STANDARD IS 'ITEM_NOMEN_STANDARD - Description of the item.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.SCHEDULED_LOAD_DATE IS 'SCHEDULED_LOAD_DATE - When the NIIN is to be reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.SCHEDULED_LOAD_DATE_ID IS 'SCHEDULED_LOAD_DATE_ID - Foreign key of the PFSAWH_DATE_DIM table for when the NIIN is to be reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.LOAD_DATE IS 'LOAD_DATE - When the NIIN was reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.LOAD_DATE_ID IS 'LOAD_DATE_ID - Foreign key of the PFSAWH_DATE_DIM table when the NIIN was reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.DELETE_BY IS 'DELETE_BY - Reports who last deleted the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.HIDDEN_BY IS 'HIDDEN_BY - Reports who last hide the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_FACT_LD_NIIN_CNTRL.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- PK_PFSAWH_FACT_LD_NIIN_CNTRL  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_FACT_LD_NIIN_CNTRL ON PFSAWH_FACT_LD_NIIN_CNTRL
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_FACT_LD_NIIN_CNTRL  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_FACT_LD_NIIN_CNTRL ON PFSAWH_FACT_LD_NIIN_CNTRL
(PHYSICAL_ITEM_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_FACT_LD_NIIN_CNTRL  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_FACT_LD_NIIN_CNTRL FOR PFSAWH_FACT_LD_NIIN_CNTRL;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_FACT_LD_NIIN_CNTRL 
-- 
ALTER TABLE PFSAWH_FACT_LD_NIIN_CNTRL ADD (
  CONSTRAINT PK_PFSAWH_FACT_LD_NIIN_CNTRL
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT DELETE, INSERT, SELECT, UPDATE ON PFSAWH_FACT_LD_NIIN_CNTRL TO C_PFSAW_DB_IN;

GRANT SELECT ON PFSAWH_FACT_LD_NIIN_CNTRL TO S_PFSAW;

