--
-- PFSA_MAINT_WORK  (Table) 
--
CREATE TABLE PFSA_MAINT_WORK
(
  MAINT_EV_ID           VARCHAR2(40 BYTE)       NOT NULL,
  MAINT_TASK_ID         VARCHAR2(50 BYTE)       NOT NULL,
  MAINT_WORK_ID         VARCHAR2(12 BYTE)       NOT NULL,
  MAINT_WORK_MH         NUMBER,
  MIL_CIV_KON           VARCHAR2(1 BYTE),
  MOS                   VARCHAR2(10 BYTE),
  SPEC_PERSON           VARCHAR2(20 BYTE),
  REPAIR                VARCHAR2(1 BYTE),
  STATUS                VARCHAR2(1 BYTE),
  LST_UPDT              DATE,
  UPDT_BY               VARCHAR2(30 BYTE),
  MOS_SENT              VARCHAR2(10 BYTE),
  HEIR_ID               VARCHAR2(20 BYTE),
  PRIORITY              NUMBER,
  PBA_ID                INTEGER                 DEFAULT 1000000,
  MAINT_EVENT_ID_PART1  VARCHAR2(25 BYTE),
  MAINT_EVENT_ID_PART2  VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE        DATE,
  FRZ_INPUT_DATE_ID     NUMBER,
  ACTIVE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  ACTIVE_DATE           DATE                    DEFAULT sysdate,
  INACTIVE_DATE         DATE                    DEFAULT '01-JAN-1900',
  INSERT_BY             VARCHAR2(30 BYTE)       DEFAULT user,
  INSERT_DATE           DATE                    DEFAULT sysdate,
  UPDATE_BY             VARCHAR2(30 BYTE),
  UPDATE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  DELETE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_BY             VARCHAR2(30 BYTE),
  HIDDEN_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  HIDDEN_DATE           DATE                    DEFAULT '01-JAN-1900',
  HIDDEN_BY             VARCHAR2(30 BYTE),
  REC_ID                NUMBER                  DEFAULT 0,
  SOURCE_REC_ID         NUMBER                  DEFAULT 0,
  PHYSICAL_ITEM_ID      NUMBER                  DEFAULT 0,
  PHYSICAL_ITEM_SN_ID   NUMBER                  DEFAULT 0,
  FORCE_UNIT_ID         NUMBER                  DEFAULT 0,
  MIMOSA_ITEM_SN_ID     VARCHAR2(8 BYTE)        DEFAULT '00000000'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          3M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSA_MAINT_WORK IS 'PFSA_MAINT_WORK - This table documents all work performed by maintanenace personnel during a maintenance event.  Work not attributable to a specific person is aggregated';

COMMENT ON COLUMN PFSA_MAINT_WORK.MAINT_EV_ID IS 'MAINT_EV_ID - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number';

COMMENT ON COLUMN PFSA_MAINT_WORK.MAINT_TASK_ID IS 'MAINT_TASK_ID - The identifier that when combined with the MAINT_EV_ID creates a unique maintenance task id.';

COMMENT ON COLUMN PFSA_MAINT_WORK.MAINT_WORK_ID IS 'MAINT_WORK_ID - The identifier that when combined with the MAINT_EV_ID and MAINT_TASK_ID creates a unique maintenance task work id.';

COMMENT ON COLUMN PFSA_MAINT_WORK.MAINT_WORK_MH IS 'MAINT_WORK_MH - The number of hours the maintenance work took to complete.';

COMMENT ON COLUMN PFSA_MAINT_WORK.MIL_CIV_KON IS 'MIL_CIV_KON - The code for the type of person doing the maintenance, Civilian, Kontractor, Military or Unknown.  Values are C\K\M\U';

COMMENT ON COLUMN PFSA_MAINT_WORK.MOS IS 'MOS - OCCUPATIONAL SPECIALTY CODE - The code that represents the Military Occupational Specialty (MOS) of the person performing the maintenance action.';

COMMENT ON COLUMN PFSA_MAINT_WORK.SPEC_PERSON IS 'SPEC_PERSON ? Specific person who performed the work.';

COMMENT ON COLUMN PFSA_MAINT_WORK.REPAIR IS 'REPAIR - Item was repaired.  Values should be Y - Yes, N - No, ? - Unknown';

COMMENT ON COLUMN PFSA_MAINT_WORK.STATUS IS 'STATUS - The status of the record.  Values are Q/R/P or D';

COMMENT ON COLUMN PFSA_MAINT_WORK.LST_UPDT IS 'LST_UPDT - The date/time stamp the record was last updated';

COMMENT ON COLUMN PFSA_MAINT_WORK.UPDT_BY IS 'UPDT_BY - Who/what updated the record.';

COMMENT ON COLUMN PFSA_MAINT_WORK.MOS_SENT IS 'MOS_SENT - The value of provided in the source data for the MOS.  This value is used to derive the MOS used.  The derived values generally remove the skill level code, and standardize terms used for Contractor and Civilian personnel.';

COMMENT ON COLUMN PFSA_MAINT_WORK.HEIR_ID IS 'HEIR_ID - A PFSA generated identification used to ensure heirarchical data source integrity is maintained.';

COMMENT ON COLUMN PFSA_MAINT_WORK.PRIORITY IS 'PRIORITY - The relative prioirty of the data source.  Care should be taken to leave gaps in numbers to ensure additions can be made later.  The lower the number, the higher the priority.';


--
-- IDX_PFSA_MAINT_WORK_LST_UPDT  (Index) 
--
CREATE INDEX IDX_PFSA_MAINT_WORK_LST_UPDT ON PFSA_MAINT_WORK
(LST_UPDT)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSA_MAINT_WORK_INSERT_DT  (Index) 
--
CREATE INDEX IDX_PFSA_MAINT_WORK_INSERT_DT ON PFSA_MAINT_WORK
(INSERT_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSA_MAINT_WORK_UPDATE_DT  (Index) 
--
CREATE INDEX IDX_PFSA_MAINT_WORK_UPDATE_DT ON PFSA_MAINT_WORK
(UPDATE_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSA_MAINT_WORK  (Index) 
--
CREATE UNIQUE INDEX PK_PFSA_MAINT_WORK ON PFSA_MAINT_WORK
(MAINT_EV_ID, MAINT_TASK_ID, MAINT_WORK_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          6M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSA_MAINT_WORK  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_MAINT_WORK FOR PFSA_MAINT_WORK;


-- 
-- Non Foreign Key Constraints for Table PFSA_MAINT_WORK 
-- 
ALTER TABLE PFSA_MAINT_WORK ADD (
  CONSTRAINT PK_PFSA_MAINT_WORK
 PRIMARY KEY
 (MAINT_EV_ID, MAINT_TASK_ID, MAINT_WORK_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          6M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSA_MAINT_WORK TO S_PFSAW;

