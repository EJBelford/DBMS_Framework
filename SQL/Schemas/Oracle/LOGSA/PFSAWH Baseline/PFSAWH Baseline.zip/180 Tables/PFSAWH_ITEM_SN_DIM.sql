--
-- PFSAWH_ITEM_SN_DIM  (Table) 
--
CREATE TABLE PFSAWH_ITEM_SN_DIM
(
  REC_ID                       NUMBER           NOT NULL,
  ITEM_SERIAL_NUMBER           VARCHAR2(48 BYTE) DEFAULT '-1',
  ITEM_NIIN                    VARCHAR2(9 BYTE) NOT NULL,
  ITEM_REGISTRATION_NUM        VARCHAR2(30 BYTE) DEFAULT 'UNK',
  ITEM_LOCATION                VARCHAR2(4 BYTE) DEFAULT '-1',
  ITEM_UIC                     VARCHAR2(6 BYTE) DEFAULT '-1',
  ITEM_UIC_LOCATION            VARCHAR2(4 BYTE) DEFAULT '-1',
  ITEM_SOC_FLAG                VARCHAR2(2 BYTE) DEFAULT 'N',
  ITEM_ACQ_DATE                DATE             DEFAULT '01-JAN-1900',
  ITEM_NOTES                   VARCHAR2(255 BYTE),
  STATUS                       VARCHAR2(1 BYTE) DEFAULT 'I',
  LST_UPDT                     DATE             DEFAULT SYSDATE,
  UPDT_BY                      VARCHAR2(30 BYTE) DEFAULT USER,
  ACTIVE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'I',
  ACTIVE_DATE                  DATE             DEFAULT '01-JAN-1900',
  INACTIVE_DATE                DATE             DEFAULT '31-DEC-2099',
  INSERT_BY                    VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                  DATE             DEFAULT SYSDATE,
  UPDATE_BY                    VARCHAR2(30 BYTE),
  UPDATE_DATE                  DATE             DEFAULT '01-JAN-1900',
  DELETE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                  DATE             DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  HIDDEN_DATE                  DATE             DEFAULT '01-JAN-1900',
  PHYSICAL_ITEM_ID             NUMBER           DEFAULT 0                     NOT NULL,
  PHYSICAL_ITEM_SN_ID          NUMBER           DEFAULT 0                     NOT NULL,
  ITEM_LOCATION_ID             NUMBER           DEFAULT -1,
  ITEM_FORCE_ID                NUMBER           DEFAULT -1,
  ITEM_ARMY_TYPE_DESIGNATOR    VARCHAR2(30 BYTE),
  ITEM_MANUFACTURER            VARCHAR2(30 BYTE),
  ITEM_MANUFACTURER_CD         VARCHAR2(6 BYTE),
  ITEM_MANUFACTURED_DATE       DATE,
  ITEM_MANUFACTURED_DATE_ID    NUMBER           DEFAULT -1,
  MIMOSA_ITEM_SN_ID            VARCHAR2(8 BYTE) DEFAULT '00000000' NOT NULL,
  WH_FLAG                      VARCHAR2(1 BYTE) DEFAULT 'N',
  WH_EARLIEST_FACT_REC_DT      DATE,
  WH_EARLIEST_FACT_REC_SOURCE  VARCHAR2(65 BYTE),
  FORCE_PARENT_UNIT_CODE       VARCHAR2(6 BYTE),
  FORCE_PARENT_UNIT_ID         NUMBER           DEFAULT 0,
  FORCE_COMMAND_UNIT_CODE      VARCHAR2(6 BYTE),
  FORCE_COMMAND_UNIT_ID        NUMBER           DEFAULT 0,
  ITEM_SN_W_DASHES             VARCHAR2(48 BYTE),
  ITEM_SN_WO_DASHES            VARCHAR2(48 BYTE),
  MIMOSA_ENTERPRISE_ID         VARCHAR2(8 BYTE) DEFAULT '00000430' NOT NULL,
  MIMOSA_SITE_ID               VARCHAR2(8 BYTE) DEFAULT '00000001' NOT NULL,
  OEM_MIMOSA_ENTERPRISE_ID     VARCHAR2(8 BYTE) DEFAULT '00000000' NOT NULL,
  OEM_MIMOSA_SITE_ID           VARCHAR2(8 BYTE) DEFAULT '00000000' NOT NULL,
  OEM_MIMOSA_ITEM_SN_ID        VARCHAR2(8 BYTE) DEFAULT '00000000' NOT NULL
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_ITEM_SN_DIM IS 'PFSAWH_ITEM_SN_DIM - This table contains the serial numbered items in the PFSA world.  It therefore reflects the current information from the PFSA_SN_EI_HIST table  and other sources. It is populated and controlled by TBD process.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.HIDDEN_DATE IS 'HIDDEN_DATE - Additional control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - LIW/PFSAWH identitier for the item/part.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_LOCATION_ID IS 'ITEM_LOCATION_ID - LOCATION - Identifies the location as CONUS (Continental United States) or OCONUS (Outside the Continental United States) as represented in the PFSAWH_LOCATION_DIM.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_FORCE_ID IS 'ITEM_FORCE_ID - FORCE UIC - The unit identifier of valid Force UICs as represented in the PFSAWH_FORCE_DIM.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_ARMY_TYPE_DESIGNATOR IS 'ITEM_ARMY_TYPE_DESIGNATOR - Model number';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_MANUFACTURER IS 'ITEM_MANUFACTURER - MANUFACTURER - Identifies the manufacturer of the item.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_MANUFACTURER_CD IS 'ITEM_MANUFACTURER_CD - MANUFACTURER - Identifies the manufacturer of the item.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_MANUFACTURED_DATE IS 'ITEM_MANUFACTURED_DATE - The date the item was manufactuerd.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_MANUFACTURED_DATE_ID IS 'ITEM_MANUFACTURED_DATE_ID - The date the item was manufactuerd as represented by the PFSAWH_DATE_DIM.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number. HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.REC_ID IS 'REC_ID - Sequence/identity for dimension.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_SERIAL_NUMBER IS 'ITEM_SERIAL_NUMBER - Serial number of the item.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_NIIN IS 'ITEM_NIIN - National Item Identification Number for the item/part.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_REGISTRATION_NUM IS 'ITEM_REGISTRATION_NUM - REGISTRATION NUMBER - The U.S. Army Registration (Serial) Number.  A combination of numbers and letters assigned in a unique manner to each item of vehicular equipment for ready identification and control during the item''s service life.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_LOCATION IS 'ITEM_LOCATION - LOCATION - Identifies the location as CONUS (Continental United States) or OCONUS (Outside the Continental United States).';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_UIC IS 'ITEM_UIC - FORCE UIC - The unit identifier of valid Force UICs.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_UIC_LOCATION IS 'ITEM_UIC_LOCATION - Force location';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_SOC_FLAG IS 'ITEM_SOC_FLAG - Special Operations flag.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_ACQ_DATE IS 'ITEM_ACQ_DATE - ACQUISITION DATE - Indicates the date an item was acquired.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ITEM_NOTES IS 'ITEM_NOTES - This will be NULL if the record is good.  Records information about the record error.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Flag indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Flag indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_DIM.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';


--
-- IDX_PFSAWH_ITEM_SN_DIM_REC_ID  (Index) 
--
CREATE UNIQUE INDEX IDX_PFSAWH_ITEM_SN_DIM_REC_ID ON PFSAWH_ITEM_SN_DIM
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITMSN_DIM_ITMIDSNID  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITMSN_DIM_ITMIDSNID ON PFSAWH_ITEM_SN_DIM
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITMSN_DIM_NIIN_SN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITMSN_DIM_NIIN_SN ON PFSAWH_ITEM_SN_DIM
(ITEM_NIIN, ITEM_SERIAL_NUMBER)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITMSN_DIM_SN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITMSN_DIM_SN ON PFSAWH_ITEM_SN_DIM
(ITEM_SERIAL_NUMBER)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITM_SN_DIM_SN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITM_SN_DIM_SN ON PFSAWH_ITEM_SN_DIM
(PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDU_PFSAWH_ITMSN_DIM_ITMIDSNID  (Index) 
--
CREATE UNIQUE INDEX IDU_PFSAWH_ITMSN_DIM_ITMIDSNID ON PFSAWH_ITEM_SN_DIM
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID, STATUS, LST_UPDT)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDU_PFSAWH_ITMSN_DIM_NIIN_SN  (Index) 
--
CREATE UNIQUE INDEX IDU_PFSAWH_ITMSN_DIM_NIIN_SN ON PFSAWH_ITEM_SN_DIM
(ITEM_NIIN, ITEM_SERIAL_NUMBER, STATUS, LST_UPDT)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ITEM_SN_DIM  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ITEM_SN_DIM FOR PFSAWH_ITEM_SN_DIM;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_DIM 
-- 
ALTER TABLE PFSAWH_ITEM_SN_DIM ADD (
  CONSTRAINT PK_PFSAWH_ITM_SN_DIM_ITM_SN_ID
 PRIMARY KEY
 (PHYSICAL_ITEM_SN_ID));

GRANT SELECT ON PFSAWH_ITEM_SN_DIM TO S_PFSAW;

