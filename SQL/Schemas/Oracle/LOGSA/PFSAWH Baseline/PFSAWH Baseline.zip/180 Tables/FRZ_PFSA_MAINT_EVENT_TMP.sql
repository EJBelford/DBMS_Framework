--
-- FRZ_PFSA_MAINT_EVENT_TMP  (Table) 
--
CREATE TABLE FRZ_PFSA_MAINT_EVENT_TMP
(
  REC_ID                   NUMBER               NOT NULL,
  SOURCE_REC_ID            NUMBER               DEFAULT 0,
  PBA_ID                   NUMBER               NOT NULL,
  PHYSICAL_ITEM_ID         NUMBER               DEFAULT 0,
  PHYSICAL_ITEM_SN_ID      NUMBER               DEFAULT 0,
  FORCE_UNIT_ID            NUMBER               DEFAULT 0,
  MIMOSA_ITEM_SN_ID        VARCHAR2(8 BYTE)     DEFAULT '00000000',
  MAINT_EV_ID              VARCHAR2(40 BYTE)    NOT NULL,
  MAINT_ORG                VARCHAR2(32 BYTE),
  MAINT_UIC                VARCHAR2(6 BYTE),
  MAINT_LVL_CD             VARCHAR2(1 BYTE),
  MAINT_ITEM               VARCHAR2(37 BYTE),
  MAINT_ITEM_NIIN          VARCHAR2(9 BYTE),
  MAINT_ITEM_SN            VARCHAR2(32 BYTE),
  NUM_MAINT_ITEM           NUMBER,
  SYS_EI_NIIN              VARCHAR2(9 BYTE),
  SYS_EI_SN                VARCHAR2(32 BYTE),
  NUM_MI_NRTS              NUMBER,
  NUM_MI_RPRD              NUMBER,
  NUM_MI_CNDMD             NUMBER,
  NUM_MI_NEOF              NUMBER,
  DT_MAINT_EV_EST          DATE,
  DT_MAINT_EV_CMPL         DATE,
  SYS_EI_NMCM              VARCHAR2(1 BYTE),
  PHASE_EV                 VARCHAR2(1 BYTE),
  SOF_EV                   VARCHAR2(1 BYTE),
  ASAM_EV                  VARCHAR2(1 BYTE),
  MWO_EV                   VARCHAR2(1 BYTE),
  ELAPSED_ME_WK_TM         NUMBER,
  SOURCE_ID                VARCHAR2(20 BYTE),
  HEIR_ID                  VARCHAR2(20 BYTE),
  PRIORITY                 NUMBER,
  CUST_ORG                 VARCHAR2(32 BYTE),
  CUST_UIC                 VARCHAR2(6 BYTE),
  MAINT_EVENT_ID_PART1     VARCHAR2(25 BYTE),
  MAINT_EVENT_ID_PART2     VARCHAR2(30 BYTE),
  FAULT_MALFUNCTION_DESCR  VARCHAR2(80 BYTE),
  WON                      VARCHAR2(12 BYTE),
  LAST_WO_STATUS           VARCHAR2(1 BYTE),
  LAST_WO_STATUS_DATE      DATE,
  RIDB_ON_TIME_FLAG        VARCHAR2(1 BYTE),
  REPORT_DATE              DATE,
  STATUS                   VARCHAR2(1 BYTE),
  LST_UPDT                 DATE,
  UPDT_BY                  VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE           DATE,
  FRZ_INPUT_DATE_ID        NUMBER,
  REC_FRZ_FLAG             VARCHAR2(1 BYTE)     DEFAULT 'N',
  FRZ_DATE                 DATE                 DEFAULT '31-DEC-2099',
  ACTIVE_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'Y',
  ACTIVE_DATE              DATE                 DEFAULT sysdate,
  INACTIVE_DATE            DATE                 DEFAULT '01-JAN-1900',
  INSERT_BY                VARCHAR2(30 BYTE)    DEFAULT USER,
  INSERT_DATE              DATE                 DEFAULT SYSDATE,
  UPDATE_BY                VARCHAR2(30 BYTE),
  UPDATE_DATE              DATE                 DEFAULT '01-JAN-1900',
  DELETE_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'N',
  DELETE_DATE              DATE                 DEFAULT '01-JAN-1900',
  DELETE_BY                VARCHAR2(30 BYTE),
  HIDDEN_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'N',
  HIDDEN_DATE              DATE                 DEFAULT '01-JAN-1900',
  HIDDEN_BY                VARCHAR2(30 BYTE)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE FRZ_PFSA_MAINT_EVENT_TMP IS 'FRZ_PFSA_MAINT_EVENT_TMP - All maintenance data in the PFSA World is tied to a specific maintenance event.  This table documents all maintenance events.  Maintenance events are assumed to be tied to a specific instance of a system/end item.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.HIDDEN_BY IS 'HIDDEN_BY - Reports who last hide the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_item_sn_p_fact table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SOURCE_REC_ID IS 'SOURCE_REC_ID - Identifier to the orginial record received from the outside source.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key of the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key of the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.FORCE_UNIT_ID IS 'FORCE_UNIT_ID - Foreign key of the PFSAWH_FORCE_UNIT_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_EV_ID IS 'MAINT_EV_ID - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_ORG IS 'MAINT_ORG - The organization accomplishing the maintenance event.  If a UIC, the value will match the maint_uic.  Field used to identify manufacturer/non-UIC identified contractor maintenance';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_UIC IS 'MAINT_UIC - The UIC provided by the STAMIS system for the Maintenance Event';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_LVL_CD IS 'MAINT_LVL_CD - MAINTENANCE LEVEL CODE - A code assigned to support items to indicate the lowest maintenance level authorized to remove and replace the support item and the lowest maintenance level authorized to completely repair the support item.  The following codes are valid:  O - Organizational maintenance (AVUM); F - Direct support maintenance (AVIM); H - General support maintenance; D - Depot maintenance; C - Crew; L - Special repair activity.  Publications: [(MIL-STD-1388-2B 28 MARCH 1991) C -- Operator/Crew/Unit-Crew.  O -- Organizational/On Equipment/Unit-Organizational.  F -- Intermediate/Direct Support/Afloat/Third Echelon/Off Equipment/Intermediate-Forward.  H -- Intermediate/General Support/Ashore\Fourth Echelon/Intermediate-Rear.  G -- Intermediate/Ashore and Afloat.  D -- Depot/Shipyards.  L -- Specialized Repair Activity.]  [(DA PAM 731-751 15 MARCH 1999) O -- Aviation Unit Maintenance (AVUM), F -- Aviation Intermediate Maintenance (AVIM), D -- Depot, K -- Contractor, L -- Special Repair Activity.] Codes that are assigned to indicate the maintenance levels authorized to perform the required maintenance function (see DED 277 for definitions of the individual O/M Levels).  C -- Operator/Crew/Unit-Crew.  O -- Organizational/On Equipment/Unit-Organizational.  F -- Intermediate/Direct Support/Afloat/Third Echelon/Off quipment/Intermediate-Forward.  H -- Intermediate/General Support/Ashore\Fourth Echelon/Intermediate-Rear.  G -- Intermediate/Ashore and Afloat.  D -- Depot/Shipyards.  L -- Specialized Repair Activity';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_ITEM IS 'MAINT_ITEM - The item maintenance is being performed on';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_ITEM_NIIN IS 'MAINT_ITEM_NIIN - The niin of the item maintenance is being performed on.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MAINT_ITEM_SN IS 'MAINT_ITEM_SN - The serial number of the specific item maintenance is being performed on.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.NUM_MAINT_ITEM IS 'NUM_MAINT_ITEM - The number of items identified for the maintenance action.  Frequently 1.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SYS_EI_NIIN IS 'SYS_EI_NIIN - The system\end item niin to which the maintenance event is tied to.  All maintenance events in the PFSA world are tied to a specific system end item type.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SYS_EI_SN IS 'SYS_EI_SN - The serial number of the system end item which the maintenance event is tied to.  Can be aggregated.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.NUM_MI_NRTS IS 'NUM_MI_NRTS - The number of maintenance items which were not repairable this station.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.NUM_MI_RPRD IS 'NUM_MI_RPRD - The number of maintenance items which were repaired in the maintenance event.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.NUM_MI_CNDMD IS 'NUM_MI_CNDMD - The number of maintenance items which were condemned during the maintenance event.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.NUM_MI_NEOF IS 'NUM_MI_NEOF - The number of maintenance items where no evidence of failure could be found.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.DT_MAINT_EV_EST IS 'DT_MAINT_EV_EST - The date/time stamp of when the maintenance event was established.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.DT_MAINT_EV_CMPL IS 'DT_MAINT_EV_CMPL - The date/time stamp of when the maintenance event was completed/closed.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SYS_EI_NMCM IS 'SYS_EI_NMCM - A flag identifying the system/end item was not mission capabile for some portion of the mainteannce event.  Values are Y or N.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.PHASE_EV IS 'PHASE_EV - A flag used in PFSA to identify phased maintenance events for aircraft.  values are Y, N, U (unknown, but aircraft) and null, for not applicable.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SOF_EV IS 'SOF_EV - A flag indicating a Safety of Flight (SOF) event.  Values of Y or N';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.ASAM_EV IS 'ASAM_EV - A flag indicating an Aviation safety Action Message (ASAM) event.  Used to quickly alert field to potential/pending safety issues with aircraft and/or components.  Values are Y or N';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.MWO_EV IS 'MWO_EV - A flag indicating an Modification Work Order(MWO) event.  Values are Y or N';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.ELAPSED_ME_WK_TM IS 'ELAPSED_ME_WK_TM - The total elapsed time during the maintenance event when work was being performed, when available from the data source.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.SOURCE_ID IS 'SOURCE_ID - The PFSA maintained identification for the source of the data';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.HEIR_ID IS 'HEIR_ID - A PFSA generated identification used to ensure heirarchical data source integrity is maintained.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.PRIORITY IS 'PRIORITY - The relative prioirty of the data source.  Care should be taken to leave gaps in numbers to ensure additions can be made later.  The lower the number, the higher the priority.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.CUST_ORG IS 'CUST_ORG - The customer organization orginating the maintenance event.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.CUST_UIC IS 'CUST_UIC - The uic which owns the equipment.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.STATUS IS 'STATUS - The status of the record.  Values are Q/R/P or D';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.LST_UPDT IS 'LST_UPDT - The date/time stamp the record was last updated';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.UPDT_BY IS 'UPDT_BY - Who/what updated the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.FRZ_INPUT_DATE IS 'FRZ_INPUT_DATE - ';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.FRZ_INPUT_DATE_ID IS 'FRZ_INPUT_DATE_ID - ';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.REC_FRZ_FLAG IS 'REC_FRZ_FLAG - Flag indicating if the record is frozen or not.  Values: N - Not frozen, Y - Frozen';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.FRZ_DATE IS 'FRZ_DATE - Additional control for REC_FRZ_FLAG indicating when the record was frozen.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.DELETE_BY IS 'DELETE_BY - Reports who deleted the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_EVENT_TMP.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';


--
-- FRZ_PFSA_MAINT_EVENT_TMP  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_MAINT_EVENT_TMP FOR FRZ_PFSA_MAINT_EVENT_TMP;


GRANT SELECT ON FRZ_PFSA_MAINT_EVENT_TMP TO S_PFSAW;

