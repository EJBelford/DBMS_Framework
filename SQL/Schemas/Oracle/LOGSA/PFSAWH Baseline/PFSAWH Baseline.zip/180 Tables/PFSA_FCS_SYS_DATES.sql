--
-- PFSA_FCS_SYS_DATES  (Table) 
--
CREATE TABLE PFSA_FCS_SYS_DATES
(
  EQUIP_AVAIL_PERIOD_DATE  DATE,
  MAINT_EVENT_PERIOD_DATE  DATE,
  USAGE_PERIOD_DATE        DATE,
  MONTHLY_CWT_PERIOD_DATE  DATE,
  STATUS                   VARCHAR2(1 BYTE)     DEFAULT 'C',
  LST_UPDT                 DATE                 DEFAULT SYSDATE,
  UPDT_BY                  VARCHAR2(30 BYTE)    DEFAULT SUBSTR(USER,1,30)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN PFSA_FCS_SYS_DATES.EQUIP_AVAIL_PERIOD_DATE IS 'Current period date for the most current full period of data imported from pfsa_equip_avail into the pfsawh warehouse.  Used in the BI tool to filter data for monthly availability screens.';

COMMENT ON COLUMN PFSA_FCS_SYS_DATES.MAINT_EVENT_PERIOD_DATE IS 'Current period date for the most current full period of data imported from pfsa_maint_* tables  into the pfsawh warehouse.  Used in the BI tool to filter data for monthly Mean Down Time screens.';

COMMENT ON COLUMN PFSA_FCS_SYS_DATES.USAGE_PERIOD_DATE IS 'Current period date for the most current full period of data imported from pfsa_usage_event  into the pfsawh warehouse.  Used in the BI tool to filter data for monthly MTBMA screens.';

COMMENT ON COLUMN PFSA_FCS_SYS_DATES.MONTHLY_CWT_PERIOD_DATE IS 'Current period date for the most current full period of data imported from ilap cwt view  into the pfsawh warehouse.  Used in the BI tool to filter data for monthly CWT screens.';


--
-- PFSA_FCS_SYS_DATES  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_FCS_SYS_DATES FOR PFSA_FCS_SYS_DATES;


GRANT SELECT ON PFSA_FCS_SYS_DATES TO OBIONE;

GRANT SELECT ON PFSA_FCS_SYS_DATES TO S_PFSAW;

