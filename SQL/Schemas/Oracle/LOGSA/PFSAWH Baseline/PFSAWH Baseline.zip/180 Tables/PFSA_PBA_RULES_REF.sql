--
-- PFSA_PBA_RULES_REF  (Table) 
--
CREATE TABLE PFSA_PBA_RULES_REF
(
  REC_ID                NUMBER                  NOT NULL,
  METRIC_ID             NUMBER                  DEFAULT -2,
  RULE_ID               NUMBER                  DEFAULT 0,
  RULE_DESCRIPTION      VARCHAR2(50 BYTE)       DEFAULT 'unk',
  RULE_DATE_FROM_ID     NUMBER                  DEFAULT 0,
  RULE_DATE_TO_ID       NUMBER                  DEFAULT 0,
  RULE_LOWER_LIMIT      NUMBER                  DEFAULT 100,
  RULE_UPPER_LIMIT      NUMBER                  DEFAULT 0,
  BI_DISPLAY_OBJECT     VARCHAR2(2 BYTE),
  BI_DISPLAY_ATTRIBUTE  VARCHAR2(2 BYTE),
  BI_COLOR_ID           VARCHAR2(2 BYTE)        DEFAULT 'W',
  STATUS                VARCHAR2(1 BYTE)        DEFAULT 'N',
  UPDT_BY               VARCHAR2(30 BYTE)       DEFAULT USER,
  LST_UPDT              DATE                    DEFAULT SYSDATE,
  ACTIVE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'I',
  ACTIVE_DATE           DATE                    DEFAULT '01-JAN-1900',
  INACTIVE_DATE         DATE                    DEFAULT '31-DEC-2099',
  INSERT_BY             VARCHAR2(30 BYTE)       DEFAULT USER,
  INSERT_DATE           DATE                    DEFAULT SYSDATE,
  UPDATE_BY             VARCHAR2(30 BYTE),
  UPDATE_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  DELETE_DATE           DATE                    DEFAULT '01-JAN-1900',
  HIDDEN_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  HIDDEN_DATE           DATE                    DEFAULT '01-JAN-1900',
  DELETE_BY             VARCHAR2(50 BYTE),
  HIDDEN_BY             VARCHAR2(50 BYTE),
  RULE_DISPLAY_TEXT     VARCHAR2(50 BYTE),
  TRFR_N_TO_S           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  TRFR_S_TO_N           VARCHAR2(1 BYTE)        DEFAULT 'N'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN PFSA_PBA_RULES_REF.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSA_PBA_RULES_REF.REC_ID IS 'REC_ID - Sequence/identity for the table.';


--
-- IXU_PFSA_PBA_RULES_REF_RECID  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSA_PBA_RULES_REF_RECID ON PFSA_PBA_RULES_REF
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSA_PBA_RULES_REF  (Index) 
--
CREATE UNIQUE INDEX PK_PFSA_PBA_RULES_REF ON PFSA_PBA_RULES_REF
(METRIC_ID, RULE_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSA_PBA_RULES_REF  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_PBA_RULES_REF FOR PFSA_PBA_RULES_REF;


-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_RULES_REF 
-- 
ALTER TABLE PFSA_PBA_RULES_REF ADD (
  CONSTRAINT CK_PFSA_PBA_MET_RULE_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSA_PBA_RULE_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSA_PBA_RULE_REF_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSA_PBA_MET_REF_COLOR
 CHECK (bi_color_id='B' OR bi_color_id='W' OR bi_color_id='R' 
        OR bi_color_id='A' OR bi_color_id='G' 
        ),
  CONSTRAINT CK_PFSA_PBA_RULE_REF_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSA_PBA_RULES_REF
 PRIMARY KEY
 (METRIC_ID, RULE_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSA_PBA_RULES_REF 
-- 
ALTER TABLE PFSA_PBA_RULES_REF ADD (
  CONSTRAINT FK_PFSA_PBA_RULES_REF_METRICID 
 FOREIGN KEY (METRIC_ID) 
 REFERENCES PFSA_PBA_METRICS_REF (METRIC_ID));

GRANT SELECT ON PFSA_PBA_RULES_REF TO S_PFSAW;

