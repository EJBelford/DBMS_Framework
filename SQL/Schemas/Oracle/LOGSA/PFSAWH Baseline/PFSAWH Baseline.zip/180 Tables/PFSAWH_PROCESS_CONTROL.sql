--
-- PFSAWH_PROCESS_CONTROL  (Table) 
--
CREATE TABLE PFSAWH_PROCESS_CONTROL
(
  PROCESS_CONTROL_ID           NUMBER           NOT NULL,
  PROCESS_CONTROL_NAME         VARCHAR2(65 BYTE) NOT NULL,
  PROCESS_CONTROL_VALUE        VARCHAR2(10 BYTE) NOT NULL,
  PROCESS_CONTROL_DESCRIPTION  VARCHAR2(100 BYTE),
  STATUS                       VARCHAR2(1 BYTE) DEFAULT 'C',
  UPDT_BY                      VARCHAR2(30 BYTE) DEFAULT user,
  LST_UPDT                     DATE             DEFAULT sysdate,
  ACTIVE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'Y',
  ACTIVE_DATE                  DATE             DEFAULT '01-JAN-1900',
  INACTIVE_DATE                DATE             DEFAULT '31-DEC-2099',
  INSERT_BY                    VARCHAR2(30 BYTE) DEFAULT user,
  INSERT_DATE                  DATE             DEFAULT sysdate,
  UPDATE_BY                    VARCHAR2(30 BYTE),
  UPDATE_DATE                  DATE             DEFAULT '01-JAN-1900',
  DELETE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                  DATE             DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  HIDDEN_DATE                  DATE             DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_PROCESS_CONTROL IS 'Master process control table for PFSAWH to eliminate hard coding in processes. ';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.PROCESS_CONTROL_ID IS 'Record sequenece. ';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.PROCESS_CONTROL_NAME IS 'Field name. ';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.PROCESS_CONTROL_VALUE IS 'The value used by other processes. ';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.PROCESS_CONTROL_DESCRIPTION IS 'Purpose/description of control field. ';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.STATUS IS 'The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.ACTIVE_DATE IS 'Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.INACTIVE_DATE IS 'Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_PROCESS_CONTROL.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- PK_PFSAWH_PROCESS_CONTROL  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_PROCESS_CONTROL ON PFSAWH_PROCESS_CONTROL
(PROCESS_CONTROL_NAME)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_BLANK_DIM  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_BLANK_DIM ON PFSAWH_PROCESS_CONTROL
(PROCESS_CONTROL_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_PROCESS_CONTROL  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_PROCESS_CONTROL FOR PFSAWH_PROCESS_CONTROL;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_CONTROL 
-- 
ALTER TABLE PFSAWH_PROCESS_CONTROL ADD (
  CONSTRAINT CK_PFSAWH_PROCESS_CNTRL_ACT_FL
 CHECK (ACTIVE_FLAG='I' OR ACTIVE_FLAG='N' OR ACTIVE_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_CNTRL_DEL_FL
 CHECK (DELETE_FLAG='N' OR DELETE_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_CNTRL_HID_FL
 CHECK (HIDDEN_FLAG='N' OR HIDDEN_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_PROCESS_CNTRL_STATUS
 CHECK (STATUS='C' OR STATUS='D' OR STATUS='E' OR STATUS='H' 
        OR STATUS='L' OR STATUS='P' OR STATUS='Q' OR STATUS='R' 
        OR STATUS='T' OR STATUS='Z' OR STATUS='N' 
        ),
  CONSTRAINT PK_PFSAWH_PROCESS_CONTROL
 PRIMARY KEY
 (PROCESS_CONTROL_NAME)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT DELETE, INSERT, SELECT, UPDATE ON PFSAWH_PROCESS_CONTROL TO C_PFSAW_DB_IN;

GRANT SELECT ON PFSAWH_PROCESS_CONTROL TO S_PFSAW;

