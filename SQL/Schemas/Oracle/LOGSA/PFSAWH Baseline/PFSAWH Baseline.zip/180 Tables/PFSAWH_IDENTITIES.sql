--
-- PFSAWH_IDENTITIES  (Table) 
--
CREATE TABLE PFSAWH_IDENTITIES
(
  REC_ID                   NUMBER               NOT NULL,
  DIMENSION_TABLENAME      VARCHAR2(30 BYTE)    NOT NULL,
  LAST_DIMENSION_IDENTITY  NUMBER               NOT NULL,
  STATUS                   VARCHAR2(1 BYTE)     DEFAULT 'C',
  UPDT_BY                  VARCHAR2(30 BYTE)    DEFAULT user,
  LST_UPDT                 DATE                 DEFAULT sysdate,
  ACTIVE_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'Y',
  ACTIVE_DATE              DATE                 DEFAULT sysdate,
  INACTIVE_DATE            DATE                 DEFAULT '31-DEC-2099',
  INSERT_BY                VARCHAR2(30 BYTE)    DEFAULT user,
  INSERT_DATE              DATE                 DEFAULT sysdate,
  UPDATE_BY                VARCHAR2(30 BYTE),
  UPDATE_DATE              DATE                 DEFAULT '01-JAN-1900',
  DELETE_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'N',
  DELETE_DATE              DATE                 DEFAULT '01-JAN-1900',
  HIDDEN_FLAG              VARCHAR2(1 BYTE)     DEFAULT 'Y',
  HIDDEN_DATE              DATE                 DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_IDENTITIES IS 'Stores the last value used as a identity for a given dimension.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.REC_ID IS 'Record identity';

COMMENT ON COLUMN PFSAWH_IDENTITIES.DIMENSION_TABLENAME IS 'Dimension table name';

COMMENT ON COLUMN PFSAWH_IDENTITIES.LAST_DIMENSION_IDENTITY IS 'The last value used for the dimension.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.STATUS IS 'The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_IDENTITIES.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.ACTIVE_DATE IS 'Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.INACTIVE_DATE IS 'Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_IDENTITIES.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- PK_PFSAWH_IDENTITIES  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_IDENTITIES ON PFSAWH_IDENTITIES
(DIMENSION_TABLENAME)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_IDENTITIES  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_IDENTITIES ON PFSAWH_IDENTITIES
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_IDENTITIES  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_IDENTITIES FOR PFSAWH_IDENTITIES;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_IDENTITIES 
-- 
ALTER TABLE PFSAWH_IDENTITIES ADD (
  CONSTRAINT CK_PFSAWH_IDENTITIES_STATUS
 CHECK (STATUS='C' OR STATUS='D' OR STATUS='E' OR STATUS='H' 
        OR STATUS='L' OR STATUS='P' OR STATUS='Q' OR STATUS='R' 
        OR STATUS='T' OR STATUS='Z' OR STATUS='N' 
        ),
  CONSTRAINT CK_PFSAWH_IDENTITIES_DEL_FL
 CHECK (DELETE_FLAG='N' OR DELETE_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_IDENTITIES_HIDE_FL
 CHECK (HIDDEN_FLAG='N' OR HIDDEN_FLAG='Y'),
  CONSTRAINT PK_PFSAWH_IDENTITIES
 PRIMARY KEY
 (DIMENSION_TABLENAME)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_IDENTITIES TO S_PFSAW;

