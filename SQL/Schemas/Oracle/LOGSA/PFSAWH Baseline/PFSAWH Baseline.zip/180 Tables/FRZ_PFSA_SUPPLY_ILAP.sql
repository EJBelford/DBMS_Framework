--
-- FRZ_PFSA_SUPPLY_ILAP  (Table) 
--
CREATE TABLE FRZ_PFSA_SUPPLY_ILAP
(
  REC_ID               NUMBER                   NOT NULL,
  DOCNO                VARCHAR2(14 BYTE),
  RIC_STOR             VARCHAR2(3 BYTE),
  IPG                  VARCHAR2(1 BYTE),
  PNIIN                VARCHAR2(11 BYTE),
  ISS_NIIN             VARCHAR2(11 BYTE),
  WH_PERIOD_DATE       DATE,
  WH_PERIOD_DATE_ID    NUMBER                   DEFAULT 0,
  DOCNO_UIC            VARCHAR2(6 BYTE),
  DOCNO_FORCE_UNIT_ID  NUMBER                   DEFAULT 0,
  NIIN                 VARCHAR2(9 BYTE),
  PNIIN_ITEM_ID        NUMBER                   DEFAULT 0,
  PHYSICAL_ITEM_NIIN   VARCHAR2(9 BYTE),
  PHYSICAL_ITEM_ID     NUMBER                   DEFAULT 0,
  PHYSICAL_ITEM_SN     VARCHAR2(48 BYTE),
  PHYSICAL_ITEM_SN_ID  NUMBER                   DEFAULT 0,
  CWT                  NUMBER,
  D_CUST_ISS           DATE,
  RCPT_DOCNO           VARCHAR2(14 BYTE),
  RCPT_DIC             VARCHAR2(3 BYTE),
  D_RCPT               DATE,
  RCPT_RIC_FR          VARCHAR2(3 BYTE),
  PSEUDO               VARCHAR2(1 BYTE),
  SOF                  VARCHAR2(7 BYTE),
  PRICE                NUMBER,
  CAT_SOS              VARCHAR2(3 BYTE),
  SC                   VARCHAR2(2 BYTE),
  SCMC                 VARCHAR2(2 BYTE),
  AMI                  VARCHAR2(1 BYTE),
  DLR                  VARCHAR2(1 BYTE),
  MSC_SPT              VARCHAR2(10 BYTE),
  INSTL                VARCHAR2(20 BYTE),
  CORPS                VARCHAR2(20 BYTE),
  MACOM                VARCHAR2(10 BYTE),
  D_UPD                DATE,
  SSFCOC_FLAG          VARCHAR2(1 BYTE),
  COMPONENT            VARCHAR2(7 BYTE),
  D_DOCNO              DATE,
  D_SARSS1             DATE,
  D_SARSS2B            DATE,
  AGE_DOC_S1           NUMBER,
  AGE_S1_S2B           NUMBER,
  FUND                 VARCHAR2(4 BYTE),
  CONUS                VARCHAR2(1 BYTE),
  QTY                  NUMBER,
  EXT_PRICE            NUMBER,
  PRJ                  VARCHAR2(3 BYTE),
  D_ISS_MONTH          DATE,
  ISS_MON              VARCHAR2(5 BYTE),
  DODAAC               VARCHAR2(6 BYTE),
  AGE_S1_ISS           NUMBER,
  SFX                  VARCHAR2(1 BYTE),
  FRZ_INPUT_DATE       DATE,
  FRZ_INPUT_DATE_ID    NUMBER,
  REC_FRZ_FLAG         VARCHAR2(1 BYTE)         DEFAULT 'N',
  FRZ_DATE             DATE                     DEFAULT '31-DEC-2099',
  STATUS               VARCHAR2(1 BYTE)         DEFAULT 'C',
  UPDT_BY              VARCHAR2(30 BYTE)        DEFAULT user,
  LST_UPDT             DATE                     DEFAULT sysdate,
  GRAB_STAMP           DATE,
  PROC_STAMP           DATE,
  ACTIVE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'Y',
  ACTIVE_DATE          DATE                     DEFAULT '01-JAN-1900',
  INACTIVE_DATE        DATE                     DEFAULT '31-DEC-2099',
  SOURCE_REC_ID        NUMBER                   DEFAULT 0,
  INSERT_BY            VARCHAR2(30 BYTE)        DEFAULT user,
  INSERT_DATE          DATE                     DEFAULT sysdate,
  LST_UPDATE_REC_ID    NUMBER                   DEFAULT 0,
  UPDATE_BY            VARCHAR2(30 BYTE),
  UPDATE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  DELETE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_BY            VARCHAR2(30 BYTE),
  HIDDEN_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  HIDDEN_DATE          DATE                     DEFAULT '01-JAN-1900',
  HIDDEN_BY            VARCHAR2(30 BYTE),
  PBA_ID               NUMBER                   DEFAULT 1000000,
  SOF_DVD_FLAG         NUMBER                   DEFAULT 0,
  SOF_DVD_BO_FLAG      NUMBER                   DEFAULT 0,
  SOF_LAT_OFF_FLAG     NUMBER                   DEFAULT 0,
  SOF_LAT_ON_FLAG      NUMBER                   DEFAULT 0,
  SOF_LP_FLAG          NUMBER                   DEFAULT 0,
  SOF_MAINT_FLAG       NUMBER                   DEFAULT 0,
  SOF_REF_OFF_FLAG     NUMBER                   DEFAULT 0,
  SOF_REF_ON_FLAG      NUMBER                   DEFAULT 0,
  SOF_SSA_FLAG         NUMBER                   DEFAULT 0,
  SOF_TI_FLAG          NUMBER                   DEFAULT 0,
  SOF_UNK_FLAG         NUMBER                   DEFAULT 0,
  SOF_WHSL_BO_FLAG     NUMBER                   DEFAULT 0,
  SOF_WHSL_GE_FLAG     NUMBER                   DEFAULT 0,
  SOF_WHSL_KO_FLAG     NUMBER                   DEFAULT 0,
  SOF_WHSL_KU_FLAG     NUMBER                   DEFAULT 0,
  SOF_WHSL_FLAG        NUMBER                   DEFAULT 0
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--
-- FRZ_PFSA_SUPPLY_ILAP  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_SUPPLY_ILAP FOR FRZ_PFSA_SUPPLY_ILAP;


GRANT SELECT ON FRZ_PFSA_SUPPLY_ILAP TO S_PFSAW;

