--
-- PFSAWH_MV_REFRESH_STATUS  (Table) 
--
CREATE TABLE PFSAWH_MV_REFRESH_STATUS
(
  MV_REFRESH_ID  NUMBER                         DEFAULT 0,
  MV_SCHEMA      VARCHAR2(30 BYTE),
  MV_NAME        VARCHAR2(30 BYTE),
  MV_TYPE        VARCHAR2(20 BYTE),
  MV_DESC        VARCHAR2(100 BYTE),
  MV_STATUS      VARCHAR2(1 BYTE)               DEFAULT 'X',
  MV_LST_RUN     DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  SRC_NAME       VARCHAR2(100 BYTE),
  SRC_LST_UPDT   DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  STATUS         VARCHAR2(1 BYTE)               DEFAULT 'C',
  LST_UPDT       DATE                           DEFAULT sysdate,
  UPDT_BY        VARCHAR2(30 BYTE)              DEFAULT SUBSTR( USER, 1, 30 ),
  ACTIVE_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'Y',
  ACTIVE_DATE    DATE                           DEFAULT sysdate,
  INACTIVE_DATE  DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  INSERT_BY      VARCHAR2(30 BYTE)              DEFAULT SUBSTR( USER, 1, 30 ),
  INSERT_DATE    DATE                           DEFAULT sysdate,
  UPDATE_BY      VARCHAR2(30 BYTE),
  UPDATE_DATE    DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  DELETE_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'N',
  DELETE_DATE    DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  DELETE_BY      VARCHAR2(30 BYTE),
  HIDDEN_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'N',
  HIDDEN_DATE    DATE                           DEFAULT TO_DATE( '01/01/1900', 'MM/DD/YYYY' ),
  HIDDEN_BY      VARCHAR2(30 BYTE)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN PFSAWH_MV_REFRESH_STATUS.MV_STATUS IS 'E - ETL Materialized View in SOURCE_DATA schema
R - Ready to refresh
S - Successfully refreshed 
U - Unsusccessfully refreshed
X - Never refreshed by REFRESH_PFSAWH_MV_FILES procedure';


--
-- IDX_REFRESH_MV_SRC_NAME  (Index) 
--
CREATE UNIQUE INDEX IDX_REFRESH_MV_SRC_NAME ON PFSAWH_MV_REFRESH_STATUS
(MV_NAME, SRC_NAME)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_MV_REFRESH_STATUS  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_MV_REFRESH_STATUS FOR PFSAWH_MV_REFRESH_STATUS;


GRANT SELECT ON PFSAWH_MV_REFRESH_STATUS TO S_PFSAW;

