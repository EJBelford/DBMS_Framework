--
-- PFSAWH_MAINT_ITM_PRT_FACT  (Table) 
--
CREATE TABLE PFSAWH_MAINT_ITM_PRT_FACT
(
  REC_ID                  NUMBER                NOT NULL,
  TSK_END_DATE_ID         NUMBER,
  TSK_END_TIME_ID         NUMBER,
  PHYSICAL_ITEM_ID        NUMBER                NOT NULL,
  PHYSICAL_ITEM_SN_ID     NUMBER                NOT NULL,
  ITEM_COMP_ID            NUMBER                DEFAULT '-1',
  ITEM_PART_ID            NUMBER                DEFAULT '-1',
  ITEM_COMP_SN            NUMBER                DEFAULT '-1',
  PART_NUM                VARCHAR2(32 BYTE),
  PART_SN                 VARCHAR2(32 BYTE),
  PART_NUM_USED           NUMBER,
  PART_CNTLD_EXCHNG_FLAG  VARCHAR2(1 BYTE),
  PART_REMOVED_FLAG       VARCHAR2(1 BYTE),
  PART_CAGE_CD            VARCHAR2(5 BYTE),
  TSK_ELAPSED_PART_WT_TM  NUMBER,
  TSK_WAS_DEF_FLAG        VARCHAR2(1 BYTE),
  TSK_SCHED_FLAG          VARCHAR2(1 BYTE),
  STATUS                  VARCHAR2(1 BYTE)      DEFAULT 'N',
  UPDT_BY                 VARCHAR2(30 BYTE)     DEFAULT USER,
  LST_UPDT                DATE                  DEFAULT SYSDATE,
  ACTIVE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'I',
  ACTIVE_DATE             DATE                  DEFAULT '01-JAN-1900',
  INACTIVE_DATE           DATE                  DEFAULT '31-DEC-2099',
  INSERT_BY               VARCHAR2(30 BYTE)     DEFAULT USER,
  INSERT_DATE             DATE                  DEFAULT SYSDATE,
  UPDATE_BY               VARCHAR2(30 BYTE),
  UPDATE_DATE             DATE                  DEFAULT '01-JAN-1900',
  DELETE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'N',
  DELETE_DATE             DATE                  DEFAULT '01-JAN-1900',
  HIDDEN_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'Y',
  HIDDEN_DATE             DATE                  DEFAULT '01-JAN-1900',
  ETL_PROCESSED_BY        VARCHAR2(50 BYTE)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_MAINT_ITM_PRT_FACT IS 'PFSAWH_MAINT_ITM_PRT_FACT - This table serves as the daily/transactional fact for a particular item/serial number combination.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_CNTLD_EXCHNG_FLAG IS 'PART_CNTLD_EXCHNG_FLAG - CNTLD_EXCHNG - A flag indicating is controlled exchange item. Values are F\T\U';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_REMOVED_FLAG IS 'PART_REMOVED_FLAG - REMOVED - A flag indicating that the item was removed. Values are F\T\U';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_CAGE_CD IS 'PART_CAGE_CD - COMMERCIAL AND GOVERNMENT ENTITY (CAGE) CODE - The Commercial and Government Entity (CAGE) Code is a five-character code assigned by the Defense Logistics Information Service (DLIS) to the design control activity or actual manufacturer of an item.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.TSK_ELAPSED_PART_WT_TM IS 'TSK_ELAPSED_PART_WT_TM - ELAPSED_PART_WT_TM - The elapsed task wait time.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.TSK_WAS_DEF_FLAG IS 'TSK_WAS_DEF_FLAG - Flag indicating if this task was the result of a defect.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.TSK_SCHED_FLAG IS 'TSK_SCHED_FLAG - SCHED_UNSCHED - Flag indicating if this task was a scheduled or un-scheduled. Values are ?\S\U';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.REC_ID IS 'REC_ID - Sequence/identity for dimension/fact table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.TSK_END_DATE_ID IS 'TSK_END_DATE_ID - Foreign key of the PFSAWH_DATE_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.TSK_END_TIME_ID IS 'TSK_END_TIME_ID - Foreign key of the PFSAWH_TIME_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key to the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key to the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ITEM_COMP_ID IS 'ITEM_COMP_ID - Foreign key to the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ITEM_PART_ID IS 'ITEM_PART_ID - Foreign key to the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.ITEM_COMP_SN IS 'ITEM_COMP_SN - ';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_NUM IS 'PART_NUM - PART NUMBER - This field may contain a 13-digit FSC/NIIN, ACVC, Manufacturers Control Number, or a part number of variable length.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_SN IS 'PART_SN - The serial number of the repair part INSTALLED???? during the maintenance event.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_PRT_FACT.PART_NUM_USED IS 'PART_NUM_USED - NUM_ITEMS - The number items with this NIIN used as part of the maintenance event and task.';


--
-- IDX_PFSAWH_MAINT_ITM_PRT_FACT  (Index) 
--
CREATE INDEX IDX_PFSAWH_MAINT_ITM_PRT_FACT ON PFSAWH_MAINT_ITM_PRT_FACT
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID, TSK_END_DATE_ID, TSK_END_TIME_ID, ITEM_COMP_ID, 
ITEM_PART_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_ITM_PRT_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ITM_PRT_FACT ON PFSAWH_MAINT_ITM_PRT_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_MAINT_ITM_PRT_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_MAINT_ITM_PRT_FACT FOR PFSAWH_MAINT_ITM_PRT_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_MAINT_ITM_PRT_FACT 
-- 
ALTER TABLE PFSAWH_MAINT_ITM_PRT_FACT ADD (
  CONSTRAINT CK_MAINT_ITM_PRT_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_ITM_PRT_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSAWH_MAINT_ITM_PRT_FACT 
-- 
ALTER TABLE PFSAWH_MAINT_ITM_PRT_FACT ADD (
  CONSTRAINT FK_PFSAWH_MNT_ITM_PRT_ID_ITMSN 
 FOREIGN KEY (PHYSICAL_ITEM_SN_ID) 
 REFERENCES PFSAWH_ITEM_SN_DIM (PHYSICAL_ITEM_SN_ID) DISABLE);

GRANT SELECT ON PFSAWH_MAINT_ITM_PRT_FACT TO S_PFSAW;

