--
-- PFSAWH_PROCESS_LOG  (Table) 
--
CREATE TABLE PFSAWH_PROCESS_LOG
(
  PROCESS_KEY          NUMBER                   NOT NULL,
  PROCESS_RECID        NUMBER                   NOT NULL,
  MODULE_NUM           NUMBER                   DEFAULT 0,
  STEP_NUM             NUMBER                   DEFAULT 0,
  PROCESS_START_DATE   DATE,
  PROCESS_END_DATE     DATE,
  PROCESS_STATUS_CODE  INTEGER,
  SQL_ERROR_CODE       NUMBER,
  REC_READ_INT         NUMBER,
  REC_VALID_INT        NUMBER,
  REC_LOAD_INT         NUMBER,
  REC_INSERTED_INT     NUMBER,
  REC_SELECTED_INT     NUMBER,
  REC_UPDATED_INT      NUMBER,
  REC_DELETED_INT      NUMBER,
  USER_LOGIN_ID        VARCHAR2(30 BYTE),
  MESSAGE              VARCHAR2(255 BYTE),
  REC_MERGED_INT       NUMBER,
  PROCESS_BATCH_ID     NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_PROCESS_LOG IS 'Process log tracking stored procedure performance in the the CMIS database.  Data is inserted by stored procedure dbo.spr_InsUpd_RptToCourt_ProcessLog.';

COMMENT ON COLUMN PFSAWH_PROCESS_LOG.PROCESS_KEY IS 'Identity and Primary key for facRptToCourtProcessLog records.';

COMMENT ON COLUMN PFSAWH_PROCESS_LOG.PROCESS_RECID IS 'Primary key for facRptToCourtProcessLog records.';

COMMENT ON COLUMN PFSAWH_PROCESS_LOG.MODULE_NUM IS 'Identities module within a give mutli-step process.';

COMMENT ON COLUMN PFSAWH_PROCESS_LOG.STEP_NUM IS 'Identities steps within a give mutli-step process.';


--
-- PK_PFSAWH_PROCESS_LOG  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_PROCESS_LOG ON PFSAWH_PROCESS_LOG
(PROCESS_KEY)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_PROCESS_LOG  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_PROCESS_LOG ON PFSAWH_PROCESS_LOG
(PROCESS_KEY, PROCESS_RECID, MODULE_NUM, STEP_NUM)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_PROCESS_RECID  (Index) 
--
CREATE INDEX IXU_PFSAWH_PROCESS_RECID ON PFSAWH_PROCESS_LOG
(PROCESS_RECID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_PROCESS_LOG  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_PROCESS_LOG FOR PFSAWH_PROCESS_LOG;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_PROCESS_LOG 
-- 
ALTER TABLE PFSAWH_PROCESS_LOG ADD (
  CONSTRAINT CK_PFSA_PROCESS_STATUS_CODE
 CHECK (process_status_code=-1 OR process_status_code=0 OR process_status_code=1),
  CONSTRAINT PK_PFSAWH_PROCESS_LOG
 PRIMARY KEY
 (PROCESS_KEY)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSAWH_PROCESS_LOG 
-- 
ALTER TABLE PFSAWH_PROCESS_LOG ADD (
  CONSTRAINT FK_PFSAWH_PROCESS_RECID 
 FOREIGN KEY (PROCESS_RECID) 
 REFERENCES PFSAWH_PROCESS_REF (PROCESS_KEY));

GRANT SELECT ON PFSAWH_PROCESS_LOG TO S_PFSAW;

