--
-- FRZ_PFSA_MAINT_ITEMS_TMP  (Table) 
--
CREATE TABLE FRZ_PFSA_MAINT_ITEMS_TMP
(
  REC_ID               NUMBER                   NOT NULL,
  SOURCE_REC_ID        NUMBER                   DEFAULT 0,
  PBA_ID               NUMBER                   NOT NULL,
  PHYSICAL_ITEM_ID     NUMBER                   DEFAULT 0,
  PHYSICAL_ITEM_SN_ID  NUMBER                   DEFAULT 0,
  FORCE_UNIT_ID        NUMBER                   DEFAULT 0,
  MIMOSA_ITEM_SN_ID    VARCHAR2(8 BYTE)         DEFAULT '00000000',
  MAINT_EV_ID          VARCHAR2(40 BYTE)        NOT NULL,
  MAINT_TASK_ID        VARCHAR2(50 BYTE)        NOT NULL,
  MAINT_ITEM_ID        VARCHAR2(37 BYTE)        NOT NULL,
  CAGE_CD              VARCHAR2(5 BYTE),
  PART_NUM             VARCHAR2(32 BYTE),
  NIIN                 VARCHAR2(9 BYTE),
  PART_SN              VARCHAR2(32 BYTE),
  NUM_ITEMS            NUMBER,
  CNTLD_EXCHNG         VARCHAR2(1 BYTE),
  REMOVED              VARCHAR2(1 BYTE),
  FAILURE              VARCHAR2(1 BYTE),
  HEIR_ID              VARCHAR2(20 BYTE),
  PRIORITY             NUMBER,
  DOC_NO               VARCHAR2(14 BYTE),
  DOC_NO_EXPAND        VARCHAR2(18 BYTE),
  PART_UID             VARCHAR2(78 BYTE),
  STATUS               VARCHAR2(1 BYTE),
  LST_UPDT             DATE,
  UPDT_BY              VARCHAR2(30 BYTE),
  FRZ_INPUT_DATE       DATE,
  FRZ_INPUT_DATE_ID    NUMBER,
  REC_FRZ_FLAG         VARCHAR2(1 BYTE)         DEFAULT 'N',
  FRZ_DATE             DATE                     DEFAULT '31-DEC-2099',
  INSERT_BY            VARCHAR2(30 BYTE)        DEFAULT USER,
  INSERT_DATE          DATE                     DEFAULT SYSDATE,
  UPDATE_BY            VARCHAR2(30 BYTE),
  UPDATE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  DELETE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_BY            VARCHAR2(30 BYTE),
  HIDDEN_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  HIDDEN_DATE          DATE                     DEFAULT '01-JAN-1900',
  HIDDEN_BY            VARCHAR2(30 BYTE)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE FRZ_PFSA_MAINT_ITEMS_TMP IS 'FRZ_PFSA_MAINT_ITEMS_TMP - This table documents all items used/consumed during a maintenance event';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.MAINT_TASK_ID IS 'MAINT_TASK_ID - The identifier that when combined with the MAINT_EV_ID creates a unique maintenance task id.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.MAINT_ITEM_ID IS 'MAINT_ITEM_ID - The identifier that when combined with the MAINT_EV_ID and MAINT_TASK_ID creates a unique maintenance task part id.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.CAGE_CD IS 'COMMERCIAL AND GOVERNMENT ENTITY (CAGE) CODE - The Commercial and Government Entity (CAGE) Code is a five-character code assigned by the Defense Logistics Information Service (DLIS) to the design control activity or actual manufacturer of an item.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PART_NUM IS 'PART_NUM - PART NUMBER - This field may contain a 13-digit FSC/NIIN, ACVC, Manufacturers Control Number, or a part number of variable length.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.NIIN IS 'NIIN - The NIIN of the repair part installed/consumable used during the maintenance event.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PART_SN IS 'PART_SN - The serial number of the repair part installed during the maintenance event.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.NUM_ITEMS IS 'NUM_ITEMS - The number items with this NIIN used as part of the maintenance event and task.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.CNTLD_EXCHNG IS 'CNTLD_EXCHNG - A flag indicating is controlled exchange item. Values are F\T\U';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.REMOVED IS 'REMOVED - A flag indicating that the item was removed. Values are F\T\U';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.FAILURE IS 'FAILURE - A flag indicating that the item failed. Values are F\T\U';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.HEIR_ID IS 'HEIR_ID - A PFSA generated identification used to ensure heirarchical data source integrity is maintained.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PRIORITY IS 'PRIORITY - The relative prioirty of the data source.  Care should be taken to leave gaps in numbers to ensure additions can be made later.  The lower the number, the higher the priority.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.FRZ_INPUT_DATE IS 'FRZ_INPUT_DATE - ';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.FRZ_INPUT_DATE_ID IS 'FRZ_INPUT_DATE_ID - ';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.REC_FRZ_FLAG IS 'REC_FRZ_FLAG - Flag indicating if the record is frozen or not.  Values: N - Not frozen, Y - Frozen';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.FRZ_DATE IS 'FRZ_DATE - Additional control for REC_FRZ_FLAG indicating when the record was frozen.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.DELETE_BY IS 'DELETE_BY - Reports who deleted the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.HIDDEN_BY IS 'HIDDEN_BY - Reports who last hide the record.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_item_sn_p_fact table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.SOURCE_REC_ID IS 'SOURCE_REC_ID - Identifier to the orginial record received from the outside source.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key of the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key of the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.FORCE_UNIT_ID IS 'FORCE_UNIT_ID - Foreign key of the PFSAWH_FORCE_UNIT_DIM table.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN FRZ_PFSA_MAINT_ITEMS_TMP.MAINT_EV_ID IS 'MAINT_EV_ID - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number';


--
-- FRZ_PFSA_MAINT_ITEMS_TMP  (Synonym) 
--
CREATE PUBLIC SYNONYM FRZ_PFSA_MAINT_ITEMS_TMP FOR FRZ_PFSA_MAINT_ITEMS_TMP;


GRANT SELECT ON FRZ_PFSA_MAINT_ITEMS_TMP TO S_PFSAW;

