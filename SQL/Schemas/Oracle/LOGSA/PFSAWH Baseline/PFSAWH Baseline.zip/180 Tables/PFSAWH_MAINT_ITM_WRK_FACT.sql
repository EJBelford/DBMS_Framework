--
-- PFSAWH_MAINT_ITM_WRK_FACT  (Table) 
--
CREATE TABLE PFSAWH_MAINT_ITM_WRK_FACT
(
  REC_ID                       NUMBER           NOT NULL,
  TSK_BEGIN_DATE_ID            NUMBER,
  TSK_BEGIN_TIME_ID            NUMBER,
  TSK_END_DATE_ID              NUMBER,
  TSK_END_TIME_ID              NUMBER,
  PHYSICAL_ITEM_ID             NUMBER           NOT NULL,
  PHYSICAL_ITEM_SN_ID          NUMBER           NOT NULL,
  MIMOSA_ITEM_SN_ID            VARCHAR2(8 BYTE) DEFAULT '00000000',
  FORCE_UNIT_ID                NUMBER           DEFAULT 0,
  PBA_ID                       NUMBER           DEFAULT 1000000,
  WRK_TSK_CNT                  NUMBER           DEFAULT 0,
  TSK_DAYS_TO_CMPLT            NUMBER           DEFAULT 0,
  TSK_HRS_TO_CMPLT             NUMBER           DEFAULT 0,
  MAINT_EV_ID_A                VARCHAR2(40 BYTE) NOT NULL,
  MAINT_EV_ID_B                VARCHAR2(40 BYTE) NOT NULL,
  MAINT_TASK_ID                VARCHAR2(50 BYTE) NOT NULL,
  MAINT_WORK_ID                VARCHAR2(12 BYTE) NOT NULL,
  MAINT_ORG                    VARCHAR2(32 BYTE),
  MAINT_UIC                    VARCHAR2(6 BYTE),
  MAINT_LVL_CD                 VARCHAR2(1 BYTE),
  ELAPSED_TSK_WK_TM            NUMBER,
  INSPECT_TSK                  VARCHAR2(1 BYTE),
  ESSENTIAL_TSK                VARCHAR2(1 BYTE),
  MAINT_WORK_MH                NUMBER,
  WRK_MIL_CIV_KON              VARCHAR2(1 BYTE),
  WRK_MOS                      VARCHAR2(10 BYTE),
  WRK_SPEC_PERSON              VARCHAR2(20 BYTE),
  WRK_REPAIR                   VARCHAR2(1 BYTE),
  WRK_MOS_SENT                 VARCHAR2(10 BYTE),
  STATUS                       VARCHAR2(1 BYTE) DEFAULT 'N',
  UPDT_BY                      VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                     DATE             DEFAULT SYSDATE,
  ACTIVE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'I',
  ACTIVE_DATE                  DATE             DEFAULT '01-JAN-1900',
  INACTIVE_DATE                DATE             DEFAULT '31-DEC-2099',
  INSERT_BY                    VARCHAR2(20 BYTE) DEFAULT USER,
  INSERT_DATE                  DATE             DEFAULT SYSDATE,
  UPDATE_BY                    VARCHAR2(20 BYTE),
  UPDATE_DATE                  DATE             DEFAULT '01-JAN-1900',
  DELETE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                  DATE             DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'Y',
  HIDDEN_DATE                  DATE             DEFAULT '01-JAN-1900',
  CUST_ORG                     VARCHAR2(32 BYTE),
  CUST_UIC                     VARCHAR2(6 BYTE),
  EVNT_BEGIN_DATE_ID           NUMBER,
  EVNT_CMPL_DATE_ID            NUMBER,
  FAULT_MALFUNCTION_DESCR      VARCHAR2(80 BYTE),
  WON                          VARCHAR2(12 BYTE),
  ETL_PROCESSED_BY             VARCHAR2(50 BYTE),
  DATE_CMPLT_READINESS_PRD_ID  NUMBER,
  FORCE_PARENT_UNIT_ID         NUMBER,
  FORCE_COMMAND_UNIT_ID        NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_MAINT_ITM_WRK_FACT IS 'PFSAWH_MAINT_ITM_WRK_FACT - ';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_SPEC_PERSON IS 'WRK_SPEC_PERSON - SPEC_PERSON - Specific person who performed the work.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_REPAIR IS 'WRK_REPAIR - Item was repaired.  Values should be Y - Yes, N - No, ? - Unknown';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_MOS_SENT IS 'WRK_MOS_SENT - The value of provided in the source data for the MOS.  This value is used to derive the MOS used.  The derived values generally remove the skill level code, and standardize terms used for Contractor and Civilian personnel.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.CUST_ORG IS 'cust_org';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.CUST_UIC IS 'cust_uic';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.EVNT_BEGIN_DATE_ID IS 'evnt_begin_date_id';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.EVNT_CMPL_DATE_ID IS 'evnt_cmpl_date_id';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.FAULT_MALFUNCTION_DESCR IS 'fault_malfunction_descr';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WON IS 'won';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.REC_ID IS 'REC_ID - Sequence/identity for dimension/fact table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_BEGIN_DATE_ID IS 'TSK_BEGIN_DATE_ID - Foreign key to the PFSAWH_DATE_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_BEGIN_TIME_ID IS 'TSK_BEGIN_TIME_ID - Foreign key of the PFSAWH_TIME_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_END_DATE_ID IS 'TSK_END_DATE_ID - Foreign key to the PFSAWH_DATE_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_END_TIME_ID IS 'TSK_END_TIME_ID - Foreign key of the PFSAWH_TIME_DIM records.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - Foreign key to the PFSAWH_ITEM_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - Foreign key to the PFSAWH_ITEM_SN_DIM table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.FORCE_UNIT_ID IS 'FORCE_UNIT_ID - Primary, blind key of the pfsawh_force_unit_dim table.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_TSK_CNT IS 'WRK_TSK_CNT - ????? Number of tasks completed as part of this work item.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_DAYS_TO_CMPLT IS 'TSK_DAYS_TO_CMPLT - The total number of days elapsed time during the maintenance event when work was being performed.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.TSK_HRS_TO_CMPLT IS 'TSK_HRS_TO_CMPLT - The total number of hours elapsed time during the maintenance event when work was being performed.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_EV_ID_A IS 'MAINT_EV_ID_A - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_EV_ID_B IS 'MAINT_EV_ID_B - A PFSA generated key used to accomodate the multiple sources of maintenance data used in the metrics.  The structure used to build the key is dependent on the source.  LIDB maintenance data is a concatenation of the won and accept_dt.  AMAC source data is a concatenation of mwo and ac_serial_number.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_TASK_ID IS 'MAINT_TASK_ID - The identifier that when combined with the MAINT_EV_ID creates a unique maintenance task id.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_WORK_ID IS 'MAINT_WORK_ID - The identifier that when combined with the MAINT_EV_ID and MAINT_TASK_ID creates a unique maintenance task work id.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_ORG IS 'MAINT_ORG - The organization accomplishing the maintenance event.  If a UIC, the value will match the maint_uic.  Field used to identify manufacturer/non-UIC identified contractor maintenance.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_UIC IS 'MAINT_UIC - The UIC provided by the STAMIS system for the Maintenance Event.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_LVL_CD IS 'MAINT_LVL_CD - The maint lvl of the org.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.ELAPSED_TSK_WK_TM IS 'ELAPSED_TSK_WK_TM - The total elapsed time during the maintenance event when work was being performed, when available from the data source.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.INSPECT_TSK IS 'INSPECT_TSK - Flag indicating if this was an inspection task. Values are F\T\U';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.ESSENTIAL_TSK IS 'ESSENTIAL_TSK - A flag for records that are essential. Values are ?\F\T\U\Y';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.MAINT_WORK_MH IS 'MAINT_WORK_MH - The number of hours the maintenance work took to complete.';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_MIL_CIV_KON IS 'WRK_MIL_CIV_KON - The code for the type of person doing the maintenance, Civilian, Kontractor, Military or Unknown.  Values are C\K\M\U';

COMMENT ON COLUMN PFSAWH_MAINT_ITM_WRK_FACT.WRK_MOS IS 'WRK_MOS - OCCUPATIONAL SPECIALTY CODE - The code that represents the Military Occupational Specialty (MOS) of the person performing the maintenance action.';


--
-- PK_PFSAWH_MAINT_ITM_WRK_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_MAINT_ITM_WRK_FACT ON PFSAWH_MAINT_ITM_WRK_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_MAINT_ITM_WRK_EVENT  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_MAINT_ITM_WRK_EVENT ON PFSAWH_MAINT_ITM_WRK_FACT
(MAINT_EV_ID_A, MAINT_EV_ID_B, MAINT_TASK_ID, MAINT_WORK_ID, PBA_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_MAINT_ITM_WRK_FAC  (Index) 
--
CREATE INDEX IDX_PFSAWH_MAINT_ITM_WRK_FAC ON PFSAWH_MAINT_ITM_WRK_FACT
(TSK_BEGIN_DATE_ID, TSK_BEGIN_TIME_ID, TSK_END_DATE_ID, TSK_END_TIME_ID, PHYSICAL_ITEM_ID, 
PHYSICAL_ITEM_SN_ID, MAINT_EV_ID_A, MAINT_EV_ID_B, MAINT_TASK_ID, MAINT_WORK_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_MAINT_ITEM_SN_FAC  (Index) 
--
CREATE INDEX IDX_PFSAWH_MAINT_ITEM_SN_FAC ON PFSAWH_MAINT_ITM_WRK_FACT
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_MAINT_ITM_WRK_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_MAINT_ITM_WRK_FACT FOR PFSAWH_MAINT_ITM_WRK_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_MAINT_ITM_WRK_FACT 
-- 
ALTER TABLE PFSAWH_MAINT_ITM_WRK_FACT ADD (
  CONSTRAINT CK_PFSAWH_MNTITMWRK_FCT_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_MNTITMWRK_FCT_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_MNTITMWRK_FCT_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSAWH_MNTITMWRK_FCT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_MAINT_ITM_WRK_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ),
  CONSTRAINT IXU_PFSAWH_MAINT_ITM_WRK_EVENT
 UNIQUE (MAINT_EV_ID_A, MAINT_EV_ID_B, MAINT_TASK_ID, MAINT_WORK_ID, PBA_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSAWH_MAINT_ITM_WRK_FACT 
-- 
ALTER TABLE PFSAWH_MAINT_ITM_WRK_FACT ADD (
  CONSTRAINT FK_PFSAWH_MNT_ITM_WRK_ID_ITMSN 
 FOREIGN KEY (PHYSICAL_ITEM_SN_ID) 
 REFERENCES PFSAWH_ITEM_SN_DIM (PHYSICAL_ITEM_SN_ID) DISABLE);

GRANT SELECT ON PFSAWH_MAINT_ITM_WRK_FACT TO S_PFSAW;

