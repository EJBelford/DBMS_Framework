--
-- PFSA_USAGE_EVENT  (Table) 
--
CREATE TABLE PFSA_USAGE_EVENT
(
  SYS_EI_NIIN           VARCHAR2(9 BYTE)        NOT NULL,
  PFSA_ITEM_ID          VARCHAR2(20 BYTE)       NOT NULL,
  RECORD_TYPE           VARCHAR2(1 BYTE)        NOT NULL,
  USAGE_MB              VARCHAR2(2 BYTE)        NOT NULL,
  FROM_DT               DATE                    NOT NULL,
  USAGE                 NUMBER,
  TYPE_USAGE            VARCHAR2(12 BYTE),
  TO_DT                 DATE,
  USAGE_DATE            DATE,
  READY_DATE            DATE,
  DAY_DATE              DATE,
  MONTH_DATE            DATE,
  PFSA_ORG              VARCHAR2(32 BYTE),
  UIC                   VARCHAR2(6 BYTE),
  SYS_EI_SN             VARCHAR2(32 BYTE),
  ITEM_DAYS             NUMBER,
  DATA_SRC              VARCHAR2(20 BYTE),
  GENIND                NUMBER,
  LST_UPDT              DATE,
  UPDT_BY               VARCHAR2(30 BYTE),
  STATUS                VARCHAR2(1 BYTE),
  READING               NUMBER,
  REPORTED_USAGE        NUMBER,
  ACTUAL_MB             VARCHAR2(2 BYTE),
  ACTUAL_READING        NUMBER,
  ACTUAL_USAGE          NUMBER,
  ACTUAL_DATA_REC_FLAG  VARCHAR2(1 BYTE)        DEFAULT '?',
  PHYSICAL_ITEM_ID      NUMBER,
  PHYSICAL_ITEM_SN_ID   NUMBER,
  FRZ_INPUT_DATE        DATE,
  FRZ_INPUT_DATE_ID     NUMBER,
  ACTIVE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'Y',
  ACTIVE_DATE           DATE                    DEFAULT sysdate,
  INACTIVE_DATE         DATE                    DEFAULT '1-JAN-1990',
  INSERT_BY             VARCHAR2(30 BYTE)       DEFAULT user,
  INSERT_DATE           DATE                    DEFAULT sysdate,
  UPDATE_BY             VARCHAR2(30 BYTE),
  UPDATE_DATE           DATE                    DEFAULT to_date('01-01-1900', 'MM-DD-YYYY'),
  DELETE_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  DELETE_DATE           DATE                    DEFAULT to_date('01-01-1900', 'MM-DD-YYYY'),
  HIDDEN_FLAG           VARCHAR2(1 BYTE)        DEFAULT 'N',
  HIDDEN_DATE           DATE                    DEFAULT to_date('01-01-1900', 'MM-DD-YYYY'),
  DELETE_BY             VARCHAR2(30 BYTE),
  HIDDEN_BY             VARCHAR2(30 BYTE),
  FORCE_UNIT_ID         INTEGER,
  PBA_ID                INTEGER                 DEFAULT 1000000,
  FROM_DT_ID            INTEGER,
  TO_DT_ID              INTEGER,
  MIMOSA_ITEM_SN_ID     VARCHAR2(8 BYTE)        DEFAULT 00000000,
  FROM_DT_TM_ID         INTEGER,
  TO_DT_TM_ID           INTEGER,
  CRC_VALUE             INTEGER,
  MONTH_SEG_DATE_ID     NUMBER,
  FACT_LOAD_DATE        DATE
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          3M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSA_USAGE_EVENT IS 'PFSA_USAGE_EVENT - This is a temp table for development only to load production into development. ';


--
-- IDX_PFSA_USAGE_EVENT_INSERT_DT  (Index) 
--
CREATE INDEX IDX_PFSA_USAGE_EVENT_INSERT_DT ON PFSA_USAGE_EVENT
(INSERT_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSA_USAGE_EVENT_LST_UPDT  (Index) 
--
CREATE INDEX IDX_PFSA_USAGE_EVENT_LST_UPDT ON PFSA_USAGE_EVENT
(LST_UPDT)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSA_USAGE_EVENT_UPDATE_DT  (Index) 
--
CREATE INDEX IDX_PFSA_USAGE_EVENT_UPDATE_DT ON PFSA_USAGE_EVENT
(UPDATE_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSA_USAGE_EVENT_ITM  (Index) 
--
CREATE INDEX IDX_PFSA_USAGE_EVENT_ITM ON PFSA_USAGE_EVENT
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSA_USAGE_EVENT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSA_USAGE_EVENT ON PFSA_USAGE_EVENT
(SYS_EI_NIIN, PFSA_ITEM_ID, RECORD_TYPE, USAGE_MB, FROM_DT)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSA_USAGE_EVENT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_USAGE_EVENT FOR PFSA_USAGE_EVENT;


-- 
-- Non Foreign Key Constraints for Table PFSA_USAGE_EVENT 
-- 
ALTER TABLE PFSA_USAGE_EVENT ADD (
  CONSTRAINT PK_PFSA_USAGE_EVENT
 PRIMARY KEY
 (SYS_EI_NIIN, PFSA_ITEM_ID, RECORD_TYPE, USAGE_MB, FROM_DT)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSA_USAGE_EVENT TO S_PFSAW;

