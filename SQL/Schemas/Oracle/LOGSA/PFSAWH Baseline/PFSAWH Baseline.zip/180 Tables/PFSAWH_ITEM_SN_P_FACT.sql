--
-- PFSAWH_ITEM_SN_P_FACT  (Table) 
--
CREATE TABLE PFSAWH_ITEM_SN_P_FACT
(
  REC_ID                          NUMBER        NOT NULL,
  PERIOD_TYPE                     VARCHAR2(2 BYTE) DEFAULT 'MN',
  DATE_ID                         NUMBER        NOT NULL,
  PHYSICAL_ITEM_ID                NUMBER        NOT NULL,
  PHYSICAL_ITEM_SN_ID             NUMBER        NOT NULL,
  MIMOSA_ITEM_SN_ID               VARCHAR2(8 BYTE) DEFAULT '00000000',
  PBA_ID                          NUMBER        DEFAULT 1000000,
  ITEM_DATE_FROM_ID               NUMBER        NOT NULL,
  ITEM_TIME_FROM_ID               NUMBER        DEFAULT 10001,
  ITEM_DATE_TO_ID                 NUMBER        NOT NULL,
  ITEM_TIME_TO_ID                 NUMBER        DEFAULT 86401,
  ITEM_FORCE_ID                   NUMBER        DEFAULT 0,
  ITEM_LOCATION_ID                NUMBER        DEFAULT 0,
  ITEM_USAGE_0                    NUMBER,
  ITEM_USAGE_TYPE_0               VARCHAR2(12 BYTE),
  ITEM_DAYS                       NUMBER,
  PERIOD_HRS                      NUMBER,
  MC_HRS                          NUMBER,
  FMC_HRS                         NUMBER,
  PMC_HRS                         NUMBER,
  PMCM_HRS                        NUMBER,
  PMCM_USER_HRS                   NUMBER,
  PMCM_INT_HRS                    NUMBER,
  PMCS_HRS                        NUMBER,
  PMCS_USER_HRS                   NUMBER,
  PMCS_INT_HRS                    NUMBER,
  NMC_HRS                         NUMBER,
  NMCM_HRS                        NUMBER,
  NMCM_USER_HRS                   NUMBER,
  NMCM_INT_HRS                    NUMBER,
  NMCS_HRS                        NUMBER,
  NMCS_USER_HRS                   NUMBER,
  NMCS_INT_HRS                    NUMBER,
  DEP_HRS                         NUMBER,
  NMCM_DEP_HRS                    NUMBER,
  NMCS_DEP_HRS                    NUMBER,
  OPERATIONAL_READINESS_RATE      NUMBER,
  MAINT_ACTION_CNT                NUMBER,
  MEANTIME_BTWN_MAINT_ACT         NUMBER,
  MEANDOWN_ITEM                   NUMBER,
  CUSTOMER_WAIT_TIME              NUMBER,
  OPERATING_COST_PER_HOUR         NUMBER,
  COST_PARTS                      NUMBER,
  COST_MANPOWER                   NUMBER,
  DEFERRED_MAINT_ITEMS            NUMBER,
  OPERAT_HRS_SINCE_LAST_OVERHAUL  NUMBER,
  MAINT_HRS_SINCE_LAST_OVERHAUL   NUMBER,
  TIME_SINCE_LAST_OVERHAUL        NUMBER,
  STATUS                          VARCHAR2(1 BYTE) DEFAULT 'C',
  UPDT_BY                         VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                        DATE          DEFAULT SYSDATE,
  ACTIVE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'Y',
  ACTIVE_DATE                     DATE          DEFAULT '01-JAN-1900',
  INACTIVE_DATE                   DATE          DEFAULT '31-DEC-2099',
  INSERT_BY                       VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                     DATE          DEFAULT SYSDATE,
  UPDATE_BY                       VARCHAR2(30 BYTE),
  UPDATE_DATE                     DATE          DEFAULT '01-JAN-1900',
  DELETE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                     DATE          DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'N',
  HIDDEN_DATE                     DATE          DEFAULT '01-JAN-1900',
  NOTES                           VARCHAR2(255 BYTE) DEFAULT '',
  ITEM_USAGE_1                    NUMBER,
  ITEM_USAGE_TYPE_1               VARCHAR2(12 BYTE),
  ITEM_USAGE_2                    NUMBER,
  ITEM_USAGE_TYPE_2               VARCHAR2(12 BYTE),
  ETL_PROCESSED_BY                VARCHAR2(50 BYTE),
  READINESS_REPORTED_QTY          NUMBER,
  TOTAL_DOWN_TIME                 NUMBER,
  FORCE_PARENT_UNIT_ID            NUMBER,
  FORCE_COMMAND_UNIT_ID           NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN PFSAWH_ITEM_SN_P_FACT.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_ITEM_SN_P_FACT.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';


--
-- IXU_PFSAWH_ITEM_SN_P_FACT  (Index) 
--
CREATE INDEX IXU_PFSAWH_ITEM_SN_P_FACT ON PFSAWH_ITEM_SN_P_FACT
(DATE_ID, ITEM_DATE_FROM_ID, ITEM_DATE_TO_ID, PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITEM_SN_P_FACT_ITM  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITEM_SN_P_FACT_ITM ON PFSAWH_ITEM_SN_P_FACT
(PHYSICAL_ITEM_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITEM_SN_P_FACT_SN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITEM_SN_P_FACT_SN ON PFSAWH_ITEM_SN_P_FACT
(PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_ITEM_SN_P_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ITEM_SN_P_FACT ON PFSAWH_ITEM_SN_P_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ITEM_SN_P_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ITEM_SN_P_FACT FOR PFSAWH_ITEM_SN_P_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_P_FACT 
-- 
ALTER TABLE PFSAWH_ITEM_SN_P_FACT ADD (
  CONSTRAINT CK_AVAILABILITY_P_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_ITEM_SN_P_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSAWH_ITEM_SN_P_FACT 
-- 
ALTER TABLE PFSAWH_ITEM_SN_P_FACT ADD (
  CONSTRAINT FK_PFSAWH_ITEM_SN_P_FACT_ITMSN 
 FOREIGN KEY (PHYSICAL_ITEM_SN_ID) 
 REFERENCES PFSAWH_ITEM_SN_DIM (PHYSICAL_ITEM_SN_ID) DISABLE);

GRANT SELECT ON PFSAWH_ITEM_SN_P_FACT TO S_PFSAW;

