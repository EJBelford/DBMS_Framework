--
-- PFSAWH_ITEM_DIM  (Table) 
--
CREATE TABLE PFSAWH_ITEM_DIM
(
  REC_ID                       NUMBER           NOT NULL,
  ITEM_DIM_ID                  NUMBER           DEFAULT 0,
  PHYSICAL_ITEM_ID             NUMBER           DEFAULT 0,
  NIIN                         VARCHAR2(9 BYTE) DEFAULT 'unk',
  NSN                          VARCHAR2(13 BYTE) DEFAULT 'unk',
  MCN                          VARCHAR2(13 BYTE) DEFAULT 'unk',
  NIIN_UNIQUE                  VARCHAR2(13 BYTE),
  STANDARD_NIIN_FLAG           VARCHAR2(12 BYTE),
  STANDARD_ARMY_ITEM           VARCHAR2(1 BYTE),
  FSC                          VARCHAR2(4 BYTE) DEFAULT 'unk',
  LIN                          VARCHAR2(6 BYTE),
  ARMY_TYPE_DESIGNATOR         VARCHAR2(30 BYTE) DEFAULT 'unk',
  NIIN_NOMEN                   VARCHAR2(35 BYTE),
  ITEM_NOMEN_SHORT             VARCHAR2(35 BYTE) DEFAULT 'unk',
  ITEM_NOMEN_STANDARD          VARCHAR2(35 BYTE) DEFAULT 'unk',
  ITEM_NOMEN_LONG              VARCHAR2(105 BYTE) DEFAULT 'unk',
  LIN_NOMEN                    VARCHAR2(255 BYTE),
  NEWEST_NIIN_FOR_LIN_FLAG     VARCHAR2(1 BYTE),
  LIN_ACTIVE_DATE              DATE             DEFAULT '01-JAN-1900',
  LIN_INACTIVE_DATE            DATE             DEFAULT '31-DEC-2099',
  LIN_INACTIVE_STATEMENT       VARCHAR2(35 BYTE) DEFAULT 'not applicable',
  UNIT_PRICE                   NUMBER(12,2)     DEFAULT 0.00,
  UI                           VARCHAR2(2 BYTE) DEFAULT '-1',
  UM                           VARCHAR2(20 BYTE),
  EIC                          VARCHAR2(3 BYTE) DEFAULT '-1',
  EIC_MODEL                    VARCHAR2(100 BYTE) DEFAULT 'unk',
  ECC                          VARCHAR2(3 BYTE) DEFAULT '-1',
  ECC_DESC                     VARCHAR2(100 BYTE) DEFAULT 'unk',
  MAT_CAT_CD_1                 VARCHAR2(2 BYTE),
  MAT_CAT_1_NAME               VARCHAR2(30 BYTE),
  MAT_CAT_1_RIC                VARCHAR2(3 BYTE),
  MAT_CAT_CD_1_DESC            VARCHAR2(20 BYTE),
  MAT_CAT_CD_2                 VARCHAR2(2 BYTE),
  MAT_CAT_CD_2_DESC            VARCHAR2(250 BYTE),
  MAT_CAT_CD_3                 VARCHAR2(2 BYTE),
  MAT_CAT_CD_3_DESC            VARCHAR2(20 BYTE),
  MAT_CAT_3_NAME               VARCHAR2(70 BYTE),
  MAT_CAT_CD_4                 VARCHAR2(2 BYTE),
  MAT_CAT_CD_4_DESC            VARCHAR2(100 BYTE),
  MAT_CAT_CD_4_5               VARCHAR2(2 BYTE),
  MAT_CAT_CD_4_5_DESC          VARCHAR2(200 BYTE),
  CAGE_CODE                    VARCHAR2(5 BYTE) DEFAULT '-1',
  CAGE_DESC                    VARCHAR2(20 BYTE) DEFAULT 'unk',
  CHAP                         VARCHAR2(1 BYTE),
  MSCR                         VARCHAR2(8 BYTE),
  UID1_DESC                    VARCHAR2(15 BYTE),
  UID2_DESC                    VARCHAR2(19 BYTE),
  TYPE_CLASS_CD                VARCHAR2(2 BYTE),
  TYPE_CLASS_CD_DESC           VARCHAR2(20 BYTE),
  SB_PUB_DT                    DATE,
  RICC                         VARCHAR2(2 BYTE),
  ABA                          VARCHAR2(2 BYTE),
  SOS                          VARCHAR2(3 BYTE),
  CIIC                         VARCHAR2(2 BYTE),
  SUPPLY_CLASS                 VARCHAR2(2 BYTE),
  SUPPLY_CLASS_DESC            VARCHAR2(20 BYTE),
  CL_OF_SUPPLY_CD              VARCHAR2(2 BYTE),
  CL_OF_SUPPLY_CD_DESC         VARCHAR2(20 BYTE),
  STATUS                       VARCHAR2(1 BYTE) DEFAULT 'I',
  LST_UPDT                     DATE             DEFAULT sysdate,
  UPDT_BY                      VARCHAR2(20 BYTE) DEFAULT user,
  ACTIVE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'I',
  ACTIVE_DATE                  DATE             DEFAULT '01-JAN-1900',
  INACTIVE_DATE                DATE             DEFAULT '31-DEC-2099',
  INSERT_BY                    VARCHAR2(20 BYTE) DEFAULT user,
  INSERT_DATE                  DATE             DEFAULT sysdate,
  UPDATE_BY                    VARCHAR2(20 BYTE),
  UPDATE_DATE                  DATE             DEFAULT '01-JAN-1900',
  DELETE_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                  DATE             DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                  VARCHAR2(1 BYTE) DEFAULT 'Y',
  HIDDEN_DATE                  DATE             DEFAULT '01-JAN-1900',
  WH_DATE_SOURCE               VARCHAR2(25 BYTE),
  WH_EFFECTIVE_DATE            DATE             DEFAULT '01-JAN-1900',
  WH_EXPIRATION_DATE           DATE             DEFAULT '31-DEC-2099',
  WH_LAST_UPDATE_DATE          DATE             DEFAULT '01-JAN-1900',
  WH_RECORD_STATUS             VARCHAR2(10 BYTE),
  ACT_ORIGN_CD                 VARCHAR2(3 BYTE),
  ACT_ORIGN_RIC                VARCHAR2(3 BYTE),
  ACTNG_RQMT_CD                VARCHAR2(1 BYTE),
  ACTNG_RQMT_CLASS             VARCHAR2(400 BYTE),
  ACTNG_RQMT_DESC              VARCHAR2(400 BYTE),
  AEC_CD                       VARCHAR2(1 BYTE),
  AEC_DESC                     VARCHAR2(50 BYTE),
  AERC                         VARCHAR2(25 BYTE),
  ANAL_CD                      VARCHAR2(5 BYTE),
  ANALYST_CMD                  VARCHAR2(15 BYTE),
  ANALYST_DSN_NUMBER           VARCHAR2(15 BYTE),
  ANALYST_EMAIL                VARCHAR2(50 BYTE),
  ANALYST_OFFICE_SYMBOL        VARCHAR2(20 BYTE),
  ANALYST_PHONE                VARCHAR2(15 BYTE),
  ANALYST_WHOLE_NAME           VARCHAR2(35 BYTE),
  ARI_CD                       VARCHAR2(1 BYTE),
  ARMY_TYPE_CL_CD              VARCHAR2(1 BYTE),
  ARMY_TYPE_CL_DESC            VARCHAR2(25 BYTE),
  ARMY_TYPE_DESIGN             VARCHAR2(30 BYTE) DEFAULT 'unk',
  CIIC_DESC                    VARCHAR2(400 BYTE),
  CIIC_NAME                    VARCHAR2(60 BYTE),
  COMMODITY                    VARCHAR2(15 BYTE),
  CURRENT_ARI_FLAG             VARCHAR2(7 BYTE),
  DEMIL_CD                     VARCHAR2(1 BYTE),
  DEMIL_DESC                   VARCHAR2(500 BYTE),
  DEMIL_NAME                   VARCHAR2(30 BYTE),
  DODIC                        VARCHAR2(4 BYTE),
  EFF_DATE                     DATE,
  ESNTL_CD                     VARCHAR2(1 BYTE),
  ESNTL_DESC                   VARCHAR2(600 BYTE),
  ESNTL_NAME                   VARCHAR2(15 BYTE),
  EST_UP_IND                   VARCHAR2(1 BYTE),
  FSG                          NUMBER,
  LC_CD                        VARCHAR2(1 BYTE),
  LC_DESC                      VARCHAR2(100 BYTE),
  MAINT_RPR_CD                 VARCHAR2(1 BYTE),
  MAINT_RPR_DESC               VARCHAR2(200 BYTE),
  PARENT_MCN                   VARCHAR2(13 BYTE),
  RECOV_CD                     VARCHAR2(1 BYTE),
  RECOV_DESC                   VARCHAR2(300 BYTE),
  RICC_DESC                    VARCHAR2(650 BYTE),
  SLAMIS_RQST_ID               VARCHAR2(20 BYTE),
  SOS_DESCRIPTION              VARCHAR2(35 BYTE),
  SOS_MOD_CD                   VARCHAR2(3 BYTE),
  SOS_MOD_DESC                 VARCHAR2(75 BYTE),
  SOS_MOD_NAME                 VARCHAR2(75 BYTE),
  SOS_NAME                     VARCHAR2(50 BYTE),
  SRRC                         VARCHAR2(1 BYTE),
  SRRC_DESC                    VARCHAR2(255 BYTE),
  SUBCLASS_OF_SUPPLY_CD        VARCHAR2(2 BYTE),
  SUBCLASS_OF_SUPPLY_NAME      VARCHAR2(55 BYTE),
  SUBCLASS_OF_SUPPLY_DESC      VARCHAR2(500 BYTE),
  TRANS_SOURCE                 VARCHAR2(20 BYTE),
  WH_FLAG                      VARCHAR2(1 BYTE) DEFAULT 'N',
  WH_EARLIEST_FACT_REC_DT      DATE,
  WH_EARLIEST_FACT_REC_SOURCE  VARCHAR2(65 BYTE),
  RESOURCE_TYPE_DB_ID          VARCHAR2(16 BYTE),
  RESOURCE_TYPE_CODE           NUMBER(10)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1024M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_ITEM_DIM IS 'PFSAWH_ITEM_DIM - This table documents system and/or end items by NIIN or MCN.  It is used as the definitive item description, by validation in the load processes and selection criteria for reports.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.REC_ID IS 'REC_ID - Sequence/identity for dimension.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ITEM_DIM_ID IS 'ITEM_DIM_ID - LIW/PFSAWH identitier for the item/part.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - LIW/PFSAWH identitier for the item/part.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.NIIN IS 'NIIN - National Item Identification Number';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.NSN IS 'NSN - National Stock Number';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.FSC IS 'FSC - Federal Supply Classification';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.LIN IS 'LIN - Line Iten Number';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ARMY_TYPE_DESIGNATOR IS 'ARMY_TYPE_DESIGNATOR - Model number';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ITEM_NOMEN_SHORT IS 'ITEM_NOMEN_SHORT - Description of the item.  On initial load it was taken from gcssa_lin.item_nomen.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ITEM_NOMEN_STANDARD IS 'ITEM_NOMEN_STANDARD - Description of the item.  ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ITEM_NOMEN_LONG IS 'ITEM_NOMEN_LONG - Description of the item.  On initial load it was taken from gcssa_lin.gen_nomen.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.LIN_ACTIVE_DATE IS 'LIN_ACTIVE_DATE - SUPPLY BULLETIN 700-20 ASSIGNED DATE - The date the National Item Identification Number (NIIN) was assigned to a specific Line Item Number (LIN).  The value of this field can be changed only when it is a future date.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.LIN_INACTIVE_DATE IS 'LIN_INACTIVE_DATE - SUPPLY BULLETIN 700-20 INACTIVE DATE - The date the National Item Identification Number (NIIN) was inactivated from a specific Line Item Number (LIN).  The value of this field can be changed only when it is a future date.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.LIN_INACTIVE_STATEMENT IS 'LIN_INACTIVE_STATEMENT - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UNIT_PRICE IS 'UNIT_PRICE - Cost per unit of the item.  On initial load it was taken from gcssa_lin.unit_price.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UI IS 'UI - Cost per unit of the item.  On initial load it was taken from gcssa_lin.ui.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.EIC IS 'EIC - End Item Code';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.EIC_MODEL IS 'EIC_MODEL - End Item Code Desc';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ECC IS 'ECC - Equipment Category Code';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ECC_DESC IS 'ECC_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_1 IS 'MAT_CAT_CD_1 - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_1_DESC IS 'MAT_CAT_CD_1_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_2 IS 'MAT_CAT_CD_2 - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_2_DESC IS 'MAT_CAT_CD_2_DESC - APPROPRIATION AND BUDGET ACTIVITY ACCOUNT CODE DESCRIPTION - A description of the Appropriation and Budget Activity Account Code (MAT_CAT_CD_2).';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_3 IS 'MAT_CAT_CD_3 - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_3_DESC IS 'MAT_CAT_CD_3_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_4 IS 'MAT_CAT_CD_4 - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_4_DESC IS 'MAT_CAT_CD_4_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_4_5 IS 'MAT_CAT_CD_4_5 - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MAT_CAT_CD_4_5_DESC IS 'MAT_CAT_CD_4_5_DESC - MATERIEL CATEGORY CODE - The fourth and fifth positions of the five-position, alphanumeric Materiel Category Structure Code (MATCAT).  Position 4 is the specific group/generic code.  It is alphanumeric, excluding the letter O and the numeral 1.  This code provides further subdivision of those items identified by Positions 1 - 3.  Position 5 is the generic category code.  It is alphanumeric, excluding the letters I and O.  This code identifies items to weapons systems/end items or other applications.  (Ref. CDA PAM NO. 18-1.)';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CAGE_CODE IS 'CAGE - Commercial And Government Entity';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CAGE_DESC IS 'CAGE_DESC - Commercial And Government Entity';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CHAP IS 'CHAP - CHAPTER - Identifies the chapter or appendix of SB 700-20 in which an instance of the materiel item is published.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.MSCR IS 'MSCR - Materiel Status Committee Record identifier - The identifier assigned by the materiel status office to the record of the decisions and actions reported by materiel developers.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UID1_DESC IS 'UID1 - Unique IDentification Construct 1';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UID2_DESC IS 'UID2 - Unique IDentification Construct 2';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.TYPE_CLASS_CD IS 'TYPE_CLASS_CD - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.TYPE_CLASS_CD_DESC IS 'TYPE_CLASS_CD_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.SB_PUB_DT IS 'SB_PUB_DT - SUPPLY BULLETIN 700-20 PUBLICATION DATE - The next date the information is to be published.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.RICC IS 'RICC - Reportable Item Control Code - On initial load it was taken from gcssa_lin.ricc.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ABA IS 'ABA - Appropriation And Budget Activity - On initial load it was taken from gcssa_lin.aba.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.SOS IS 'SOS - Source Of Supply - On initial load it was taken from gcssa_lin.sos.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CIIC IS 'CIIC - Controlled Inventory Item Code - On initial load it was taken from gcssa_lin.ciic.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.SUPPLY_CLASS IS 'SUPPLY CLASS - A code that indicates the major category of materiel to which an item of supply is assigned.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.SUPPLY_CLASS_DESC IS 'SUPPLY_CLASS_DESC - ';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CL_OF_SUPPLY_CD IS 'CL_OF_SUPPLY_CD - CLASS OF SUPPLY - The code that represents the category of use for which an item of equipment is authorized in support of logistics decisions.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.CL_OF_SUPPLY_CD_DESC IS 'CL_OF_SUPPLY_CD_DESC - CLASS OF SUPPLY CODE DESCRIPTION - A description of the Class of Supply Code (CL_OF_SUPPLY_CD).';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Flag indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Flag indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_ITEM_DIM.HIDDEN_DATE IS 'HIDDEN_DATE - Additional control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- IDX_PFSAWH_ITEM_DIM_MCN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITEM_DIM_MCN ON PFSAWH_ITEM_DIM
(MCN)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITEM_DIM_NIIN  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITEM_DIM_NIIN ON PFSAWH_ITEM_DIM
(NIIN)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_ITEM_DIM_ITEM_ID  (Index) 
--
CREATE INDEX IDX_PFSAWH_ITEM_DIM_ITEM_ID ON PFSAWH_ITEM_DIM
(PHYSICAL_ITEM_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_ITEM_DIM_NIIN_MCN  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ITEM_DIM_NIIN_MCN ON PFSAWH_ITEM_DIM
(NIIN, MCN)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ITEM_DIM  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ITEM_DIM FOR PFSAWH_ITEM_DIM;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_DIM 
-- 
ALTER TABLE PFSAWH_ITEM_DIM ADD (
  CONSTRAINT PK_PFSAWH_ITEM_DIM_NIIN_MCN
 PRIMARY KEY
 (NIIN, MCN)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_ITEM_DIM TO S_PFSAW;

