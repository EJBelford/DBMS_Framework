--
-- PFSAWH_ITEM_SN_T_FACT  (Table) 
--
CREATE TABLE PFSAWH_ITEM_SN_T_FACT
(
  REC_ID                          NUMBER        NOT NULL,
  DATE_ID                         NUMBER        NOT NULL,
  PHYSICAL_ITEM_ID                NUMBER        NOT NULL,
  PHYSICAL_ITEM_SN_ID             NUMBER        NOT NULL,
  MIMOSA_ITEM_SN_ID               VARCHAR2(8 BYTE) DEFAULT '00000000',
  ITEM_DATE_FROM_ID               NUMBER        NOT NULL,
  ITEM_TIME_FROM_ID               NUMBER        DEFAULT 10001,
  ITEM_DATE_TO_ID                 NUMBER        NOT NULL,
  ITEM_TIME_TO_ID                 NUMBER        DEFAULT 86401,
  ITEM_FORCE_ID                   NUMBER        DEFAULT 0,
  ITEM_LOCATION_ID                NUMBER        DEFAULT 0,
  ITEM_USAGE_0                    NUMBER,
  ITEM_USAGE_TYPE_0               VARCHAR2(12 BYTE),
  PERIOD_HRS                      NUMBER,
  ITEM_MISSION_CAPABLE_CODE       VARCHAR2(3 BYTE),
  ITEM_NMC_CAUSE_CODE             VARCHAR2(3 BYTE),
  ITEM_MOST_CRITICAL_PART_CODE    VARCHAR2(12 BYTE),
  ITEM_DEFERRED_MAINT_ITEMS       NUMBER,
  ITEM_PROJECT_FLAG               VARCHAR2(1 BYTE),
  ITEM_PROJECT_CODE               VARCHAR2(6 BYTE),
  TRAN_MC_HRS                     NUMBER,
  TRAN_FMC_HRS                    NUMBER,
  TRAN_PMC_HRS                    NUMBER,
  TRAN_PMCM_HRS                   NUMBER,
  TRAN_PMCM_USER_HRS              NUMBER,
  TRAN_PMCM_INT_HRS               NUMBER,
  TRAN_PMCS_HRS                   NUMBER,
  TRAN_PMCS_USER_HRS              NUMBER,
  TRAN_PMCS_INT_HRS               NUMBER,
  TRAN_NMC_HRS                    NUMBER,
  TRAN_NMCM_HRS                   NUMBER,
  TRAN_NMCM_USER_HRS              NUMBER,
  TRAN_NMCM_INT_HRS               NUMBER,
  TRAN_NMCM_DEP_HRS               NUMBER,
  TRAN_NMCS_HRS                   NUMBER,
  TRAN_NMCS_USER_HRS              NUMBER,
  TRAN_NMCS_INT_HRS               NUMBER,
  TRAN_NMCS_DEP_HRS               NUMBER,
  TRAN_DEP_HRS                    NUMBER,
  TRAN_OPERAT_READINESS_RATE      NUMBER,
  TRAN_OPERAT_COST_PER_HOUR       NUMBER,
  TRAN_COST_PARTS                 NUMBER,
  TRAN_COST_MANPOWER              NUMBER,
  TRAN_DEFERRED_MAINT_ITEMS       NUMBER,
  TRAN_OPERAT_HRS_SINCE_LST_OVHL  NUMBER,
  TRAN_MAINT_HRS_SINCE_LST_OVHL   NUMBER,
  TRAN_TIME_SINCE_LST_OVHL        NUMBER,
  STATUS                          VARCHAR2(1 BYTE) DEFAULT 'C',
  UPDT_BY                         VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                        DATE          DEFAULT SYSDATE,
  ACTIVE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'Y',
  ACTIVE_DATE                     DATE          DEFAULT '01-JAN-1900',
  INACTIVE_DATE                   DATE          DEFAULT '31-DEC-2099',
  INSERT_BY                       VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                     DATE          DEFAULT SYSDATE,
  UPDATE_BY                       VARCHAR2(30 BYTE),
  UPDATE_DATE                     DATE          DEFAULT '01-JAN-1900',
  DELETE_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                     DATE          DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                     VARCHAR2(1 BYTE) DEFAULT 'N',
  HIDDEN_DATE                     DATE          DEFAULT '01-JAN-1900',
  NOTES                           VARCHAR2(255 BYTE) DEFAULT '',
  PBA_ID                          NUMBER        DEFAULT 1000000,
  TRAN_MAINT_ACTION_CNT           NUMBER,
  TRAN_MEANTIME_BTWN_MAINT_CNT    NUMBER,
  TRAN_MEANDOWN_TIME              NUMBER,
  TRAN_CUSTOMER_WAIT_TIME         NUMBER,
  ITEM_USAGE_1                    NUMBER,
  ITEM_USAGE_TYPE_1               VARCHAR2(12 BYTE),
  ITEM_USAGE_2                    NUMBER,
  ITEM_USAGE_TYPE_2               VARCHAR2(12 BYTE),
  ETL_PROCESSED_BY                VARCHAR2(50 BYTE),
  CRC_USAGE_EVENT                 INTEGER,
  TRAN_TOTAL_DOWN_TIME            NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_ITEM_SN_T_FACT IS 'PFSAWH_ITEM_SN_T_FACT - This table serves as the daily/transactional fact for a particular item/serial number combination.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ETL_PROCESSED_BY IS 'ETL_PROCESSED_BY - Indicates which ETL process is responsible for inserting and maintainfing this record.  This is critically for dealing with records similar in nature to the freeze records.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.REC_ID IS 'REC_ID - Sequence/identity for fact';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.DATE_ID IS 'DATE_ID - Identity for PFSA_DATE_DIM records.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - LIW/PFSAWH identitier for the item/part as represented in the PFSAWH_ITEM_DIM';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.PHYSICAL_ITEM_SN_ID IS 'PHYSICAL_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number as represented in the PFSAWH_ITEM_SN_DIM.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.MIMOSA_ITEM_SN_ID IS 'MIMOSA_ITEM_SN_ID - PFSAWH identitier for item/part for a particular serial number/tail number.  HEX version of the PHYSICAL_ITEN_SN_ID for use with the MIMOSA standard.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_DATE_FROM_ID IS 'ITEM_DATE_FROM_ID - The date this records coverage starts with.  Identity for PFSA_DATE_DIM records';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_TIME_FROM_ID IS 'ITEM_TIME_FROM_ID - The time this records coverage starts with.  Identity for PFSA_TIMEDIM records';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_DATE_TO_ID IS 'ITEM_DATE_TO_ID - The date this records coverage ends with.  Identity for PFSA_DATE_DIM records';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_TIME_TO_ID IS 'ITEM_TIME_TO_ID - The time this records coverage ends with.  Identity for PFSA_TIMEDIM records';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_FORCE_ID IS 'ITEM_FORCE_ID - FORCE UIC - The unit identifier of valid Force UICs as represented in the PFSAWH_FORCE_DIM.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_LOCATION_ID IS 'ITEM_LOCATION_ID - LOCATION - Identifies the location as CONUS (Continental United States) or OCONUS (Outside the Continental United States).';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_USAGE_0 IS 'ITEM_USAGE - CURRENT USAGE QUANTITY - The current reported usage quantity.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_USAGE_TYPE_0 IS 'ITEM_USAGE_TYPE - USAGE BASIS - A one-character, alphanumeric code that identifies the type of use measurement to be applied to the item usage (e.g., miles, hours, rounds).';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.PERIOD_HRS IS 'PERIOD_HRS - The total number of hours included in the period indicate from the from_dt through the to_dt.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_MISSION_CAPABLE_CODE IS 'ITEM_MISSION_CAPABLE_CODE - MISSION CAPABLE - Rate at which an item is considered mission capable.  Determined by the following formula: MC Rate(%) - (FMC Hours + PMC Hours/Total Hours on Hand) *100';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_NMC_CAUSE_CODE IS 'ITEM_NMC_CAUSE_CODE - The reason code for why the item was "Not Mission Capable."';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_MOST_CRITICAL_PART_CODE IS 'ITEM_MOST_CRITICAL_PART_CODE - The part code of the repair part that most effected the mission capability of the item.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_DEFERRED_MAINT_ITEMS IS 'ITEM_DEFERRED_MAINT_ITEMS - The item has maintenance actions that effect mission capability that have been deferred.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_PROJECT_FLAG IS 'ITEM_PROJECT_FLAG - PROJECT CODE FLAG - No description available at this time.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ITEM_PROJECT_CODE IS 'ITEM_PROJECT_CODE - PROJECT CODE - The DA Master Project Code is a three-position, alphanumeric code used to distinguish requisitions and related documentation and shipments and to accumulate intraservice performance and cost data related to exercises, maneuvers, and other distinct programs, projects, and operations.  The Project Code is used to identify requisitions, related documents, and shipments of materiel for specific projects, programs, or maneuvers.  It identifies specific programs to provide funding and costing at the requisitioner or supplier level, to satisfy program costs and analysis, including an indicator of transactions within or outside of the federal government.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_MC_HRS IS 'TRAN_MC_HRS - MC_HRS - The total number of hours in a mission capable status (fully or partially) during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_FMC_HRS IS 'TRAN_FMC_HRS - FULLY MISSION CAPABLE (FMC) HOURS - The reported number of hours, during the subject report period, that the particular aircraft (identified by MODEL and SERIAL_NUMBER) is reported to be Fully Mission Capable (FMC).';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMC_HRS IS 'TRAN_PMC_HRS - PARTIALLY MISSION CAPABLE (PMC) HOURS - The reported hours that an item of equipment was capable of performing one or more, but not all, assigned missions, due to one or more of its mission-essential subsystems being inoperative for maintenance or supply reasons.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCM_HRS IS 'TRAN_PMCM_HRS - PARTIALLY MISSION CAPABLE (PMC) MAINTENANCE HOURS (AIRCRAFT) - The reported hours that an aircraft was capable of performing one or more, but not all, assigned missions, due to one or more of its mission-essential subsystems being inoperative for maintenance reasons.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCM_USER_HRS IS 'TRAN_PMCM_USER_HRS - PMCM_USER_HRS - The total number of hours in a partially mission capability maintenance status at the user level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCM_INT_HRS IS 'TRAN_PMCM_INT_HRS - PMCM_INT_HRS - The total number of hours in a partially mission capability maintenance status at the intermediate level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCS_HRS IS 'TRAN_PMCS_HRS - PARTIALLY MISSION CAPABLE (PMC) SUPPLY HOURS (AIRCRAFT) - The reported hours that an aircraft was capable of performing one or more, but not all, assigned missions, due to one or more of its mission-essential subsystems being inoperative for supply reasons.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCS_USER_HRS IS 'TRAN_PMCS_USER_HRS - PMCS_USER_HRS - The total number of hours in a partially mission capability supply status at the user level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_PMCS_INT_HRS IS 'TRAN_PMCS_INT_HRS - PMCS_INT_HRS - The total number of hours in a partially mission capability supply status at the intermediate level during the indicated period';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMC_HRS IS 'TRAN_NMC_HRS - NMC_HRS - The total number of hours in a not mission capable status durint the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCM_HRS IS 'TRAN_NMCM_HRS - NMCM_HRS - The total number of hours in a not mission capable maintenance status durint the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCM_USER_HRS IS 'TRAN_NMCM_USER_HRS - NMCM_USER_HRS - The total number of hours in a non mission capable maintenance status at the user level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCM_INT_HRS IS 'TRAN_NMCM_INT_HRS - NMCM_INT_HRS - The total number of hours in a non mission capable maintenance status at the intermediate level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCM_DEP_HRS IS 'TRAN_NMCM_DEP_HRS - NMCM_DEP_HRS - The total number of hours in a non mission capable maintenance status at the depot level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCS_HRS IS 'TRAN_NMCS_HRS - NUMBER OF HOURS NOT MISSION CAPABLE DUE TO SUPPLY - The number of hours that an item is considered not mission capable due to supply.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCS_USER_HRS IS 'TRAN_NMCS_USER_HRS - NMCS_USER_HRS - The total number of hours in a non mission capable supply status at the user level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCS_INT_HRS IS 'TRAN_NMCS_INT_HRS - NMCS_INT_HRS - The total number of hours in a non mission capable supply status at the intermediate level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_NMCS_DEP_HRS IS 'TRAN_NMCS_DEP_HRS - NMCS_DEP_HRS - The total number of hours in a non mission capable supply status at the depot level during the indicated period.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_DEP_HRS IS 'TRAN_DEP_HRS - DEP_HRS - The total number of hours in a non mission capable status at the depot level.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_OPERAT_READINESS_RATE IS 'TRAN_OPERAT_READINESS_RATE - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_OPERAT_COST_PER_HOUR IS 'TRAN_OPERAT_COST_PER_HOUR - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_COST_PARTS IS 'TRAN_COST_PARTS - PART COST - Part Cost is the product of Quantity Consumed (QTY_CONSM_MAINT) and Current Unit Price (UNIT_PRICE).  Part Cost = (QTY_CONSM_MAINT) X (UNIT_PRICE)';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_COST_MANPOWER IS 'TRAN_COST_MANPOWER - MAN-HOUR COST - The man-hour costs for performing the action.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_DEFERRED_MAINT_ITEMS IS 'TRAN_DEFERRED_MAINT_ITEMS - ';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_OPERAT_HRS_SINCE_LST_OVHL IS 'TRAN_OPERAT_HRS_SINCE_LST_OVHL - Operational hours since last overhaul.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_MAINT_HRS_SINCE_LST_OVHL IS 'TRAN_MAINT_HRS_SINCE_LST_OVHL - Maintenance hours since last overhaul.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_TIME_SINCE_LST_OVHL IS 'TRAN_TIME_SINCE_LST_OVHL - Time since last overhaul.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.STATUS IS 'STATUS - The status of the record in question.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.NOTES IS 'NOTES - Processing notes from the ETL process.';

COMMENT ON COLUMN PFSAWH_ITEM_SN_T_FACT.TRAN_MAINT_ACTION_CNT IS 'TRAN_MAINT_ACTION_CNT -  The number of maintenance actions that have been identified during this event';


--
-- PK_PFSAWH_ITEM_SN_T_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ITEM_SN_T_FACT ON PFSAWH_ITEM_SN_T_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_ITEM_SN_T_FACT  (Index) 
--
CREATE INDEX IXU_PFSAWH_ITEM_SN_T_FACT ON PFSAWH_ITEM_SN_T_FACT
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID, ITEM_DATE_FROM_ID, ITEM_TIME_FROM_ID, ITEM_DATE_TO_ID, 
ITEM_TIME_TO_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ITEM_SN_T_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ITEM_SN_T_FACT FOR PFSAWH_ITEM_SN_T_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ITEM_SN_T_FACT 
-- 
ALTER TABLE PFSAWH_ITEM_SN_T_FACT ADD (
  CONSTRAINT CK_AVAILABILITY_T_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_ITEM_SN_T_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSAWH_ITEM_SN_T_FACT 
-- 
ALTER TABLE PFSAWH_ITEM_SN_T_FACT ADD (
  CONSTRAINT FK_PFSAWH_ITEM_SN_T_FACT_ITMSN 
 FOREIGN KEY (PHYSICAL_ITEM_SN_ID) 
 REFERENCES PFSAWH_ITEM_SN_DIM (PHYSICAL_ITEM_SN_ID));

GRANT SELECT ON PFSAWH_ITEM_SN_T_FACT TO S_PFSAW;

