--
-- PFSAWH_SOURCE_HIST_REF  (Table) 
--
CREATE TABLE PFSAWH_SOURCE_HIST_REF
(
  SOURCE_HIST_REF_ID          NUMBER            NOT NULL,
  SOURCE_LAST_CHECKED_DATE    DATE,
  SOURCE_LAST_PROCESSED_DATE  DATE,
  SOURCE_DATABASE             VARCHAR2(30 BYTE),
  SOURCE_SCHEMA               VARCHAR2(30 BYTE),
  SOURCE_TABLE                VARCHAR2(30 BYTE) NOT NULL,
  SOURCE_LAST_RECORD_COUNT    NUMBER,
  SOURCE_LAST_UPDATE_DATE     DATE,
  SOURCE_LAST_UPDATE_COUNT    NUMBER,
  SOURCE_LAST_INSERT_COUNT    NUMBER,
  SOURCE_LAST_DELETE_COUNT    NUMBER,
  STATUS                      VARCHAR2(1 BYTE)  DEFAULT 'N',
  UPDT_BY                     VARCHAR2(30 BYTE) DEFAULT user,
  LST_UPDT                    DATE              DEFAULT sysdate,
  ACTIVE_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'I',
  ACTIVE_DATE                 DATE              DEFAULT '01-JAN-1900',
  INACTIVE_DATE               DATE              DEFAULT '31-DEC-2099',
  INSERT_BY                   VARCHAR2(30 BYTE) DEFAULT user,
  INSERT_DATE                 DATE              DEFAULT sysdate,
  UPDATE_BY                   VARCHAR2(30 BYTE),
  UPDATE_DATE                 DATE              DEFAULT '01-JAN-1900',
  DELETE_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'N',
  DELETE_DATE                 DATE              DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'Y',
  HIDDEN_DATE                 DATE              DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_SOURCE_HIST_REF IS 'Contains usefull information for the warehouse ETL process use in processing upstream information. ';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_UPDATE_COUNT IS 'The number of updated records in the source table when last processed by the warehouse ETL.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_INSERT_COUNT IS 'The number of new records in the source table when last processed by the warehouse ETL.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_DELETE_COUNT IS 'The number of delete/hidden records in the source table when last processed by the warehouse ETL.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.STATUS IS 'The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.ACTIVE_DATE IS 'Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.INACTIVE_DATE IS 'Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_HIST_REF_ID IS 'Row identity';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_CHECKED_DATE IS 'The last time the source table was audited by the warehouse or the source flagged changes for the warehouse.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_PROCESSED_DATE IS 'The last time the source table were loaded to the warehouse.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_DATABASE IS 'The database where the source schema and table can be found.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_SCHEMA IS 'The schema where the source table can be found.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_TABLE IS 'The source table.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_RECORD_COUNT IS 'The number of records in the source table when last processed by the warehouse ETL.';

COMMENT ON COLUMN PFSAWH_SOURCE_HIST_REF.SOURCE_LAST_UPDATE_DATE IS 'The date of the last source table update when processed by the warehouse ETL.';


--
-- IXU_PFSA_SOURCE_TABLE_HIST_REF  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSA_SOURCE_TABLE_HIST_REF ON PFSAWH_SOURCE_HIST_REF
(SOURCE_TABLE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_SOURCE_HIST_REF  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_SOURCE_HIST_REF ON PFSAWH_SOURCE_HIST_REF
(SOURCE_HIST_REF_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_SOURCE_HIST_REF  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_SOURCE_HIST_REF FOR PFSAWH_SOURCE_HIST_REF;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_SOURCE_HIST_REF 
-- 
ALTER TABLE PFSAWH_SOURCE_HIST_REF ADD (
  CONSTRAINT CK_PFSAWH_SRC_HIST_REF_ACT_FLG
 CHECK (ACTIVE_FLAG='I' OR ACTIVE_FLAG='N' OR ACTIVE_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_SRC_HIST_REF_DEL_FLG
 CHECK (DELETE_FLAG='N' OR DELETE_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_SRC_HIST_REF_HIDE_FL
 CHECK (HIDDEN_FLAG='N' OR HIDDEN_FLAG='Y'),
  CONSTRAINT CK_PFSAWH_SRC_HIST_REF_STATUS
 CHECK (STATUS='C' OR STATUS='D' OR STATUS='E' OR STATUS='H' 
        OR STATUS='L' OR STATUS='P' OR STATUS='Q' OR STATUS='R' 
        OR STATUS='T' OR STATUS='Z' OR STATUS='N' 
        ),
  CONSTRAINT PK_PFSAWH_SOURCE_HIST_REF
 PRIMARY KEY
 (SOURCE_HIST_REF_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_SOURCE_HIST_REF TO S_PFSAW;

