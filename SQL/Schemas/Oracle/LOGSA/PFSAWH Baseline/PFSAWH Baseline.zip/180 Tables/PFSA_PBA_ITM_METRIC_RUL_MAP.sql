--
-- PFSA_PBA_ITM_METRIC_RUL_MAP  (Table) 
--
CREATE TABLE PFSA_PBA_ITM_METRIC_RUL_MAP
(
  REC_ID            NUMBER                      NOT NULL,
  PBA_ID            NUMBER                      DEFAULT 0,
  PHYSICAL_ITEM_ID  NUMBER                      DEFAULT 0,
  METRIC_ID         NUMBER                      DEFAULT 0,
  RULE_ID           NUMBER                      DEFAULT 0,
  STATUS            VARCHAR2(1 BYTE)            DEFAULT 'N',
  UPDT_BY           VARCHAR2(30 BYTE)           DEFAULT USER,
  LST_UPDT          DATE                        DEFAULT SYSDATE,
  ACTIVE_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'I',
  ACTIVE_DATE       DATE                        DEFAULT '01-JAN-1900',
  INACTIVE_DATE     DATE                        DEFAULT '31-DEC-2099',
  INSERT_BY         VARCHAR2(30 BYTE)           DEFAULT USER,
  INSERT_DATE       DATE                        DEFAULT SYSDATE,
  UPDATE_BY         VARCHAR2(30 BYTE),
  UPDATE_DATE       DATE                        DEFAULT '01-JAN-1900',
  DELETE_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'N',
  DELETE_DATE       DATE                        DEFAULT '01-JAN-1900',
  HIDDEN_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'Y',
  HIDDEN_DATE       DATE                        DEFAULT '01-JAN-1900',
  TRFR_N_TO_S       VARCHAR2(1 BYTE)            DEFAULT 'Y',
  TRFR_S_TO_N       VARCHAR2(1 BYTE)            DEFAULT 'N'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSA_PBA_ITM_METRIC_RUL_MAP IS 'GB_PFSA_PBA_ITM_METRIC_RUL_MAP - ';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.REC_ID IS 'REC_ID - Sequence/identity for the table.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.PHYSICAL_ITEM_ID IS 'PHYSICAL_ITEM_ID - ';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.METRIC_ID IS 'METRIC_ID - ';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.RULE_ID IS 'RULE_ID - ';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSA_PBA_ITM_METRIC_RUL_MAP.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- PK_PFSA_PBS_ITM_METRIC_RUL_MAP  (Index) 
--
CREATE UNIQUE INDEX PK_PFSA_PBS_ITM_METRIC_RUL_MAP ON PFSA_PBA_ITM_METRIC_RUL_MAP
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSA_PBA_ITM_MET_RUL_MAP  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSA_PBA_ITM_MET_RUL_MAP ON PFSA_PBA_ITM_METRIC_RUL_MAP
(PBA_ID, PHYSICAL_ITEM_ID, METRIC_ID, RULE_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSA_PBA_ITM_METRIC_RUL_MAP  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_PBA_ITM_METRIC_RUL_MAP FOR PFSA_PBA_ITM_METRIC_RUL_MAP;


-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_ITM_METRIC_RUL_MAP 
-- 
ALTER TABLE PFSA_PBA_ITM_METRIC_RUL_MAP ADD (
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PBA_ITM_MET_RUL_MAP_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT PK_PFSA_PBS_ITM_METRIC_RUL_MAP
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSA_PBA_ITM_METRIC_RUL_MAP 
-- 
ALTER TABLE PFSA_PBA_ITM_METRIC_RUL_MAP ADD (
  CONSTRAINT FK_PFSA_CODE_ITEM_ID 
 FOREIGN KEY (PHYSICAL_ITEM_ID) 
 REFERENCES PFSA_PBA_ITEMS_REF (REC_ID) DISABLE,
  CONSTRAINT FK_PFSA_CODE_METRIC_ID 
 FOREIGN KEY (METRIC_ID) 
 REFERENCES PFSA_PBA_METRICS_REF (METRIC_ID),
  CONSTRAINT FK_PFSA_CODE_RULE_ID 
 FOREIGN KEY (METRIC_ID, RULE_ID) 
 REFERENCES PFSA_PBA_RULES_REF (METRIC_ID,RULE_ID));

GRANT SELECT ON PFSA_PBA_ITM_METRIC_RUL_MAP TO S_PFSAW;

