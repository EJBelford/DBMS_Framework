--
-- PFSAWH_LOCATION_DIM  (Table) 
--
CREATE TABLE PFSAWH_LOCATION_DIM
(
  REC_ID                        NUMBER          NOT NULL,
  GEO_ID                        NUMBER          NOT NULL,
  GEO_CD                        VARCHAR2(5 BYTE) NOT NULL,
  ST_CNTRY_NAME                 VARCHAR2(20 BYTE),
  GEO_CD_DESC                   VARCHAR2(200 BYTE),
  INSTALLATION_NAME             VARCHAR2(70 BYTE),
  CITY_NAME                     VARCHAR2(60 BYTE),
  COUNTY_NAME                   VARCHAR2(20 BYTE),
  STATE_CODE                    VARCHAR2(2 BYTE),
  STATE_NAME                    VARCHAR2(20 BYTE),
  PROVINCE_NAME                 VARCHAR2(20 BYTE),
  ISO_3166_2_NUMERIC            NUMBER,
  COUNTRY_NAME                  VARCHAR2(50 BYTE),
  ISO_3166_1_ALPHA_2            VARCHAR2(2 BYTE),
  ISO_3166_1_ALPHA_3            VARCHAR2(3 BYTE),
  ISO_3166_1_NUMERIC            NUMBER,
  ZIP_CODE                      VARCHAR2(10 BYTE),
  THEATER_NAME                  VARCHAR2(20 BYTE),
  TIME_ZONE_REGION_CODE         VARCHAR2(3 BYTE) DEFAULT 'UNK',
  TIME_ZONE_REGION_ZULU_OFFSET  NUMBER(3)       DEFAULT '0',
  TIME_ZONE_REGION_DESC         VARCHAR2(20 BYTE) DEFAULT 'UNKNOWN',
  INSTALLATION_TYPE_CODE        VARCHAR2(3 BYTE) DEFAULT 'UNK',
  CIPHER_ST_CNTRY_NAME          VARCHAR2(20 BYTE),
  CIPHER_GEO_CD_DESC            VARCHAR2(200 BYTE),
  CIPHER_INSTALLATION_NAME      VARCHAR2(70 BYTE),
  CIPHER_CITY_NAME              VARCHAR2(60 BYTE),
  CIPHER_PROVINCE_NAME          VARCHAR2(20 BYTE),
  CIPHER_ISO_3166_2_NUMERIC     NUMBER,
  CIPHER_COUNTRY_NAME           VARCHAR2(50 BYTE),
  CIPHER_ISO_3166_1_ALPHA_2     VARCHAR2(2 BYTE),
  CIPHER_ISO_3166_1_ALPHA_3     VARCHAR2(3 BYTE),
  CIPHER_ISO_3166_1_NUMERIC     NUMBER,
  STATUS                        VARCHAR2(1 BYTE) DEFAULT 'Z',
  LST_UPDT                      DATE,
  UPDT_BY                       VARCHAR2(30 BYTE),
  ACTIVE_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'I',
  ACTIVE_DATE                   DATE            DEFAULT '01-JAN-1900',
  INACTIVE_DATE                 DATE            DEFAULT '31-DEC-2099',
  INSERT_BY                     VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                   DATE            DEFAULT SYSDATE,
  UPDATE_BY                     VARCHAR2(30 BYTE),
  UPDATE_DATE                   DATE            DEFAULT '01-JAN-1900',
  DELETE_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                   DATE            DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'Y',
  HIDDEN_DATE                   DATE            DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_LOCATION_DIM IS 'This table is used in the PFSA world to normalize the station code based geographical data in the LIDB STN_REF table to geographical codes (GEO_CD).  It is maintained by a nightly process to remove duplicate geographical codes.  Duplicate geographical codes are created by changes in countries, i.e., the re-unification of Germany.  Station Codes are based upon the state/country code of the country, plus a 3 digit sequence number.  Station codes can also change/relate to the same geographical location based upon the type of station (i.e., an airfield on a fort will have a separate station code from the fort itself.  The geographical code is the same for both.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_CITY_NAME IS 'Name of city or town covered by this location.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_PROVINCE_NAME IS 'If applicable, name of foreign country province this location in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_ISO_3166_2_NUMERIC IS 'ISO 3166-2 is the second part of the ISO 3166 standard published by the International Organization for Standardization (ISO). It is a geocode system created for coding the names of country subdivisions and dependent areas. The purpose of the standard is to establish a worldwide series of short abbreviations for places, for use on package labels, containers, and such; anywhere where a short alphanumeric code can serve to clearly indicate a location in a more convenient and less ambiguous form than the full place name.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_COUNTRY_NAME IS 'Name of country this location is in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_ISO_3166_1_ALPHA_2 IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 alpha-2, a two-letter system, used in many applications, most prominently for country code top-level domains (ccTLDs), with some exceptions.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_ISO_3166_1_ALPHA_3 IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 alpha-3, a three-letter system, which allows a better visual association between country name and code element than the alpha-2 code.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_ISO_3166_1_NUMERIC IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 numeric, a three-digit numerical system, with the advantage of script (writing system) independence, and hence useful for people or systems which uses a non-Latin script. This is identical to codes defined by the United Nations Statistics Division.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.STATUS IS 'The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ACTIVE_DATE IS 'Additional control for active_Flag indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.INACTIVE_DATE IS 'Additional control for active_Flag indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.REC_ID IS 'Identity for PFSAWH_LOCATION_DIM';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.GEO_ID IS 'Location code for PFSAWH_LOCATION_DIM';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.GEO_CD IS 'GEOGRAPHIC CODE - A code that represents a specific geographical location.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ST_CNTRY_NAME IS 'STATE OR COUNTRY NAME - The name of a specific U.S. state or the name of a specific, recognized country.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.GEO_CD_DESC IS 'The PFSA selected station code description used to describe the GEO_CD';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.INSTALLATION_NAME IS 'Name of installation if there is one associated with the location.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CITY_NAME IS 'Name of city or town covered by this location.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.COUNTY_NAME IS 'Name of US county covered by this location.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.STATE_CODE IS '2-character US state code that this location is found in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.STATE_NAME IS 'Name of US state that this location is found in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.PROVINCE_NAME IS 'If applicable, name of foreign country province this location in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ISO_3166_2_NUMERIC IS 'ISO 3166-2 is the second part of the ISO 3166 standard published by the International Organization for Standardization (ISO). It is a geocode system created for coding the names of country subdivisions and dependent areas. The purpose of the standard is to establish a worldwide series of short abbreviations for places, for use on package labels, containers, and such; anywhere where a short alphanumeric code can serve to clearly indicate a location in a more convenient and less ambiguous form than the full place name.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.COUNTRY_NAME IS 'Name of country this location is in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ISO_3166_1_ALPHA_2 IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 alpha-2, a two-letter system, used in many applications, most prominently for country code top-level domains (ccTLDs), with some exceptions.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ISO_3166_1_ALPHA_3 IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 alpha-3, a three-letter system, which allows a better visual association between country name and code element than the alpha-2 code.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ISO_3166_1_NUMERIC IS 'ISO 3166-1, as part of the ISO 3166 standard, provides codes for the names of countries and dependent territories, and is published by the International Organization for Standardization (ISO).  ISO 3166-1 numeric, a three-digit numerical system, with the advantage of script (writing system) independence, and hence useful for people or systems which uses a non-Latin script. This is identical to codes defined by the United Nations Statistics Division.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.ZIP_CODE IS 'Postal zip code.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.THEATER_NAME IS 'Name of theater this location is in.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.TIME_ZONE_REGION_CODE IS '3-charter time zone region code.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.TIME_ZONE_REGION_ZULU_OFFSET IS 'Numeric offset from Zulu/Greenwiche mean time.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.TIME_ZONE_REGION_DESC IS 'Time zone region description.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.INSTALLATION_TYPE_CODE IS 'Installation type code.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_ST_CNTRY_NAME IS 'STATE OR COUNTRY NAME - The name of a specific U.S. state or the name of a specific, recognized country.';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_GEO_CD_DESC IS 'The PFSA selected station code description used to describe the GEO_CD';

COMMENT ON COLUMN PFSAWH_LOCATION_DIM.CIPHER_INSTALLATION_NAME IS 'Name of installation if there is one associated with the location.';


--
-- PK_PFSAWH_LOCATION_DIM  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_LOCATION_DIM ON PFSAWH_LOCATION_DIM
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_LOCATION_GEO_CD_DIM  (Index) 
--
CREATE UNIQUE INDEX IXU_LOCATION_GEO_CD_DIM ON PFSAWH_LOCATION_DIM
(GEO_CD)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_LOCATION_DIM  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_LOCATION_DIM FOR PFSAWH_LOCATION_DIM;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_LOCATION_DIM 
-- 
ALTER TABLE PFSAWH_LOCATION_DIM ADD (
  CONSTRAINT PK_PFSAWH_LOCATION_DIM
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_LOCATION_DIM TO S_PFSAW;

