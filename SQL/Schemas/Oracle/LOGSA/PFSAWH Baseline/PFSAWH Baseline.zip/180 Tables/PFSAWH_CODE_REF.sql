--
-- PFSAWH_CODE_REF  (Table) 
--
CREATE TABLE PFSAWH_CODE_REF
(
  REC_ID            NUMBER                      NOT NULL,
  CAT_CODE          NUMBER                      NOT NULL,
  ITEM_CODE         VARCHAR2(50 BYTE)           NOT NULL,
  ITEM_TEXT         VARCHAR2(500 BYTE),
  CODE_SOURCE       VARCHAR2(20 BYTE),
  CODE_SOURCE_ID    VARCHAR2(20 BYTE),
  CODE_SOURCE_CODE  VARCHAR2(50 BYTE),
  CODE_SOURCE_TEXT  VARCHAR2(150 BYTE),
  CODE_SORT_ORDER   NUMBER,
  STATUS            VARCHAR2(1 BYTE)            DEFAULT 'N',
  UPDT_BY           VARCHAR2(30 BYTE)           DEFAULT USER,
  LST_UPDT          DATE                        DEFAULT SYSDATE,
  ACTIVE_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'I',
  ACTIVE_DATE       DATE                        DEFAULT '01-JAN-1900',
  INACTIVE_DATE     DATE                        DEFAULT '31-DEC-2099',
  INSERT_BY         VARCHAR2(30 BYTE)           DEFAULT USER,
  INSERT_DATE       DATE                        DEFAULT SYSDATE,
  UPDATE_BY         VARCHAR2(30 BYTE),
  UPDATE_DATE       DATE                        DEFAULT '01-JAN-1900',
  DELETE_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'N',
  DELETE_DATE       DATE                        DEFAULT '01-JAN-1900',
  HIDDEN_FLAG       VARCHAR2(1 BYTE)            DEFAULT 'Y',
  HIDDEN_DATE       DATE                        DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_CODE_REF IS 'Contains the values and description of the codes that change very slowly.';

COMMENT ON COLUMN PFSAWH_CODE_REF.STATUS IS 'The status of the record in question.';

COMMENT ON COLUMN PFSAWH_CODE_REF.UPDT_BY IS 'The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_CODE_REF.LST_UPDT IS 'Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_CODE_REF.ACTIVE_FLAG IS 'Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_CODE_REF.ACTIVE_DATE IS 'Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_CODE_REF.INACTIVE_DATE IS 'Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_CODE_REF.INSERT_BY IS 'Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_CODE_REF.INSERT_DATE IS 'Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_CODE_REF.UPDATE_BY IS 'Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_CODE_REF.UPDATE_DATE IS 'Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_CODE_REF.DELETE_FLAG IS 'Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_CODE_REF.DELETE_DATE IS 'Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_CODE_REF.HIDDEN_FLAG IS 'Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_CODE_REF.HIDDEN_DATE IS 'Additional control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- IXU_PFSAWH_CODE_REF  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_CODE_REF ON PFSAWH_CODE_REF
(CAT_CODE, ITEM_CODE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_CODE_REF  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_CODE_REF FOR PFSAWH_CODE_REF;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_CODE_REF 
-- 
ALTER TABLE PFSAWH_CODE_REF ADD (
  CONSTRAINT CK_PFSAWH_CODE_REF_ACT_FLAG
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_CODE_REF_DEL_FLAG
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_CODE_REF_DEL_FLG
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_CODE_REF_HIDE_FLG
 CHECK (hidden_flag='N' OR hidden_flag='Y'));

-- 
-- Foreign Key Constraints for Table PFSAWH_CODE_REF 
-- 
ALTER TABLE PFSAWH_CODE_REF ADD (
  CONSTRAINT FK_PFSA_CODE_CATCODE 
 FOREIGN KEY (CAT_CODE) 
 REFERENCES PFSAWH_CODE_DEFINITION_REF (CAT_CODE));

GRANT SELECT ON PFSAWH_CODE_REF TO S_PFSAW;

