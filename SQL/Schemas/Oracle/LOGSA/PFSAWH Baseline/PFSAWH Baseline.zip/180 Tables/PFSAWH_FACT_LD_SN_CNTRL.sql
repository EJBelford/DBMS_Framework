--
-- PFSAWH_FACT_LD_SN_CNTRL  (Table) 
--
CREATE TABLE PFSAWH_FACT_LD_SN_CNTRL
(
  REC_ID                  NUMBER                NOT NULL,
  PHYSICAL_ITEM_ID        NUMBER                NOT NULL,
  NIIN                    VARCHAR2(9 BYTE)      DEFAULT 'UNK',
  PHYSICAL_ITEM_SN_ID     NUMBER                NOT NULL,
  SERIAL_NUMBER           VARCHAR2(48 BYTE)     DEFAULT 'UNK',
  ITEM_NOMEN_STANDARD     VARCHAR2(35 BYTE)     DEFAULT 'UNK',
  STATUS                  VARCHAR2(1 BYTE)      DEFAULT 'W',
  LOAD_DATE               DATE,
  LOAD_DATE_ID            NUMBER,
  TOUCH_COUNT             NUMBER                DEFAULT 0,
  SERIAL_NUMBER_NEW_FLAG  VARCHAR2(1 BYTE),
  NEW_PERIOD_DATA_FLAG    VARCHAR2(1 BYTE),
  SCHEDULED_LOAD_DATE     DATE,
  SCHEDULED_LOAD_DATE_ID  NUMBER,
  UPDT_BY                 VARCHAR2(30 BYTE)     DEFAULT USER,
  LST_UPDT                DATE                  DEFAULT SYSDATE,
  ACTIVE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'Y',
  ACTIVE_DATE             DATE                  DEFAULT '01-JAN-1900',
  INACTIVE_DATE           DATE                  DEFAULT '31-DEC-2099',
  INSERT_BY               VARCHAR2(50 BYTE)     DEFAULT USER,
  INSERT_DATE             DATE                  DEFAULT SYSDATE,
  UPDATE_BY               VARCHAR2(50 BYTE),
  UPDATE_DATE             DATE                  DEFAULT '01-JAN-1900',
  DELETE_BY               VARCHAR2(50 BYTE),
  DELETE_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'N',
  DELETE_DATE             DATE                  DEFAULT '01-JAN-1900',
  HIDDEN_BY               VARCHAR2(50 BYTE),
  HIDDEN_FLAG             VARCHAR2(1 BYTE)      DEFAULT 'N',
  HIDDEN_DATE             DATE                  DEFAULT '01-JAN-1900',
  PROCESS_BATCH_ID        NUMBER
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_FACT_LD_SN_CNTRL IS 'PFSAWH_FACT_LD_SN_CNTRL - Identifies what niin are scheduled to be reloaded in the fact tables, or whne they were last reloaded. ';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.REC_ID IS 'REC_ID - Primary, blind key of the pfsawh_fact_ld_sn_cntrl table.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.LOAD_DATE IS 'LOAD_DATE - When the NIIN was reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.LOAD_DATE_ID IS 'LOAD_DATE_ID - Foreign key of the PFSAWH_DATE_DIM table when the NIIN was reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.SCHEDULED_LOAD_DATE_ID IS 'SCHEDULED_LOAD_DATE_ID - Foreign key of the PFSAWH_DATE_DIM table for when the NIIN is to be reloaded.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.ACTIVE_DATE IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.INACTIVE_DATE IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.UPDATE_DATE IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.DELETE_BY IS 'DELETE_BY - Reports who last deleted the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.HIDDEN_BY IS 'HIDDEN_BY - Reports who last hide the record.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_FACT_LD_SN_CNTRL.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- PK_PFSAWH_FACT_LD_SN_CNTRL  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_FACT_LD_SN_CNTRL ON PFSAWH_FACT_LD_SN_CNTRL
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_FACT_LD_SN_CNTRL  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_FACT_LD_SN_CNTRL ON PFSAWH_FACT_LD_SN_CNTRL
(PHYSICAL_ITEM_ID, PHYSICAL_ITEM_SN_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_FACT_LD_SN_CNTRL  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_FACT_LD_SN_CNTRL FOR PFSAWH_FACT_LD_SN_CNTRL;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_FACT_LD_SN_CNTRL 
-- 
ALTER TABLE PFSAWH_FACT_LD_SN_CNTRL ADD (
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_STATUS
 CHECK (status='C' OR status='W' OR status='Z'),
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_NEW_FL
 CHECK (serial_number_new_flag='N' OR serial_number_new_flag='Y'),
  CONSTRAINT CK_PFSAWH_FT_LD_SN_CTRL_DAT_FL
 CHECK (new_period_data_flag='N' OR new_period_data_flag='Y'),
  CONSTRAINT PK_PFSAWH_FACT_LD_SN_CNTRL
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT DELETE, INSERT, SELECT, UPDATE ON PFSAWH_FACT_LD_SN_CNTRL TO C_PFSAW_DB_IN;

GRANT SELECT ON PFSAWH_FACT_LD_SN_CNTRL TO S_PFSAW;

