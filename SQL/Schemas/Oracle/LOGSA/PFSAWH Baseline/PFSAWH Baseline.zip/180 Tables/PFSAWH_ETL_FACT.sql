--
-- PFSAWH_ETL_FACT  (Table) 
--
CREATE TABLE PFSAWH_ETL_FACT
(
  REC_ID               NUMBER                   NOT NULL,
  SRC_SCHEMA           VARCHAR2(30 BYTE)        NOT NULL,
  SRC_TABLE            VARCHAR2(30 BYTE)        NOT NULL,
  SRC_SNAPSHOOT_DATE   DATE,
  SRC_CNT              NUMBER,
  SRC_MAX_INSERT_DATE  DATE,
  SRC_MAX_LST_UPDT     DATE,
  WH_SNAPSHOOT_DATE    DATE,
  WH_CNT               NUMBER,
  WH_MAX_INSERT_DATE   DATE,
  WH_MAX_LST_UPDT      DATE,
  STATUS               VARCHAR2(1 BYTE)         DEFAULT 'C',
  UPDT_BY              VARCHAR2(30 BYTE)        DEFAULT USER,
  LST_UPDT             DATE                     DEFAULT SYSDATE,
  GRAB_STAMP           VARCHAR2(30 BYTE),
  PROC_STAMP           VARCHAR2(30 BYTE),
  ACTIVE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'Y',
  ACTIVE_DATE          DATE                     DEFAULT '01-JAN-1900',
  INACTIVE_DATE        DATE                     DEFAULT '31-DEC-2099',
  WH_RECORD_STATUS     VARCHAR2(10 BYTE),
  WH_LAST_UPDATE_DATE  DATE,
  WH_EFFECTIVE_DATE    DATE,
  WH_EXPIRATION_DATE   DATE,
  INSERT_BY            VARCHAR2(50 BYTE)        DEFAULT USER,
  INSERT_DATE          DATE                     DEFAULT SYSDATE,
  UPDATE_BY            VARCHAR2(50 BYTE),
  UPDATE_DATE          DATE                     DEFAULT '01-JAN-1900',
  DELETE_BY            VARCHAR2(50 BYTE),
  DELETE_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  DELETE_DATE          DATE                     DEFAULT '01-JAN-1900',
  HIDDEN_BY            VARCHAR2(50 BYTE),
  HIDDEN_FLAG          VARCHAR2(1 BYTE)         DEFAULT 'N',
  HIDDEN_DATE          DATE                     DEFAULT '01-JAN-1900'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--
-- PK_PFSAWH_ETL_FACT  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_ETL_FACT ON PFSAWH_ETL_FACT
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_ETL_FACT  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSAWH_ETL_FACT ON PFSAWH_ETL_FACT
(SRC_SCHEMA, SRC_TABLE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_ETL_FACT  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_ETL_FACT FOR PFSAWH_ETL_FACT;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_ETL_FACT 
-- 
ALTER TABLE PFSAWH_ETL_FACT ADD (
  CONSTRAINT CK_PFSAWH_ETL_FACT_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_ETL_FACT_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_ETL_FACT_HIDE_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSAWH_ETL_FACT_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_ETL_FACT
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_ETL_FACT TO S_PFSAW;

