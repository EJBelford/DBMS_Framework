--
-- PFSAWH_FORCE_UNIT_DIM  (Table) 
--
CREATE TABLE PFSAWH_FORCE_UNIT_DIM
(
  REC_ID                        NUMBER          NOT NULL,
  FORCE_UNIT_ID                 NUMBER          DEFAULT 0,
  UIC                           VARCHAR2(6 BYTE),
  UNIT_DESCRIPTION              VARCHAR2(55 BYTE),
  FORCE_PARENT_UNIT_ID          NUMBER          DEFAULT 0,
  COMPONENT_CODE                VARCHAR2(1 BYTE),
  COMPONENT_DESCRIPTION         VARCHAR2(50 BYTE),
  HOMESTATION_STATE_OR_COUNTRY  VARCHAR2(20 BYTE),
  D_DATE                        DATE,
  R_DATE                        DATE,
  S_DATE                        DATE,
  EDD1_DATE                     DATE,
  EDD2_DATE                     DATE,
  MRE_DATE                      DATE,
  DODAAC                        VARCHAR2(6 BYTE),
  ARI_LIST_REF_DATE             DATE,
  UNIT_IN_RESET                 VARCHAR2(12 BYTE),
  SORTS_UIC_STATUS              VARCHAR2(1 BYTE),
  MACOM                         VARCHAR2(10 BYTE),
  BCT_FORCE_UNIT_DIM_ID         NUMBER,
  BCT                           VARCHAR2(6 BYTE),
  BCT_DESCRIPTION               VARCHAR2(55 BYTE),
  BCT_ICON                      VARCHAR2(30 BYTE),
  BCT_LEVELS                    NUMBER,
  BCT_TREE_LEVEL                VARCHAR2(6 BYTE),
  BCT_UIC_IS_LEAF               VARCHAR2(3 BYTE),
  BCT_D_DATE                    DATE,
  BCT_R_DATE                    DATE,
  BCT_S_DATE                    DATE,
  BCT_EDD1_DATE                 DATE,
  BCT_EDD2_DATE                 DATE,
  BCT_MRE_DATE                  DATE,
  UTO_FORCE_UNIT_DIM_ID         NUMBER,
  UTO_UNIT_DESCRIPTION          VARCHAR2(55 BYTE),
  STATUS                        VARCHAR2(1 BYTE) DEFAULT 'N',
  UPDT_BY                       VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                      DATE            DEFAULT SYSDATE,
  ACTIVE_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'I',
  WH_RECORD_STATUS              VARCHAR2(10 BYTE),
  WH_EFFECTIVE_DATE             DATE,
  WH_EXPIRATION_DATE            DATE,
  INSERT_BY                     VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                   DATE            DEFAULT SYSDATE,
  UPDATE_BY                     VARCHAR2(30 BYTE),
  WH_LAST_UPDATE_DATE           DATE            DEFAULT '01-JAN-1900',
  DELETE_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'N',
  DELETE_DATE                   DATE            DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                   VARCHAR2(1 BYTE) DEFAULT 'Y',
  HIDDEN_DATE                   DATE            DEFAULT '01-JAN-1900',
  GEO_ID                        NUMBER          DEFAULT 0,
  PFSA_TPSN                     VARCHAR2(5 BYTE),
  PFSA_BRANCH                   VARCHAR2(2 BYTE),
  PFSA_PARENT_ORG               VARCHAR2(32 BYTE),
  PFSA_CMD_UIC                  VARCHAR2(6 BYTE),
  PFSA_PARENT_UIC               VARCHAR2(6 BYTE),
  PFSA_GEO_CD                   VARCHAR2(4 BYTE),
  PFSA_COMP_CD                  VARCHAR2(1 BYTE),
  PFSA_GOOF_UIC_IND             VARCHAR2(1 BYTE),
  DELETE_BY                     VARCHAR2(30 BYTE),
  HIDDEN_BY                     VARCHAR2(30 BYTE),
  PFSA_ORG                      VARCHAR2(32 BYTE),
  FORCE_PARENT_UNIT_CODE        VARCHAR2(6 BYTE),
  FORCE_COMMAND_UNIT_CODE       VARCHAR2(6 BYTE),
  FORCE_COMMAND_UNIT_ID         NUMBER,
  DIM_CODE                      VARCHAR2(6 BYTE)
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON TABLE PFSAWH_FORCE_UNIT_DIM IS 'PFSAWH_FORCE_UNIT_DIM - The force_unit_dim table contains one row for every UIC (Current or Historical) that has been transmitted to LOGSA via the asorts data feed from FORSCOM.  Each row contains various descriptive information about the UIC.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.REC_ID IS 'REC_ID - Sequence/identity for dimension.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.FORCE_UNIT_ID IS 'FORCE_UNIT_ID - Primary, blind key of the pfsawh_force_unit_dim table.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UIC IS 'UIC - UNIT IDENTIFICATION CODE (UIC) - A six-position, alphanumeric code that uniquely identifies a Department of Defense (DOD) organization as a "unit."  Each unit of the Active Army, Army Reserve, and Army National Guard is identified by a UIC.  The UIC is issued by the HQDA DCSOPS.  The UICs assigned parent unit is defined by HQDA and may be recognized by "AA" in the last two characters of the UIC.  UICs are constructed as follows:  Position 1 = Service Designator (all Army UICs start with a W); Positions 2 - 4 = Parent Organization Designator; Positions 5 - 6 = Descriptive Designator.  (UIC codes are prescribed by JCS Publication 6, AR 310-49, and AR 525-10.)';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UNIT_DESCRIPTION IS 'unit_description - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.FORCE_PARENT_UNIT_ID IS 'FORCE_PARENT_UNIT_ID - .';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.COMPONENT_CODE IS 'component_code - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.COMPONENT_DESCRIPTION IS 'component_description - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.HOMESTATION_STATE_OR_COUNTRY IS 'homestation_state_or_country - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.D_DATE IS 'd_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.R_DATE IS 'r_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.S_DATE IS 's_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.EDD1_DATE IS 'edd1_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.EDD2_DATE IS 'edd2_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.MRE_DATE IS 'mre_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.DODAAC IS 'dodaac - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.ARI_LIST_REF_DATE IS 'ari_list_ref_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UNIT_IN_RESET IS 'unit_in_reset - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.SORTS_UIC_STATUS IS 'sorts_uic_status - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.MACOM IS 'macom - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_FORCE_UNIT_DIM_ID IS 'bct_force_unit_dim_id - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT IS 'bct - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_DESCRIPTION IS 'bct_description - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_ICON IS 'bct_icon - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_LEVELS IS 'bct_levels - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_TREE_LEVEL IS 'bct_tree_level - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_UIC_IS_LEAF IS 'bct_uic_is_leaf - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_D_DATE IS 'bct_d_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_R_DATE IS 'bct_r_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_S_DATE IS 'bct_s_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_EDD1_DATE IS 'bct_edd1_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_EDD2_DATE IS 'bct_edd2_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.BCT_MRE_DATE IS 'bct_mre_date - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UTO_FORCE_UNIT_DIM_ID IS 'uto_force_unit_dim_id - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UTO_UNIT_DESCRIPTION IS 'uto_unit_description - ';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UPDT_BY IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.LST_UPDT IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.ACTIVE_FLAG IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.WH_RECORD_STATUS IS 'WH_RECORD_STATUS - Flag indicating if the record is active or not.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.WH_EFFECTIVE_DATE IS 'WH_EFFECTIVE_DATE - Additional control for ACTIVE_FL indicating when the record became active.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.WH_EXPIRATION_DATE IS 'WH_EXPIRATION_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.INSERT_BY IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.INSERT_DATE IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.UPDATE_BY IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.WH_LAST_UPDATE_DATE IS 'WH_LAST_UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.DELETE_FLAG IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.DELETE_DATE IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.HIDDEN_FLAG IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN PFSAWH_FORCE_UNIT_DIM.HIDDEN_DATE IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';


--
-- IDX_PFSAWH_FRCE_UNT_ID_UIC  (Index) 
--
CREATE INDEX IDX_PFSAWH_FRCE_UNT_ID_UIC ON PFSAWH_FORCE_UNIT_DIM
(FORCE_COMMAND_UNIT_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_FRCE_UNT_CMD_UIC  (Index) 
--
CREATE INDEX IDX_PFSAWH_FRCE_UNT_CMD_UIC ON PFSAWH_FORCE_UNIT_DIM
(FORCE_COMMAND_UNIT_CODE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_FRCE_UNT_STATUS  (Index) 
--
CREATE INDEX IDX_PFSAWH_FRCE_UNT_STATUS ON PFSAWH_FORCE_UNIT_DIM
(STATUS)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_FORCE_UNIT_DIM  (Index) 
--
CREATE INDEX IDX_PFSAWH_FORCE_UNIT_DIM ON PFSAWH_FORCE_UNIT_DIM
(UIC, STATUS, WH_EFFECTIVE_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSAWH_FRCE_UNT_DIM_CD  (Index) 
--
CREATE INDEX IXU_PFSAWH_FRCE_UNT_DIM_CD ON PFSAWH_FORCE_UNIT_DIM
(DIM_CODE, STATUS, WH_EFFECTIVE_DATE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PK_PFSAWH_FORCE_UNIT_DIM  (Index) 
--
CREATE UNIQUE INDEX PK_PFSAWH_FORCE_UNIT_DIM ON PFSAWH_FORCE_UNIT_DIM
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IDX_PFSAWH_FORCE_UNT_DIM_UNTID  (Index) 
--
CREATE INDEX IDX_PFSAWH_FORCE_UNT_DIM_UNTID ON PFSAWH_FORCE_UNIT_DIM
(FORCE_UNIT_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_FORCE_UNIT_DIM  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_FORCE_UNIT_DIM FOR PFSAWH_FORCE_UNIT_DIM;


-- 
-- Non Foreign Key Constraints for Table PFSAWH_FORCE_UNIT_DIM 
-- 
ALTER TABLE PFSAWH_FORCE_UNIT_DIM ADD (
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT CK_PFSAWH_FORCE_UNT_DIM_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT PK_PFSAWH_FORCE_UNIT_DIM
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

GRANT SELECT ON PFSAWH_FORCE_UNIT_DIM TO S_PFSAW;

