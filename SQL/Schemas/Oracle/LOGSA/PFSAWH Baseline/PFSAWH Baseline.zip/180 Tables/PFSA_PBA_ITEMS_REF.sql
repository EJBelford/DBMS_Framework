--
-- PFSA_PBA_ITEMS_REF  (Table) 
--
CREATE TABLE PFSA_PBA_ITEMS_REF
(
  REC_ID                      NUMBER            NOT NULL,
  PBA_ID                      NUMBER            DEFAULT -2,
  ITEM_IDENTIFIER_TYPE_ID     NUMBER            DEFAULT -2,
  ITEM_TYPE_VALUE             VARCHAR2(30 BYTE) DEFAULT 'unk',
  ITEM_FROM_DATE_ID           NUMBER,
  ITEM_TO_DATE_ID             NUMBER,
  ITEM_CHANGE_REASON_DESC     VARCHAR2(100 BYTE),
  ITEM_IMPLEMENTATION_LVL_CD  VARCHAR2(2 BYTE),
  PHYSICAL_ITEM_ID            NUMBER            DEFAULT 0,
  PHYSICAL_ITEM_SN_ID         NUMBER            DEFAULT 0,
  FORCE_UNIT_ID               NUMBER            DEFAULT 0,
  STATUS                      VARCHAR2(1 BYTE)  DEFAULT 'N',
  UPDT_BY                     VARCHAR2(30 BYTE) DEFAULT USER,
  LST_UPDT                    DATE              DEFAULT SYSDATE,
  ACTIVE_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'I',
  ACTIVE_DATE                 DATE              DEFAULT '01-JAN-1900',
  INACTIVE_DATE               DATE              DEFAULT '31-DEC-2099',
  INSERT_BY                   VARCHAR2(30 BYTE) DEFAULT USER,
  INSERT_DATE                 DATE              DEFAULT SYSDATE,
  UPDATE_BY                   VARCHAR2(30 BYTE),
  UPDATE_DATE                 DATE              DEFAULT '01-JAN-1900',
  DELETE_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'N',
  DELETE_DATE                 DATE              DEFAULT '01-JAN-1900',
  HIDDEN_FLAG                 VARCHAR2(1 BYTE)  DEFAULT 'Y',
  HIDDEN_DATE                 DATE              DEFAULT '01-JAN-1900',
  FORCE_PARENT_UNIT_ID        NUMBER            DEFAULT 0,
  TRFR_N_TO_S                 VARCHAR2(1 BYTE)  DEFAULT 'Y',
  TRFR_S_TO_N                 VARCHAR2(1 BYTE)  DEFAULT 'N'
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

COMMENT ON COLUMN PFSA_PBA_ITEMS_REF.STATUS IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN PFSA_PBA_ITEMS_REF.REC_ID IS 'REC_ID - Sequence/identity for the table.';

COMMENT ON COLUMN PFSA_PBA_ITEMS_REF.PBA_ID IS 'PBA_ID - PFSAW identitier for a particular Performance Based Agreement.';


--
-- PK_PFSA_PBA_ITEMS_REF  (Index) 
--
CREATE UNIQUE INDEX PK_PFSA_PBA_ITEMS_REF ON PFSA_PBA_ITEMS_REF
(REC_ID)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- IXU_PFSA_PBA_ITEMS_REF  (Index) 
--
CREATE UNIQUE INDEX IXU_PFSA_PBA_ITEMS_REF ON PFSA_PBA_ITEMS_REF
(PBA_ID, ITEM_IDENTIFIER_TYPE_ID, ITEM_TYPE_VALUE)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSA_PBA_ITEMS_REF  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSA_PBA_ITEMS_REF FOR PFSA_PBA_ITEMS_REF;


-- 
-- Non Foreign Key Constraints for Table PFSA_PBA_ITEMS_REF 
-- 
ALTER TABLE PFSA_PBA_ITEMS_REF ADD (
  CONSTRAINT CK_PFSA_ITEM_GL_MET_REF_STATUS
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ),
  CONSTRAINT CK_PFSA_ITEM_GL_MET_REF_ACT_FL
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y'),
  CONSTRAINT CK_PFSA_ITEM_GL_MET_REF_DEL_FL
 CHECK (delete_flag='N' OR delete_flag='Y'),
  CONSTRAINT CK_PFSA_ITEM_GL_MET_REF_HID_FL
 CHECK (hidden_flag='N' OR hidden_flag='Y'),
  CONSTRAINT PK_PFSA_PBA_ITEMS_REF
 PRIMARY KEY
 (REC_ID)
    USING INDEX 
    TABLESPACE PFSA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

-- 
-- Foreign Key Constraints for Table PFSA_PBA_ITEMS_REF 
-- 
ALTER TABLE PFSA_PBA_ITEMS_REF ADD (
  CONSTRAINT FK_PFSA_PBA_TYPE_ID_REF 
 FOREIGN KEY (ITEM_IDENTIFIER_TYPE_ID) 
 REFERENCES PFSA_PBA_TYPE_REF (REC_ID));

GRANT SELECT, UPDATE ON PFSA_PBA_ITEMS_REF TO C_PFSAW_ADMIN_IN;

GRANT SELECT ON PFSA_PBA_ITEMS_REF TO S_PFSAW;

