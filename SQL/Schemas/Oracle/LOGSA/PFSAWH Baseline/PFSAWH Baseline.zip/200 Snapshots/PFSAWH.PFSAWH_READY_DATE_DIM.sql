--
-- PFSAWH_READY_DATE_DIM  (Table) 
--
CREATE TABLE PFSAWH_READY_DATE_DIM
(
  DATE_DIM_ID  INTEGER,
  ORACLE_DATE  DATE,
  READY_DATE   DATE
)
TABLESPACE PFSA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--
-- I_SNAP$_PFSAWH_READY_DATE_  (Index) 
--
-- Note: Index I_SNAP$_PFSAWH_READY_DATE_ will be created automatically 
--       by Oracle with the associated materialized view.  The following
--       script for this index is for informational purposes only.
CREATE UNIQUE INDEX I_SNAP$_PFSAWH_READY_DATE_ ON PFSAWH_READY_DATE_DIM
(M_ROW$$)
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


--
-- PFSAWH_READY_DATE_DIM  (Synonym) 
--
CREATE PUBLIC SYNONYM PFSAWH_READY_DATE_DIM FOR PFSAWH_READY_DATE_DIM;


GRANT SELECT ON PFSAWH_READY_DATE_DIM TO S_PFSAW;

