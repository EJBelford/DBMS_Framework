/*--*----|----*----|----*----|----*----|---- TEAM ITSS ----|----*----|----*----|----*----|----*---*/
-- 
--         Table Name: cbmwh_processes
--         Table Desc: Contains a mapping to the name of the stored procedure or function
-- 
--   Table Created By: Gene Belford 
-- Table Created Date: 19 December 2007 
-- 
--       Table Source: cbmwh_processes.sql
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History: 
-- DDMMMYY - Who - Ticket # - CR # - Details 
-- 19Dec07 - GB  - 00000000 - 0000 - Created 
-- 
/*--*----|----*----|----*----|----*----|---- TEAM ITSS ----|----*----|----*----|----*----|----*---*/

/*----- Populate -----*/

BEGIN 

    INSERT INTO cbmwh_processes (process_Key, process_Description, status) 
        VALUES ( -1,   'not applicable', 'C');
        
    INSERT INTO cbmwh_processes (process_Key, process_Description, status) 
        VALUES (  1,   'pr_cbmwh_InsUpd_ProcessLog', 'C');
        
    INSERT INTO cbmwh_processes (process_Key, process_Description, status) 
        VALUES (  10,  'pr_cbmwh_Processlog_Cleanup', 'C');
        
    INSERT INTO cbmwh_processes (process_Key, process_Description, status) 
        VALUES (  11,  'pr_cbmwh_stdPfsaDebugTbl_Del', 'C');
        
    INSERT INTO cbmwh_processes (process_Key, process_Description, status) 
        VALUES (  100, 'maintain_cbm_warehouse', 'C'); 
    
    
    COMMIT;   

END;  
    
/*

SELECT * FROM cbmwh_processes; 

*/
