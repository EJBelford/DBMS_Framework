/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--               Name: cbmwh_xxx_insert 
--               Desc: Addition to the CBMWH_xxx table. 
--
--         Created By: Gene Belford 
--       Created Date: 06 June 2008   
--
--             Source: cbmwh_xxx_insert.sql
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 06JUN08 - GB  - RDR00xxx -      - Created 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/


BEGIN 

Insert into CBMWH_xxx
   (PROCESS_RECID, PROCESS_KEY, PROCESS_DESCRIPTION, STATUS, UPDT_BY, LST_UPDT, ACTIVE_FLAG, ACTIVE_DATE, INACTIVE_DATE, INSERT_BY, INSERT_DATE, UPDATE_DATE, DELETE_FLAG, DELETE_DATE, HIDDEN_FLAG, HIDDEN_DATE)
 Values
   (1006, 5103, 'tfrm_pfsa_maint_ilap', 'C', 'RDR00008', TO_DATE('05/15/2008 08:05:27', 'MM/DD/YYYY HH24:MI:SS'), 'Y', TO_DATE('05/15/2008 08:05:27', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/31/2099 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'RDR00008', TO_DATE('05/15/2008 08:05:27', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/01/1900 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'N', TO_DATE('01/01/1900 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'Y', TO_DATE('01/01/1900 00:00:00', 'MM/DD/YYYY HH24:MI:SS'));

COMMIT; 

END;
/ 
