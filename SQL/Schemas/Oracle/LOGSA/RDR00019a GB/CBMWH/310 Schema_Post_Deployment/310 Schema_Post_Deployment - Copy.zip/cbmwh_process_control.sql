/*--*----|----*----|----*----|----*----|---- TEAM ITSS ----|----*----|----*---*/
--
--         NAME: cbmwh_process_control
--      PURPOSE: To calculate the desired information.
--
-- TABLE SOURCE: cbmwh_process_control.sql
--
--   CREATED BY: Gene Belford
-- CREATED DATE: 02 JANUSRY 2008
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
/*--*----|----*----|----*----|----*----|---- TEAM ITSS ----|----*----|----*---*/

/*----- Populate -----*/

BEGIN 

    INSERT 
    INTO cbmwh_process_control 
        (
        process_control_name, process_control_value, process_control_description 
        ) 
    VALUES 
        ('v_keep_n_days_of_debug', '5', 'NOT APPLICABLE');
        
    INSERT 
    INTO cbmwh_process_control 
        (
        process_control_name, process_control_value, process_control_description 
        ) 
    VALUES 
        ('v_keep_n_days_of_log', '5', 'NOT APPLICABLE'); 
        
    COMMIT;     

END; 
/ 
    
/*

SELECT * FROM cbmwh_process_control; 

SELECT process_control_value
FROM   cbmwh_process_control 
WHERE  process_control_name = 'v_keep_n_days_of_debug' 
    AND status = 'C' 
    AND active_flag = 'Y' 
    AND sysdate BETWEEN active_date AND inactive_date; 

*/

