ALTER TABLE pfsawh_fact_ld_niin_cntrl
 ADD (
 process_batch_id                 NUMBER
 ); 
/ 

/* 29 Dec 2008 */ 

ALTER TABLE pfsawh_fact_ld_niin_cntrl
 ADD (
 reload_niin_process_time         NUMBER,
 pfsa_sn_ei_cnt                   NUMBER, 
 equip_avail_cnt                  NUMBER, 
 usage_event_cnt                  NUMBER, 
 maint_event_cnt                  NUMBER 
 ); 
/ 


