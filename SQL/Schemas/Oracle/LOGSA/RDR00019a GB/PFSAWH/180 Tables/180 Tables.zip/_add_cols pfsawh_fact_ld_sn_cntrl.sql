ALTER TABLE pfsawh_fact_ld_sn_cntrl
 ADD (
 process_batch_id                 NUMBER
 ); 
 
/ 