ALTER TABLE pfsa_maint_event
 ADD (
 maint_priority_desgn     VARCHAR2(2)
 ); 
/ 

