ALTER TABLE pfsawh_force_unit_dim 
-- 
-- RDR00019b --
-- 
 ADD (
 dim_code                 VARCHAR2(6)
 ); 
/ 

-- 
-- Non Foreign Key Constraints for Table PFSAWH_MAINT_ITM_WRK_FACT 
-- 

ALTER TABLE pfsawh_force_unit_dim 
    ADD (
        CONSTRAINT ixu_pfsawh_forc_unit_dim_cd
        UNIQUE (
            dim_code, 
            status, 
            wh_effective_date
            )
        );
        
--
-- IXU_PFSAWH_FORC_UNIT_DIM  (Index) 
--

-- DROP INDEX ixu_pfsawh_forc_unit_dim_cd; 

CREATE UNIQUE INDEX ixu_pfsawh_forc_unit_dim_cd 
-- 
-- RDR00019b --
-- 
ON pfsawh_force_unit_dim
    (
    dim_code, 
    status, 
    wh_effective_date
    )
LOGGING
TABLESPACE PFSA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;
/

ALTER TABLE pfsawh_force_unit_dim DISABLE ALL 

UPDATE pfsawh_force_unit_dim 
-- 
-- RDR00019b --
-- 
SET    dim_code = uic;
/ 

COMMIT;

