ALTER TABLE pfsa_maint_event_tmp
 ADD (
 maint_priority_desgn     VARCHAR2(2) 
 ); 
/ 

