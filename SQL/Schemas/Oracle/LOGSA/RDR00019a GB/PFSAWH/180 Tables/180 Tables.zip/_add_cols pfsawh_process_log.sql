ALTER TABLE pfsawh_process_log
 ADD (
 process_batch_id                 NUMBER
 ); 
 
/ 