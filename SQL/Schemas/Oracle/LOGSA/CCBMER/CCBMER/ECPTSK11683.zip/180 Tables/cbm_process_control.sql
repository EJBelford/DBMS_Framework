/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_process_control..
--      PURPOSE: This table is .. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: cbm_process_control.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_func_warn
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:42:43, and 01-Sep-2009 10:42:43
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_process_control;
    
CREATE TABLE cbm_process_control
(
process_control_id               NUMBER           NOT NULL,
process_control_name             VARCHAR2(65)     NOT NULL,
process_control_value            VARCHAR2(10)     NOT NULL,
process_control_description      VARCHAR2(100),
status                           VARCHAR2(1)      DEFAULT 'C',
updt_by                          VARCHAR2(30)     DEFAULT user,
lst_updt                         DATE             DEFAULT sysdate,
active_flag                      VARCHAR2(1)      DEFAULT 'Y',
active_date                      DATE             DEFAULT '01-JAN-1900',
inactive_date                    DATE             DEFAULT '31-DEC-2099',
insert_by                        VARCHAR2(30)     DEFAULT user,
insert_date                      DATE             DEFAULT sysdate,
update_by                        VARCHAR2(30),
update_date                      DATE             DEFAULT '01-JAN-1900',
delete_flag                      VARCHAR2(1)      DEFAULT 'N',
delete_date                      DATE             DEFAULT '01-JAN-1900',
hidden_flag                      VARCHAR2(1)      DEFAULT 'N',
hidden_date                      DATE             DEFAULT '01-JAN-1900'
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


COMMENT ON TABLE cbm_process_control 
IS 'CBM_PROCESS_CONTROL - Master process control table for PFSAWH to eliminate hard coding in processes. ';


COMMENT ON COLUMN cbm_process_control.PROCESS_CONTROL_ID 
IS 'PROCESS_CONTROL_ID - Record sequenece. ';

COMMENT ON COLUMN cbm_process_control.PROCESS_CONTROL_NAME 
IS 'PROCESS_CONTROL_NAME - Field name. ';

COMMENT ON COLUMN cbm_process_control.PROCESS_CONTROL_VALUE 
IS 'PROCESS_CONTROL_VALUE - The value used by other processes. ';

COMMENT ON COLUMN cbm_process_control.PROCESS_CONTROL_DESCRIPTION 
IS 'PROCESS_CONTROL_DESCRIPTION - Purpose/description of control field. ';

COMMENT ON COLUMN cbm_process_control.STATUS 
IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN cbm_process_control.UPDT_BY 
IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN cbm_process_control.LST_UPDT 
IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN cbm_process_control.ACTIVE_FLAG 
IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN cbm_process_control.ACTIVE_DATE 
IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN cbm_process_control.INACTIVE_DATE 
IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN cbm_process_control.INSERT_BY 
IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN cbm_process_control.INSERT_DATE 
IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN cbm_process_control.UPDATE_BY 
IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN cbm_process_control.UPDATE_DATE 
IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN cbm_process_control.DELETE_FLAG 
IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN cbm_process_control.DELETE_DATE 
IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN cbm_process_control.HIDDEN_FLAG 
IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN cbm_process_control.HIDDEN_DATE 
IS 'HIDDEN_DATE - Additional control for HIDDEN_FLAG indicating when the record was hidden.';
