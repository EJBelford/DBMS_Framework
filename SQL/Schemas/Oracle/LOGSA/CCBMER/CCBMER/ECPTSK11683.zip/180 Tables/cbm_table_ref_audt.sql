/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_table_ref_audt..
--      PURPOSE: Descriptive information..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: cbm_table_ref_audt.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_table_ref_audt;
	
CREATE TABLE cbm_table_ref_audt 
(
    rec_id                           NUMBER              NOT NULL ,
--
    update_by                        VARCHAR2(50)        NULL ,
    update_date                      DATE                NULL ,
-- 
    new_cbm_tabl_id                  NUMBER              NOT NULL ,
    old_cbm_tabl_id                  NUMBER              NULL ,
    new_cbm_tabl_nam                 VARCHAR2(50)        NOT  NULL , 
    old_cbm_tabl_nam                 VARCHAR2(50)        NULL , 
    new_cbm_cris_ver                 VARCHAR2(10) ,
    new_cbm_tabl_type                VARCHAR2(4) ,
    new_cbm_tabl_stat                VARCHAR2(1) ,
    new_cbm_tabl_cloe_flag           VARCHAR2(1) ,
    new_cbm_tabl_colm_cnt            NUMBER ,
    new_cbm_tabl_row_cnt             NUMBER ,
    new_cbm_tabl_lst_updt            DATE ,
    new_cbm_tabl_lst_push            DATE ,
    old_cbm_cris_ver                 VARCHAR2(10) ,
    old_cbm_tabl_type                VARCHAR2(4) ,
    old_cbm_tabl_stat                VARCHAR2(1) ,
    old_cbm_tabl_cloe_flag           VARCHAR2(1) ,
    old_cbm_tabl_colm_cnt            NUMBER ,
    old_cbm_tabl_row_cnt             NUMBER ,
    old_cbm_tabl_lst_updt            DATE ,
    old_cbm_tabl_lst_push            DATE  
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_table_ref_audt 
IS 'CBM_TABLE_REF_AUDT - '; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN cbm_table_ref_audt.rec_id 
IS 'REC_ID - Primary, blind key from the cbm_table_ref table.'; 

COMMENT ON COLUMN cbm_table_ref_audt.update_by 
IS 'UPDATE_BY - Reports who updated the record.';

COMMENT ON COLUMN cbm_table_ref_audt.update_date 
IS 'UPDATE_DATE - Reports when the record was updated.';


