/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_process_control_audt..
--      PURPOSE: Descriptive information..
--
--   CREATED BY: Gene Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: cbm_process_control_audt.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName%
--    Sysdate:         %SYSDATE%
--    Date and Time:   %DATE%, %TIME%, and %DATETIME%
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor)
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_process_control_audt;
    
CREATE TABLE cbm_process_control_audt 
(
    process_control_id               NUMBER              NOT NULL ,
--
    update_by                        VARCHAR2(50)        NULL ,
    update_date                      DATE                NULL ,
-- Do a replace of the xx to create base table.. 
    new_process_control_name         VARCHAR2(65) ,
    old_process_control_name         VARCHAR2(65) ,
    new_process_control_value        VARCHAR2(10) ,
    old_process_control_value        VARCHAR2(10) ,
    new_process_control_desc         VARCHAR2(100) ,
    old_process_control_desc         VARCHAR2(100) ,
    new_status                       VARCHAR2(1) , 
    old_status                       VARCHAR2(1) ,
    new_active_flag                  VARCHAR2(1) , 
    old_active_flag                  VARCHAR2(1) 
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_process_control_audt 
IS 'CBM_ORICESS_CONTROL_AUDT - '; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN cbm_process_control_audt.process_control_id 
IS 'PROCESS_CONTROL_ID - Primary, blind key from the %YourObjectName% table.'; 

COMMENT ON COLUMN cbm_process_control_audt.update_by 
IS 'UPDATE_BY - Reports who updated the record.';

COMMENT ON COLUMN cbm_process_control_audt.update_date 
IS 'UPDATE_DATE - Reports when the record was updated.';

