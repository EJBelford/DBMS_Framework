/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_bus_rule_type..
--      PURPOSE: ..
--
--   CREATED BY: L. Johnson..
-- CREATED DATE: 01/04/2010..
--
--       SOURCE: bfh_bus_rule_type.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 01-JAN-2010 - L. Johnson  - ECPTSK11681 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

CREATE TABLE bfh_bus_rule_type
(
  BFH_BR_TYPE    NUMBER                         NOT NULL,
  BFH_BR_NAME    VARCHAR2(256 BYTE)             NOT NULL,
  BFH_BR_DESC    VARCHAR2(1000 BYTE)            NOT NULL,
  BFH_USER       NUMBER                         NOT NULL,
  STATUS         VARCHAR2(1 BYTE)               NOT NULL,
  LST_UPDT       DATE                           DEFAULT TO_DATE( '01-JAN-1900', 'DD-MON-YYYY' ),
  UPDT_BY        VARCHAR2(30 BYTE),
  ACTIVE_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'Y',
  ACTIVE_DATE    DATE                           DEFAULT TO_DATE( '01-JAN-1900', 'DD-MON-YYYY' ),
  INACTIVE_DATE  DATE                           DEFAULT TO_DATE( '31-DEC-2099', 'DD-MON-YYYY' ),
  INSERT_BY      VARCHAR2(30 BYTE)              DEFAULT user,
  INSERT_DATE    DATE                           DEFAULT sysdate,
  UPDATE_BY      VARCHAR2(30 BYTE),
  UPDATE_DATE    DATE                           DEFAULT TO_DATE( '01-JAN-1900', 'DD-MON-YYYY' ),
  DELETE_BY      VARCHAR2(30 BYTE),
  DELETE_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'N',
  DELETE_DATE    DATE                           DEFAULT TO_DATE( '01-JAN-1900', 'DD-MON-YYYY' ),
  HIDDEN_BY      VARCHAR2(30 BYTE),
  HIDDEN_FLAG    VARCHAR2(1 BYTE)               DEFAULT 'N',
  HIDDEN_DATE    DATE                           DEFAULT TO_DATE( '01-JAN-1900', 'DD-MON-YYYY' )
);


