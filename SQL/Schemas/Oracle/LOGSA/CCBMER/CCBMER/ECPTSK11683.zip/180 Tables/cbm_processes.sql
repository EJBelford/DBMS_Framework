/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--
--         Table Name: cbm_processes..
--         Table Desc:  
-- 
--   Table Created By: Gene Belford..
-- Table Created Date: 23 November 2009..
--
--       Table Source: cbm_processes.sql 
--
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 23MOV09 - GB  - 00000000 - 0000 - Created 
-- 
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/

-- DROP TABLE cbm_processes; 

CREATE TABLE cbm_processes
(
cbm_process                      VARCHAR2(32),
last_run                         DATE,
who_ran                          VARCHAR2(32),
last_run_status                  VARCHAR2(10),
last_run_status_time             DATE,
last_run_compl                   DATE
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


COMMENT ON TABLE cbm_processes 
IS 'CBM_PROCESSES - PRODUCTION DATE 25 Sep 2004.  This table contains all top level processes used to maintain the PFSA world, as well as individual load and maintenance procedures.  Individual load and maintenance procedures are called by one of these processes.  This processes should be initiated via unix scheduler for production cases.  Once called, controlling processes will trigger the appropriate processes to be ran.';


COMMENT ON COLUMN cbm_processes.CBM_PROCESS 
IS 'CBM_PROCESS - A unique identifier for ORACLE based processes';

COMMENT ON COLUMN cbm_processes.LAST_RUN 
IS 'LAST_RUN - The specific sysdate value of the time the process was last ran';

COMMENT ON COLUMN cbm_processes.WHO_RAN 
IS 'WHO_RAN - Indicates the calling process if called via some structured and ordered process';

COMMENT ON COLUMN cbm_processes.LAST_RUN_STATUS 
IS 'LAST_RUN_STATUS - Indicates the status of the process being ran';

COMMENT ON COLUMN cbm_processes.LAST_RUN_STATUS_TIME 
IS 'LAST_RUN_STATUS_TIME - The time stamp of the last_run_status';

COMMENT ON COLUMN cbm_processes.LAST_RUN_COMPL 
IS 'LAST_RUN_COMPL - Indicates the sysdate value of the time the process last successfully completed';


--
-- PK_PFSA_PROCESSES  (Index) 
--
CREATE UNIQUE INDEX pk_cbm_processes 
    ON cbm_processes
        (
        cbm_process
        )
LOGGING
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

