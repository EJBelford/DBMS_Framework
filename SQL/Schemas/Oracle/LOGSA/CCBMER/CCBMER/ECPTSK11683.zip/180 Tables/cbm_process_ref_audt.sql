/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_process_ref_audt..
--      PURPOSE: Descriptive information..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 16 November 2009..
--
--       SOURCE: cbm_process_ref_audt.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_process_ref
--    Sysdate:         %SYSDATE%
--    Date and Time:   %DATE%, %TIME%, and %DATETIME%
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor)
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_process_ref_audt;
    
CREATE TABLE cbm_process_ref_audt 
(
    process_recid                    NUMBER              NOT NULL ,
--
    update_by                        VARCHAR2(50)        NULL ,
    update_date                      DATE                NULL ,
    old_process_key                  NUMBER,
    new_process_key                  NUMBER,
    old_process_description          VARCHAR2(50),
    new_process_description          VARCHAR2(50),
    old_status                       VARCHAR2(1),
    new_status                       VARCHAR2(1),
    old_run_cntrl                    NUMBER,
    new_run_cntrl                    NUMBER,
    old_override_run_cntrl           VARCHAR2(1),
    new_override_run_cntrl           VARCHAR2(1),
    old_debug_on_flag                VARCHAR2(1),
    new_debug_on_flag                VARCHAR2(1)
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_process_ref_audt 
IS 'CBM_PROCESS_REF_AUDT - '; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN cbm_process_ref_audt.process_recid 
IS 'PROCESS_RECID - Primary, blind key from the cbm_process_ref table.'; 

COMMENT ON COLUMN cbm_process_ref_audt.update_by 
IS 'UPDATE_BY - Reports who updated the record.';

COMMENT ON COLUMN cbm_process_ref_audt.update_date 
IS 'UPDATE_DATE - Reports when the record was updated.';

