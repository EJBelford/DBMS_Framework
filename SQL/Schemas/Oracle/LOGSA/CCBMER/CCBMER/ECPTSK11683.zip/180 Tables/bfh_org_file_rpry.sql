/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_org_file_rpry..
--      PURPOSE: This tables contains the primary information on all files 
--               received by LOGSA for CBM use..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 11/23/2009..
--
--       SOURCE: bfh_org_file_rpry.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 23-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE bfh_org_file_rpry CASCADE CONSTRAINTS;  

CREATE TABLE bfh_org_file_rpry
(
rec_id                    NUMBER           NOT NULL,
bfh_src_file_nam          VARCHAR2(50)     NOT NULL,
bfh_src_file_crea_date    DATE, 
bfh_src_file_recv_date    DATE,
bfh_src_file_size         NUMBER, 
bfh_file_b32_id           VARCHAR2(32)     NOT NULL,
macom_abbr                VARCHAR2(2),
ecc                       VARCHAR2(2),
yr_mon                    VARCHAR2(4),
spar_01                   VARCHAR2(2),
bfh_file_id               NUMBER,
bfh_file_desc             VARCHAR2(200)    DEFAULT 'unk',
mimosa_enterprise_id      VARCHAR2(8)      DEFAULT '00000430',
mimosa_site_id            VARCHAR2(8)      DEFAULT '00000001',
mimosa_item_sn_id         VARCHAR2(8)      DEFAULT '00000000',
start_timestamp_utc       DATE,
stop_timestamp_utc        DATE,
user_id_tag               VARCHAR2(1000),
checksum                  NUMBER,
counter                   NUMBER,
physical_item_id          NUMBER           DEFAULT 0,
physical_item_sn_id       NUMBER           DEFAULT 0,
item_niin                 VARCHAR2(9)      DEFAULT '000000000',
item_serial_number        VARCHAR2(48)     DEFAULT '-1',
item_sn_w_dashes          VARCHAR2(48),
item_sn_wo_dashes         VARCHAR2(48),
oem_mimosa_enterprise_id  VARCHAR2(8)      DEFAULT '00000000',
oem_mimosa_site_id        VARCHAR2(8)      DEFAULT '00000000',
oem_mimosa_item_sn_id     VARCHAR2(8)      DEFAULT '00000000',
status                    VARCHAR2(1)      DEFAULT 'C',
updt_by                   VARCHAR2(30)     DEFAULT USER,
lst_updt                  DATE             DEFAULT SYSDATE,
grab_stamp                VARCHAR2(30),
proc_stamp                VARCHAR2(30),
active_flag               VARCHAR2(1)      DEFAULT 'Y',
active_date               DATE             DEFAULT '01-JAN-1900',
inactive_date             DATE             DEFAULT '31-DEC-2099',
wh_record_status          VARCHAR2(10),
wh_last_update_date       DATE,
wh_effective_date         DATE,
wh_expiration_date        DATE,
source_rec_id             NUMBER,
insert_by                 VARCHAR2(50)     DEFAULT USER,
insert_date               DATE             DEFAULT SYSDATE,
lst_update_rec_id         NUMBER,
update_by                 VARCHAR2(50),
update_date               DATE             DEFAULT '01-JAN-1900',
delete_by                 VARCHAR2(50),
delete_flag               VARCHAR2(1)      DEFAULT 'N',
delete_date               DATE             DEFAULT '01-JAN-1900',
hidden_by                 VARCHAR2(50),
hidden_flag               VARCHAR2(1)      DEFAULT 'N',
hidden_date               DATE             DEFAULT '01-JAN-1900',
trfr_n_to_s               VARCHAR2(1)      DEFAULT 'N',
trfr_s_to_n               VARCHAR2(1)      DEFAULT 'N' 
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE bfh_org_file_rpry 
IS 'BFH_ORG_FILE_RPRY - This tables contains the primary information on all files received by LOGSA for CBM use'; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN bfh_org_file_rpry.rec_id 
IS 'REC_ID - Primary, blind key of the bfh_org_file_rpry table.'; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_src_file_nam 
IS 'BFH_SRC_FILE_NAM  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_src_file_crea_date 
IS 'BFH_SRC_FILE_CREA_DATE - If available in the file, the date the file was created at the source.'; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_src_file_recv_date 
IS 'BFH_SRC_FILE_RECV_DATE - The date received at the LOGSA receiving dock.'; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_src_file_size 
IS 'BFH_SRC_FILE_SIZE - The size of the file when received at the LOGSA receiving dock.'; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_file_b32_id 
IS 'BFH_FILE_B32_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.macom_abbr 
IS 'MACOM_ABBR - '; 

COMMENT ON COLUMN bfh_org_file_rpry.ecc 
IS 'ECC - '; 

COMMENT ON COLUMN bfh_org_file_rpry.yr_mon 
IS 'YR_MON  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.spar_01 
IS 'SPAR_01  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_file_id 
IS 'BFH_FILE_ID  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.bfh_file_desc 
IS 'BFH_FILE_DESC - '; 

COMMENT ON COLUMN bfh_org_file_rpry.mimosa_enterprise_id 
IS 'MIMOSA_ENTERPRISE_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.mimosa_site_id 
IS 'MIMOSA_SITE_ID  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.mimosa_item_sn_id 
IS 'MIMOSA_ITEM_SN_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.start_timestamp_utc 
IS 'START_TIMESTAMP_UTC - '; 

COMMENT ON COLUMN bfh_org_file_rpry.stop_timestamp_utc 
IS 'STOP_TIMESTAMP_UTC - '; 

COMMENT ON COLUMN bfh_org_file_rpry.user_id_tag 
IS 'USER_ID_TAG - '; 

COMMENT ON COLUMN bfh_org_file_rpry.checksum 
IS 'CHECKSUM  - '; 

COMMENT ON COLUMN bfh_org_file_rpry.counter 
IS 'COUNTER - '; 

COMMENT ON COLUMN bfh_org_file_rpry.physical_item_id 
IS 'PHYSICAL_ITEM_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.physical_item_sn_id 
IS 'PHYSICAL_ITEM_SN_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.item_niin 
IS 'ITEM_NIIN - '; 

COMMENT ON COLUMN bfh_org_file_rpry.item_serial_number 
IS 'ITEM_SERIAL_NUMBER - '; 

COMMENT ON COLUMN bfh_org_file_rpry.item_sn_w_dashes 
IS 'ITEM_SN_W_DASHES - '; 

COMMENT ON COLUMN bfh_org_file_rpry.item_sn_wo_dashes 
IS 'ITEM_SN_WO_DASHES - '; 

COMMENT ON COLUMN bfh_org_file_rpry.oem_mimosa_enterprise_id 
IS 'OEM_MIMOSA_ENTERPRISE_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.oem_mimosa_site_id 
IS 'OEM_MIMOSA_SITE_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.oem_mimosa_item_sn_id 
IS 'OEM_MIMOSA_ITEM_SN_ID - '; 

COMMENT ON COLUMN bfh_org_file_rpry.status 
IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN bfh_org_file_rpry.updt_by 
IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN bfh_org_file_rpry.lst_updt 
IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN bfh_org_file_rpry.grab_stamp 
IS 'GRAB_STAMP - The date and time the record entered the PFSA world.  The actual value is the sysdate when the PFSA grab procedure that populated a PFSA table (BLD, POTENTIAL or production) table for the first time in PFSA.  When the record move from "BLD to POTENITAL" or "BLD to production" the grab_date does not change.';

COMMENT ON COLUMN bfh_org_file_rpry.proc_stamp 
IS 'PROC_STAMP - The date timestamp (sysdate) of the promotion action.  ie: "BLD to POTENITAL" or "BLD to production"';       

COMMENT ON COLUMN bfh_org_file_rpry.active_flag 
IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN bfh_org_file_rpry.active_date 
IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN bfh_org_file_rpry.inactive_date 
IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN bfh_org_file_rpry.wh_record_status 
IS 'WH_RECORD_STATUS - Flag indicating if the record is active or not.';

COMMENT ON COLUMN bfh_org_file_rpry.wh_last_update_date 
IS 'WH_LAST_UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN bfh_org_file_rpry.wh_effective_date 
IS 'WH_EFFECTIVE_DATE - Additional control for WH_RECORD_STATUS indicating when the record became active.';

COMMENT ON COLUMN bfh_org_file_rpry.wh_expiration_date 
IS 'WH_EXPIRATION_DATE - Additional control for WH_RECORD_STATUS indicating when the record went inactive.';

COMMENT ON COLUMN bfh_org_file_rpry.source_rec_id 
IS 'SOURCE_REC_ID - Identifier to the orginial record received from a outside source.';       

COMMENT ON COLUMN bfh_org_file_rpry.insert_by 
IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN bfh_org_file_rpry.insert_date 
IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN bfh_org_file_rpry.lst_update_rec_id 
IS 'LST_UPDATE_REC_ID - Identifier to the last update record received from an outside source.';       

COMMENT ON COLUMN bfh_org_file_rpry.update_by 
IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN bfh_org_file_rpry.update_date 
IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN bfh_org_file_rpry.delete_by 
IS 'DELETE_BY - Reports who last deleted the record.';       

COMMENT ON COLUMN bfh_org_file_rpry.delete_flag 
IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN bfh_org_file_rpry.delete_date 
IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN bfh_org_file_rpry.hidden_by 
IS 'HIDDEN_BY - Reports who last hide the record.';       

COMMENT ON COLUMN bfh_org_file_rpry.hidden_flag 
IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN bfh_org_file_rpry.hidden_date 
IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN bfh_org_file_rpry.trfr_n_to_s 
IS 'TRFR_N_TO_S - TRFR_N_TO_S - Record needs to be moved from NIPR to SIPR.';

COMMENT ON COLUMN bfh_org_file_rpry.trfr_s_to_n 
IS 'TRFR_S_TO_N - TRFR_S_TO_N - Record needs to be moved from SIPR to NIPR.';

/*----- Check to see if the table comment is present -----*/
/*
SELECT table_name, comments 
FROM   user_tab_comments 
WHERE  table_name = UPPER('bfh_org_file_rpry'); 
*/
/*----- Check to see if the table column comments are present -----*/
/*
SELECT  b.column_id, 
        a.table_name, 
        a.column_name, 
        b.data_type, 
        b.data_length, 
        b.nullable, 
        b.data_default,  
        a.comments 
--        , '|', b.*  
FROM    user_col_comments a
LEFT OUTER JOIN user_tab_columns b ON b.table_name = UPPER('bfh_org_file_rpry') 
    AND  a.column_name = b.column_name
WHERE    a.table_name = UPPER('bfh_org_file_rpry') 
ORDER BY b.column_id; 
*/
/*----- Look-up field description from master LIDB table -----*/
/*
SELECT a.* 
FROM   lidb_cmnt@pfsawh.lidbdev a
WHERE  a.col_name LIKE UPPER('%supply%')
ORDER BY a.col_name; 
/ 
*/
/*   
SELECT a.* 
FROM   user_col_comments a
WHERE  a.column_name LIKE UPPER('%rec_id%'); 
/ 
*/

