/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_func_warn..
--      PURPOSE: This table is used to post warnings for the PFSA functional 
--               team.  Warnings are generally reported as exceptions to 
--               processing as well as to data integrity issues.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: cbm_func_warn.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_func_warn
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:42:43, and 01-Sep-2009 10:42:43
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_func_warn;
	
CREATE TABLE cbm_func_warn 
(
    rec_id                           NUMBER              NOT NULL ,
--
    warning_type                     VARCHAR2(32),
    warning_from                     VARCHAR2(100),
    warning_msg                      VARCHAR2(2000),
    warning_status                   VARCHAR2(1),
    warning_time                     DATE,
    updt_by                          VARCHAR2(30),
    lst_updt                         DATE,
    action_taken                     VARCHAR2(2000)
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_func_warn 
IS 'CBM_FUNC_WARN - This table is used to post warnings for the PFSA functional team.  Warnings are generally reported as exceptions to processing as well as to data integrity issues. '; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN cbm_func_warn.rec_id 
IS 'REC_ID - Primary, blind key of the cbm_func_warn table.'; 

COMMENT ON COLUMN cbm_func_warn.WARNING_TYPE 
IS 'WARNING_TYPE - PROCESSING/DATA INTEGRITY/REVIEW REQUIRED/tbd as indicated by raising object';

COMMENT ON COLUMN cbm_func_warn.WARNING_FROM 
IS 'WARNING_FROM - Should contain the raising object name with the entire called by string';

COMMENT ON COLUMN cbm_func_warn.WARNING_MSG 
IS 'WARNING_MSG - What the exception was that needs to be deal with. ';

COMMENT ON COLUMN cbm_func_warn.WARNING_STATUS 
IS 'WARNING_STATUS - C for current and H for historical';

COMMENT ON COLUMN cbm_func_warn.WARNING_TIME 
IS 'WARNING_TIME - The date/time stamp of when the warning was generate';

COMMENT ON COLUMN cbm_func_warn.UPDT_BY 
IS 'UPDT_BY - User that last updated this record';

COMMENT ON COLUMN cbm_func_warn.LST_UPDT 
IS 'LST_UPDT - Date of last update';

COMMENT ON COLUMN cbm_func_warn.ACTION_TAKEN 
IS 'ACTION_TAKEN - Action taken by user';

/*----- Check to see if the table comment is present -----*/
/*
SELECT table_name, comments 
FROM   user_tab_comments 
WHERE  table_name = UPPER('cbm_func_warn'); 
*/
/*----- Check to see if the table column comments are present -----*/
/*
SELECT  b.column_id, 
        a.table_name, 
        a.column_name, 
        b.data_type, 
        b.data_length, 
        b.nullable, 
        b.data_default,  
        a.comments 
--        , '|', b.*  
FROM    user_col_comments a
LEFT OUTER JOIN user_tab_columns b ON b.table_name = UPPER('cbm_func_warn') 
    AND  a.column_name = b.column_name
WHERE    a.table_name = UPPER('cbm_func_warn') 
ORDER BY b.column_id; 
*/
/*----- Look-up field description from master LIDB table -----*/
/*
SELECT a.* 
FROM   lidb_cmnt@pfsawh.lidbdev a
WHERE  a.col_name LIKE UPPER('%supply%')
ORDER BY a.col_name; 
/ 
*/
/*   
SELECT a.* 
FROM   user_col_comments a
WHERE  a.column_name LIKE UPPER('%rec_id%'); 
/ 
*/

