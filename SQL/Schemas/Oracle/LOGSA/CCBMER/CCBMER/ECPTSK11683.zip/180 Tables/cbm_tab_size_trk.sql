/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--
--         Table Name: cbm_tab_size_trk..
--         Table Desc:  
-- 
--   Table Created By: Gene Belford..
-- Table Created Date: 23 November 2009..
--
--       Table Source: cbm_tab_size_trk.sql 
--
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 16MOV09 - GB  - 00000000 - 0000 - Created 
-- 
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/

-- DROP TABLE cbm_tab_size_trk; 

CREATE TABLE cbm_tab_size_trk
(
table_name                       VARCHAR2(32),
chk_date                         DATE,
num_of_rows                      NUMBER,
last_analysis                    DATE
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

