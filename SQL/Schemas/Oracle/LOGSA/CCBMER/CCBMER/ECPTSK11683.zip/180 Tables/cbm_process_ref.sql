/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--
--         Table Name: cbm_process_ref..
--         Table Desc:  
-- 
--   Table Created By: Gene Belford..
-- Table Created Date: 18 November 2009..
--
--       Table Source: cbm_process_ref.sql 
--
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 18MOV09 - GB  - 00000000 - 0000 - Created 
-- 
/*----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*----|----*--*/

-- DROP TABLE cbm_process_ref; 

CREATE TABLE cbm_process_ref
(
process_recid        NUMBER                   NOT NULL,
process_key          NUMBER                   NOT NULL,
process_description  VARCHAR2(50 BYTE)        NOT NULL,
run_cntrl            NUMBER,
override_run_cntrl   VARCHAR2(1 BYTE)         DEFAULT 'N',
debug_on_flag        VARCHAR2(1 BYTE)         DEFAULT 'N',
status               VARCHAR2(1 BYTE)         DEFAULT 'N',
updt_by              VARCHAR2(30 BYTE)        DEFAULT user,
lst_updt             DATE                     DEFAULT sysdate,
active_flag          VARCHAR2(1 BYTE)         DEFAULT 'I',
active_date          DATE                     DEFAULT '01-JAN-1900',
inactive_date        DATE                     DEFAULT '31-DEC-2099',
insert_by            VARCHAR2(30 BYTE)        DEFAULT user,
insert_date          DATE                     DEFAULT sysdate,
update_by            VARCHAR2(30 BYTE),
update_date          DATE                     DEFAULT '01-JAN-1900',
delete_flag          VARCHAR2(1 BYTE)         DEFAULT 'N',
delete_date          DATE                     DEFAULT '01-JAN-1900',
hidden_flag          VARCHAR2(1 BYTE)         DEFAULT 'N',
hidden_date          DATE                     DEFAULT '01-JAN-1900'
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


COMMENT ON TABLE cbm_process_ref 
IS 'CBM_PROCESS_REF - Contains a mapping to the name of the stored procedure or function';


COMMENT ON COLUMN cbm_process_ref.STATUS 
IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN cbm_process_ref.UPDT_BY 
IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN cbm_process_ref.LST_UPDT 
IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN cbm_process_ref.ACTIVE_FLAG 
IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN cbm_process_ref.ACTIVE_DATE 
IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN cbm_process_ref.INACTIVE_DATE 
IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN cbm_process_ref.INSERT_BY 
IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN cbm_process_ref.INSERT_DATE 
IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN cbm_process_ref.UPDATE_BY 
IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN cbm_process_ref.UPDATE_DATE 
IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN cbm_process_ref.DELETE_FLAG 
IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN cbm_process_ref.DELETE_DATE 
IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN cbm_process_ref.HIDDEN_FLAG 
IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN cbm_process_ref.HIDDEN_DATE 
IS 'HIDDEN_DATE- Additional control for HIDDEN_FLAG indicating when the record was hidden.';
