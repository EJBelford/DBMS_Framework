/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_org_file_rpry_audt..
--      PURPOSE: Descriptive information..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 11/23/2009..
--
--       SOURCE: bfh_org_file_rpry_audt.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 11/23/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE bfh_org_file_rpry_audt;
	
CREATE TABLE bfh_org_file_rpry_audt 
(
    rec_id                           NUMBER              NOT NULL ,
--
    update_by                        VARCHAR2(50)        NULL ,
    update_date                      DATE                NULL ,
-- Do a replace of the xx to create base table.. 
    new_xx_code                      NUMBER              NOT NULL ,
    old_xx_code                      NUMBER              NULL ,
    new_xx_desc                      VARCHAR2(50)        NOT  NULL , 
    old_xx_desc                      VARCHAR2(50)        NULL 
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE bfh_org_file_rpry_audt 
IS 'bfh_org_file_rpry_audt - '; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN bfh_org_file_rpry_audt.rec_id 
IS 'REC_ID - Primary, blind key from the bfh_org_file_rpry table.'; 

COMMENT ON COLUMN bfh_org_file_rpry_audt.update_by 
IS 'UPDATE_BY - Reports who updated the record.';

COMMENT ON COLUMN bfh_org_file_rpry_audt.update_date 
IS 'UPDATE_DATE - Reports when the record was updated.';

