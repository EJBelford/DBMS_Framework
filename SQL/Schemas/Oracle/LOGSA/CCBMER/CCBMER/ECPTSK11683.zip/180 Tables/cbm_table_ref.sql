/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_table_ref..
--      PURPOSE: Descriptive information about the MIMOSA tables needed for 
--               automated management and processing..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: cbm_table_ref.sql..
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create Table  -----*/

-- DROP TABLE cbm_table_ref;
	
CREATE TABLE cbm_table_ref 
(
    rec_id                           NUMBER              NOT NULL ,
--
    cbm_cris_ver                     VARCHAR2(10)        DEFAULT '3.2.1' ,
    cbm_tabl_id                      NUMBER              DEFAULT 0 ,
    cbm_tabl_nam                     VARCHAR2(30)        DEFAULT 'unk' ,
    cbm_tabl_type                    VARCHAR2(4) ,
    cbm_tabl_stat                    VARCHAR2(1)         DEFAULT 'Z' ,
    cbm_tabl_flag                    VARCHAR2(1)         DEFAULT 'Y' ,
    cbm_tabl_cloe_flag               VARCHAR2(1)         DEFAULT 'N' ,
    cbm_tabl_colm_cnt                NUMBER              DEFAULT 0 ,
    cbm_tabl_row_cnt                 NUMBER              DEFAULT 0 ,
    cbm_tabl_nam_audt                VARCHAR2(30) ,
    cbm_tabl_lst_updt                DATE ,
    cbm_tabl_lst_push                DATE ,
--
    status                           VARCHAR2(1)         DEFAULT 'Z' ,
    updt_by                          VARCHAR2(50)        DEFAULT SUBSTR(USER, 1, 50) ,
    lst_updt                         DATE                DEFAULT SYSDATE ,
--
    grab_stamp                       DATE                NULL ,
    proc_stamp                       DATE                NULL ,
--
    active_flag                      VARCHAR2(1)         DEFAULT 'Y' , 
    active_date                      DATE                DEFAULT TO_DATE('01-JAN-1900', 'DD-MON-YYYY') , 
    inactive_date                    DATE                DEFAULT TO_DATE('31-DEC-2099', 'DD-MON-YYYY') ,
--
    wh_record_status                 VARCHAR2(10)        NULL , 
    wh_last_update_date              DATE                NULL ,
    wh_effective_date                DATE                NULL , 
    wh_expiration_date               DATE                NULL ,
--
    source_rec_id                    NUMBER              NOT NULL ,
    insert_by                        VARCHAR2(50)        DEFAULT SUBSTR(USER, 1, 50) , 
    insert_date                      DATE                DEFAULT SYSDATE , 
    lst_update_rec_id                NUMBER              NOT NULL ,
    update_by                        VARCHAR2(50)        NULL ,
    update_date                      DATE                DEFAULT TO_DATE('01-JAN-1900', 'DD-MON-YYYY') ,
    delete_by                        VARCHAR2(50)        NULL ,
    delete_flag                      VARCHAR2(1)         DEFAULT 'N' ,
    delete_date                      DATE                DEFAULT TO_DATE('01-JAN-1900', 'DD-MON-YYYY') ,
    hidden_by                        VARCHAR2(50)        NULL ,
    hidden_flag                      VARCHAR2(1)         DEFAULT 'N' ,
    hidden_date                      DATE                DEFAULT TO_DATE('01-JAN-1900', 'DD-MON-YYYY') ,
--
    trfr_n_to_s                      VARCHAR2(1)         DEFAULT 'N' ,
    trfr_s_to_n                      VARCHAR2(1)         DEFAULT 'N' ,
    cbm_tabl_desc                    VARCHAR2(4000)    
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_table_ref 
IS 'CBM_TABLE_REF - Descriptive information about the MIMOSA tables needed for automated management and processing.'; 


/*----- Column Meta-Data -----*/ 

COMMENT ON COLUMN cbm_table_ref.rec_id 
IS 'REC_ID - Primary, blind key of the cbm_table_ref table.'; 

COMMENT ON COLUMN cbm_table_ref.cbm_cris_ver 
IS 'CBM_CRIS_VER - MIMOSA CRS schema version ';

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_id 
IS 'CBM_TABL_ID - Blind key in case the table name should be changed.'; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_nam 
IS 'CBM_TABL_NAM - Mimosa table name.'; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_type 
IS 'CBM_TABL_TYPE - 4-character code for the type of MIMOSA table.  Use to determine the type processing to be done on it.  CHLD - child  DATA - data  ENUM - enumerator  reg -   SEG - segment  TYPE - type '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_stat 
IS 'CBM_TABL_STAT - 1-character code for the status of MIMOSA table.  C - current  A - altered  N - new  P - proposed  H - historical  D - deleted '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_flag 
IS 'CBM_TABL_FLAG -  '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_cloe_flag 
IS 'CBM_TABL_CLOE_FLAG - 1-character flag indicating if the MIMOSA table is in the CLOE SV-11, the defualt is No.  N - No  Y - Yes '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_colm_cnt 
IS 'CBM_TABL_COLM_CNT - Number of columns in this table for this particular version of the CRIS version. '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_row_cnt 
IS 'CBM_TABL_ROW_CNT - Number of rows currently in the MIMOSA table. '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_lst_updt 
IS 'CBM_TABL_LST_UPDT - The last time a row was updated in the given MIMOSA baseline table. '; 

COMMENT ON COLUMN cbm_table_ref.cbm_tabl_lst_push 
IS 'CBM_TABL_LST_PUSH - The last time the MIMOSA baseline table was pushed to the MIMOSA view.  '; 

COMMENT ON COLUMN cbm_table_ref.status 
IS 'STATUS - The Extract-Transform-Load (ETL) status of the record in question.  [C - Current, D - Duplicate, E - Error, H - Historical, L - Logical, P - Processed, Q - Questionable, R - Ready to Process, T- ?????, Z - Future]';

COMMENT ON COLUMN cbm_table_ref.updt_by 
IS 'UPDT_BY - The date/timestamp of when the record was created/updated.';

COMMENT ON COLUMN cbm_table_ref.lst_updt 
IS 'LST_UPDT - Indicates either the program name or user ID of the person who updated the record.';

COMMENT ON COLUMN cbm_table_ref.grab_stamp 
IS 'GRAB_STAMP - The date and time the record entered the PFSA world.  The actual value is the sysdate when the PFSA grab procedure that populated a PFSA table (BLD, POTENTIAL or production) table for the first time in PFSA.  When the record move from "BLD to POTENITAL" or "BLD to production" the grab_date does not change.';

COMMENT ON COLUMN cbm_table_ref.proc_stamp 
IS 'PROC_STAMP - The date timestamp (sysdate) of the promotion action.  ie: "BLD to POTENITAL" or "BLD to production"';       

COMMENT ON COLUMN cbm_table_ref.active_flag 
IS 'ACTIVE_FLAG - Flag indicating if the record is active or not.';

COMMENT ON COLUMN cbm_table_ref.active_date 
IS 'ACTIVE_DATE - Additional control for active_Fl indicating when the record became active.';

COMMENT ON COLUMN cbm_table_ref.inactive_date 
IS 'INACTIVE_DATE - Additional control for active_Fl indicating when the record went inactive.';

COMMENT ON COLUMN cbm_table_ref.wh_record_status 
IS 'WH_RECORD_STATUS - Flag indicating if the record is active or not.';

COMMENT ON COLUMN cbm_table_ref.wh_last_update_date 
IS 'WH_LAST_UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN cbm_table_ref.wh_effective_date 
IS 'WH_EFFECTIVE_DATE - Additional control for WH_RECORD_STATUS indicating when the record became active.';

COMMENT ON COLUMN cbm_table_ref.wh_expiration_date 
IS 'WH_EXPIRATION_DATE - Additional control for WH_RECORD_STATUS indicating when the record went inactive.';

COMMENT ON COLUMN cbm_table_ref.source_rec_id 
IS 'SOURCE_REC_ID - Identifier to the orginial record received from a outside source.';       

COMMENT ON COLUMN cbm_table_ref.insert_by 
IS 'INSERT_BY - Reports who initially created the record.';

COMMENT ON COLUMN cbm_table_ref.insert_date 
IS 'INSERT_DATE - Reports when the record was initially created.';

COMMENT ON COLUMN cbm_table_ref.lst_update_rec_id 
IS 'LST_UPDATE_REC_ID - Identifier to the last update record received from an outside source.';       

COMMENT ON COLUMN cbm_table_ref.update_by 
IS 'UPDATE_BY - Reports who last updated the record.';

COMMENT ON COLUMN cbm_table_ref.update_date 
IS 'UPDATE_DATE - Reports when the record was last updated.';

COMMENT ON COLUMN cbm_table_ref.delete_by 
IS 'DELETE_BY - Reports who last deleted the record.';       

COMMENT ON COLUMN cbm_table_ref.delete_flag 
IS 'DELETE_FLAG - Flag indicating if the record can be deleted.';

COMMENT ON COLUMN cbm_table_ref.delete_date 
IS 'DELETE_DATE - Additional control for DELETE_FLAG indicating when the record was marked for deletion.';

COMMENT ON COLUMN cbm_table_ref.hidden_by 
IS 'HIDDEN_BY - Reports who last hide the record.';       

COMMENT ON COLUMN cbm_table_ref.hidden_flag 
IS 'HIDDEN_FLAG - Flag indicating if the record should be hidden from the general user in things like drop-down lists.';

COMMENT ON COLUMN cbm_table_ref.hidden_date 
IS 'HIDDEN_DATE - Addition control for HIDDEN_FLAG indicating when the record was hidden.';

COMMENT ON COLUMN cbm_table_ref.trfr_n_to_s 
IS 'TRFR_N_TO_S - TRFR_N_TO_S - Record needs to be moved from NIPR to SIPR.';

COMMENT ON COLUMN cbm_table_ref.trfr_s_to_n 
IS 'TRFR_S_TO_N - TRFR_S_TO_N - Record needs to be moved from SIPR to NIPR.';

/*----- Check to see if the table comment is present -----*/
/*
SELECT table_name, comments 
FROM   user_tab_comments 
WHERE  table_name = UPPER('cbm_table_ref'); 
*/
/*----- Check to see if the table column comments are present -----*/
/*
SELECT  b.column_id, 
        a.table_name, 
        a.column_name, 
        b.data_type, 
        b.data_length, 
        b.nullable, 
        b.data_default,  
        a.comments 
--        , '|', b.*  
FROM    user_col_comments a
LEFT OUTER JOIN user_tab_columns b ON b.table_name = UPPER('cbm_table_ref') 
    AND  a.column_name = b.column_name
WHERE    a.table_name = UPPER('cbm_table_ref') 
ORDER BY b.column_id; 
*/
/*----- Look-up field description from master LIDB table -----*/
/*
SELECT a.* 
FROM   lidb_cmnt@pfsawh.lidbdev a
WHERE  a.col_name LIKE UPPER('%supply%')
ORDER BY a.col_name; 
/ 
*/
/*   
SELECT a.* 
FROM   user_col_comments a
WHERE  a.column_name LIKE UPPER('%rec_id%'); 
/ 
*/

