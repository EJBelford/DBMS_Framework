/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_val_tabl...
--      PURPOSE: Stores command scripts to execute dynamically.
--
-- TABLE SOURCE: cbm_val_tabl.sql...
--
--   CREATED BY: Gene Belford...
-- CREATED DATE: 16 November 2009...
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 16NOV09 - GB  -                 - Created..
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- value Table  -----*/

-- DROP TABLE cbm_val_tabl;
	
--
CREATE TABLE cbm_val_tabl 
(
rec_id                           NUMBER,
table_name                       VARCHAR2(32)    NOT NULL, 
seq_no                           NUMBER          NOT NULL,
str_insert_value                 VARCHAR2(4000)  NOT NULL, 
source_id                        VARCHAR2(32) 
)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

/*----- Table Meta-Data -----*/ 

COMMENT ON TABLE cbm_val_tabl 
IS 'CBM_VAL_TABL - Stores command scripts to execute dynamically. '; 


COMMENT ON COLUMN cbm_val_tabl.rec_id 
IS 'REC_ID - Primary, blind key of the cbm_val_tabl table. '; 

COMMENT ON COLUMN cbm_val_tabl.table_name 
IS 'TABLE_NAME - The name of the table to be transfered. '; 

COMMENT ON COLUMN cbm_val_tabl.seq_no 
IS 'SEQ_NO - The order statements are to be executed. '; 

COMMENT ON COLUMN cbm_val_tabl.str_insert_value 
IS 'STR_INSERT_VALUE - The value TABLE statement for the table being transfered. ';

COMMENT ON COLUMN cbm_val_tabl.source_id 
IS 'SOURCE_ID - A PFSA team generated identification of the source of data.  Values used should be short to allow for concatenation of a more specific source, such as a site using a specific reporting system.. ';


/*----- Check to see if the table comment is present -----*/
/*
SELECT table_name, comments 
FROM   user_tab_comments 
WHERE  table_name = UPPER('cbm_val_tabl'); 
*/
/*----- Check to see if the table column comments are present -----*/
/*
SELECT  b.column_id, 
        a.table_name, 
        a.column_name, 
        b.data_type, 
        b.data_length, 
        b.nullable, 
        b.data_default,  
        a.comments 
--        , '|', b.*  
FROM    user_col_comments a
LEFT OUTER JOIN user_tab_columns b ON b.table_name = UPPER('cbm_val_tabl') 
    AND  a.column_name = b.column_name
WHERE    a.table_name = UPPER('cbm_val_tabl') 
ORDER BY b.column_id; 
*/
/*----- Look-up field description from master LIDB table -----*/
/*
SELECT a.* 
FROM   lidb_cmnt@pfsawh.lidbdev a
WHERE  a.col_name LIKE UPPER('%supply%')
ORDER BY a.col_name; 
/ 
   
SELECT a.* 
FROM   user_col_comments a
WHERE  a.column_name LIKE UPPER('%source_id%'); 
/ 
*/
