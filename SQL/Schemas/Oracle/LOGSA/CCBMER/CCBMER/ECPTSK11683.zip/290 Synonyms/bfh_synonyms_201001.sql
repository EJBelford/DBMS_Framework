/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_synonym_201001..
--      PURPOSE: Create synonyn for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 01/04/2010..
--
--       SOURCE: synonym_201001.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 04-DEC-2010 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 290 - Synonyms -----*/   

CREATE PUBLIC SYNONYM bfh_bus_rules            FOR ccbmer.bfh_bus_rules;
CREATE PUBLIC SYNONYM bfh_bus_rule_type        FOR ccbmer.bfh_bus_rule_type;
CREATE PUBLIC SYNONYM bfh_mod_det              FOR ccbmer.bfh_mod_det;
CREATE PUBLIC SYNONYM bfh_module_type          FOR ccbmer.bfh_module_type;
CREATE PUBLIC SYNONYM bfh_modules              FOR ccbmer.bfh_modules;

CREATE PUBLIC SYNONYM bfh_org_file_rpry        FOR ccbmer.bfh_org_file_rpry; 
CREATE PUBLIC SYNONYM bfh_org_file_rpry_audt   FOR ccbmer.bfh_org_file_rpry_audt

-- CREATE PUBLIC SYNONYM bfh_org_file_rpry_hist   FOR ccbmer.bfh_org_file_rpry_hist;
CREATE PUBLIC SYNONYM bfh_templates            FOR ccbmer.bfh_templates;
CREATE PUBLIC SYNONYM bfh_tmplt_det            FOR ccbmer.bfh_tmplt_det;
CREATE PUBLIC SYNONYM bfh_user                 FOR ccbmer.bfh_user;
