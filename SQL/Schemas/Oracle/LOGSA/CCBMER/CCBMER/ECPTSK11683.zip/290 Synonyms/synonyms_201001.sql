/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: synonym_201001..
--      PURPOSE: Create synonyn for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: synonym_201001.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009  - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 290 - Synonyms -----*/   

CREATE PUBLIC SYNONYM cbm_cmd_tabl             FOR ccbmer.cbm_cmd_tabl; 
CREATE PUBLIC SYNONYM cbm_crea_tabl            FOR ccbmer.cbm_crea_tabl; 
CREATE PUBLIC SYNONYM cbm_func_warn            FOR ccbmer.cbm_func_warn; 
CREATE PUBLIC SYNONYM cbm_process_control      FOR ccbmer.cbm_process_control; 
CREATE PUBLIC SYNONYM cbm_process_control_audt FOR ccbmer.cbm_process_control_audt; 
CREATE PUBLIC SYNONYM cbm_process_log          FOR ccbmer.cbm_process_log; 
CREATE PUBLIC SYNONYM cbm_process_ref          FOR ccbmer.cbm_process_ref; 
CREATE PUBLIC SYNONYM cbm_process_ref_audt     FOR ccbmer.cbm_process_ref_audt; 
CREATE PUBLIC SYNONYM cbm_processes            FOR ccbmer.cbm_processes;
CREATE PUBLIC SYNONYM cbm_processes_hist       FOR ccbmer.cbm_processes_hist; 
CREATE PUBLIC SYNONYM cbm_tab_size_trk         FOR ccbmer.cbm_tab_size_trk;
CREATE PUBLIC SYNONYM cbm_table_ref            FOR ccbmer.cbm_table_ref;
CREATE PUBLIC SYNONYM cbm_table_ref_audt       FOR ccbmer.cbm_table_ref_audt;
CREATE PUBLIC SYNONYM cbm_user_hist            FOR ccbmer.cbm_user_hist; 
CREATE PUBLIC SYNONYM cbm_val_tabl             FOR ccbmer.cbm_val_tabl; 
CREATE PUBLIC SYNONYM std_cbm_debug_tbl        FOR ccbmer.std_cbm_debug_tbl; 


