/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_org_file_rpry_seq..
--      PURPOSE: REC_ID sequence for bfh_org_file_rpry..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 01/04/2010..
--
--       SOURCE: bfh_org_file_rpry.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 04-JAN-2010 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Sequence  -----*/

-- DROP SEQUENCE bfh_org_file_rpry_seq;

CREATE SEQUENCE bfh_org_file_rpry_seq
    START WITH 1 
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

