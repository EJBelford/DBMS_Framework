/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_func_warn..
--      PURPOSE: REC_ID sequence for cbm_func_warn..
--               This table is used to post warnings for the functional 
--               team.  Warnings are generally reported as exceptions to 
--               processing as well as to data integrity issues.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 16-Nov-2009..
--
--       SOURCE: cbm_func_warn_seq.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_func_warn
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:42:43, and 01-Sep-2009 10:42:43
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequence  -----*/

-- DROP SEQUENCE cbm_func_warn_seq;

CREATE SEQUENCE cbm_func_warn_seq
    START WITH 1 
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

