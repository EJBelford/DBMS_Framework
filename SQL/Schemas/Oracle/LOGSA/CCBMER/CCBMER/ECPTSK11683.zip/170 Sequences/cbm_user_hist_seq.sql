/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_user_hist..
--      PURPOSE: REC_ID sequence for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: cbm_user_hist.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009  
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009 - G. Belford   - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequences  -----*/

-- DROP SEQUENCE cbm_user_hist_seq;

CREATE SEQUENCE cbm_user_hist_seq
    START WITH 1
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

