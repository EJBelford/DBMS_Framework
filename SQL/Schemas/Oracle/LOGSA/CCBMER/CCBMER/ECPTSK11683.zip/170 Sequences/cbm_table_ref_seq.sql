/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_table_ref..
--      PURPOSE: REC_ID sequence for cbm_table_ref..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 16-Nov-2009..
--
--       SOURCE: cbm_table_ref.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequence  -----*/

-- DROP SEQUENCE cbm_table_ref_seq;

CREATE SEQUENCE cbm_table_ref_seq
    START WITH 1
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

