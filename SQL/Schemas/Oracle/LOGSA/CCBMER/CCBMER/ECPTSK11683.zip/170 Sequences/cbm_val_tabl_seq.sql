/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_val_tabl_seq 
--      PURPOSE: REC_ID sequence for cbm_val_tabl.
--
-- TABLE SOURCE: cbm_table_seq.sql  
--
--   CREATED BY: Gene Belford 
-- CREATED DATE: 16 November 2009 
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 16NOV09 - GB  - ECPTSK11683     - Created..
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequence  -----*/

-- DROP SEQUENCE cbm_val_tabl_seq;

CREATE SEQUENCE cbm_val_tabl_seq
    START WITH 1
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

