/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_cmd_tabl_seq..
--      PURPOSE: REC_ID sequence for cbm_crea_tabl..
--
-- TABLE SOURCE: cbm_cmd_table..  
--
--   CREATED BY: Gene Belford.. 
-- CREATED DATE: 16 Nowember 2009.. 
--
--  ASSUMPTIONS:
--
--  LIMITATIONS:
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 16NOV09 - GB  - ECPTSK11683     - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequence  -----*/

-- DROP SEQUENCE cbm_cmd_tabl_seq ;

CREATE SEQUENCE cbm_cmd_tabl_seq 
    START WITH 1
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER; 

