/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_process_log_seq..
--      PURPOSE: REC_ID sequence for cbm_process_log..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 16 November 2009..
--
--       SOURCE: cbm_process_log_seq.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName%
--    Sysdate:         %SYSDATE%
--    Date and Time:   %DATE%, %TIME%, and %DATETIME%
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor)
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 170 - Sequence  -----*/

-- DROP SEQUENCE cbm_process_log_seq;

CREATE SEQUENCE cbm_process_log_seq
    START WITH 1
    MINVALUE   1
    NOCYCLE
    NOCACHE
    NOORDER;
