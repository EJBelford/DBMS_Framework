/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: grant_201001..
--      PURPOSE: Create grants for MIMOSA (views)..
--
--   CREATED BY: G. Belford..
--       Created Date: 21 December 2009    
--
--       SOURCE: Grants_201001.sql..
--
--        NOTES:
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     std_mimosa_bl_debug_tbl
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:02:59, and 01-Sep-2009 10:02:59
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 21-Dec-2009 - G. Belford  - ECPTSK11681 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 110 DBA_Pre_Deployment - Grants -----*/

GRANT EXECUTE ON utl_file              TO ccbmer; 

GRANT EXECUTE ON admin2.broadcastemail TO ccbmer;
