/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--               Name: bfh_roles_201001.. 
--               Desc: Inital role setup for CCBMER..  
--
--         Created By: Gene Belford.. 
--       Created Date: 04 January 2010..   
--
--             Source: bfh_roles_201001.sql..  
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YY - Who - Ticket # - CR # - Details
-- 04-JAN-10 - GB  - ECPTSK11683     - Created 
-- 07-JAN-10 - GB  - ECPTSK11683     - Typo with the initial CREATE 
--                                     ROLE e_cbm_bfh_vw_dml_sprt
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/

----- MIMOSA_BL ----- 

-- 110 dba_pre_deployment --

-- s_         - read only (select)..
-- c_         - change/combo (select, insert, update)..
-- e_         - execute (select, insert, update, execute) ..
-- cbm_       - Groups the collect of objects used for CBM..
-- mimosa_bl_ - Schema name 
-- remaining text is descriptive..

CREATE ROLE s_cbm_bfh_read_only     NOT IDENTIFIED; 
CREATE ROLE c_cbm_bfh_admin_sprt    NOT IDENTIFIED; 
CREATE ROLE e_cbm_bfh_dml_sprt      NOT IDENTIFIED; 

-- Typo with the initial 

DROP ROLE e_cbm_bfh_vw_dml_spr; 
