/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_grant_201001..
--      PURPOSE: Create grants for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 04 January 2010..
--
--       SOURCE: bfh_grant_201001.sql..
--
--        NOTES:
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 04-JAN-2010 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 300 - Grants -----*/

GRANT SELECT                          ON bfh_bus_rules               TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_bus_rules               TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_bus_rules               TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_bus_rule_type           TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_bus_rule_type           TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_bus_rule_type           TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_mod_det                 TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_mod_det                 TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_mod_det                 TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_module_type             TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_module_type             TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_module_type             TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_modules                 TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_modules                 TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_modules                 TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_org_file_rpry           TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_org_file_rpry           TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_org_file_rpry           TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_org_file_rpry_audt      TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_org_file_rpry_audt      TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_org_file_rpry_audt      TO e_cbm_bfh_dml_sprt;

-- GRANT SELECT                          ON bfh_org_file_rpry_hist      TO s_cbm_bfh_read_only;
-- GRANT SELECT, INSERT, UPDATE          ON bfh_org_file_rpry_hist      TO c_cbm_bfh_admin_sprt;
-- GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_org_file_rpry_hist      TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_templates               TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_templates               TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_templates               TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_tmplt_det               TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_tmplt_det               TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_tmplt_det               TO e_cbm_bfh_dml_sprt;

GRANT SELECT                          ON bfh_user                    TO s_cbm_bfh_read_only;
GRANT SELECT, INSERT, UPDATE          ON bfh_user                    TO c_cbm_bfh_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON bfh_user                    TO e_cbm_bfh_dml_sprt;
