/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: grant_201001..
--      PURPOSE: Create grants for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: grant_201001.sql..
--
--        NOTES:
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009  - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 300 - Grants -----*/

GRANT SELECT                          ON cbm_cmd_tabl                TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_cmd_tabl                TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_cmd_tabl                TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_crea_tabl               TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_crea_tabl               TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_crea_tabl               TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_func_warn               TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_func_warn               TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_func_warn               TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_process_control         TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_process_control         TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_process_control         TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_process_control_audt    TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_process_control_audt    TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_process_control_audt    TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_process_log             TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_process_log             TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_process_log             TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_process_ref             TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_process_ref             TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_process_ref             TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_process_ref_audt        TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_process_ref_audt        TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_process_ref_audt        TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_processes               TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_processes               TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_processes               TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_processes_hist          TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_processes_hist          TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_processes_hist          TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_tab_size_trk            TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_tab_size_trk            TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_tab_size_trk            TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_table_ref               TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_table_ref               TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_table_ref               TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_table_ref_audt          TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_table_ref_audt          TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_table_ref_audt          TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_user_hist               TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_user_hist               TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_user_hist               TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON cbm_val_tabl                TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON cbm_val_tabl                TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON cbm_val_tabl                TO e_cbm_ccbmer_dml_sprt;

GRANT SELECT                          ON std_cbm_debug_tbl           TO s_cbm_ccbmer_read_only;
GRANT SELECT, INSERT, UPDATE          ON std_cbm_debug_tbl           TO c_cbm_ccbmer_admin_sprt;
GRANT SELECT, INSERT, UPDATE, DELETE  ON std_cbm_debug_tbl           TO e_cbm_ccbmer_dml_sprt;
