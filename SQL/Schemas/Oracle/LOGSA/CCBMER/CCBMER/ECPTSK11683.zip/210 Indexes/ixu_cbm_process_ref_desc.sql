--
-- IXU_cbm_process_ref_DESC  (Index) 
--
CREATE UNIQUE INDEX ixu_cbm_process_ref_desc 
ON cbm_process_ref
    (
    process_description
    );

