---------------------------------------------------------------------BFH_MODULES---------------

CREATE INDEX idx_bfh_modules ON bfh_modules
(bfh_mod_id);

