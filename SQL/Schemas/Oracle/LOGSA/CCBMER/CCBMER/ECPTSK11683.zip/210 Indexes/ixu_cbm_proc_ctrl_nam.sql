--
-- PK_cbm_process_control  (Index) 
--

CREATE UNIQUE INDEX ixu_cbm_proc_ctrl_nam 
ON cbm_process_control
    (
    process_control_name
    );


