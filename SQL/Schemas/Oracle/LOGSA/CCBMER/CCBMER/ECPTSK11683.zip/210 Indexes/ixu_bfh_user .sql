----------------------------------------------------------------------- BFH_USER----------------

CREATE UNIQUE INDEX ixu_bfh_user ON bfh_user
(bfh_user);

