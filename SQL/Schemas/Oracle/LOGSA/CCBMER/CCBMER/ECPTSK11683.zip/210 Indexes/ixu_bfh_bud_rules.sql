-----------------------------------------------BFH_BUS_RULES------------------------------

CREATE UNIQUE INDEX ixu_bfh_bus_rules ON bfh_bus_rules
(bfh_br_id);


