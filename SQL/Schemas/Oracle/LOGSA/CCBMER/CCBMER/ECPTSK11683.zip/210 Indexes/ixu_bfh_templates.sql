----------------------------------------------------------------BFH_TEMPLATES----------------

CREATE UNIQUE INDEX ixu_bfh_templates ON bfh_templates
(bfh_tmpflt_id);

