/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_table_ref..
--      PURPOSE: Unique index for ixu_cbm_table_ref..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: ixu_cbm_tabl_ref_ver_nam.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Indexs -----*/

-- DROP INDEX ixu_cbm_table_id;

CREATE UNIQUE INDEX ixu_cbm_tabl_ref_ver_nam 
    ON cbm_table_ref
        (
        cbm_cris_ver , 
        cbm_tabl_nam
        );
