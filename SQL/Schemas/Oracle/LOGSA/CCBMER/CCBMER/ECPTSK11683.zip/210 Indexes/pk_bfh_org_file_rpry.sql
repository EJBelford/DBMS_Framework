/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_org_file_rpry..
--      PURPOSE: Primary key for bfh_org_file_rpry..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 11/23/2009..
--
--       SOURCE: pk_bfh_org_file_rpry.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 11/23/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Primary Key -----*/

ALTER TABLE bfh_org_file_rpry  
    ADD CONSTRAINT pk_bfh_org_file_rpry 
    PRIMARY KEY 
    (
    rec_id
    );
    
