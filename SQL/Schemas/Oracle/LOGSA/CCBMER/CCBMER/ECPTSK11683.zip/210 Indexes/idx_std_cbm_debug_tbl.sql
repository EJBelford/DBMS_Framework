/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: std_cbm_debug_tbl..
--      PURPOSE: Index for idx_std_cbm_debug_tbl..
--               Used in MIMOSA_BL processing to capture unexpected errors in 
--               processing as well as general program debugging during 
--               development.  Production systems should expect no records to 
--               be created.  Creation of a record is considerred a problem.. 
--               The design was taken from PFSA.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: ixu_std_cbm_debug_tbl.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     std_cbm_debug_tbl
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:02:59, and 01-Sep-2009 10:02:59
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Indexs -----*/

-- DROP INDEX idx_std_cbm_debug_tbl;

CREATE INDEX idx_std_cbm_debug_tbl 
    ON std_cbm_debug_tbl
        (
        msg_dt DESC
        );
