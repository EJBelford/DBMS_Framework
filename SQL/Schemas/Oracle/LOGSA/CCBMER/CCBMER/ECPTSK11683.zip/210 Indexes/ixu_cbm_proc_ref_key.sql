--
-- IXU_cbm_process_ref  (Index) 
--
CREATE UNIQUE INDEX ixu_cbm_proc_ref_key 
ON cbm_process_ref
    (
    process_key
    );


