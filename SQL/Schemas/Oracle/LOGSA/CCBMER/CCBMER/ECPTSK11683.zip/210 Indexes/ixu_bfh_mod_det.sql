---------------------------------------------------------------------BFH_MOD_DET---------------

CREATE UNIQUE INDEX  ixu_bfh_mod_det ON bfh_mod_det
(bfh_mod_id, bfh_mod_seq);

