--
-- IXU_CBM_BLANK_DIM  (Index) 
--

CREATE UNIQUE INDEX ixu_cbm_proc_ctrl_id 
ON cbm_process_control
    (
    process_control_id
    );


