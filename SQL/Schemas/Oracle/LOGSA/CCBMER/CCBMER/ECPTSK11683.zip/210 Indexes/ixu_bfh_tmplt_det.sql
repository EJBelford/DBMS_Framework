----------------------------------------------------------------BFH_TMPLT_DET----------------

CREATE UNIQUE INDEX ixu_bfh_tmplt_det ON bfh_tmplt_det
(bfh_tmplt_id, bfh_tmplt_seq_no);

