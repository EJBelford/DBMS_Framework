---------------------------------------------------------------------BFH_MODULE_TYPE-----------

CREATE UNIQUE INDEX ixu_bfh_module_type ON bfh_module_type
(bfh_mod_typ_id);

