-----------------------------------------------BFH_BUS_RULE_TYPE------------------------------

CREATE UNIQUE INDEX ixu_bfh_bus_rule_type ON bfh_bus_rule_type
(bfh_br_type);

