--
-- IXU_cbm_process_ref_ID  (Index) 
--
CREATE UNIQUE INDEX ixu_cbm_proc_ref_recid 
ON cbm_process_ref
    (
    process_recid
    );


