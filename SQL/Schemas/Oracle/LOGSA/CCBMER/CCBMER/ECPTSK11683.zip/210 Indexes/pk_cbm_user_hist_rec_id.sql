/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_user_hist..
--      PURPOSE: Primary key for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: pk_cbm_user_hist_rec_id.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 210 - Indexes -----*/

ALTER TABLE cbm_user_hist  
    ADD CONSTRAINT pk_cbm_user_hist_rec_id 
    PRIMARY KEY 
    (
    rec_id
    );
    
   
