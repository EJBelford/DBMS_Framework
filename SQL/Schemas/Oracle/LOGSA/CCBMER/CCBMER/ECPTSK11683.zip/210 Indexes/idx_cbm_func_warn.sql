/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_func_warn..
--      PURPOSE: Index for ixu_cbm_func_warn..
--               This table is used to post warnings for the PFSA functional 
--               team.  Warnings are generally reported as exceptions to 
--               processing as well as to data integrity issues.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: idx_cbm_func_warn.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_func_warn
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:42:43, and 01-Sep-2009 10:42:43
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Indexs -----*/

-- DROP INDEX idx_cbm_func_warn;

CREATE INDEX idx_cbm_func_warn 
    ON cbm_func_warn
        (
        rec_id DESC
        );
