CREATE OR REPLACE PROCEDURE cbm_insupd_processlog 
    (
    v_processRecId          IN      cbm_process_log.process_recid%TYPE, 
    v_processKey            IN      cbm_process_log.process_key%TYPE,
    v_moduleNum             IN      cbm_process_log.module_num%TYPE          := NULL,
    v_stepNum               IN      cbm_process_log.step_num%TYPE            := NULL,
    v_processStartDt        IN      cbm_process_log.process_Start_Date%TYPE  := NULL,
    v_processEndDt          IN      cbm_process_log.process_End_Date%TYPE    := NULL,
    v_processStatusCd       IN      cbm_process_log.process_Status_Code%TYPE := NULL,
    v_sqlErrorCode          IN      cbm_process_log.sql_Error_Code%TYPE      := NULL,
    v_recReadInt            IN      cbm_process_log.rec_Read_Int%TYPE        := NULL,
    v_recValidInt           IN      cbm_process_log.rec_Valid_Int%TYPE       := NULL,
    v_recLoadInt            IN      cbm_process_log.rec_Load_Int%TYPE        := NULL,
    v_recInsertedInt        IN      cbm_process_log.rec_Inserted_Int%TYPE    := NULL,
    v_recMergedInt          IN      cbm_process_log.rec_Merged_Int%TYPE      := NULL,
    v_recSelectedInt        IN      cbm_process_log.rec_Selected_Int%TYPE    := NULL,
    v_recUpdatedInt         IN      cbm_process_log.rec_Updated_Int%TYPE     := NULL,
    v_recDeletedInt         IN      cbm_process_log.rec_Deleted_Int%TYPE     := NULL,
    v_userLoginId           IN      cbm_process_log.user_Login_Id%TYPE       := '',
    v_message               IN      cbm_process_log.message%TYPE             := '', 
    v_rec_Id                IN OUT  cbm_process_log.process_RecId%TYPE  
    )

IS

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--            SP Name: cbm_insupd_processlog..
--            SP Desc: 
--
--      SP Created By: G. Belford..
--    SP Created Date: 23 November 2009..
--
--          SP Source: cbm_insupd_processlog.sql..
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--      SP Parameters: 
--              Input: 
-- 
--             Output:   
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Used in the following:
--
--         
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName%
--    Sysdate:         %SYSDATE%
--    Date and Time:   %DATE%, %TIME%, and %DATETIME%
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor)
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/

/*----- Test script -----*/

/* 

DECLARE 

calling_procedure         std_cbm_debug_tbl.called_by%TYPE := 'GBelford';   
l_call_error              VARCHAR2(20)                           := NULL;                                    

BEGIN 

    cbm_insupd_processlog 
        (
        calling_procedure, 
        l_call_error
        ); 
    
    COMMIT;  
    
    DBMS_OUTPUT.PUT_LINE('l_call_error: ' || l_call_error); 

END; 

*/ 

-- Exception handling variables (ps_)  

ps_procedure_name                std_cbm_debug_tbl.ps_procedure%TYPE  
    := 'cbm_insupd_processlog';
ps_location                      std_cbm_debug_tbl.ps_location%TYPE  
    := 'Needed'; 
ps_oerr                          std_cbm_debug_tbl.ps_oerr%TYPE   
    := null;                 /*  */
ps_msg                           std_cbm_debug_tbl.ps_msg%TYPE 
    := null;                 /*  */
ps_id_key                        std_cbm_debug_tbl.ps_id_key%TYPE 
    := null;                 /*  */
    -- coder responsible for identying key for debug

tmpVar                  NUMBER;

v_debug                 NUMBER; 

CURSOR process_cur IS
    SELECT   a.process_key, a.message
    FROM     cbm_process_log a
    ORDER BY a.process_key DESC;
        
process_rec    process_cur%ROWTYPE;
        
BEGIN
    DBMS_OUTPUT.ENABLE(1000000);
    
    DBMS_OUTPUT.NEW_LINE;
    
    v_debug := 0;

    IF v_debug > 0 THEN
        DBMS_OUTPUT.PUT_LINE('v_rec_Id: ' || v_rec_Id 
            || ' | ' || v_processRecId || ' | ' || v_processKey
            );
    END IF;  


-- If the v_rec_Id is NULL then we assume that a new log record is required

    IF v_rec_Id IS NULL THEN
 
        ps_location := 'Insert'; 
        
        IF v_debug > 0 THEN 
            DBMS_OUTPUT.PUT_LINE('Insert'); 
        END IF;

        INSERT 
        INTO   cbm_process_log                
            (
            process_key,
            process_start_date, 
            process_RecId, 
            user_login_id, 
            module_num,
            step_num, 
            message        
            )
        VALUES 
            (
            v_ProcessKey, 
            v_processStartDt, 
            v_processRecId, 
            v_userLoginId, 
            v_moduleNum,
            v_stepNum, 
            v_message
            ); 

-- Get the IDENTITY of the new record to pass back out for 
-- updates to the log entry

        SELECT MAX(process_key) 
        INTO   v_rec_Id 
        FROM   cbm_process_log;                 

    ELSE
    
        ps_location := 'Update'; 
        
        IF v_debug > 0 THEN 
            DBMS_OUTPUT.PUT_LINE('Update v_rec_Id: ' || v_rec_Id); 
        END IF;

        UPDATE cbm_process_log                
        SET    module_num          = v_moduleNum, 
               step_num            = v_stepNum, 
               process_End_Date    = v_processEndDt,
               process_Status_Code = NVL(v_processStatusCd, v_sqlErrorCode),
               sql_Error_Code      = v_sqlErrorCode,
               rec_Read_Int        = v_recReadInt,
               rec_Valid_Int       = v_recValidInt,
               rec_Load_Int        = v_recLoadInt,
               rec_Inserted_Int    = v_recInsertedInt,
               rec_Merged_Int      = v_recMergedInt,
               rec_Selected_Int    = v_recSelectedInt,
               rec_Updated_Int     = v_recUpdatedInt,
               rec_Deleted_Int     = v_recDeletedInt,
               message             = v_message 
        WHERE  process_key = v_rec_Id;
    END IF;

    IF v_debug > 0 THEN 
    
        DBMS_OUTPUT.NEW_LINE;

        OPEN process_cur;
    
        LOOP
            FETCH process_cur 
            INTO  process_rec;
        
            EXIT WHEN process_cur%NOTFOUND;
        
            DBMS_OUTPUT.PUT_LINE(process_rec.process_key 
                || ', ' || process_rec.message
                );
        
        END LOOP;
    
        CLOSE process_cur;
    
    END IF;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
		    ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := '';
            
		    INSERT 
            INTO   std_cbm_debug_tbl (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
		    VALUES (
                ps_procedure_name, ps_oerr, ps_location, v_userLoginId, 
                ps_id_key, ps_msg, sysdate
                );

END cbm_insupd_processlog;
/


