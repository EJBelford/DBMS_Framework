CREATE OR REPLACE PROCEDURE cleanup_cbm_weekly    
(
calling_procedure     IN        VARCHAR2,-- Calling procedure name, used in 
                                         -- debugging, calling procedure 
                                         -- responsible for maintaining 
                                         -- heirachy 
unexpected_error      IN OUT    VARCHAR2 -- This would let the calling process 
                                         -- know that there was an error during 
                                         -- processing..                                    
)
    
IS

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--            SP Name: cleanup_cbm_weekly 
--            SP Desc: 
--
--      SP Created By: Gene Belford
--    SP Created Date: 24 NOVEMBER 2009  
--
--          SP Source: cleanup_cbm_weekly.sql 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--      SP Parameters: 
--              Input: 
-- 
--             Output:   
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Used in the following:
--
--         
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 24NOV09 - GB  -          -      - Created 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/

-- Testing Scripts 

/* 

DECLARE 

calling_procedure         std_mimosa_vw_debug_tbl.called_by%TYPE := 'GBelford';   
l_call_error              VARCHAR2(20)                           := NULL;                                    


BEGIN 

    cleanup_cbm_weekly ('GBelford', l_call_error); 
    
    COMMIT; 

    DBMS_OUTPUT.PUT_LINE('l_call_error: ' || l_call_error); 

END; 

*/ 

-- Exception handling variables (ps_) 

ps_procedure_name                std_cbm_debug_tbl.ps_procedure%TYPE  
    := 'CLEANUP_CBM_WEEKLY';  /*  */
ps_location                      std_cbm_debug_tbl.ps_location%TYPE  
    := 'Begin';              /*  */
ps_oerr                          std_cbm_debug_tbl.ps_oerr%TYPE   
    := null;                 /*  */
ps_msg                           std_cbm_debug_tbl.ps_msg%TYPE 
    := 'No message defined'; /*  */
ps_id_key                        std_cbm_debug_tbl.ps_id_key%TYPE 
    := null;                 /*  */
    -- coder responsible for identying key for debug..

-- standard variables

ps_status                        VARCHAR2(10)  := 'STARTED';

ps_main_status                   VARCHAR2(10)  := null;

l_ps_start                       DATE          := sysdate;
l_now_is                         DATE          := sysdate;

l_call_error                     VARCHAR2(20)  := null;
ls_start                         DATE          := null;

proc0_recId                          cbm_process_log.process_RecId%TYPE
    := NULL;                 /* NUMBER */
proc1_recId                          cbm_process_log.process_RecId%TYPE
    := NULL;                 /* NUMBER */

proc0                 cbm_process_log%ROWTYPE; 
proc1                 cbm_process_log%ROWTYPE; 

ps_last_process       cbm_processes%ROWTYPE;
ps_this_process       cbm_processes%ROWTYPE;
ls_current_process    cbm_processes%ROWTYPE; 

v_fact_ld_niin_cntrl_start    cbm_process_control.process_control_value%TYPE 
    := NULL; 
v_fact_ld_niin_cntrl_cutoff   cbm_process_control.process_control_value%TYPE 
    := NULL; 

-- module variables (v_)

v_physical_item_id               NUMBER;
v_time_id                        NUMBER; 

v_debug                          NUMBER        
     := 0;   -- Controls debug options (0 -Off)

BEGIN 

    IF v_debug > 0 THEN
        DBMS_OUTPUT.ENABLE(1000000);
    END IF;  
    
    proc0.process_RecId      := 870; 
    proc0.process_Key        := NULL;
    proc0.module_Num         := 0;
    proc0.process_Start_Date := SYSDATE;
    proc0.user_Login_Id      := USER; 
  
    cbm_insupd_processlog 
        (
        proc0.process_RecId, proc0.process_Key, 
        proc0.module_Num, proc0.step_Num,  
        proc0.process_Start_Date, NULL, 
        NULL, NULL, 
        NULL, NULL, NULL, 
        NULL, NULL, NULL, NULL, NULL, 
        proc0.user_Login_Id, NULL, proc0_recId
        );  
        
-- Added batch id  

   proc0.process_batch_id := cbm_get_prcss_run_id;
   proc1.process_batch_id := proc0.process_batch_id; 
   
   UPDATE cbm_process_log 
   SET    process_batch_id = proc0.process_batch_id 
   WHERE  process_key = proc0_recId; 

    ps_id_key := NVL(calling_procedure, 'cleanup_cbm_weekly');

    IF v_debug > 0 THEN
        DBMS_OUTPUT.PUT_LINE
           ( 
           'proc0_recId: ' || proc0_recId || ', ' || 
           proc0.process_RecId || ', ' || proc0.process_Key
           );
    END IF;  

-- Housekeeping for the MAIN process 
  
    ps_location := 'CBM 00';            -- For std_mimosa_vw_debug_tbl logging. 

    ps_this_process.last_run             := l_ps_start;
    ps_this_process.who_ran              := ps_id_key;
    ps_this_process.last_run_status      := 'BEGAN';
    ps_this_process.last_run_status_time := sysdate;
    ps_this_process.last_run_compl       := null;

-- get the run criteria from the pfsa_processes table for the last run of this 
-- MAIN process 
  
    get_cbm_process_info ( 
        ps_procedure_name, ps_procedure_name, ps_last_process.last_run, 
        ps_last_process.who_ran, ps_last_process.last_run_status, 
        ps_last_process.last_run_status_time, ps_last_process.last_run_compl
        );

-- Update the PFSA_PROCESSES table to indicate MAIN process began.  

    updt_cbm_processes (
        ps_procedure_name, ps_procedure_name, ps_this_process.last_run,  
        ps_this_process.who_ran, ps_this_process.last_run_status, 
        ps_this_process.last_run_status_time, ps_last_process.last_run_compl
        );
      
/*----- Sub Process -----*/ 
      
    ls_start                             := sysdate;
    ls_current_process.last_run          := ls_start;
    ls_current_process.last_run_status   := 'BEGAN';
    ls_current_process.who_ran           := ps_id_key;
    ps_this_process.last_run_status_time := sysdate;
    ps_this_process.last_run_status      := ps_location;

-- Update the pfsa_processes table to indicate MAIN process has started.   

    ps_location := 'CBM 20';            -- For std_mimosa_vw_debug_tbl logging.

    updt_cbm_processes
        (
        ps_procedure_name, ps_procedure_name, ps_this_process.last_run, 
        ps_this_process.who_ran, ps_this_process.last_run_status, 
        ps_this_process.last_run_status_time, ps_last_process.last_run_compl
        );

-- Update the pfsa_processes table to indicate the sub-process has started.  

    ps_location := 'CBM 30';            -- For std_mimosa_vw_debug_tbl logging.

    updt_cbm_processes
        (
        ps_procedure_name, ls_current_process.cbm_process, ls_start, 
        ps_this_process.who_ran, ls_current_process.last_run_status, 
        l_now_is, ls_current_process.last_run_compl
        );

    COMMIT;
  
/*----------------------------------------------------------------------------*/ 
/*----- Start of actual work                                             -----*/  
/*----------------------------------------------------------------------------*/ 

    FOR re_indexing 
    IN  ( 
        SELECT 
        DISTINCT trk.table_name 
        FROM   cbm_tab_size_trk trk, 
            cbm_table_ref ref  
        WHERE  ( 
               num_of_rows   IS NULL 
            OR last_analysis IS NULL 
            ) 
            AND UPPER(trk.table_name) = UPPER(ref.cbm_tabl_nam) 
            AND ref.status = 'C' 
        ORDER BY table_name
        )
    LOOP 
    
        EXECUTE IMMEDIATE 'ANALYZE TABLE ' || re_indexing.table_name || ' DELETE STATISTICS'; 
        EXECUTE IMMEDIATE 'ANALYZE TABLE ' || re_indexing.table_name || ' COMPUTE STATISTICS'; 
        
        proc0.rec_read_int := NVL(proc0.rec_read_int, 0) + 1;
  
    END LOOP; -- std_debug..
    
/*----------------------------------------------------------------------------*/ 
/*----- End of actual work                                               -----*/  
/*----------------------------------------------------------------------------*/ 

-- Update the pfsa_process table to indicate MAIN process has ended.  

-- Housekeeping for the end of the MAIN process 

    ps_this_process.last_run_status_time := SYSDATE; 
    ps_this_process.last_run_compl       := ps_this_process.last_run_status_time; 
  
    IF ps_main_status IS NULL THEN
        ps_main_status := 'COMPLETE';
    ELSE
        ps_main_status := 'CMPLERROR';
    END IF;
      
    updt_cbm_processes
        (
        ps_procedure_name,       ps_procedure_name, ps_this_process.last_run, 
        ps_this_process.who_ran, ps_main_status,  
        ps_this_process.last_run_status_time, ps_this_process.last_run_compl
        );

    proc0.process_end_date := sysdate;
    proc0.sql_error_code := sqlcode;
    proc0.process_status_code := NVL(proc0.sql_error_code, sqlcode);
    proc0.message := sqlcode || ' - ' || sqlerrm; 
    
    cbm_insupd_processlog 
        (
        proc0.process_recid, proc0.process_key, 
        proc0.module_num, proc0.step_num,  
        proc0.process_start_date, proc0.process_end_date, 
        proc0.process_status_code, proc0.sql_error_code, 
        proc0.rec_read_int, proc0.rec_valid_int, proc0.rec_load_int, 
        proc0.rec_inserted_int, proc0.rec_merged_int, proc0.rec_selected_int, 
        proc0.rec_updated_int, proc0.rec_deleted_int, 
        proc0.user_login_id, proc0.message, proc0_recid
        );

    COMMIT;

EXCEPTION 
    WHEN OTHERS THEN
        ps_oerr := sqlcode; 
        ps_msg  := sqlerrm; 
        
        INSERT 
        INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr, ps_location, called_by, 
        ps_id_key, ps_msg, msg_dt
        )
        VALUES 
        (
        ps_procedure_name, ps_oerr, ps_location, NULL, 
        ps_id_key, ps_msg, SYSDATE
        );
        
    COMMIT; 

END; -- cleanup_weekly 
/


