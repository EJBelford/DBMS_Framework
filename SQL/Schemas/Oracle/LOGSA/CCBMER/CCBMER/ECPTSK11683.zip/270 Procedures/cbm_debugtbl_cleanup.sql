CREATE OR REPLACE PROCEDURE cbm_debugtbl_cleanup 

IS

/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--
--            SP Name: pr_cbm_debugtbl_cleanup
--            SP Desc: 
--
--      SP Created By: Gene Belford
--    SP Created Date: 16 November 2007 
--
--          SP Source: pr_cbm_debugtbl_cleanup.sql
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--      SP Parameters: 
--              Input: 
-- 
--             Output:   
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Used in the following:
--
--         
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DDMMMYY - Who - Ticket # - CR # - Details
-- 23NOV09 - GB  -          -      - Created 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/

/*----- Test script -----*/ 
/*

BEGIN 

    pr_cbm_debugtbl_cleanup; 
    
    COMMIT; 
    
END; 

*/ 

-- standard variables 

-- Exception handling variables (ps_) 


ps_oerr              std_cbm_debug_tbl.ps_oerr%TYPE    
    := null;
ps_location          std_cbm_debug_tbl.ps_location%TYPE  
    := 'Begin';
ps_procedure_name    std_cbm_debug_tbl.ps_procedure%TYPE  
    := 'pr_cbm_debugtbl_cleanup';
ps_msg               std_cbm_debug_tbl.ps_msg%TYPE         
    := 'No message defined.';
ps_id_key            std_cbm_debug_tbl.ps_id_key%TYPE      
    := null; -- coder responsible for identifying key for debug

-- Process status variables (s0_)

s0_rec_Id                        cbm_process_log.process_RecId%TYPE
    := NULL;                 /* NUMBER */

s0_processRecId                  cbm_process_log.process_RecId%TYPE   
    := 11;                   /* NUMBER */
s0_processKey                    cbm_process_log.process_Key%TYPE     
    := NULL;                 /* NUMBER */
s0_moduleNum                     cbm_process_log.Module_Num%TYPE   
    := 0;                    /* NUMBER */
s0_stepNum                       cbm_process_log.Step_Num%TYPE   
    := NULL;                 /* NUMBER */
s0_processStartDt                cbm_process_log.process_Start_Date%TYPE      
    := sysdate;              /* DATE */
s0_processEndDt                  cbm_process_log.process_End_Date%TYPE      
    := NULL;                 /* DATE */
s0_processStatusCd               cbm_process_log.process_Status_Code%TYPE  
    := NULL;                 /* NUMBER */
s0_sqlErrorCode                  cbm_process_log.sql_Error_Code%TYPE    
    := NULL;                 /* NUMBER */
s0_recReadInt                    cbm_process_log.rec_Read_Int%TYPE      
    := NULL;                 /* NUMBER */
s0_recValidInt                   cbm_process_log.rec_Valid_Int%TYPE     
    := NULL;                 /* NUMBER */
s0_recLoadInt                    cbm_process_log.rec_Load_Int%TYPE    
    := NULL;                 /* NUMBER */
s0_recInsertedInt                cbm_process_log.rec_Inserted_Int%TYPE     
    := NULL;                 /* NUMBER */
s0_recMergedInt                  cbm_process_log.rec_Merged_Int%TYPE  
    := NULL;                 /* NUMBER */
s0_recSelectedInt                cbm_process_log.rec_Selected_Int%TYPE  
    := NULL;                 /* NUMBER */
s0_recUpdatedInt                 cbm_process_log.rec_Updated_Int%TYPE    
    := NULL;                 /* NUMBER */
s0_recDeletedInt                 cbm_process_log.rec_Deleted_Int%TYPE    
    := NULL;                 /* NUMBER */
s0_userLoginId                   cbm_process_log.user_Login_Id%TYPE  
    := user;                 /* VARCHAR2(30) */
s0_message                       cbm_process_log.message%TYPE 
    := '';                   /* VARCHAR2(255) */
    
-- module variables (v_)

v_debug                  PLS_INTEGER   := 0; 
v_keep_n_days_of_debug   PLS_INTEGER   := 5; 

CURSOR process_cur IS
    SELECT   a.process_key, a.message
    FROM     cbm_process_log a
    ORDER BY a.process_key DESC;
        
process_rec    process_cur%ROWTYPE;
        
BEGIN
    ps_location := '00-Log Rec';

    cbm_insupd_processlog (s0_processRecId, s0_processKey, 
        s0_moduleNum, s0_stepNum,  
        s0_processStartDt, NULL, 
        NULL, NULL, 
        NULL, NULL, NULL, 
        NULL, NULL, NULL, NULL, NULL, 
        s0_userLoginId, NULL, s0_rec_Id);

    IF v_debug > 0 THEN
        DBMS_OUTPUT.ENABLE(1000000); 
        DBMS_OUTPUT.NEW_LINE; 
        DBMS_OUTPUT.PUT_LINE
           (
           's0_rec_Id: ' || s0_rec_Id || ', ' || 
           s0_processRecId || ', ' || s0_processKey
           );
    END IF;  

-- Get the # of days to delete fro process control, (cbm_PROCESS_CONTROL).

    v_keep_n_days_of_debug := cbm_get_prcss_cntrl_val('v_keep_n_days_of_debug'); 

-- Delete all PFSADW_Process_Log records more than # days old. 

    DELETE std_cbm_debug_tbl  
    WHERE  msg_dt < (sysdate - v_keep_n_days_of_debug)
        AND v_keep_n_days_of_debug > 0; 

    s0_recDeletedInt := SQL%ROWCOUNT;
    
    ps_location := '99-Log Rec';

    s0_processEndDt := sysdate;
    s0_sqlErrorCode := sqlcode;
    s0_processStatusCd := NVL(s0_sqlErrorCode, sqlcode);
    s0_message := SUBSTR(sqlcode || ' - ' || sqlerrm, 1, 200); 
    
    cbm_insupd_processlog (s0_processRecId, s0_processKey,  
        s0_moduleNum, s0_stepNum,  
        s0_processStartDt, s0_processEndDt, 
        s0_processStatusCd, s0_sqlErrorCode, 
        s0_recReadInt, s0_recValidInt, s0_recLoadInt, 
        s0_recInsertedInt, s0_recMergedInt, s0_recSelectedInt, 
        s0_recUpdatedInt, s0_recDeletedInt, 
        s0_userLoginId, s0_message, s0_rec_Id);

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NULL;
        WHEN OTHERS THEN
           ps_oerr   := sqlcode;
           ps_msg    := sqlerrm;
           ps_id_key := '';
           
           INSERT 
           INTO std_cbm_debug_tbl 
              (
              ps_procedure, ps_oerr, ps_location, 
              called_by, ps_id_key, ps_msg, msg_dt
              )
		    VALUES 
              (
              ps_procedure_name, ps_oerr, ps_location, 
              s0_userLoginId, ps_id_key, ps_msg, sysdate
              );
              
END cbm_debugtbl_cleanup;
/


