BEGIN 

    MERGE INTO cbm_process_control 
    A USING (
        SELECT
            'schema_owner' as "PROCESS_CONTROL_NAME",
            'RDR00023'     as "PROCESS_CONTROL_VALUE",
            'Schema the procedure should focus on. ' as "PROCESS_CONTROL_DESCRIPTION",
            'C'            as "STATUS",
            'Y'            as "ACTIVE_FLAG" 
        FROM DUAL) B
    ON (a.process_control_name = b.process_control_name)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_control_name,          process_control_value, 
            process_control_description,   status, 
            active_flag 
            )
        VALUES (
            b.process_control_name,        b.process_control_value, 
            b.process_control_description, b.status, 
            b.active_flag 
            )
    WHEN MATCHED THEN
        UPDATE SET 
            a.process_control_value = b.process_control_value,
            a.process_control_description = b.process_control_description,
            a.status = b.status,
            a.active_flag = b.active_flag; 

    MERGE INTO cbm_process_control 
    A USING (
        SELECT
            'v_keep_n_days_of_log' as "PROCESS_CONTROL_NAME",
            '90'                   as "PROCESS_CONTROL_VALUE",
            'Number of days of history to keep in CBM_PROCESS_LOG' as "PROCESS_CONTROL_DESCRIPTION",
            'C'                    as "STATUS",
            'Y'                    as "ACTIVE_FLAG" 
        FROM DUAL) B
    ON (a.process_control_name = b.process_control_name)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_control_name,          process_control_value, 
            process_control_description,   status, 
            active_flag 
            )
        VALUES (
            b.process_control_name,        b.process_control_value, 
            b.process_control_description, b.status, 
            b.active_flag 
            )
    WHEN MATCHED THEN
        UPDATE SET 
            a.process_control_value = b.process_control_value,
            a.process_control_description = b.process_control_description,
            a.status = b.status,
            a.active_flag = b.active_flag; 

    MERGE INTO cbm_process_control 
    A USING (
        SELECT
            'v_keep_n_days_of_debug' as "PROCESS_CONTROL_NAME",
            '30'                     as "PROCESS_CONTROL_VALUE",
            'Number of days of history to keep in STD_CBM_DEBUG_TBL' as "PROCESS_CONTROL_DESCRIPTION",
            'C'                      as "STATUS",
            'Y'                      as "ACTIVE_FLAG" 
        FROM DUAL) B
    ON (a.process_control_name = b.process_control_name)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_control_name,          process_control_value, 
            process_control_description,   status, 
            active_flag 
            )
        VALUES (
            b.process_control_name,        b.process_control_value, 
            b.process_control_description, b.status, 
            b.active_flag 
            )
    WHEN MATCHED THEN
        UPDATE SET 
            a.process_control_value = b.process_control_value,
            a.process_control_description = b.process_control_description,
            a.status = b.status,
            a.active_flag = b.active_flag; 

    COMMIT;

END; 
/
