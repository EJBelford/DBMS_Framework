BEGIN

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        -2                   as "PROCESS_KEY",
        'pr_cbm_blank' as "PROCESS_DESCRIPTION",
        'C'                  as "STATUS",
        NULL                 as "RUN_CNTRL",
        'N'                  as "OVERRIDE_RUN_CNTRL",
        'N'                  as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        -1                   as "PROCESS_KEY",
        'NOT APPLICABLE'     as "PROCESS_DESCRIPTION",
        'C'                  as "STATUS",
        NULL                 as "RUN_CNTRL",
        'N'                  as "OVERRIDE_RUN_CNTRL",
        'N'                  as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        1                             as "PROCESS_KEY",
        'cbm_insupd_processlog' as "PROCESS_DESCRIPTION",
        'C'                           as "STATUS",
        NULL                          as "RUN_CNTRL",
        'N'                           as "OVERRIDE_RUN_CNTRL",
        'N'                           as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        5                          as "PROCESS_KEY",
        'maintain_cbm_world' as "PROCESS_DESCRIPTION",
        'C'                        as "STATUS",
        127                        as "RUN_CNTRL",
        'N'                        as "OVERRIDE_RUN_CNTRL",
        'N'                        as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        10                      as "PROCESS_KEY",
        'cbm_log_cleanup' as "PROCESS_DESCRIPTION",
        'C'                     as "STATUS",
        127                     as "RUN_CNTRL",
        'N'                     as "OVERRIDE_RUN_CNTRL",
        'N'                     as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        11                           as "PROCESS_KEY",
        'cbm_debugtbl_cleanup' as "PROCESS_DESCRIPTION",
        'C'                          as "STATUS",
        127                          as "RUN_CNTRL",
        'N'                          as "OVERRIDE_RUN_CNTRL",
        'N'                          as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        100                   as "PROCESS_KEY",
        'etl_cbm_world' as "PROCESS_DESCRIPTION",
        'C'                   as "STATUS",
        127                   as "RUN_CNTRL",
        'N'                   as "OVERRIDE_RUN_CNTRL",
        'N'                   as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;

    MERGE INTO cbm_process_ref A USING
        (
        SELECT
        870                  as "PROCESS_KEY",
        'cleanup_cbm_weekly' as "PROCESS_DESCRIPTION",
        'C'                  as "STATUS",
        127                  as "RUN_CNTRL",
        'N'                  as "OVERRIDE_RUN_CNTRL",
        'N'                  as "DEBUG_ON_FLAG"
        FROM dual) b
    ON (a.process_key = b.process_key)
    WHEN NOT MATCHED THEN 
        INSERT (
            process_key, process_description, 
            status,  
            run_cntrl,   override_run_cntrl,  debug_on_flag
            )
        VALUES (
            b.process_key, b.process_description, 
            b.status, 
            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
            )
    WHEN MATCHED THEN
    UPDATE SET 
        a.process_description = b.process_description,
        a.status = b.status,
        a.run_cntrl = b.run_cntrl,
        a.override_run_cntrl = b.override_run_cntrl,
        a.debug_on_flag = b.debug_on_flag;
    
--    MERGE INTO cbm_process_ref A USING
--        (
--        SELECT
--        9100                as "PROCESS_KEY",
--        'bld_view_4_mimosa' as "PROCESS_DESCRIPTION",
--        'C'                 as "STATUS",
--        127                 as "RUN_CNTRL",
--        'N'                 as "OVERRIDE_RUN_CNTRL",
--        'N'                 as "DEBUG_ON_FLAG"
--        FROM dual) b
--    ON (a.process_key = b.process_key)
--    WHEN NOT MATCHED THEN 
--        INSERT (
--            process_key, process_description, 
--            status,  
--            run_cntrl,   override_run_cntrl,  debug_on_flag
--            )
--        VALUES (
--            b.process_key, b.process_description, 
--            b.status, 
--            b.run_cntrl, b.override_run_cntrl, b.debug_on_flag
--            )
--    WHEN MATCHED THEN
--    UPDATE SET 
--        a.process_description = b.process_description,
--        a.status = b.status,
--        a.run_cntrl = b.run_cntrl,
--        a.override_run_cntrl = b.override_run_cntrl,
--        a.debug_on_flag = b.debug_on_flag; 
        
    COMMIT;
    
END;
/
