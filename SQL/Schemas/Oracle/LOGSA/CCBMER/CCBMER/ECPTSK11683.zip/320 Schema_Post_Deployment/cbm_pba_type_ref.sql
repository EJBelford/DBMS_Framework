BEGIN 

    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '12' as "ITEM_ID_TYPE_ID",
      '-1' as "ITEM_ID_TYPE_CD",
      'Select one ...' as "ITEM_ID_TYPE_DESC" 
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '11' as "ITEM_ID_TYPE_ID",
      '-2' as "ITEM_ID_TYPE_CD",
      'Not found' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '10' as "ITEM_ID_TYPE_ID",
      'DODAAC' as "ITEM_ID_TYPE_CD",
      'DODAAC - DEPARTMENT OF DEFENSE ACTIVITY ADDRESS CODE - A six-position, alphanumeric field.' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '14' as "ITEM_ID_TYPE_ID",
      'ITEM_SN' as "ITEM_ID_TYPE_CD",
      'ITEM_SN - END ITEM SERIAL NUMBER - The unique serial number assigned to the end item in which the enrolled component is installed.' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '15' as "ITEM_ID_TYPE_ID",
      'LIN' as "ITEM_ID_TYPE_CD",
      'LIN - LINE ITEM NUMBER - The Line Item Number (LIN) is a six-character, alphanumeric identification of generic nomenclature.  It pertains to the line on which the generic nomenclature is listed in bul' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '13' as "ITEM_ID_TYPE_ID",
      'NIIN' as "ITEM_ID_TYPE_CD",
      'NIIN - NATIONAL ITEM IDENTIFICATION NUMBER - A 9-digit number sequentially assigned to each approved item identification number under the federal cataloging program.' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;


    MERGE INTO cbm_pba_type_ref A USING
     (SELECT
      '16' as "ITEM_ID_TYPE_ID",
      'UIC' as "ITEM_ID_TYPE_CD",
      'UIC - UNIT IDENTIFICATION CODE (UIC) - A six-position, alphanumeric code that uniquely identifies a Department of Defense (DOD) organization as a "unit."  Each unit of the Active Army, Army Reserve, a' as "ITEM_ID_TYPE_DESC"
      FROM DUAL) B
    ON (A.ITEM_ID_TYPE_CD = B.ITEM_ID_TYPE_CD)
    WHEN NOT MATCHED THEN 
    INSERT (
        ITEM_ID_TYPE_ID, ITEM_ID_TYPE_CD, ITEM_ID_TYPE_DESC
        )
    VALUES (
        B.ITEM_ID_TYPE_ID, B.ITEM_ID_TYPE_CD, B.ITEM_ID_TYPE_DESC
        )
    WHEN MATCHED THEN
    UPDATE SET 
      A.ITEM_ID_TYPE_ID   = B.ITEM_ID_TYPE_ID, 
      A.ITEM_ID_TYPE_DESC = B.ITEM_ID_TYPE_DESC;

    COMMIT;

END;