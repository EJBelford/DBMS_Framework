/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: merge_cbm_table_ref..
--      PURPOSE: Inital load script for cbm_table_ref..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: xxxTSK00xxxx_merge_cbm_table_ref.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
/*                                                                            */
/*                                 Populate                                   */
/*                                                                            */
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

DECLARE 

v_cbm_cris_ver             cbm_table_ref.cbm_cris_ver%TYPE;
v_cbm_tabl_flag            cbm_table_ref.cbm_tabl_flag%TYPE;
v_cbm_tabl_type            cbm_table_ref.cbm_tabl_type%TYPE;

v_table_name                     VARCHAR2(30); 

loop_cnt                         NUMBER := 0;

BEGIN 

    DBMS_OUTPUT.ENABLE(1000000);
    DBMS_OUTPUT.NEW_LINE;
    
    FOR table_load 
    IN  (
        SELECT table_name    
        FROM user_tables  
        ORDER BY table_name
        )
    LOOP
    
        loop_cnt := loop_cnt + 1; 
        
        DBMS_OUTPUT.PUT_LINE
            (          table_load.table_name 
            );
    
        v_cbm_tabl_type := NULL; 
        
        IF INSTR(table_load.table_name, 'MIMOSA_BL_') > 0 THEN 
            v_cbm_cris_ver  := '0.0.0';
            v_cbm_tabl_flag := 'N'; 
            
            v_table_name := NULL;
        ELSE 
            v_cbm_cris_ver  := '3.2.1';
            v_cbm_tabl_flag := 'Y';
            
            v_table_name := table_load.table_name;
            
            IF SUBSTR(v_table_name, LENGTH(v_table_name)-4, 5) = '_TYPE' THEN 
                v_cbm_tabl_type := 'TYPE';
            END IF; 
            
            v_table_name := REPLACE(v_table_name, '_EVENT', '_EVNT'); 
            v_table_name := REPLACE(v_table_name, '_COMPLETED', '_CMPL');
            v_table_name := REPLACE(v_table_name, 'SEGMENT_', 'SG_'); 
            v_table_name := REPLACE(v_table_name, 'ASSET_', 'AS_'); 
            v_table_name := REPLACE(v_table_name, 'NETWORK_', 'NET_');
            v_table_name := REPLACE(v_table_name, 'WORK_', 'WRK_');
            v_table_name := REPLACE(v_table_name, 'FOR_', '4_');
            v_table_name := REPLACE(v_table_name, 'PACKAGE_', 'PKG_');
            v_table_name := REPLACE(v_table_name, '_HISTORY', '_HST');
            v_table_name := REPLACE(v_table_name, '_RESOURCE', '_RSRC');
            v_table_name := REPLACE(v_table_name, 'SOLUTION_', 'SOLU_');
            v_table_name := REPLACE(v_table_name, '_DATA', '_DAT');
            v_table_name := REPLACE(v_table_name, 'REQUEST_', 'REQ_');
            v_table_name := REPLACE(v_table_name, 'TEST_', 'TST_');
            v_table_name := REPLACE(v_table_name, 'VALID_', 'VALD_');
            v_table_name := REPLACE(v_table_name, '_ITEM_', '_ITM_');
            v_table_name := REPLACE(v_table_name, 'CONFIG_', 'CFG_');
            v_table_name := REPLACE(v_table_name, 'ORDER_', 'ORD_');
            v_table_name := REPLACE(v_table_name, 'BLOB_', 'BLB_');
            v_table_name := REPLACE(v_table_name, 'ALARM_', 'ALRM_');
            v_table_name := REPLACE(v_table_name, 'ASSOC_', 'ASSC_');
            v_table_name := REPLACE(v_table_name, '_ENTRY', '_ENTR');
            v_table_name := REPLACE(v_table_name, '_NEEDED', '_NEED');
            v_table_name := REPLACE(v_table_name, '_LIST', '_LST');
            v_table_name := REPLACE(v_table_name, '_STUDY', '_STDY');
            v_table_name := REPLACE(v_table_name, 'COMP_', 'CMP_');
            
            v_table_name := v_table_name || '_ADT'; 
            
        END IF;
        

        MERGE INTO  cbm_table_ref tar 
        USING (
            SELECT
                loop_cnt              AS cbm_tabl_id , 
                table_load.table_name AS cbm_tabl_nam , 
                0                     AS source_rec_id ,
                0                     AS lst_update_rec_id
                FROM dual
            ) src
        ON (tar.cbm_tabl_id = src.cbm_tabl_id)
        WHEN NOT MATCHED THEN 
            INSERT ( cbm_cris_ver,     
                cbm_tabl_id,     cbm_tabl_nam,     source_rec_id,     lst_update_rec_id,  
                cbm_tabl_cloe_flag,       cbm_tabl_flag,    cbm_tabl_nam_audt, 
                cbm_tabl_type 
                )
            VALUES ( v_cbm_cris_ver, 
                src.cbm_tabl_id, src.cbm_tabl_nam, src.source_rec_id, src.lst_update_rec_id, 
                'N',                          v_cbm_tabl_flag,  v_table_name, 
                v_cbm_tabl_type     
                )
        WHEN MATCHED THEN
            UPDATE SET 
                tar.cbm_cris_ver      = v_cbm_cris_ver, 
                tar.cbm_tabl_nam      = src.cbm_tabl_nam, 
                tar.cbm_tabl_nam_audt = v_table_name,
                tar.cbm_tabl_type     = v_cbm_tabl_type;

        COMMIT;    
    END LOOP;    -- table_load.. 

END;  
/ 
    
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
/*                                                                            */
/*                                 Validate                                   */
/*                                                                            */
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
/*

SELECT * FROM cbm_table_ref ORDER BY rec_id; 
/  


DECLARE

BEGIN 

    DBMS_OUTPUT.ENABLE(1000000);
    DBMS_OUTPUT.NEW_LINE;
    
    FOR table_load 
    IN  (
        SELECT rec_id, 
            cbm_tabl_id,
            cbm_tabl_nam
        FROM cbm_table_ref 
        ORDER BY rec_id
        )
    LOOP
        DBMS_OUTPUT.PUT_LINE
            (          table_load.rec_id 
            || ', ' || table_load.cbm_tabl_id 
            || ', ' || table_load.cbm_tabl_nam
            );
    END LOOP;    -- table_load.. 
    
END;  
/ 

*/

