/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_i_std_cbm_debug_tbl..
--      PURPOSE: Insert trigger for std_cbm_debug_tbl..
--               Used in MIMOSA_BL processing to capture unexpected errors in 
--               processing as well as general program debugging during 
--               development.  Production systems should expect no records to 
--               be created.  Creation of a record is considerred a problem.. 
--               The design was taken from PFSA.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: tr_i_std_cbm_debug_tbl.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     std_cbm_debug_tbl
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:02:59, and 01-Sep-2009 10:02:59
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create the Trigger now -----*/

CREATE OR REPLACE TRIGGER tr_i_std_cbm_debg_tbl_sq
BEFORE INSERT
ON std_cbm_debug_tbl
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

DECLARE

v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT std_cbm_debug_tbl_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise..
        RAISE;
       
END std_cbm_debug_tbl_seq;
/
