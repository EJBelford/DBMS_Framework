CREATE OR REPLACE TRIGGER tr_cbm_proces_ctrl_audt 
AFTER INSERT OR UPDATE OR DELETE ON cbm_process_control  
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_cbm_proces_ctrl_audt
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
--       NOTES:
-- 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName% 
--    Sysdate:         %SYSDATE% 
--    Date and Time:   %DATE%, %TIME%, and %DATETIME% 
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor) 
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
-- 

DECLARE

ps_procedure_name              std_cbm_debug_tbl.ps_procedure%type
    :=  'TR_CBM_PROCES_CTRL_AUDT';
ps_location                    std_cbm_debug_tbl.ps_location%type := 'Begin';
ps_oerr                        std_cbm_debug_tbl.ps_oerr%type     := NULL;
ps_msg                         std_cbm_debug_tbl.ps_msg%type      
    := 'Trigger failed';
ps_id_key                      std_cbm_debug_tbl.ps_id_key%type   := NULL;

BEGIN

    IF INSERTING THEN 
        INSERT 
        INTO cbm_process_control_audt 
            (
            process_control_id,
            update_by,
            update_date,
            new_process_control_name, 
            new_process_control_value, 
            new_process_control_desc, 
            new_status, 
            new_active_flag 
            )
        VALUES 
            (
            :new.process_control_id, 
            USER, 
            SYSDATE,
            :new.process_control_name, 
            :new.process_control_value, 
            :new.process_control_description, 
            :new.status, 
            :new.active_flag 
            ); 
    ELSIF UPDATING THEN 
        INSERT 
        INTO cbm_process_control_audt 
            (
            process_control_id, 
            update_by, 
            update_date, 
            new_process_control_name, 
            old_process_control_name, 
            new_process_control_value, 
            old_process_control_value, 
            new_process_control_desc, 
            old_process_control_desc, 
            new_status, 
            old_status, 
            new_active_flag, 
            old_active_flag 
            )
        VALUES 
            (
            :old.process_control_id, 
            USER, 
            SYSDATE,
            :new.process_control_name, 
            :old.process_control_name, 
            :new.process_control_value, 
            :old.process_control_value, 
            :new.process_control_description, 
            :old.process_control_description, 
            :new.status, 
            :old.status, 
            :new.active_flag, 
            :old.active_flag 
            ); 
    ELSE 
        INSERT 
        INTO cbm_process_control_audt 
            (
            process_control_id,
            update_by,
            update_date,
            old_process_control_name, 
            old_process_control_value, 
            old_process_control_desc, 
            old_status, 
            old_active_flag 
            )
        VALUES 
            (
            :old.process_control_id, 
            USER, 
            SYSDATE,
            :old.process_control_name, 
            :old.process_control_value, 
            :old.process_control_description, 
            :old.status, 
            :old.active_flag 
            ); 
    END IF;

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.process_control_id; 
    
    INSERT 
    INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of tr_cbm_process_ref_audt
/

