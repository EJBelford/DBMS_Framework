/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_i_cbm_table_ref..
--      PURPOSE: Insert trigger for cbm_table_ref..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: tr_i_cbm_table_ref.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create the Trigger now -----*/

CREATE OR REPLACE TRIGGER tr_i_cbm_table_ref_seq
BEFORE INSERT
ON cbm_table_ref
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

DECLARE

v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT cbm_table_ref_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;
--    :new.status   := 'C';
    :new.lst_updt := sysdate;
    :new.updt_by  := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise..
        RAISE;
       
END cbm_table_ref_seq;
/
