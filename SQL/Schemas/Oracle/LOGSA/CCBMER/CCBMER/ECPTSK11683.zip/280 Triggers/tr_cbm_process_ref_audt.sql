CREATE OR REPLACE TRIGGER tr_cbm_process_ref_audt 
AFTER INSERT OR UPDATE OR DELETE ON cbm_process_ref  
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_cbm_process_ref_audt
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
--       NOTES:
-- 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName% 
--    Sysdate:         %SYSDATE% 
--    Date and Time:   %DATE%, %TIME%, and %DATETIME% 
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor) 
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
-- 

DECLARE 

ps_procedure_name              std_cbm_debug_tbl.ps_procedure%type
    :=  'TR_CBM_PROCESS_REF_AUDT';
ps_location                    std_cbm_debug_tbl.ps_location%type := 'Begin';
ps_oerr                        std_cbm_debug_tbl.ps_oerr%type     := NULL;
ps_msg                         std_cbm_debug_tbl.ps_msg%type      
    := 'Trigger failed';
ps_id_key                      std_cbm_debug_tbl.ps_id_key%type   := NULL;

BEGIN

    IF INSERTING THEN 
        INSERT 
        INTO cbm_process_ref_audt 
            (
            process_recid,
            update_by,
            update_date,
            new_process_key,
            new_process_description,
            new_status,
            new_run_cntrl,
            new_override_run_cntrl,
            new_debug_on_flag 
            )
        VALUES 
            (
            :new.process_recid, 
            USER, 
            SYSDATE,
            :new.process_key,
            :new.process_description,
            :new.status,
            :new.run_cntrl,
            :new.override_run_cntrl,
            :new.debug_on_flag 
            ); 
    ELSIF UPDATING THEN 
        INSERT 
        INTO cbm_process_ref_audt 
            (
            process_recid,
            update_by,
            update_date,
            old_process_key,
            new_process_key,
            old_process_description,
            new_process_description,
            old_status,
            new_status,
            old_run_cntrl,
            new_run_cntrl,
            old_override_run_cntrl,
            new_override_run_cntrl,
            old_debug_on_flag,
            new_debug_on_flag
            )
        VALUES 
            (
            :old.process_recid, 
            USER, 
            SYSDATE,
            :old.process_key,
            :new.process_key,
            :old.process_description,
            :new.process_description,
            :old.status,
            :new.status,
            :old.run_cntrl,
            :new.run_cntrl,
            :old.override_run_cntrl,
            :new.override_run_cntrl,
            :old.debug_on_flag,
            :new.debug_on_flag
            ); 
    ELSE 
        INSERT 
        INTO cbm_process_ref_audt 
            (
            process_recid,
            update_by,
            update_date,
            old_process_key,
            old_process_description,
            old_status,
            old_run_cntrl,
            old_override_run_cntrl,
            old_debug_on_flag 
            )
        VALUES 
            (
            :old.process_recid, 
            USER, 
            SYSDATE,
            :old.process_key,
            :old.process_description,
            :old.status,
            :old.run_cntrl,
            :old.override_run_cntrl,
            :old.debug_on_flag 
            ); 
    END IF;

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.process_recid; 
    
    INSERT 
    INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of tr_cbm_process_ref_audt
/

