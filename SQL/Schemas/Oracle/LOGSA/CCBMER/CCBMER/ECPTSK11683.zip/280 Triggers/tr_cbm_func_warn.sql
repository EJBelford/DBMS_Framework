CREATE OR REPLACE TRIGGER tr_cbm_func_warn  
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_cbm_func_warn..
--      PURPOSE: Insert trigger for cbm_func_warn..
--               This table is used to post warnings for the PFSA functional 
--               team.  Warnings are generally reported as exceptions to 
--               processing as well as to data integrity issues.. 
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 18-Nov-2009..
--
--       SOURCE: tr_cbm_func_warn.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_func_warn
--    Sysdate:         01-Sep-2009
--    Date and Time:   01-Sep-2009, 10:42:43, and 01-Sep-2009 10:42:43
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 18-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create the Trigger now -----*/

BEFORE UPDATE OR INSERT ON cbm_func_warn
FOR EACH ROW
DECLARE

  ps_oerr                        std_cbm_debug_tbl.ps_oerr%TYPE   
      := null;
  ps_location                    std_cbm_debug_tbl.ps_location%TYPE   
      := 'BEGIN';
  ps_procedure_name              std_cbm_debug_tbl.ps_procedure%TYPE   
      := 'TR_CBM_FUNC_WARN';
  ps_msg                         std_cbm_debug_tbl.ps_msg%TYPE  
      := 'Trigger_failed';
  ps_id_key                      std_cbm_debug_tbl.ps_id_key%TYPE  
      := null; -- set in cases

  fail_update                    BOOLEAN       := FALSE;
 
  v_rec_id                       cbm_func_warn.rec_id%TYPE;

BEGIN 

-- set standards 

    v_rec_id := 0;

    SELECT cbm_func_warn_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id   := v_rec_id;
    :new.lst_updt := sysdate;
  
    IF :new.updt_by IS NULL THEN 
        :new.updt_by := user; 
    END IF;
      
    IF inserting THEN 
        :new.warning_status := 'C';
    END IF;

    IF updating THEN
-- don't allow initial data to change -
        :new.warning_type := :old.warning_type;
        :new.warning_from := :old.warning_from;
        :new.warning_msg  := :old.warning_msg;
        :new.warning_time := :old.warning_time;
       
-- resolving, ensure action not null (ie, is recorded) - 
        IF :new.warning_status = 'H' AND :old.warning_status = 'C' THEN 
            IF :new.action_taken IS NULL THEN
                fail_update := TRUE;
            END IF;
-- do not get rid of a specific action            
        ELSIF :new.action_taken IS NULL AND :old.action_taken IS NOT NULL THEN 
            fail_update := TRUE;
        END IF;
    END IF;

    IF fail_update THEN
        :new.lst_updt       := :old.lst_updt;
        :new.warning_status := :old.warning_status;
        :new.action_taken   := :old.action_taken;
        :new.updt_by        := :old.updt_by;
    END IF;

EXCEPTION WHEN OTHERS THEN
    ps_oerr := sqlcode;
    ps_msg := 'Unknown error'; 
    
    INSERT 
    INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr, ps_location, called_by, 
        ps_id_key,         ps_msg,  msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr, ps_location, null, 
        ps_id_key,         ps_msg,  sysdate
        );

END cbm_func_warn_seq;
/
