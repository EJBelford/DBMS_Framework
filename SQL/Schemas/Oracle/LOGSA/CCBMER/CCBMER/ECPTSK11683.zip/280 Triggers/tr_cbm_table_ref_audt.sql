CREATE OR REPLACE TRIGGER tr_cbm_table_ref_audt 
AFTER INSERT OR UPDATE OR DELETE ON cbm_table_ref  
FOR EACH ROW
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_cbm_table_ref_audt
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
--       NOTES:
-- 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref 
--    Sysdate:         16-Nov-2009 
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07 
--    Username:        G. Belford (set in TOAD Options, Procedure Editor) 
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-Nov-2009 - G. Belford  - RDPTSK00xxx - Created.. 
-- 

DECLARE

ps_procedure_name              std_cbm_debug_tbl.ps_procedure%type
    :=  'TR_CBM_TABLE_REF_AUDT';
ps_location                    std_cbm_debug_tbl.ps_location%type := 'Begin';
ps_oerr                        std_cbm_debug_tbl.ps_oerr%type     := NULL;
ps_msg                         std_cbm_debug_tbl.ps_msg%type      
    := 'Trigger failed';
ps_id_key                      std_cbm_debug_tbl.ps_id_key%type   := NULL;

BEGIN

    IF INSERTING THEN
        INSERT 
        INTO cbm_table_ref_audt 
            (
            rec_id,
            update_by,
            update_date,
            new_cbm_tabl_id,
            new_cbm_tabl_nam,  
            new_cbm_cris_ver,
            new_cbm_tabl_type,
            new_cbm_tabl_stat,
            new_cbm_tabl_cloe_flag,
            new_cbm_tabl_colm_cnt,
            new_cbm_tabl_row_cnt,
            new_cbm_tabl_lst_updt, 
            new_cbm_tabl_lst_push 
            )
        VALUES 
            (
            :new.rec_id, 
            USER, 
            SYSDATE,
            :new.cbm_tabl_id, 
            :new.cbm_tabl_nam,  
            :new.cbm_cris_ver,
            :new.cbm_tabl_type,
            :new.cbm_tabl_stat,
            :new.cbm_tabl_cloe_flag,
            :new.cbm_tabl_colm_cnt,
            :new.cbm_tabl_row_cnt,
            :new.cbm_tabl_lst_updt, 
            :new.cbm_tabl_lst_push 
            ); 
    ELSIF UPDATING THEN 
        INSERT 
        INTO cbm_table_ref_audt 
            (
            rec_id,
            update_by,
            update_date,
            old_cbm_tabl_id,
            new_cbm_tabl_id,
            old_cbm_tabl_nam, 
            new_cbm_tabl_nam, 
            old_cbm_cris_ver,
            old_cbm_tabl_type,
            old_cbm_tabl_stat,
            old_cbm_tabl_cloe_flag,
            old_cbm_tabl_colm_cnt,
            old_cbm_tabl_row_cnt,
            old_cbm_tabl_lst_updt, 
            old_cbm_tabl_lst_push, 
            new_cbm_cris_ver,
            new_cbm_tabl_type,
            new_cbm_tabl_stat,
            new_cbm_tabl_cloe_flag,
            new_cbm_tabl_colm_cnt,
            new_cbm_tabl_row_cnt,
            new_cbm_tabl_lst_updt, 
            new_cbm_tabl_lst_push 
            )
        VALUES 
            (
            :old.rec_id, 
            USER, 
            SYSDATE,
            :old.cbm_tabl_id, 
            :new.cbm_tabl_id, 
            :old.cbm_tabl_nam, 
            :new.cbm_tabl_nam, 
            :old.cbm_cris_ver,
            :old.cbm_tabl_type,
            :old.cbm_tabl_stat,
            :old.cbm_tabl_cloe_flag,
            :old.cbm_tabl_colm_cnt,
            :old.cbm_tabl_row_cnt,
            :old.cbm_tabl_lst_updt, 
            :old.cbm_tabl_lst_push, 
            :new.cbm_cris_ver,
            :new.cbm_tabl_type,
            :new.cbm_tabl_stat,
            :new.cbm_tabl_cloe_flag,
            :new.cbm_tabl_colm_cnt,
            :new.cbm_tabl_row_cnt,
            :new.cbm_tabl_lst_updt, 
            :new.cbm_tabl_lst_push 
            ); 
    ELSE 
        INSERT 
        INTO cbm_table_ref_audt 
            (
            rec_id,
            update_by,
            update_date,
            new_cbm_tabl_id,
            old_cbm_tabl_id,
            new_cbm_tabl_nam,  
            old_cbm_tabl_nam,  
            old_cbm_cris_ver,
            old_cbm_tabl_type,
            old_cbm_tabl_stat,
            old_cbm_tabl_cloe_flag,
            old_cbm_tabl_colm_cnt,
            old_cbm_tabl_row_cnt,
            old_cbm_tabl_lst_updt, 
            old_cbm_tabl_lst_push 
            )
        VALUES 
            (
            :old.rec_id, 
            USER, 
            SYSDATE,
            :old.cbm_tabl_id, 
            :old.cbm_tabl_id, 
            :old.cbm_tabl_nam,  
            :old.cbm_tabl_nam,  
            :old.cbm_cris_ver,
            :old.cbm_tabl_type,
            :old.cbm_tabl_stat,
            :old.cbm_tabl_cloe_flag,
            :old.cbm_tabl_colm_cnt,
            :old.cbm_tabl_row_cnt,
            :old.cbm_tabl_lst_updt, 
            :old.cbm_tabl_lst_push 
            ); 
    END IF;
    
EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.rec_id; 
    
    INSERT 
    INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of tr_cbm_table_ref_audt
/
