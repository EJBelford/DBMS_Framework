CREATE OR REPLACE TRIGGER tr_i_cbm_user_hist_seq
BEFORE INSERT
ON cbm_user_hist
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_i_cbm_user_hist..
--      PURPOSE: Insert trigger for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: tr_i_cbm_user_hist.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 280 - Triggers -----*/

DECLARE

v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT cbm_user_hist_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id     := v_rec_id;
    :new.session_id := v_rec_id;
    :new.status     := 'C';
    :new.lst_updt   := sysdate;
    :new.updt_by    := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise..
        RAISE;
       
END cbm_user_hist_seq;
/


