CREATE OR REPLACE TRIGGER tr_i_cbm_proces_ctrl_seq
BEFORE INSERT
ON cbm_process_control
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_i_cbm_proces_ctrl_seq..
--      PURPOSE: Insert trigger for cbm_process_ref..
--
--   CREATED BY: G. Belford.
-- CREATED DATE: 16 November 2009..
--
--       SOURCE: tr_i_cbm_proces_ctrl_seq.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName%
--    Sysdate:         %SYSDATE%
--    Date and Time:   %DATE%, %TIME%, and %DATETIME%
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor)
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create the Trigger now -----*/

DECLARE

v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT cbm_process_control_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.process_control_id := v_rec_id;
    :new.status             := 'C';
    :new.lst_updt           := sysdate;
    :new.updt_by            := user;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise..
        RAISE;
       
END tr_i_cbm_proces_ctrl_seq;
/
