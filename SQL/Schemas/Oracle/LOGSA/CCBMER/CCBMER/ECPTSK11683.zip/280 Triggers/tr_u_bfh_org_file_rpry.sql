CREATE OR REPLACE TRIGGER tr_u_bfh_org_file_rpry 
BEFORE UPDATE
ON     bfh_org_file_rpry 
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--        NAME:    tr_u_bfh_org_file_rpry 
--
--     PURPOSE:    To perform work as each row is updated. 
-- 
--      SOURCE:    tr_u_bfh_org_file_rpry.sql 
--   
-- ASSUMPTIONS:
--
-- LIMITATIONS:
--
--       NOTES:
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- 
-- Date       ECP #            Author           Description
-- ---------  ---------------  ---------------  --------------------------------
-- 29JAN2009                   Gene Belford     Trigger Created
--
/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
DECLARE

-- Exception handling variables (ps_) 

ps_procedure_name                std_cbm_debug_tbl.ps_procedure%TYPE  
    := 'TR_U_BFH_ORG_FILE_RPRY';  /*  */ 
ps_location                      std_cbm_debug_tbl.ps_location%TYPE  
    := 'Begin';                /*  */ 
ps_oerr                          std_cbm_debug_tbl.ps_oerr%TYPE   
    := null;                   /*  */ 
ps_msg                           std_cbm_debug_tbl.ps_msg%TYPE 
    := null;                   /*  */ 
ps_id_key                        std_cbm_debug_tbl.ps_id_key%TYPE 
    := 'tr_u_cbmwh_item_dim';  /*  */ 
    -- coder responsible for identying key for debug 

-- module variables (v_) 

v_update_date bfh_org_file_rpry.update_date%TYPE  := sysdate;
v_update_by   bfh_org_file_rpry.update_by%TYPE    := user;

BEGIN
    
    :new.update_date := v_update_date;
    :new.update_by   := v_update_by;

    EXCEPTION
        WHEN no_data_found THEN
            NULL;
        WHEN others THEN
            ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := '';
            
            INSERT 
            INTO std_cbm_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
             VALUES 
                (
                ps_procedure_name, ps_oerr, ps_location, user, 
                ps_id_key, ps_msg, sysdate);

--        RAISE;
       
END tr_u_bfh_org_file_rpry;
/

