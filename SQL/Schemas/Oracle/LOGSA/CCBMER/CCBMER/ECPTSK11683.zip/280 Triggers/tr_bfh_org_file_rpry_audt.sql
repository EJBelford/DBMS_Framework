CREATE OR REPLACE TRIGGER tr_bfh_org_file_rpry_audt 
BEFORE UPDATE OR DELETE ON bfh_org_file_rpry  
FOR EACH ROW

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_bfh_org_file_rpry_audt
-- 
--     PURPOSE:    Provides an audit trail of user changes to the control or 
--                 reference table. 
--    
--       NOTES:
-- 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry 
--    Sysdate:         11/23/2009 
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM 
--    Username:        G. Belford (set in TOAD Options, Procedure Editor) 
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 11/23/2009 - G. Belford  - RDPTSK00xxx - Created.. 
-- 

DECLARE

ps_procedure_name              std_cbm_debug_tbl.ps_procedure%type
    :=  'TR_BFH_ORG_FILE_RPRY_AUDT';
ps_location                    std_cbm_debug_tbl.ps_location%type := 'Begin';
ps_oerr                        std_cbm_debug_tbl.ps_oerr%type     := NULL;
ps_msg                         std_cbm_debug_tbl.ps_msg%type      
    := 'Trigger failed';
ps_id_key                      std_cbm_debug_tbl.ps_id_key%type   := NULL;

BEGIN

    IF UPDATING THEN 
        INSERT 
        INTO bfh_org_file_rpry_audt 
            (
            rec_id,
            update_by,
            update_date --,
--            old_xx_code,
--            new_xx_code,
--            old_xx_desc, 
--            new_xx_desc 
            )
        VALUES 
            (
            :old.rec_id, 
            USER, 
            SYSDATE --,
--            :old.xx_code, 
--            :new.xx_code, 
--            :old.xx_desc, 
--            :new.xx_desc 
            ); 
    ELSE 
        INSERT 
        INTO bfh_org_file_rpry_audt 
            (
            rec_id,
            update_by,
            update_date --,
--            new_xx_code,
--            new_xx_desc  
            )
        VALUES 
            (
            :old.rec_id, 
            USER, 
            SYSDATE --,
--            :old.xx_code, 
--            :old.xx_desc 
            ); 
    END IF;

EXCEPTION WHEN OTHERS THEN 

    ps_oerr    := SQLCODE;
    ps_msg     := SQLERRM;
    ps_id_key  := :old.rec_id; 
    
    INSERT 
    INTO std_cbm_debug_tbl 
        (
        ps_procedure,      ps_oerr,      ps_location,  called_by,
        ps_id_key,         ps_msg,       msg_dt
        )
    VALUES 
        (
        ps_procedure_name, ps_oerr,      ps_location,  null, 
        ps_id_key,         ps_msg,       sysdate
        );

END; -- end of tr_bfh_org_file_rpry_audt
/
