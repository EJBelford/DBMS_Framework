CREATE OR REPLACE TRIGGER tr_i_bfh_org_file_rpry_seq
BEFORE INSERT
ON bfh_org_file_rpry
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW

/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: tr_i_bfh_org_file_rpry..
--      PURPOSE: Insert trigger for bfh_org_file_rpry..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 11/23/2009..
--
--       SOURCE: tr_i_bfh_org_file_rpry.sql..
--
--        NOTES:
--
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         11/23/2009
--    Date and Time:   11/23/2009, 7:33:19 AM, and 11/23/2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 11/23/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Create the Trigger now -----*/

DECLARE

v_rec_id NUMBER;

BEGIN
    v_rec_id := 0;

    SELECT bfh_org_file_rpry_seq.nextval 
    INTO   v_rec_id 
    FROM   dual;
   
    :new.rec_id             := v_rec_id;
    :new.status             := 'C';
    :new.lst_updt           := sysdate;
    :new.updt_by            := user;

    :new.active_flag        := 'Y'; 
    :new.wh_record_status   := 'R';
    :new.wh_effective_date  := sysdate;
    :new.insert_by          := user;
    :new.insert_date        := sysdate;

    EXCEPTION
        WHEN others THEN
        -- consider logging the error and then re-raise..
        RAISE;
       
END bfh_org_file_rpry_seq;
/

