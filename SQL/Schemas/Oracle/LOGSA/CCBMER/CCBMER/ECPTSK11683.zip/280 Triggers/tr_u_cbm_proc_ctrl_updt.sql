CREATE OR REPLACE TRIGGER tr_u_cbm_proc_ctrl_updt 
BEFORE UPDATE
ON     cbm_process_control
FOR EACH ROW 

/*--*----|----*----|----*----|---- Team ITSS ----|----*----|----*----|----*---*/
--
--
--        NAME:    tr_u_cbm_proc_ctrl_updt..
-- 
--     PURPOSE:    Captures who and when the record was last chanaged
--                 in reference table. 
--    
--       NOTES:
-- 
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     %YourObjectName% 
--    Sysdate:         %SYSDATE% 
--    Date and Time:   %DATE%, %TIME%, and %DATETIME% 
--    Username:        %USERNAME% (set in TOAD Options, Procedure Editor) 
--    Table Name:      %TableName% (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 16-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
-- 

DECLARE

-- Exception handling variables (ps_)

ps_procedure_name                std_cbm_debug_tbl.ps_procedure%TYPE  
    := 'TR_U_CBM_PROC_CTRL_UPDT';  /*  */
ps_location                      std_cbm_debug_tbl.ps_location%TYPE  
    := 'Begin';                /*  */
ps_oerr                          std_cbm_debug_tbl.ps_oerr%TYPE   
    := null;                   /*  */
ps_msg                           std_cbm_debug_tbl.ps_msg%TYPE 
    := null;                   /*  */
ps_id_key                        std_cbm_debug_tbl.ps_id_key%TYPE 
    := 'tr_u_cbm_proc_ctrl_updt';  /*  */
    -- coder responsible for identying key for debug

-- module variables (v_)

v_update_date cbm_process_ref.update_date%TYPE  := sysdate;
v_update_by   cbm_process_ref.update_by%TYPE    := user;

BEGIN
    
    :new.update_date := v_update_date;
    :new.update_by   := v_update_by;

    EXCEPTION
        WHEN no_data_found THEN
            NULL;
        WHEN others THEN
            ps_oerr   := sqlcode;
            ps_msg    := sqlerrm;
            ps_id_key := ''; 
            
            INSERT 
            INTO std_cbm_debug_tbl 
                (
                ps_procedure, ps_oerr, ps_location, called_by, 
                ps_id_key, ps_msg, msg_dt
                )
             VALUES 
                (
                ps_procedure_name, ps_oerr, ps_location, user, 
                ps_id_key, ps_msg, sysdate);
                
--        RAISE;
       
END tr_u_cbm_proc_ctrl_updt;
/

