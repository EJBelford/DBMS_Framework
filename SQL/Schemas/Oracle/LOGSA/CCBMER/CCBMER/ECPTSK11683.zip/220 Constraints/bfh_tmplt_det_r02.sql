----------------------------------------------------------------BFH_TMPLT_DET----------------

ALTER TABLE bfh_tmplt_det ADD (
  CONSTRAINT bfh_tmplt_det_r02 
 FOREIGN KEY (bfh_tmplt_id) 
 REFERENCES bfh_templates (bfh_tmpflt_id));