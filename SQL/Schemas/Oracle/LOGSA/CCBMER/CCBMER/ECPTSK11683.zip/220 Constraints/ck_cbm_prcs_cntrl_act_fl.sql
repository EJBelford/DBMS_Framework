-- 
-- Non Foreign Key Constraints for Table cbm_process_control 
-- 
ALTER TABLE cbm_process_control ADD (
  CONSTRAINT ck_cbm_prcs_cntrl_act_fl
 CHECK (ACTIVE_FLAG='I' OR ACTIVE_FLAG='N' OR ACTIVE_FLAG='Y')
        );
