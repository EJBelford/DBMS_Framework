---------------------------------------------------------------------BFH_MODULES---------------

ALTER TABLE bfh_modules ADD (
  CONSTRAINT bfh_modules_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));

