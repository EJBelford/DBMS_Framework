----------------------------------------------------------------BFH_TEMPLATES----------------

ALTER TABLE bfh_templates ADD (
  CONSTRAINT pk_bfh_templates
 PRIMARY KEY
 (bfh_tmpflt_id)
    USING INDEX );
