/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: bfh_org_file_rpry..
--      PURPOSE: Create the status constraint for bfh_org_file_rpry..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 23-NOV-2009..
--
--       SOURCE: ck_bfh_org_file_rpry_stat_fl.sql..
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     bfh_org_file_rpry
--    Sysdate:         23-NOV-2009
--    Date and Time:   23-NOV-2009, 7:33:19 AM, and 23-NOV-2009 7:33:19 AM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 23-NOV-2009 - G. Belford  - ECPTSK11683 - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Constraints -----*/

-- ALTER TABLE bfh_org_file_rpry  
--     DROP CONSTRAINT ck_bfh_org_file_rpry_stat_fl;        

--                          1         2         3..
--                 123456789012345678901234567890..    

ALTER TABLE bfh_org_file_rpry  
    ADD CONSTRAINT ck_bfh_org_file_rpry_stat_fl 
    CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        );

