-- 
-- Non Foreign Key Constraints for Table cbm_process_ref 
-- 
ALTER TABLE cbm_process_ref ADD (
  CONSTRAINT ck_cbm_proc_ref_status
 CHECK (status='C' OR status='D' OR status='E' OR status='H' 
        OR status='L' OR status='P' OR status='Q' OR status='R'
        OR status='T' OR status='Z' OR status='N'
        ) 
);
