-- 
-- Non Foreign Key Constraints for Table cbm_process_ref 
-- 
ALTER TABLE cbm_process_ref ADD (
  CONSTRAINT ck_cbm_proc_ref_hide_fl
 CHECK (hidden_flag='N' OR hidden_flag='Y')
);
