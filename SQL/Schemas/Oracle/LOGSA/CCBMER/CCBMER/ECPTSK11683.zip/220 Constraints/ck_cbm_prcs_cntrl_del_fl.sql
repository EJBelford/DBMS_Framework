-- 
-- Non Foreign Key Constraints for Table cbm_process_control 
-- 
ALTER TABLE cbm_process_control ADD (
  CONSTRAINT ck_cbm_prcs_cntrl_del_fl
 CHECK (DELETE_FLAG='N' OR DELETE_FLAG='Y')
        );
