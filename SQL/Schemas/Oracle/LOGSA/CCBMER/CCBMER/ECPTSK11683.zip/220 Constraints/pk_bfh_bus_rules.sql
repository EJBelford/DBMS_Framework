-----------------------------------------------BFH_BUS_RULES------------------------------

ALTER TABLE bfh_bus_rules ADD (
  CONSTRAINT pk_bfh_bus_rules
 PRIMARY KEY
 (bfh_br_id)
    USING INDEX);
