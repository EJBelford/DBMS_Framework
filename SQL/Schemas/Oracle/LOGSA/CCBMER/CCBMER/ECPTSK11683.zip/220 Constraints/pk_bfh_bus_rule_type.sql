-----------------------------------------------BFH_BUS_RULE_TYPE------------------------------

ALTER TABLE bfh_bus_rule_type ADD (
  CONSTRAINT pk_bfh_bus_rule_type
 PRIMARY KEY
 (bfh_br_type)
    USING INDEX);
    
