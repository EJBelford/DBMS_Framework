-- 
-- Non Foreign Key Constraints for Table cbm_process_control 
-- 
ALTER TABLE cbm_process_control ADD (
  CONSTRAINT ck_cbm_prcs_cntrl_status
 CHECK (STATUS='C' OR STATUS='D' OR STATUS='E' OR STATUS='H' 
        OR STATUS='L' OR STATUS='P' OR STATUS='Q' OR STATUS='R' 
        OR STATUS='T' OR STATUS='Z' OR STATUS='N')
        );
