/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_table_ref..
--      PURPOSE: Create the hidden_flag constraint for cbm_table_ref..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 08-Sep-2009..
--
--       SOURCE: ck_cbm_table_ref_hid_fl.sql..
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_table_ref
--    Sysdate:         08-Sep-2009
--    Date and Time:   08-Sep-2009, 10:23:07, and 08-Sep-2009 10:23:07
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 08-Sep-2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- Constraints -----*/

-- ALTER TABLE cbm_table_ref  DROP CONSTRAINT ck_cbm_table_ref_hid_fl;       

--                          1         2         3..
--                 123456789012345678901234567890..    

ALTER TABLE cbm_table_ref  
    ADD CONSTRAINT ck_cbm_table_ref_hid_fl 
    CHECK (hidden_flag='N' OR hidden_flag='Y');

