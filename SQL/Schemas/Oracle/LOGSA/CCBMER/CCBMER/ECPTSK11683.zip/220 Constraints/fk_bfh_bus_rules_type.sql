-----------------------------------------------BFH_BUS_RULES------------------------------

ALTER TABLE bfh_bus_rules ADD (
  CONSTRAINT fk_bfh_bus_rules_type 
 FOREIGN KEY (BFH_BR_TYPE) 
 REFERENCES bfh_bus_rule_type (bfh_br_type));

