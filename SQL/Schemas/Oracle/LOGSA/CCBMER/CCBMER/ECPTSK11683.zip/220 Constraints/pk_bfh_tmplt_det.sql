----------------------------------------------------------------BFH_TMPLT_DET----------------

ALTER TABLE bfh_tmplt_det ADD (
  CONSTRAINT pk_bfh_tmplt_det 
 PRIMARY KEY
 (bfh_tmplt_id, bfh_tmplt_seq_no)
    USING INDEX);
