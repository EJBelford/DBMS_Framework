----------------------------------------------------------------------- BFH_USER----------------

ALTER TABLE bfh_user ADD (
  CONSTRAINT pk_bfh_user
 PRIMARY KEY
 (bfh_user));

