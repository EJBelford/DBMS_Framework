/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/
--
--         NAME: cbm_user_hist..
--      PURPOSE: Create the active_flag constraint for cbm_user_hist..
--
--   CREATED BY: G. Belford..
-- CREATED DATE: 12/17/2009..
--
--       SOURCE: ck_cbm_user_hist_act_fl.sql..
-- 
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
-- Automatically available Auto Replace Keywords:
--    Object Name:     cbm_user_hist
--    Sysdate:         12/17/2009
--    Date and Time:   12/17/2009, 12:45:57 PM, and 12/17/2009 12:45:57 PM
--    Username:        G. Belford (set in TOAD Options, Procedure Editor)
--    Table Name:       (set in the "New PL/SQL Object" dialog) 
--
/*--*----|----*----|----*----|----*----|----*----|----*----|----*----|----*---*/
--     Change History:
-- DD-MMM-YYYY - Who         - RDP / ECP # - Details..
-- 12/17/2009 - G. Belford  - RDPTSK00xxx - Created.. 
--
/*--*----|----*----|----*----|---- TEAM ITSS ----*----|----|----*----|----*---*/

/*----- 220 - Constraints -----*/

-- ALTER TABLE cbm_user_hist  DROP CONSTRAINT ck_cbm_user_hist_act_fl;        

--                          1         2         3..
--                 123456789012345678901234567890..    

ALTER TABLE cbm_user_hist  
    ADD CONSTRAINT ck_cbm_user_hist_act_fl 
    CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y');

