---------------------------------------------------------------------BFH_MOD_DET---------------

ALTER TABLE bfh_mod_det ADD (
  CONSTRAINT bfh_mod_det_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));

