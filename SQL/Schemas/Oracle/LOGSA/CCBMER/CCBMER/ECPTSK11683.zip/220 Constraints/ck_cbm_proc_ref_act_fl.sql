-- 
-- Non Foreign Key Constraints for Table cbm_process_ref 
-- 
ALTER TABLE cbm_process_ref ADD (
  CONSTRAINT ck_cbm_proc_ref_act_fl
 CHECK (active_flag='I' OR active_flag='N' OR active_flag='Y')
);
