----------------------------------------------------------------BFH_TEMPLATES----------------

ALTER TABLE bfh_templates ADD (
  CONSTRAINT bfh_templates_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));

