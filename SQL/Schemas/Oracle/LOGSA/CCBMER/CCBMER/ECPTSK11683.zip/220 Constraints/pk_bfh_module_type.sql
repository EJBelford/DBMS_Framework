---------------------------------------------------------------------BFH_MODULE_TYPE-----------

ALTER TABLE bfh_module_type ADD (
  CONSTRAINT pk_bfh_module_type
 PRIMARY KEY
 (bfh_mod_typ_id)
    USING INDEX );

