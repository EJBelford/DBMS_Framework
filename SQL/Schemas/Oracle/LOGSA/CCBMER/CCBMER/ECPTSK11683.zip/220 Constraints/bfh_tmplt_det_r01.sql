----------------------------------------------------------------BFH_TMPLT_DET----------------

ALTER TABLE bfh_tmplt_det ADD (
  CONSTRAINT bfh_tmplt_det_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));