-- 
-- Non Foreign Key Constraints for Table cbm_process_control 
-- 
ALTER TABLE cbm_process_control ADD (
  CONSTRAINT ck_cbm_prcs_cntrl_hid_fl
 CHECK (HIDDEN_FLAG='N' OR HIDDEN_FLAG='Y')
        );
