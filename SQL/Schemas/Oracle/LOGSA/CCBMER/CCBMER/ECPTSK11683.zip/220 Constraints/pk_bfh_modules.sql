---------------------------------------------------------------------BFH_MODULES---------------

ALTER TABLE bfh_modules ADD (
  CONSTRAINT pk_bfh_modules
 PRIMARY KEY
 (bfh_mod_id)
    USING INDEX);
