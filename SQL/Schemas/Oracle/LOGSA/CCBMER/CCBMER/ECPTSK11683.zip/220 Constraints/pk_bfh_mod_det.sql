---------------------------------------------------------------------BFH_MOD_DET---------------

ALTER TABLE bfh_mod_det ADD (
  CONSTRAINT pk_bfh_mod_det
 PRIMARY KEY
 (bfh_mod_id, bfh_mod_seq)
    USING INDEX);
