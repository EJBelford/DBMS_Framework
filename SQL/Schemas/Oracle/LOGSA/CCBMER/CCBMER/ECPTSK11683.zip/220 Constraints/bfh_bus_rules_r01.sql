-----------------------------------------------BFH_BUS_RULES------------------------------

ALTER TABLE bfh_bus_rules ADD (
  CONSTRAINT bfh_bus_rules_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));

