-----------------------------------------------BFH_BUS_RULE_TYPE------------------------------

ALTER TABLE bfh_bus_rule_type ADD (
  CONSTRAINT bfh_bus_rule_type_r01 
 FOREIGN KEY (bfh_user) 
 REFERENCES bfh_user (bfh_user));

