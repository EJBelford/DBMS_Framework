// JavaScript Document

function doExpand(xxx,yyy){
	if(xxx.style.display=='none'){
	xxx.style.display = '';
	yyy.src="images/expando_open.gif"
	}else{
	xxx.style.display = 'none';
	yyy.src="images/expando_closed.gif"
	}
}

function doExpand3(xxx,yyy){

	// keeps us from navigating away from page
	// if href attribute is set incorrectly
	var eventTag = window.event.srcElement;
	
	eventTag.parentNode.href = "javascript:void(0)";

	if(xxx.style.display=='none'){
	xxx.style.display = '';
	yyy.src="images/x_section_close.gif"
	}else{
	xxx.style.display = 'none';
	yyy.src="images/x_section_open.gif"
	}
}

function doCloseOrOpenAll(xxx,yyy)
{
	if (AllATag.innerText=='collapse all')
	{
		xxx.style.display = 'none';
		yyy.src="images/x_section_open.gif"
	}
	else
	{
		xxx.style.display = '';
		yyy.src="images/x_section_close.gif"	
	}
}

function doExpandAllRolesRight()
{
	try
	{
	
		try
		{
			if (workstream1 != null)
			{
				doCloseOrOpenAll(workstream1, block0);
			}
		}
		catch(e)
		{
			// Do nothing
		}
		
		try
		{
			if (workitems1 != null)
			{
				doCloseOrOpenAll(workitems1,block1);
			}
		}
		catch(e)
		{
			// Do nothing
		}
		
		try
		{
			if (workproducts1 != null)
			{
				doCloseOrOpenAll(workproducts1,block4);
			}
		}
		catch(e)
		{
			// Do nothing
		}
		
		try
		{
			if (reports1 != null)
			{
				doCloseOrOpenAll(reports1,block6);
			}
		}
		catch(e)
		{
			// Do nothing
		}
		
		try
		{
			if (queries1 != null)
			{
				doCloseOrOpenAll(queries1,block5);
			}
		}
		catch(e)
		{
			// Do nothing
		}
		
		try
		{
			if (howtos1 != null)
			{
				doCloseOrOpenAll(howtos1,block3);
			}
		}
		catch(e)
		{
			// Do nothing
		}	

		// keeps us from navigating away from page
		// if href attribute is set incorrectly
		var eventTag = window.event.srcElement;
		eventTag.href = "javascript:void(0)";
		
		if (AllATag.innerText=='collapse all')
			AllATag.innerText='open all';
		else
			AllATag.innerText='collapse all';
	}
	catch(e)
	{
		alert("Exception : "+e.message);
	}
}

function open_window1(url) {
popWin = window.open(url,"win1","directories=0,location=0,menubar=0,resizable=1,scrollbars=1, status=0,titlebar=no,toolbar=0,width=300,height=400");
}

function open_window2(url) {
popWin = window.open(url);
}
function doPortal() {
var hostName = location.host;
if (hostName.length != 0) {
var fullName = location.href;
var endOfHostName = fullName.indexOf(hostName) + hostName.length + 1;
var endOfSites = fullName.indexOf("/", endOfHostName);
var endOfProjectName = fullName.indexOf("/", endOfSites + 1);
open_window1(fullName.substr(0, endOfProjectName + 1));
}
}