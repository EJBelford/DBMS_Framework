function doHeader(){
	document.write('<table class="idheader" width="100%"  height="46" border="0" cellspacing="0" cellpadding="0" bgcolor="#77A0D6">')
	document.write('<tr>')
	document.write('<td class="bottom" style="text-align:right;"><p class="p1a"><a class="white" href="#"><b>Project Portal</b></a><img src="images/clear.gif" width="36" height="1"></p></td>')
	document.write('</tr>')
	document.write('<tr>')
	document.write('<td><img src="images/clear.gif" width="24" height="1"></td>')
	document.write('</tr>')
	document.write('</table>')
}
