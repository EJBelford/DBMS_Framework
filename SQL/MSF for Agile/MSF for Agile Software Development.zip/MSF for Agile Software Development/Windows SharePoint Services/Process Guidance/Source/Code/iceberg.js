// Used to load the XSL that shows the glossary.

Main();

function Main()
{

	var addr = document.location.href.replace(/%26/g, "&");
	var matches = addr.match(/(\?|&)(.*?)(?=(?:&|$))/ig);

	var ParamNames = new Array();
	var ParamValues = new Array();
	
	var DocID = null;
	var Detail = null;
	var Highlight = null;
		
	var i = 0, j = 0;

	// Parse the URL's Attributes		
	if (matches != null)
	{
		
		for (i = 0; i < matches.length; i++)
		{
			var run = matches[i].match(/(\?|&)(.*?)(=|$)/ig);
			ParamNames[i] = RegExp.$2;
			var runagain = matches[i].match(/=(.*?)(?:&|$)/ig);
			ParamValues[i] = RegExp.$1;
			ParamValues[i] = ParamValues[i].replace(/%20/g, " ");
		}

		// Select the specific "DocID" URL attribute
		for (i = 0; i < ParamNames.length; i++)
			if (ParamNames[i] == "DocID") DocID = ParamValues[i];

		// Select the specific "Detail" URL attribute
		for (i = 0; i < ParamNames.length; i++)
			if (ParamNames[i] == "Detail") Detail = ParamValues[i];			
			
		// Select the specific "Highlight" URL attribute
		for (i = 0; i < ParamNames.length; i++)
			if (ParamNames[i] == "Highlight") Highlight = ParamValues[i];		
				
	}

	if (GetCookie("OverviewOn") == "")
	{
		SetCookie("OverviewOn", "TRUE");
	}
	
	// Set Overview Open or Closed for all pages
	if (GetCookie("OverviewOn") == "TRUE")
	{
		// Set OverviewOpen = 'TRUE'
		ParamNames[ParamNames.length] = "OverviewOpen";
		ParamValues[ParamValues.length] = "TRUE";	
	}
	else
	{
		// Set OverviewOpen = 'FALSE'
		ParamNames[ParamNames.length] = "OverviewOpen";
		ParamValues[ParamValues.length] = "FALSE";
	}
	
	// Open the main data source
	var navXmlDoc = new ActiveXObject("Msxml2.DOMDocument.3.0");
	navXmlDoc.async = false;
	navXmlDoc.resolveExternals = false;
	navXmlDoc.load("XML\\Nav.xml");
		
	// Figure out the Content XSL from the DocID in the NAV XML
	var Xsl3 = null;
	var Xsl4 = null;
	
	var SelectedTab = null;
	
	var tempPivotNode = null;
	var PivotNode = null;

	// *** Determine Xsl3
	//
	// It comes from the DocID (Nav or Query Results) or Default SideMenuItem (Nav or Query Results)

    //alert("DocID : "+DocID+" Highlight : "+Highlight);
	if (navXmlDoc != null)
	{
		
		if (DocID == null)	// No DocID, find default Tab and SideMenu
		{
			
		
			// Find the Default Xform
			var Xsl3Obj = null;
			var role = null;
			
			// Check to see if there is a role cookie.
			if (role = GetCookie("Role"))
			{
				if (role == 'Architect')
					window.location = "?DocID=Architect";
				else if (role == 'Business Analyst')
					window.location = "?DocID=Business Analyst";
				else if (role == 'Developer')
					window.location = "?DocID=Developer";
				else if (role == 'Project Manager')
					window.location = "?DocID=Project Manager";
				else if (role == 'Tester')
					window.location = "?DocID=Tester";
				else if (role == 'Release Manager')
					window.location = "?DocID=Release Manager";
				else
					Xsl3Obj = navXmlDoc.selectSingleNode("/Tabs/TabItem[@Type='DefaultTab']/SideMenu/SideMenuItem[@Type='DefaultTabSelection']/DocIDItem[@Type='DefaultDocID']/Xform");
			}
			else
			{
				Xsl3Obj = navXmlDoc.selectSingleNode("/Tabs/TabItem[@Type='DefaultTab']/SideMenu/SideMenuItem[@Type='DefaultTabSelection']/DocIDItem[@Type='DefaultDocID']/Xform");
			}
	
			// Is the Default Xform is static in the Nav?
			if (Xsl3Obj != null)  // The default SideMenu is defined in Nav.XML!
			{
				//alert("Nav Based!");
				// TODO: Figure out the TabName so that we can send it to Tabs.XSL
				
				/* //Removing 7pm
				SelectedTab = getTabName(Xsl3Obj, "../../../../TabName");

				Xsl3 = Xsl3Obj.text;
				*/
				// Set the DocID since the QueryString didn't contain it
				//var Xsl3DocID = null;
				var Xsl3DocIDObj = null;
				
				Xsl3DocIDObj = navXmlDoc.selectSingleNode("/Tabs/TabItem[@Type='DefaultTab']/SideMenu/SideMenuItem[@Type='DefaultTabSelection']/DocIDItem[@Type='DefaultDocID']/DocID");
				
				if (Xsl3DocIDObj != null)
				{
				
					//Xsl3DocID = Xsl3DocIDObj.text;
					DocID = Xsl3DocIDObj.text;
					
					ParamNames[ParamNames.length] = "DocID";
					ParamValues[ParamValues.length] = DocID;
					
					//alert("In Nav!");
				
				}
				else
					alert("Assert: The DefaultTab | DefaultTabSelection has a Xform but no DocID"); 
			}
			else	// The default SideMenu is an Xpath Query into the ProcessGuidance.XML file!
			{
			
				// Grab the Xform for the default SideMenuItem that contains the Query
				Xsl3Obj = navXmlDoc.selectSingleNode("/Tabs/TabItem[@Type='DefaultTab']/SideMenu/SideMenuItem[@Type='DefaultTabSelection'][@ItemType='Query']/Xform");
				
				if (Xsl3Obj != null)
				{	
					// TODO: Figure out the TabName so that we can send it to Tabs.XSL
					/* // Removing 7pm
					SelectedTab = getTabName(Xsl3Obj, "../../../TabName");
					
					
					// Set the Xsl3 Xform 
					Xsl3 = Xsl3Obj.text;
					*/
					// Since the DocID in this case is the first node in the
					// results of the Xpath Query, execute the query
					
					var DocIDQuery = navXmlDoc.selectSingleNode("/Tabs/TabItem[@Type='DefaultTab']/SideMenu/SideMenuItem[@Type='DefaultTabSelection'][@ItemType='Query']/SideMenuName");
					//var Xsl3DocID = null;
					
					if (DocIDQuery != null)
					{
						
						//Xsl3DocID = getFirstNode(DocIDQuery.text);
						DocID = getFirstNode(DocIDQuery.text).text;
						//alert("Xsl3DocID : "+Xsl3DocID.text);
						
						// Set the DocID XSL Param since it wasn't set by the QueryString
						ParamNames[ParamNames.length] = "DocID";
						//ParamValues[ParamValues.length] = Xsl3DocID;
						ParamValues[ParamValues.length] = DocID;
					}	
				}
			}
					
		}	
		// Handle the case when there is a QueryString (ie. internal link)
		// Note: If the page was loaded without a DocID, at this point the Default DocID has 
		// been set.
		if (DocID != null)
		{
			// Find the Xform for the current DocID
			var Xsl3Obj = null;
			
			Xsl3Obj = navXmlDoc.selectSingleNode("//DocIDItem[DocID='"+DocID+"']/Xform");
			
			if (Xsl3Obj != null) // The SideMenu based on the DocID is in Nav.XML
			{
				//alert(Xsl3Obj.text);	
				
				// Find out the TabName and set it for Tabs.XML
				
				SelectedTab = getTabName(Xsl3Obj, "../../../../TabName");
				//alert("DocID != null in Nav!");
				
				Xsl3 = Xsl3Obj.text;
				
				// Get the PivotNode
				PivotNode = Xsl3Obj.selectSingleNode("../Pivot");
				if (PivotNode != null)
				{						
					//alert("Nav based PivotNode : "+PivotNode.text);
				}
				
				// There can be ShareSideMenuItem's inside 
			}
			else // The SideMenu for the DocID is an Xpath Query into the ProcessGuidance.XML file!
			{
			
				//alert("Query Based!");
				// Look for the DocID in the SideMenuItems Xpath Queries
				var SideMenuQueriesRoot = null;
				var QueryResultsNodes = null;
				
				// BUG!  This doesn't look through all SideMenuItems, it looks through a set of SideMenuNames
				// Change to look at SideMenuItem's.  NOTE: Everthing inside this IF statement changes!
				//SideMenuQueries = navXmlDoc.selectNodes("//SideMenuItem[@ItemType='Query']/SideMenuName");
				SideMenuQueriesRoot = navXmlDoc.selectNodes("//SideMenuItem[@ItemType='Query']");
							
				if (SideMenuQueriesRoot != null)
				{
					// Find out the TabName and set it for Tabs.XML
					//alert(SideMenuQueries.selectSingleNode("..").text);
					//SelectedTab = getTabName(SideMenuQueries, "..");
					//alert("DocID != null, Query into PG.XML");
					
					var SideMenuQueryNode = null;
					var SideMenuQueryNodeText = null;
					var CurrentXform = null;
					var SideMenuQueries = null;
					
					var ResultNode = null;
					
					//alert("QueriesRoot length : "+SideMenuQueriesRoot.length);
				
					//alert(SideMenuQueriesRoot.length);
					
					// Go through all the Queries
					for (i = 0; i < SideMenuQueriesRoot.length; i++)
					{
						
						SideMenuQueryNode = SideMenuQueriesRoot.nextNode();
						
						SelectedTab = getTabName(SideMenuQueryNode,"../../TabName");
						//alert(SideMenuQueryNode.selectSingleNode("Xform").text);
						
						// Store the current Xform, just in case it contains the DocID in it's Query results
						CurrentXform = SideMenuQueryNode.selectSingleNode("Xform").text;
						
						// Get the temp tempPivotNode
						tempPivotNode = SideMenuQueryNode.selectSingleNode("Pivot");
						
						
						SideMenuQueryNodeText = SideMenuQueryNode.selectSingleNode("SideMenuName").text;
						//alert("**** i: "+i+" SMQNodeText : "+SideMenuQueryNodeText);
						//alert(" SideMenuQueryNode : "+SideMenuQueryNodeText);
						QueryResultsNodes = selectNodes(SideMenuQueryNodeText);
						
						if (QueryResultsNodes != null)
						{
						
							//alert("QueryResultsNodes Length : "+QueryResultsNodes.length);
							// Go through all the Results
							for (j = 0; j < QueryResultsNodes.length; j++)
							{
								ResultNode = QueryResultsNodes.nextNode();
								if (ResultNode != null)
								{
									//alert("ResultNodeText : "+ResultNode.text);
									
									// If the current result 
									if (ResultNode.text == DocID)
									{
										Xsl3 = CurrentXform;
										//alert("Setting Xsl3 : "+Xsl3);
										
										// Set PivotNode for use in getting XSL4
										PivotNode = tempPivotNode;
										//alert("Setting PivotNode: "+PivotNode.text);
										
										// Found the DocID inside the SideMenuQuery, let's tell the SideMenu and Tabs
										ParamNames[ParamNames.length] = "WheresDocID";
										ParamValues[ParamValues.length] = "SMQ";
									}
								}
							}
						}
						
						
						
						
						// Check to see if we can find the DocID inside a ShareSideMenuItem Node, and then grab the XSL3 Xform!
					}
					
					// Check for all ShareSideMenuItem's (anywhere in the Nav XML) and handle it.
					if (Xsl3 == null)
					{
						
						var tempXsl3 = EvaluateShareSideMenuItems(navXmlDoc, SelectedTab, DocID, ParamNames, ParamValues);
						if (tempXsl3 != null)
						{
							//alert("Setting Xsl3 : "+tempXsl3);
							Xsl3 = tempXsl3;
						}
					}
				}
			
			}
			
			//	alert("DocID '"+DocID+"' doesn't have a Xform in Nav.XML");
			
		}
	
	}
	
	
	if (Xsl3 != null)
	{	
		var NavHighlightNode = null;
		var QueryHighlightNode = null;
		var FormatNavHighlightNode = null;

		// If there is no highlight and the current DocID has a Pivot child
		// then PivotNode will contain the Pivot element.
		if (Highlight == null) 
		{
			//alert("Highlight == null");
			// Find out the default PivotItem for the current DocID.  There can 
			// only be one in the Nav XML file
			
			// Get default Highlight
			// Note: We don't support QueryAppend PivotItem types that are Default (only Normal)
			if (PivotNode != null)
			{
				//alert("Children inside Pivot : "+PivotNode.childNodes.length);
				
				NavHighlightNode = PivotNode.selectSingleNode("PivotItem[@ItemType='Nav'][@Type='Default']/PivotItemName");
				// PivotNav:
				// Get the PivotItem where Type='Default' ItemType='Nav'
				if (NavHighlightNode != null)
				{
					//alert("Nav Default Highlight : "+NavHighlightNode.text);
					Highlight = NavHighlightNode.text;
					
				}
				
				QueryHighlightNode = PivotNode.selectSingleNode("PivotItem[@ItemType='Query'][@Type='Default']/QueryDefault");
				if (QueryHighlightNode != null)
				{
					// PivotQuery:
					// Get the PivotItem where Type='Default' ItemType='Query'
					
					//alert("Query Default Highlight : "+QueryHighlightNode.text);
					
					// Replace $DocID with the value of DocID
					var query = QueryHighlightNode.text.replace("$DocID", "'"+DocID+"'");
					//alert("New Query : "+query);
					
					// Get the first result from the Query
					var queryResult = getFirstNode(query);
					
					if (queryResult != null)
					{
						//alert("Result: "+queryResult.text);
						Highlight = queryResult.text;	
					}
					
				}
				
				FormatNavHighlightNode = PivotNode.selectSingleNode("PivotItem[@ItemType='FormatNav'][@Type='Default']/PivotItemName");
				if (FormatNavHighlightNode != null)
				{
					//alert("in FormatNavHighlightNode");
					var tempHighlight = FormatNavHighlightNode.text.replace("$DocID", DocID);
					
					Highlight = tempHighlight;
					
				}
				
				
				if (Highlight != null)
				{
					ParamNames[ParamNames.length] = "Highlight";
					ParamValues[ParamValues.length] = Highlight;
				}
			}
			/*		
			try
			{
				//alert("case 1");
				Highlight = navXmlDoc.selectSingleNode("//DocIDItem[DocID='"+DocID+"']/Pivot/PivotItem[@Type='Default']/PivotItemName").text;
				Xsl4 = navXmlDoc.selectSingleNode("//DocIDItem[DocID='"+DocID+"']/Pivot/PivotItem[@Type='Default']/PivotItemXform").text;
				
				// Add the Highlight parameter even though it didn't come in through the Query String
				ParamNames[ParamNames.length] = "Highlight";
				ParamValues[ParamValues.length] = Highlight;
			}
			catch(e)
			{
			}			
			*/
		} 

		if (Highlight != null) // Highlight is non-null - in this case, we need to set XSL4
		{
			//alert("Highlight : "+Highlight);
			//alert("DocID : "+DocID);
			//alert("PivotNode : "+PivotNode.selectSingleNode("PivotItem[@ItemType='Nav']/DocIDItem[DocID='"+DocID+"']").text);
			if (PivotNode != null)
			{
				// Determine XSL4 from the current Highlight variable
				var Xsl4Node = PivotNode.selectSingleNode("PivotItem[@ItemType='Nav'][PivotItemName='"+Highlight+"']/PivotItemXform"); 
				
				// NOTE: Currently, only one FormatNav node is supported.
				var Xsl4FormatNavNode = PivotNode.selectSingleNode("PivotItem[@ItemType='FormatNav']/PivotItemXform"); 
				
				// PivotNav:
				if (Xsl4Node != null)
				{
					Xsl4 = Xsl4Node.text;
					//alert("Xsl4 : "+Xsl4);
				}
				else if (Xsl4FormatNavNode != null)
				{
					// Figure out if the current Highlight is what matches the FormatNav PivotItemName
					var pivotFormatNavNameNode = PivotNode.selectSingleNode("PivotItem[@ItemType='FormatNav']/PivotItemName")
				
					var tempHighlight = pivotFormatNavNameNode.text.replace("$DocID", DocID);
					if (Highlight == tempHighlight)
					{
						Xsl4 = Xsl4FormatNavNode.text;
					}					
				}				
				
				// If we still haven't gotten a Xsl4, maybe it's Query based
				if (Xsl4 == null)
				{
					//alert("Checking a PivotItem Query");
					// Check to see if there are Query Pivots.
					Xsl4Node = PivotNode.selectSingleNode("PivotItem[@ItemType='Query']");
					//alert("Xsl4Node : "+Xsl4Node.text);
					if (Xsl4Node != null)
					{
						// Go through all the PivotQuery's inside this PivotNode to find the Highlight in the QueryResult
						var currPivotItem = null;
						var currXsl4 = null;
						var currXsl4Text = null;
						
						//alert("PivotNode length : "+PivotNode.childNodes.length);
						for (i = 0; i < PivotNode.childNodes.length; i++)
						{
							currPivotItem = PivotNode.childNodes.item(i);
							
							if (currPivotItem != null)
							{
								currXsl4 = currPivotItem.selectSingleNode("PivotItemXform");
								
								if (currXsl4 != null)
								{
									currXsl4Text = currXsl4.text;
									//alert("currXsl4Text : "+currXsl4Text)
									
									var queryNode = currPivotItem.selectSingleNode("Query");
									var queryAppendNode = currPivotItem.selectSingleNode("AppendHighlight");
									
									if (queryNode != null)
									{
										var query = queryNode.text.replace("$DocID", "'"+DocID+"'");
										//alert("Query :"+query);
										
										//alert("Query : "+query);
										
										var queryResultNodes = selectNodes(query);
										
										if (queryResultNodes != null)
										{
											//alert("CurrentXSL4 : "+currXsl4Text+" queryResultNodes children : "+queryResultNodes.length);
											//alert("resultNodes children : "+queryResultNodes.length);
											for (j = 0; j < queryResultNodes.length; j++)
											{
												//alert("QueryResult j: "+j+" result: "+queryResultNodes.item(j).text);
												
												// Check for the results without the AppendHighlight
												if ((queryResultNodes.item(j).text == Highlight) && 
												    (queryAppendNode == null))
												{
													//alert("Setting XSL4 : "+currXsl4Text);
													Xsl4 = currXsl4Text;
												}
												
												// Check for the AppendHighlight use
												if (queryAppendNode != null)
												{
												    
												    var queryAppended =  queryResultNodes.item(j).text + " " + queryAppendNode.text;
												    //alert("QueryAppended : '"+queryAppended+"'");
												    if (queryAppended == Highlight)
												    {
												        //alert("Got HighlightAppend!");
												        Xsl4 = currXsl4Text;
												        
												        // Set the AppendHighlight XSL variable for the XSL4 page
												        ParamNames[ParamNames.length] = "AppendHighlight";
			                                            ParamValues[ParamValues.length] = " "+queryAppendNode.text;
												    }
												}
												
											}
										}
									}
									
								}
								
							}
						}
					}
					//Xsl4Node = PivotNode.selectSingleNode("PivotItem[@ItemType='Query']/");
				}
				
				// PivotQuery:
				
			}
		
			//alert("case 2");
			/*
			var xsl4Node = navXmlDoc.selectSingleNode("//DocIDItem[DocID='"+DocID+"']/Pivot/PivotItem[PivotItemName='"+Highlight+"']/PivotItemXform");
			if (xsl4Node != null)
			{
				Xsl4 = xsl4Node.text;
			}
			*/
		}
	}

	if (ParseOkay(navXmlDoc))
	{
		// PlaceXLS(xmlDoc, page, "SeeAlso.xsl", SeeAlsoHTML, ParamNames, ParamValues);
		

		if (SelectedTab != null)
		{
			// Set the SelectedTab param
			ParamNames[ParamNames.length] = "SelectedTabs";
			ParamValues[ParamValues.length] = SelectedTab;
			
			PlaceXLS(navXmlDoc, "XSLs\\Tabs.xsl", TabsHTML, ParamNames, ParamValues);
			PlaceXLS(navXmlDoc, "XSLs\\SideMenu.xsl", sidemenuHTML, ParamNames, ParamValues);
			PlaceXLS(navXmlDoc, "XSLs\\SeeAlso.xsl", SeeAlsoHTML, ParamNames, ParamValues);
			if (Xsl3 != null)
			{
				PlaceXLS(navXmlDoc, "XSLs\\"+Xsl3, XSL3, ParamNames, ParamValues);
			}
			if (Xsl4 != null)
			{
				PlaceXLS(navXmlDoc, "XSLs\\"+Xsl4, XSL4, ParamNames, ParamValues);
			}		
		}
		

	
	}
}

function EvaluateShareSideMenuItems(navRoot, SelectedTab, DocID, ParamNames, ParamValues)
{
	var Xsl3 = null;
	
	//alert("EvaluateShareSideMenuItems");

	// Grab all the 'ShareSideMenuItem' elements under SideMenuItem
	var ShareSMINodes = navRoot.selectNodes("//ShareSideMenuItem");
	
	if (ShareSMINodes != null)
	{
		//alert("ShareSMINodes : "+ShareSMINodes.length);
		for (j = 0; j < ShareSMINodes.length; j++)
		{
			var node = ShareSMINodes.nextNode();

			SelectedTab = getTabName(node,"../../../TabName");
			//alert("SelectedTab : "+SelectedTab);
		
			var SSMIQuery = node.selectSingleNode("Query");
			var SSMIXform = node.selectSingleNode("Xform");
			
			if ((SSMIQuery != null) && (SSMIXform != null))
			{
			
				
				var SSMIQueryText = SSMIQuery.text;
				var SSMIXformText = SSMIXform.text;
				//alert(SSMIXformText);
				
				// Replace $DocID with DocID's value
				SSMIQueryText = SSMIQueryText.replace("$DocID", "'"+DocID+"'");
				//alert("SSMIQueryText : "+SSMIQueryText);
				// Evaluate the Query
				var SSMIQueryResultNodes = selectNodes(SSMIQueryText);
				
				if (SSMIQueryResultNodes != null)
				{
				
					//alert("SSMIQueryResultNodes : "+SSMIQueryResultNodes.length );
					// We should only get 1 result node
					if (SSMIQueryResultNodes.length > 0)
					{
						//alert("SelectedTab : "+SelectedTab);
						//alert("SSMIQueryText : "+SSMIQueryText);
						var QueryResultNodeText = SSMIQueryResultNodes.nextNode().text;
						//alert("Got "+SSMIQueryResultNodes.length+" Node(s) : "+QueryResultNodeText);
						Xsl3 = SSMIXformText;
						
						//alert("Setting XSL3 SSMI : "+SSMIXformText);
						
						// Found the DocID inside the SharedSideMenuItem, let's tell the SideMenu and Tabs
						ParamNames[ParamNames.length] = "WheresDocID";
						ParamValues[ParamValues.length] = "ShareSMI";
						
						ParamNames[ParamNames.length] = "ShareSMILoc";
						ParamValues[ParamValues.length] = j;
						
						// Send the Role into the Xsl3
						ParamNames[ParamNames.length] = "Role";
						ParamValues[ParamValues.length] = QueryResultNodeText;						
					}
				}
				
			}
		
			// Evaluate the query
		}
	}
	
	//if (Xsl3 != null)
	//	alert("Returning Xsl3 = "+Xsl3);
	
	return Xsl3;
}

function getTabName(node, query)
{
	var tabNameObj = null;
	var tabName = null;
	
	tabNameObj = node.selectSingleNode(query);
	
	if (tabNameObj != null)
	{
		//alert("getTabName "+tabNameObj.text);
		tabName = tabNameObj.text;
	}
		else alert("ERROR! getTabName() | Couldn't determine the selected tab name!");
	
	return tabName;
}

function ParseOkay(xmldoc)
{
	if (xmldoc.parseError.errorCode != 0)
	{
		var err = xmldoc.parseError;
		alert("Parsing Error:\n" + err.url + "\n" + err.reason + "On line " + err.line + " at " + err.linepos + "\n" + err.srcText);
		return false;
	}
	else return true;
}


/*
	Params:
	- XmlInput - XML contents
	- Page - not used.  Used to be the PageInfo Page element
	- XslName - XSL used to show data
	- ParamName
	- ParamValues
*/
function PlaceXLS(XmlInput, XslName, DivID, ParamNames, ParamValues)
{
	
	// Pull information for the primary document space
	var xslt = new ActiveXObject("Msxml2.XSLTemplate.3.0");
	var xslDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.3.0");
	var xslProc;
	xslDoc.async = false;
	xslDoc.resolveExternals = false;
	xslDoc.load(XslName);
	

	// If the parsing was successful, translate and place the output
	if (ParseOkay(xslDoc))
	{
		xslt.stylesheet = xslDoc;
		xslProc = xslt.createProcessor();
		xslProc.input = XmlInput;
		
		// Pass the attributes from the URL to the XSL as parameters
		for (i = 0; i < ParamNames.length; i++)
		{
			xslProc.addParameter(ParamNames[i], ParamValues[i]);
		}
		
		// Perform the translation
		xslProc.transform();
		DivID.innerHTML = xslProc.output;
	}
}

function doLink(link){
	window.location = "ProcessGuidance.htm?DocID="+link;
}

function doLinkExternal(link){
	window.location = link;
}

function doLinkHighlight(DocID, Highlight)
{
	window.location = "ProcessGuidance.htm?DocID="+DocID+"&Highlight="+Highlight;
}

function selectNodes(strExpr)
{
	//alert("selectNodes : "+strExpr);
	var pgXmlDoc = new ActiveXObject("Msxml2.DOMDocument.3.0");
	pgXmlDoc.async = false;
	pgXmlDoc.resolveExternals = false;
	pgXmlDoc.load("XML\\ProcessGuidance.XML");
				
	pgXmlDoc.setProperty("SelectionNamespaces",    "xmlns:xsl='http://www.w3.org/1999/XSL/Transform'");
	pgXmlDoc.setProperty("SelectionNamespaces",    "xmlns:mstns='http://tempuri.org/XMLSchema.xsd'");
	pgXmlDoc.setProperty("SelectionLanguage", "XPath");
	
	var objXMLDOMNodeList = pgXmlDoc.documentElement.selectNodes(strExpr);
	
	return objXMLDOMNodeList;
}

function getFirstNode(strExpr)
{
	var objXMLDOMNodeList = selectNodes(strExpr);
	
	var firstNode = null;
	
	if (objXMLDOMNodeList.length > 0)
	{
		firstNode = objXMLDOMNodeList.item(0);
	}	
	
	return firstNode;
}

//keeps track of whether the checkbox should be populated or not for saving the roles homepage
function setCheckboxValue(){	
		try
		{
			if (GetCookie("Role") == document.homePageCheckbox.roleValue.value)
			{
				document.homePageCheckbox.setAsHomePage.checked = true;
			}
        }
        catch(e)
        {
        
        }

}

function initOverviewCookie()
{
	if ((GetCookie("OverviewOn") != "TRUE") && (GetCookie("OverviewOn") != "FALSE"))
	{
		SetCookie("OverviewOn", "FALSE");
	}

}

function toggleOverviewOn(xxx)
{
	var currentState = null;
	var doIt = false;
		
	if (xxx.style.display=='none')
	{
		currentState = "closed";
		if (GetCookie("OverviewOn") == "TRUE")
		{
			doIt = true;
		}
	}
	else
	{
		currentState = "opened";
		if (GetCookie("OverviewOn") == "FALSE")
		{
			doIt = true;
		}
	}
	
	if (doIt == true)
	{
		if (confirm("Would you like to lock all Overview sections to the "+ currentState +" state?"))
		{
			if (currentState == "opened")
			{
				SetCookie("OverviewOn", "TRUE");
			}
			else
			{	
				SetCookie("OverviewOn", "FALSE");	
			}
		}
	}
}

//set the role as the home page, or clear it if the box isn't checked.	
function setRoleAsHome(rolename){

    if (GetCookie("Role") == rolename && !document.homePageCheckbox.setAsHomePage.checked)
    {
        clearRoleSetting()
        
    }
    else
    {    
	    SetCookie("Role", rolename);
	}
}

function clearRoleSetting()
{
	SetCookie("Role", "");
}

function SetCookie(sName, sValue)
{
	var date = new Date();
	date.setFullYear(date.getFullYear() + 1);
	document.cookie = sName + "=" + escape(sValue) + "; expires=" + date.toGMTString();
}


function GetCookie(sName)
{ 
	var cookie = document.cookie;
	return FindCookie(cookie, sName);
}

function FindCookie(cookie, sName)
{
	var sNamePos = 0;
	var retString = null;
	
	sNamePos = cookie.indexOf(sName);
	if (sNamePos != -1)
	{
		// Find the '=' after the sNamePos
		var eqPos = cookie.indexOf("=", sNamePos) + 1;
		
		// Find the ';' after the '='
		var endPos = cookie.indexOf(";", eqPos);
		if (endPos != -1)
		{
			retString = cookie.substring(eqPos, endPos);
		}
		else
		{
			retString = cookie.substring(eqPos, cookie.length);
		}
		
		if (retString=="Role")
			return null;
		
		return unescape(retString);
	}
}

function doExpand(xxx){
	if(xxx.style.display=='none'){
		xxx.style.display = '';
		expand.src="images/expando_open.gif"
	}else{
		xxx.style.display = 'none';
		expand.src="images/expando_closed.gif"
	}
}

function doExpandGlossary(xxx){
	if(xxx.style.display=='none'){
		xxx.style.display = '';
	}else{
		xxx.style.display = 'none';
	}
}