function doFooter(){
	document.write('<img src="images/clear.gif" width="1" height="10">')
	document.write('<center><p class=p1a><a href="EULA/_EULA.txt">&copy; 2006 Microsoft Corporation.  All rights reserved.</a></p></center>')
	document.write('<center><p class=p1a>Version 4.1.0 </p></center>')
	document.write('<img src="images/clear.gif" width="1" height="20">')

}

	