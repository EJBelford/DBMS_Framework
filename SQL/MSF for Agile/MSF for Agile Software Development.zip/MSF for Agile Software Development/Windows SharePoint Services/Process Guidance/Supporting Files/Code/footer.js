function doFooter(){

}

	