// Used to load the XSL that shows the glossary.

Main();

function Main()
{

}


function ParseOkay(xmldoc)
{
	if (xmldoc.parseError.errorCode != 0)
	{
		var err = xmldoc.parseError;
		alert("Parsing Error:\n" + err.url + "\n" + err.reason + "On line " + err.line + " at " + err.linepos + "\n" + err.srcText);
		return false;
	}
	else return true;
}


/*
	Params:
	- XmlInput - XML contents
	- Page - not used.  Used to be the PageInfo Page element
	- XslName - XSL used to show data
	- ParamName
	- ParamValues
*/
function PlaceXLS(XmlInput, XslName, DivID)
{

	// TODO: Today Page comes in as an XML node.  Change that to handle the XSL string.

	//alert("PlaceXLS\nParams: \nPage = *"+Page+"*\nXslName = *"+XslName+"*\nDivID = *"+DivID+"*\n");
	
	// Pull information for the primary document space
	var xslt = new ActiveXObject("Msxml2.XSLTemplate.3.0");
	var xslDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.3.0");
	var xslProc;
	xslDoc.async = false;
	xslDoc.resolveExternals = false;
	xslDoc.load(XslName);
	

	// If the parsing was successful, translate and place the output
	if (ParseOkay(xslDoc))
	{
		xslt.stylesheet = xslDoc;
		xslProc = xslt.createProcessor();
		xslProc.input = XmlInput;
	
		// Perform the translation
		xslProc.transform();
		DivID.innerHTML = xslProc.output;
	}
}

function doLink(link){
	if (window.opener && !window.opener.closed)
	{
		window.opener.location = "..\\ProcessGuidance.html?"+link;
	}
}