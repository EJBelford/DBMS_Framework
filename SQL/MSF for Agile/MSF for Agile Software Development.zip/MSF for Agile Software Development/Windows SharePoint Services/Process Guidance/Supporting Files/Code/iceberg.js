// Used to load the XSL that shows the glossary.

Main();

function Main()
{
    if(GetCookie("Role") != null)
    {
        var urlparts = window.location.href.split("/");
        var urlpartslength = urlparts.length - 1;
        var role = GetCookie("Role");
        if(role != "null")
        {
            if(urlparts[urlpartslength] == "ProcessGuidance.htm")
            {
                SetCookie("RequestedPage", null);
            }    
            if(role != urlparts[urlpartslength] && GetCookie("RequestedPage") == "null")
            {
                window.location = role;
            }
        }
    }
}

function forward(str)
{
    if (document.location.href.indexOf("ProcessGuidance.htm") != -1)
        window.location = str;
}

function EvaluateShareSideMenuItems(navRoot, SelectedTab, DocID, ParamNames, ParamValues)
{
	var Xsl3 = null;
	
	//alert("EvaluateShareSideMenuItems");

	// Grab all the 'ShareSideMenuItem' elements under SideMenuItem
	var ShareSMINodes = navRoot.selectNodes("//ShareSideMenuItem");
	
	if (ShareSMINodes != null)
	{
		//alert("ShareSMINodes : "+ShareSMINodes.length);
		for (j = 0; j < ShareSMINodes.length; j++)
		{
			var node = ShareSMINodes.nextNode();

			SelectedTab = getTabName(node,"../../../TabName");
			//alert("SelectedTab : "+SelectedTab);
		
			var SSMIQuery = node.selectSingleNode("Query");
			var SSMIXform = node.selectSingleNode("Xform");
			
			if ((SSMIQuery != null) && (SSMIXform != null))
			{
			
				
				var SSMIQueryText = SSMIQuery.text;
				var SSMIXformText = SSMIXform.text;
				//alert(SSMIXformText);
				
				// Replace $DocID with DocID's value
				SSMIQueryText = SSMIQueryText.replace("$DocID", "'"+DocID+"'");
				//alert("SSMIQueryText : "+SSMIQueryText);
				// Evaluate the Query
				var SSMIQueryResultNodes = selectNodes(SSMIQueryText);
				
				if (SSMIQueryResultNodes != null)
				{
				
					//alert("SSMIQueryResultNodes : "+SSMIQueryResultNodes.length );
					// We should only get 1 result node
					if (SSMIQueryResultNodes.length > 0)
					{
						//alert("SelectedTab : "+SelectedTab);
						//alert("SSMIQueryText : "+SSMIQueryText);
						var QueryResultNodeText = SSMIQueryResultNodes.nextNode().text;
						//alert("Got "+SSMIQueryResultNodes.length+" Node(s) : "+QueryResultNodeText);
						Xsl3 = SSMIXformText;
						
						//alert("Setting XSL3 SSMI : "+SSMIXformText);
						
						// Found the DocID inside the SharedSideMenuItem, let's tell the SideMenu and Tabs
						ParamNames[ParamNames.length] = "WheresDocID";
						ParamValues[ParamValues.length] = "ShareSMI";
						
						ParamNames[ParamNames.length] = "ShareSMILoc";
						ParamValues[ParamValues.length] = j;
						
						// Send the Role into the Xsl3
						ParamNames[ParamNames.length] = "Role";
						ParamValues[ParamValues.length] = QueryResultNodeText;						
					}
				}
				
			}
		
			// Evaluate the query
		}
	}
	
	//if (Xsl3 != null)
	//	alert("Returning Xsl3 = "+Xsl3);
	
	return Xsl3;
}

function getTabName(node, query)
{
	var tabNameObj = null;
	var tabName = null;
	
	tabNameObj = node.selectSingleNode(query);
	
	if (tabNameObj != null)
	{
		//alert("getTabName "+tabNameObj.text);
		tabName = tabNameObj.text;
	}
		else alert("ERROR! getTabName() | Couldn't determine the selected tab name!");
	
	return tabName;
}

function ParseOkay(xmldoc)
{
	if (xmldoc.parseError.errorCode != 0)
	{
		var err = xmldoc.parseError;
		alert("Parsing Error:\n" + err.url + "\n" + err.reason + "On line " + err.line + " at " + err.linepos + "\n" + err.srcText);
		return false;
	}
	else return true;
}


/*
	Params:
	- XmlInput - XML contents
	- Page - not used.  Used to be the PageInfo Page element
	- XslName - XSL used to show data
	- ParamName
	- ParamValues
*/
function PlaceXLS(XmlInput, XslName, DivID, ParamNames, ParamValues)
{
	
	// Pull information for the primary document space
	var xslt = new ActiveXObject("Msxml2.XSLTemplate.3.0");
	var xslDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.3.0");
	var xslProc;
	xslDoc.async = false;
	xslDoc.resolveExternals = false;
	xslDoc.load(XslName);
	

	// If the parsing was successful, translate and place the output
	if (ParseOkay(xslDoc))
	{
		xslt.stylesheet = xslDoc;
		xslProc = xslt.createProcessor();
		xslProc.input = XmlInput;
		
		// Pass the attributes from the URL to the XSL as parameters
		for (i = 0; i < ParamNames.length; i++)
		{
			xslProc.addParameter(ParamNames[i], ParamValues[i]);
		}
		
		// Perform the translation
		xslProc.transform();
		DivID.innerHTML = xslProc.output;
	}
}

function prepare(str)
{
    var i = 0;
    
    while (str.indexOf(" ") != -1)
    {
        str = str.replace(" ", "");
    }
    
    while (str.indexOf(":") != -1)
    {
        str = str.replace(":", "");
    }
    
    return str;
}

function getNumPage(url)
{
	var urlparts = url.split("/");
	var urlpartslength = urlparts.length - 1;
	return urlparts[urlpartslength]
}

function doLink(link){
	
    SetCookie("RequestedPage", getNumPage(window.event.srcElement.href));
	var loc = prepare(link)+".htm";
	window.location = loc;
}

function doLinkExternal(link){
    SetCookie("RequestedPage", getNumPage(window.event.srcElement.href));
	window.location = link;
}

function doLinkHighlight(DocID, Highlight)
{
	var loc = prepare(DocID)+"_"+getNumPage(window.event.srcElement.href);
	SetCookie("RequestedPage", loc);
	window.location = loc;
}

function selectNodes(strExpr)
{
	//alert("selectNodes : "+strExpr);
	var pgXmlDoc = new ActiveXObject("Msxml2.DOMDocument.3.0");
	pgXmlDoc.async = false;
	pgXmlDoc.resolveExternals = false;
	pgXmlDoc.load("XML\\ProcessGuidance.XML");
				
	pgXmlDoc.setProperty("SelectionNamespaces",    "xmlns:xsl='http://www.w3.org/1999/XSL/Transform'");
	pgXmlDoc.setProperty("SelectionNamespaces",    "xmlns:mstns='http://tempuri.org/XMLSchema.xsd'");
	pgXmlDoc.setProperty("SelectionLanguage", "XPath");
	
	var objXMLDOMNodeList = pgXmlDoc.documentElement.selectNodes(strExpr);
	
	return objXMLDOMNodeList;
}

function getFirstNode(strExpr)
{
	var objXMLDOMNodeList = selectNodes(strExpr);
	
	var firstNode = null;
	
	if (objXMLDOMNodeList.length > 0)
	{
		firstNode = objXMLDOMNodeList.item(0);
	}	
	
	return firstNode;
}

//keeps track of whether the checkbox should be populated or not for saving the roles homepage
function setCheckboxValue(){	
		try
		{
			if (GetCookie("Role") == getNumPage(window.location.href))
			{
				document.homePageCheckbox.setAsHomePage.checked = true;
			}
        }
        catch(e)
        {
        
        }
        
        

}

function initOverviewCookie()
{
	if ((GetCookie("OverviewOn") != "TRUE") && (GetCookie("OverviewOn") != "FALSE"))
	{
		SetCookie("OverviewOn", "FALSE");
	}

}

function toggleOverviewOn(xxx)
{
	var currentState = null;
	var doIt = false;
		
	if (xxx.style.display=='none')
	{
		currentState = "closed";
		if (GetCookie("OverviewOn") == "TRUE")
		{
			doIt = true;
		}
	}
	else
	{
		currentState = "opened";
		if (GetCookie("OverviewOn") == "FALSE")
		{
			doIt = true;
		}
	}
	
	if (doIt == true)
	{
		if (confirm("Would you like to lock all Overview sections to the "+ currentState +" state?"))
		{
			if (currentState == "opened")
			{
				SetCookie("OverviewOn", "TRUE");
			}
			else
			{	
				SetCookie("OverviewOn", "FALSE");	
			}
		}
	}
}

//set the role as the home page, or clear it if the box isn't checked.	
function setRoleAsHome(rolename){
    if (GetCookie("Role") == getNumPage(window.location.href) && !document.homePageCheckbox.setAsHomePage.checked)
    {
        SetCookie("Role", null)
        
    }
    else
    {    
	    SetCookie("Role", getNumPage(window.location.href));
	}
}

function SetCookie(sName, sValue)
{
	var date = new Date();
	date.setFullYear(date.getFullYear() + 1);
	document.cookie = sName + "=" + escape(sValue) + "; expires=" + date.toGMTString();
}


function GetCookie(sName)
{ 
	var cookie = document.cookie;
	return FindCookie(cookie, sName);
}

function FindCookie(cookie, sName)
{
	var sNamePos = 0;
	var retString = null;
	
	sNamePos = cookie.indexOf(sName);
	if (sNamePos != -1)
	{
		// Find the '=' after the sNamePos
		var eqPos = cookie.indexOf("=", sNamePos) + 1;
		
		// Find the ';' after the '='
		var endPos = cookie.indexOf(";", eqPos);
		if (endPos != -1)
		{
			retString = cookie.substring(eqPos, endPos);
		}
		else
		{
			retString = cookie.substring(eqPos, cookie.length);
		}
		
		if (retString=="Role")
			return null;
		
		return unescape(retString);
	}
}

function doExpand(xxx){
	if(xxx.style.display=='none'){
		xxx.style.display = '';
		expand.src="images/expando_open.gif"
	}else{
		xxx.style.display = 'none';
		expand.src="images/expando_closed.gif"
	}
}

function doExpandGlossary(xxx){
	if(xxx.style.display=='none'){
		xxx.style.display = '';
	}else{
		xxx.style.display = 'none';
	}
}

function doLinkHFilter(DocID, Highlight, Filter)
{
	window.location = "ProcessGuidance.htm?DocID="+escape(DocID)+"&Highlight="+escape(Highlight)+"&Filter="+escape(Filter);
}

function doLinkFilter(DocID, Filter)
{
	window.location = "ProcessGuidance.htm?DocID="+escape(DocID)+"&Filter="+escape(Filter);
}