To get started, go to the Process Guidance folder and open ProcessGuidance.html. Comments to randymil@microsoft.com.

Known Limitations
1) The project portal link does not bring up the project portal when the process guidance is used in stand alone mode.
2) The "getting started" tasks will not show up in the stand alone version.
3) The mpp and xls work products do not automatically get filled in unless used with the Team Foundation Server.
